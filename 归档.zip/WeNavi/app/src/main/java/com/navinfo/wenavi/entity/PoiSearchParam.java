package com.navinfo.wenavi.entity;

import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;

/**
 * Created by Doone on 2015/3/25.
 */
public class PoiSearchParam {


    private String searchType=null;
    private String keyword=null;
    private String kindName =null;
    private String kindCode =null;
    private int radius=0;
    private GeoPoint currentLocation=null;
    private String region=null;
    private String orderType=null;
    private int pageIndex=1;
    private int pageRows=10;
    private Object tag=null;

    public PoiSearchParam() {
    }

    public PoiSearchParam(String searchType, String keyword, String kindName, int radius, GeoPoint currentLocation, String region, String orderType, int pageIndex, int pageRows) {
        this.searchType = searchType;
        this.keyword = keyword;
        this.kindName = kindName;
        this.radius = radius;
        this.currentLocation = currentLocation;
        this.region = region;
        this.orderType = orderType;
        this.pageIndex = pageIndex;
        this.pageRows = pageRows;
    }

    public void reset()
    {
        this.searchType = null;
        this.keyword = null;
        this.kindName = null;
        this.radius = 0;
        this.currentLocation = null;
        this.region = null;
        this.orderType = null;
        this.pageIndex=1;
        this.pageRows=10;
        this.tag=null;
    }

    public Object getTag() {
        return tag;
    }

    public void setTag(Object tag) {
        this.tag = tag;
    }

    public String getSearchType() {
        return searchType;
    }

    public void setSearchType(String searchType) {
        this.searchType = searchType;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getKindName() {
        return kindName;
    }

    public void setKindName(String kindName) {
        this.kindName = kindName;
    }

    public String getKindCode() {
        return kindCode;
    }

    public void setKindCode(String kindCode) {
        this.kindCode = kindCode;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public GeoPoint getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(GeoPoint currentLocation) {
        this.currentLocation = currentLocation;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public int getPageRows() {
        return pageRows;
    }

    public void setPageRows(int pageRows) {
        this.pageRows = pageRows;
    }
}
