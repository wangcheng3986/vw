package com.navinfo.wenavi.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.navinfo.mirrorlink.MirrorLinkDisplayManager;
import com.navinfo.sdk.mapapi.search.geocode.ReverseGeoCodeResult;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.activity.WeNaviBaseActivity;
import com.navinfo.wenavi.model.WeNaviApplication;

import java.text.NumberFormat;

/**
 * Created by Doone on 2015/2/17.
 */
public class WeNaviUtil {
    private static String[] mMeasures = new String[]{"米", "公里"};
    private static String[] mMeasuretime = new String[]{"小时", "分", "秒"};
    private static final String LOG_TAG = WeNaviUtil.class.getCanonicalName();

    public static String convertMeters(int Meters) {
        String MetersDisplayed = String.valueOf(Meters);
        String measure = mMeasures[0];
        if (Meters >= 1000) {
            NumberFormat nFormat = NumberFormat.getInstance();
            nFormat.setMaximumFractionDigits(1);
            MetersDisplayed = nFormat.format(Meters / 1000.0);
            measure = mMeasures[1];
        }
        return MetersDisplayed + measure;
    }

    public static String convertMetersKM(int Meters) {
        String MetersDisplayed = String.valueOf(Meters);
        String measure = "m";
        if (Meters >= 1000) {
            NumberFormat nFormat = NumberFormat.getInstance();
            nFormat.setMaximumFractionDigits(1);
            MetersDisplayed = nFormat.format(Meters / 1000.0);
            measure = "km";
        }
        return MetersDisplayed + measure;
    }


    public static String convertTime(int t) {
        String hour = mMeasuretime[0];
        String min = mMeasuretime[1];
        String second = mMeasuretime[2];
        NumberFormat nFormat = NumberFormat.getInstance();
        String resultH = "";
        String resultM = "";
        String resultS = "";
        int total = t;
        if (total >= 3600) {
            int h = total / 3600;
            resultH = nFormat.format(h) + hour;
            total = total - h * 3600;
        }
        if (total >= 60) {
            int m = total / 60;
            resultM = nFormat.format(m) + min;
            total = total - m * 60;
        }
        if (total > 0) {
            resultS = nFormat.format(total) + second;
        }
        return resultH + resultM + resultS;
    }


    public static double[] convertGeo(String value) {
        double[] a = new double[2];

        int a1 = value.indexOf("(");
        int a2 = value.indexOf(" ");
        int a3 = value.indexOf(")");
        Log.e("WeNaviUtil", "value=" + value);

        try {
            a[0] = Double.parseDouble(value.substring(a1 + 1, a2 + 1));
            a[1] = Double.parseDouble(value.substring(a2 + 1, a3));
            Log.e("WeNaviUtil", "a[0]=" + a[0]);
            Log.e("WeNaviUtil", "a[1]=" + a[1]);

        } catch (NumberFormatException e) {
            Log.d("WeNaviUtil", "NumberFormatException");
            e.printStackTrace();
        }


        return a;
    }


    /**
     * 将px值转换为dip或dp值，保证尺寸大小不变
     *
     * @param context
     * @param pxValue （DisplayMetrics类中属性density）
     * @return
     */
    public static int px2dip(Context context, float pxValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (pxValue / scale + 0.5f);
    }

    /**
     * 将dip或dp值转换为px值，保证尺寸大小不变
     *
     * @param context
     * @param dipValue （DisplayMetrics类中属性density）
     * @return
     */
    public static int dip2px(Context context, float dipValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dipValue * scale + 0.5f);
    }

    /**
     * 将px值转换为sp值，保证文字大小不变
     *
     * @param context
     * @param pxValue （DisplayMetrics类中属性scaledDensity）
     * @return
     */
    public static int px2sp(Context context, float pxValue) {
        final float fontScale = context.getResources().getDisplayMetrics().scaledDensity;
        return (int) (pxValue / fontScale + 0.5f);
    }

    /**
     * 将sp值转换为px值，保证文字大小不变
     *
     * @param context
     * @param spValue （DisplayMetrics类中属性scaledDensity）
     * @return
     */
    public static int sp2px(Context context, float spValue) {
        final float fontScale = context.getResources().getDisplayMetrics().scaledDensity;
        return (int) (spValue * fontScale + 0.5f);
    }


    public static void updateUiTextSize(WeNaviBaseActivity context, ViewGroup v) {
        return;
        /*if (v != null) {
            final ViewGroup root = (ViewGroup) v;//.findViewById(getFragmentLayoutID());
            if (root != null) {
                setFontSize(context, root, 16);
                //resizeControl(root,getWidthFactor(),getHeightFactor());
            }
        }*/

    }


    public static Point getReferenceScreen(WeNaviBaseActivity context) {
        Point s = new Point(2560, 1440);

        //如果连接了车机，则以车机分辨率确定最小文字尺寸为基准，其余分辨率以此为基准按比例计算文字大小
        if (context.isMirrorLinkSessionEstablished()) s = new Point(800, 450);

        return s;
    }

    public static float getNewTextSize(WeNaviBaseActivity context, TextView v) {

        //float f=v.getTextSize();
        // Log.e(LOG_TAG, "TextSize="+f);
        //return  f;

        DisplayMetrics metric = new DisplayMetrics();
        context.getWindowManager().getDefaultDisplay().getMetrics(metric);

        float oldSize = 0;
        if (v.getTag(R.id.tag_textspsize) != null) oldSize = (float) v.getTag(R.id.tag_textspsize);
        else oldSize = WeNaviUtil.px2sp(context, v.getTextSize());

        float nMinSp = 16;
        if (oldSize < nMinSp) oldSize = nMinSp;
        if (v.getTag(R.id.tag_textspsize) == null) v.setTag(R.id.tag_textspsize, oldSize);

        //缺省文字参照尺寸为2560分辨率下定义为70像素，其余分辨率以此为基准按比例计算文字大小
        int nMinTextPixiel = 64;
        float fOriginalWidth = 2560;

        //如果连接了车机，则以车机分辨率确定最小文字尺寸为基准，其余分辨率以此为基准按比例计算文字大小
        if (context.isMirrorLinkSessionEstablished()) {
            //推荐使用的主要文字高度应大于4.1 mm，约为23个像素高
            nMinTextPixiel = 25;//23;
            fOriginalWidth = 800;
            MirrorLinkDisplayManager m = (MirrorLinkDisplayManager)
                    context.getMirrorLinkManager(MirrorLinkDisplayManager.class.getCanonicalName());
            if (m != null) {
                int w = m.getClientPixelWidth();
                //MirrorLink 参考客户端显示屏被定义为800 x 480
                if (w > 800) {
                    //int h=m.getClientPixelHeight();
                    nMinTextPixiel = (int) (nMinTextPixiel * w / fOriginalWidth);
                    fOriginalWidth = w;
                }
            }
        }

        float nOriginalTextPixiel = oldSize / nMinSp * nMinTextPixiel;
        //按照比例计算当前设备分辨率下文字应该使用的大小
        float pixels = nOriginalTextPixiel * ((float) metric.widthPixels) / fOriginalWidth;
        float nSp = WeNaviUtil.px2sp(context, pixels);
        Log.d(LOG_TAG, "oldSize=" + oldSize + " pixels=" + pixels + " fOriginalWidth=" + fOriginalWidth +
                " widthPixels=" + metric.widthPixels + " nSp=" + nSp);
        return nSp;  //pixelToDp(metric,pixels);*/
    }


    private static void setFontSize(WeNaviBaseActivity context, ViewGroup group, int textSize) {
        int count = group.getChildCount();
        View v;
        for (int i = 0; i < count; i++) {
            v = group.getChildAt(i);
            if (v instanceof TextView || v instanceof EditText || v instanceof Button) {
                //((TextView)v).getTextSize()
                ((TextView) v).setTextSize(TypedValue.COMPLEX_UNIT_SP, getNewTextSize(context, (TextView) v));
            } else if (v instanceof ViewGroup)
                setFontSize(context, (ViewGroup) v, textSize);
        }
    }


    public static float getWidthFactor(WeNaviBaseActivity context) {
        DisplayMetrics metric = new DisplayMetrics();
        context.getWindowManager().getDefaultDisplay().getMetrics(metric);

        Point s = getReferenceScreen(context);
        float fOrginalWidth = s.x * 1.0f;
        float f = ((float) metric.widthPixels) / fOrginalWidth;
        return f;
    }


    public static float getHeightFactor(WeNaviBaseActivity context) {
        DisplayMetrics metric = new DisplayMetrics();
        context.getWindowManager().getDefaultDisplay().getMetrics(metric);

        Point s = getReferenceScreen(context);
        float fOrginalHeight = s.y * 1.0f;
        float f = ((float) metric.heightPixels) / fOrginalHeight;
        return f;
    }


    public static int getDefaultTextSize(WeNaviBaseActivity context) {
        DisplayMetrics metric = new DisplayMetrics();
        context.getWindowManager().getDefaultDisplay().getMetrics(metric);

        //缺省文字参照尺寸为2560分辨率下定义为70像素，其余分辨率以此为基准按比例计算文字大小
        int nTextPixiel = 70;
        float fOrginalWidth = 2560;

        //如果连接了车机，则以车机分辨率确定最小文字尺寸为基准，其余分辨率以此为基准按比例计算文字大小
        if (context.isMirrorLinkSessionEstablished()) {
            //推荐使用的主要文字高度应大于4.1 mm，约为23个像素高
            nTextPixiel = 25;//23;
            fOrginalWidth = 800;
            MirrorLinkDisplayManager m = (MirrorLinkDisplayManager)
                    context.getMirrorLinkManager(MirrorLinkDisplayManager.class.getCanonicalName());
            if (m != null) {
                int w = m.getClientPixelWidth();
                //MirrorLink 参考客户端显示屏被定义为800 x 480
                if (w > 800) {
                    //int h=m.getClientPixelHeight();
                    nTextPixiel = (int) (nTextPixiel * w / fOrginalWidth);
                    fOrginalWidth = w;
                }
            }
        }

        //按照比例计算当前设备分辨率下文字应该使用的大小
        int pixels = (int) (nTextPixiel * ((float) metric.widthPixels) / fOrginalWidth);
        return WeNaviUtil.px2sp(context, pixels);


    }
    public static Bitmap drawableToBitmap(Drawable drawable) // drawable 转换成bitmap
    {
        int width = drawable.getIntrinsicWidth();   // 取drawable的长宽
        int height = drawable.getIntrinsicHeight();
        Bitmap.Config config = drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888:Bitmap.Config.RGB_565;         //取drawable的颜色格式
        Bitmap bitmap = Bitmap.createBitmap(width, height, config);     // 建立对应bitmap
        Canvas canvas = new Canvas(bitmap);         // 建立对应bitmap的画布
        drawable.setBounds(0, 0, width, height);
        drawable.draw(canvas);      // 把drawable内容画到画布中
        return bitmap;
    }

    public static Drawable zoomDrawable(Drawable drawable, int w, int h)
    {
        int width = drawable.getIntrinsicWidth();
        int height= drawable.getIntrinsicHeight();
        Bitmap oldbmp = drawableToBitmap(drawable); // drawable转换成bitmap
        Matrix matrix = new Matrix();   // 创建操作图片用的Matrix对象
        float scaleWidth = ((float)w / width);   // 计算缩放比例
        float scaleHeight = ((float)h / height);
        matrix.postScale(scaleWidth, scaleHeight);         // 设置缩放比例
        Bitmap newbmp = Bitmap.createBitmap(oldbmp, 0, 0, width, height, matrix, true);       // 建立新的bitmap，其内容是对原bitmap的缩放后的图
        return new BitmapDrawable(newbmp);       // 把bitmap转换成drawable并返回
    }



    public static String toLocationString (ReverseGeoCodeResult result) {
        if(result==null) return null;


        boolean bGet=false;
        try {

            //获取逆地理编码状态码
            if(result.status != 0){

                // play("没有符合条件的兴趣点");
                // updateView(RET_ERROR, "没有符合条件的兴趣点");
                return null;
            }


            StringBuilder t=new StringBuilder();

            if(result.adminregion!=null)
            {
                /*if(result.adminregion.provname!=null)
                {
                    if(result.adminregion.provname.indexOf("北京")==-1 &&
                            result.adminregion.provname.indexOf("上海")==-1 &&
                            result.adminregion.provname.indexOf("天津")==-1 &&
                            result.adminregion.provname.indexOf("重庆")==0 )

                        b.append(result.adminregion.provname);
                }*/
                if(result.adminregion.cityname!=null)
                {
                    //b.append(result.adminregion.cityname);
                    t.append(result.adminregion.cityname);
                }
                if(result.adminregion.distname!=null)
                {
                    //b.append(result.adminregion.distname);
                    t.append(result.adminregion.distname);
                }
            }


            if (result.land!=null && result.land.name != null) {

                t.append(",").append(result.land.name).append("附近");
                bGet = true;
            }



            if(!bGet)
            {
                if(result.address!=null) t.append(",").append(result.address).append("附近");
                else if(result.shortdescription!=null) t.append(",").append(result.address);
            }

            if(t.length()>0) return t.toString();



        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return null;

    }

}
