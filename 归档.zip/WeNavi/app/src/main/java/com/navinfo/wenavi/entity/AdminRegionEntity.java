package com.navinfo.wenavi.entity;

/**
 * Created by liubao on 15/3/14.
 * 政区实体类
 */
public class AdminRegionEntity {

    private String proadcode;
    private String proadname;
    private String citycode;
    private String cityname;
    private String code;
    private String name;

    /**
     * 实例化一个政区实体对象
     */
    public AdminRegionEntity() {

    }

    /**
     * 实例化一个政区实体对象
     * @param proadcode 省编码
     * @param proadname 省名称
     * @param citycode 城市编码
     * @param cityname 城市名称
     * @param code 编码
     * @param name 名称
     */
    public AdminRegionEntity(String proadcode, String proadname, String citycode, String cityname, String code, String name) {
        this.proadcode = proadcode;
        this.proadname =  proadname;
        this.citycode = citycode;
        this.cityname = cityname;
        this.code = code;
        this.name = name;
    }

    /**
     * 获取省编码
     * @return 省编码
     */
    public String getProadCode() {
        return proadcode;
    }

    /**
     * 设置省编码
     * @param proadcode 省编码
     */
    public void setProadCode(String proadcode) {
        this.proadcode = proadcode;
    }

    /**
     * 获取省名称
     * @return 省名称
     */
    public String getProadName() {
        return proadname;
    }

    /**
     * 设置省名称
     * @param proadname 省名称
     */
    public void setProadName(String proadname) {
        this.proadname = proadname;
    }

    /**
     * 获取城市编码
     * @return 城市编码
     */
    public String getCityCode() {
        return citycode;
    }

    /**
     * 设置城市编码
     * @param citycode 城市编码
     */
    public void setCityCode(String citycode) {
        this.citycode = citycode;
    }

    /**
     * 获取城市名称
     * @return 城市名称
     */
    public String getCityName() {
        return cityname;
    }

    /**
     * 设置城市名称
     * @param cityname 城市名称
     */
    public void setCityName(String cityname) {
        this.cityname = cityname;
    }

    /**
     * 获取编码
     * @return 编码
     */
    public String getCode() {
        return code;
    }

    /**
     * 设置编码
     * @param code 编码
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * 获取名称
     * @return 名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置名称
     * @param name 名称
     */
    public void setName(String name) {
        this.name = name;
    }
}
