package com.navinfo.wenavi.controller;


import android.content.Context;
import android.util.Log;

import com.navinfo.audio.AudioRecongniseError;
import com.navinfo.audio.AudioRecongniseStatus;
import com.navinfo.audio.IAudioRecongniseListener;
import com.navinfo.sdk.mapapi.map.LocationData;
import com.navinfo.sdk.mapapi.search.core.POISearchOrderBy;
import com.navinfo.sdk.mapapi.search.core.POISearchSortType;
import com.navinfo.sdk.mapapi.search.geocode.GeoCodeOption;
import com.navinfo.sdk.mapapi.search.geocode.GeoCodeResult;
import com.navinfo.sdk.mapapi.search.geocode.GeoCoder;
import com.navinfo.sdk.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.navinfo.sdk.mapapi.search.geocode.ReverseGeoCodeOption;
import com.navinfo.sdk.mapapi.search.geocode.ReverseGeoCodeResult;
import com.navinfo.sdk.mapapi.search.poi.OnGetPOISearchResultListener;
import com.navinfo.sdk.mapapi.search.poi.POIAdvancedSearchOption;
import com.navinfo.sdk.mapapi.search.poi.POINearbySearchOption;
import com.navinfo.sdk.mapapi.search.poi.POISearchResult;
import com.navinfo.sdk.mapapi.search.poi.POISearcher;
import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;

import com.navinfo.wenavi.entity.PoiSearchParam;
import com.navinfo.wenavi.util.WeNaviDefine;

import java.util.HashMap;

/**
 * Created by Doone on 2015/2/3.
 * 地图控制器，提供地图操作，地理编码，逆地理编码，POI查询，定位控制等业务功能
 *
 * 使用示例:
 *
 * Activity (IView)获取地图并加载到UI中:
 *
 *  mMapView = (MapView) getController().getObject(MapView.class.getCanonicalName());
 *   if(mMapView!=null) {
 *    FrameLayout l = (FrameLayout) findViewById(R.id.mapframe);
 *     if (mMapView.getParent() != null) {
 *      FrameLayout v = (FrameLayout) mMapView.getParent();
 *       v.removeAllViews();
 *     }
 *      l.addView(mMapView);
 *    }
 *
 *
 *
 *  IView发起逆地理编码查询:
 *  IView.getController().executeAction(CMD_GET_REVERSEGEOCODE,new GeoPoint(1,2));
 *
 *
 *  IView处理逆地理编码结果:
 *  IView void updateView(Object ... datas)
 * {
 *      if(datas.length>0) {
 *         if (datas[0].getClass().getCanonicalName() == String.class.getCanonicalName()) {
 *          String sCms = (String) (datas[0]);
 *          if(sCms== GisController.RET_REVERSEGEOCODE) { //逆地理编码结果
 *           if(datas.length>2 &&
 *            datas[1].getClass().getCanonicalName() == String.class.getCanonicalName() &&
 *             datas[2].getClass().getCanonicalName() == String.class.getCanonicalName())
 *           {
 *              //获取城市名称
 *              String sCity=(String)datas[1];
 *
 *              //获取位置描述
 *              String sPos=(String)datas[2];
 *
 *              //后续逻辑
 *              //...
 *           }
 *         }
 *      }
 * }
 *
 *
 *
 *
 *
 */
public class GisController  extends AudioController implements
        OnGetGeoCoderResultListener,
        OnGetPOISearchResultListener
{

    private final static String LOG_TAG = GisController.class.getCanonicalName();


    /**
     * 功能代码: 逆地理编码查询，需提供GeoPoint
     */
    public static final String CMD_GET_REVERSEGEOCODE="CMD_GET_REVERSEGEOCODE";


    /**
     * 功能代码: 地理编码查询, 需提供地址描述 String
     */
    public static final String CMD_GET_GEOCODE="CMD_GET_GEOCODE";

    /**
     * 功能代码: 语音识别地理编码查询
     */
    public static final String CMD_AUDIO_GEOCODE="CMD_AUDIO_GEOCODE";

    /**
     * 功能代码: 周边POI查询
     */
    public static final String CMD_SEARCH_POI="CMD_SEARCH_POI";

    /**
     * 功能代码: 关键字POI查询, 需提供关键字 String
     */
    public static final String CMD_GET_KEY_POI="CMD_GET_KEY_POI";

    /**
     * 功能代码: 语音识别关键字POI查询
     */
    public static final String CMD_GET_AUDIO_POI="CMD_GET_AUDIO_POI";




    /**
     * 视图刷新代码: POI查询结果， 附带 POISearchResult 对象
     */
    public static final String RET_POI="RET_POI";


    /**
     * 视图刷新代码: 地理编码查询结果， 附带 GeoCodeResult 对象
     */
    public static final String RET_GEOCODE="RET_GEOCODE";

    /**
     * 视图刷新代码: 逆地理编码查询结果， 附带 City, Pos String对象
     */
    public static final String RET_REVERSEGEOCODE="RET_REVERSEGEOCODE";




    protected GeoCoder mSearch = null;
    protected POISearcher mPoiSearch = null;




    private ReverseGeoCodeResult mCurrentReverseGeoCodeResult=null;


    private int mPoiResponseCount=0;


    private HashMap<Integer,String> mPoiSearchError=null;


    public GisController(Context context)
    {
        super(context);


        setAudioReconiserType(HCI_POI_RECONGNISER);


        // 初始化搜索模块，注册事件监听
        mSearch = GeoCoder.newInstance();


        // 初始化POI搜索模块，注册事件监听
        mPoiSearch = POISearcher.newInstance();

        mPoiSearchError=new HashMap<Integer,String>();
        mPoiSearchError.put(-1,"地点不存在");
        mPoiSearchError.put(0,"当前行政区无此地名");
        mPoiSearchError.put(501,"访问合法性验证错误");
        mPoiSearchError.put(502,"访问权限验证失败");
        mPoiSearchError.put(503,"访问参数错误");
        mPoiSearchError.put(504,"地图API出现异常");
        mPoiSearchError.put(600,"访问失败,网络连接失效");
        mPoiSearchError.put(601,"访问失败,客户端错误");
        mPoiSearchError.put(602,"访问失败,服务应答异常");
        mPoiSearchError.put(700,"访问失败,服务应答超时");
        mPoiSearchError.put(701,"访问失败,数据接收超时");
        mPoiSearchError.put(702,"访问失败,数据接收不完整");



        //查询状态代码
        // 0 正常，查询未发生任何错误，返回0个或多个匹配结果obj
        // -1 无匹配结果
        // 501 访问合法性验证错误
        // 502 权限验证错误
        // 503 参数格式错误
        // 504 地图API出现异常
        // 600 连接失败
        // 601 客户端错误
        // 602 http服务器非正常应答
        // 700 应答超时
        // 701 数据接收超时
        // 702 下载的数据长度与服务器返回长度不等

    }


    String getPoiSearchError(int errorCode)
    {
        if(mPoiSearchError.containsKey(errorCode))
            return "["+errorCode+"]"+mPoiSearchError.get(errorCode);
        return "["+errorCode+"]访问失败,未知错误";
    }




    @Override
    public Object getObject(String sName) {

        return super.getObject(sName);
    }

    @Override
    public void onViewPause() {
        super.onViewPause();


    }

    @Override
    public void onViewResume() {
        super.onViewResume();

        mSearch.setOnGetGeoCodeResultListener(this);
        mPoiSearch.setOnGetPOISearchResultListener(this);
    }


    @Override
    public void onViewBack() {
        super.onViewBack();


    }

    @Override
    public void destroy() {
        if(mSearch!=null) mSearch.destroy();
        if(mPoiSearch!=null) mPoiSearch.destroy();



        super.destroy();
    }

    @Override
    public void executeAction(Object... actionDatas) {
        if(actionDatas.length>0)
        {
            if(actionDatas[0].getClass().equals(String.class))
            {
                String sCms=(String)(actionDatas[0]);

                if(sCms.equals(CMD_GET_REVERSEGEOCODE))
                {
                    if(actionDatas.length>1 &&
                            actionDatas[1].getClass().equals(GeoPoint.class) ) {
                        getReverseGeoCode((GeoPoint)actionDatas[1]);
                    }

                }
                else if(sCms.equals(CMD_GET_GEOCODE))
                {
                    if(actionDatas.length>1 &&
                            actionDatas[1].getClass().equals(String.class) ) {
                        getGeoCode((String)actionDatas[1]);
                    }
                }
                else if(sCms.equals(CMD_AUDIO_GEOCODE)) getGeoCodeByAudio();

                else if(sCms.equals(CMD_SEARCH_POI))
                {
                    if(actionDatas.length>1 &&
                            actionDatas[1].getClass().equals(PoiSearchParam.class) ) {
                        getPoi((PoiSearchParam) actionDatas[1]);
                    }
                }
                else if(sCms.equals(CMD_GET_AUDIO_POI)) {
                    if(actionDatas.length>1 &&
                            actionDatas[1].getClass().equals(GeoPoint.class) ) {
                        getPoibyAudio((GeoPoint) actionDatas[1]);
                    }

                }

                else super.executeAction(actionDatas);

            }
        }
    }




    public void getGeoCode(String sDesp)
    {
        //mMapView.getController()
        String sCity="";
        if(mCurrentReverseGeoCodeResult!=null)
        {
            if(mCurrentReverseGeoCodeResult.adminregion.citycode!=null)
                sCity=mCurrentReverseGeoCodeResult.adminregion.citycode;
            else if(mCurrentReverseGeoCodeResult.adminregion.provcode!=null)
                sCity=mCurrentReverseGeoCodeResult.adminregion.provcode;
        }
        boolean success = mSearch.geoCode(new GeoCodeOption().city(sCity).addr(sDesp));//new GeoCodeOption().city("110000").addr(sDesp));
        if(!success)
        {
            //提示请求失败
        }

    }


    public void getGeoCodeByAudio()
    {
           startRecongnise(new IAudioRecongniseListener() {
            @Override
            public void onRecongnised(String s) {
                Log.d(LOG_TAG,"GetGeoCode for: "+s);
                updateView(RET_RECONGNISE,s);
                getGeoCode(s);
            }

            @Override
            public void onError(AudioRecongniseError audioRecongniseError, int i,String sError) {
                play("语音识别失败,请重试",null);
                //updateView(RET_ERROR, "语音识别失败,请重试");
            }

            @Override
            public void onStatusChanged(AudioRecongniseStatus audioRecongniseStatus) {

            }
        });

    }


    public void getReverseGeoCode(GeoPoint p)
    {
        boolean success = mSearch.reverseGeoCode(new ReverseGeoCodeOption().location(p));
        if(!success)
        {
            //提示请求失败
        }

    }




    public void  getPoi(PoiSearchParam p)
    {

        if(!checkNetWork()) return;
        LocationData loc=(LocationData)getObject(LocationData.class.getCanonicalName());
        if(loc!=null && p.getCurrentLocation()==null)
        {
            p.setCurrentLocation(loc.pt);
        }

        mPoiResponseCount+=1;

        updateView(RET_STARUS,"查询中...");

        if(p.getSearchType()== WeNaviDefine.MSG_SEARCH_POI_BY_KEYWORD) getPoiByKeyword(p);
        else if(p.getSearchType()== WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME) getPoiByKindName(p);
        else if(p.getSearchType()== WeNaviDefine.MSG_SEARCH_POI_BY_KIND_CODE) getPoiByKindCode(p);
    }



    public void getPoi(String sKey, GeoPoint gp) {
//        GeoPoint location = new GeoPoint((int)(39.93864*3.6E6), (int)(116.57848*3.6E6));
        //附近查询
        boolean success = mPoiSearch.searchNearby(new POINearbySearchOption().keyword(sKey)
                .location(gp).radius(100000).pageCapacity(10).pageNum(1).sortType(POISearchSortType.DISTANCE)
                .orderBy(POISearchOrderBy.ASC));

        if (!success) {
            //提示请求失败
        }
    }


    public void getPoi(String sKey, GeoPoint gp,int pageRows,int pageIndex) {
//        GeoPoint location = new GeoPoint((int)(39.93864*3.6E6), (int)(116.57848*3.6E6));
        //附近查询
        boolean success = mPoiSearch.searchNearby(new POINearbySearchOption().keyword(sKey)
                .location(gp).radius(100000).pageCapacity(pageRows).pageNum(pageIndex).sortType(POISearchSortType.DISTANCE)
                .orderBy(POISearchOrderBy.ASC));

        if (!success) {
            //提示请求失败
        }
    }



    public void getPoiByKeyword(PoiSearchParam p){ //String sKey, GeoPoint gp, int scope, int pageRows, int pageIndex,String sCity) {

        POIAdvancedSearchOption pm=new POIAdvancedSearchOption();
        pm.pageCapacity(p.getPageRows()).pageNum(p.getPageIndex()).sortType(POISearchSortType.COMPREHENSIVE)
                .orderBy(POISearchOrderBy.ASC);
        if(p.getCurrentLocation()!=null) {
            pm.param("area", "POINT(" + Double.toString(p.getCurrentLocation().getLongitudeE6() / 3.6E6) + " "
                    + Double.toString(p.getCurrentLocation().getLatitudeE6() / 3.6E6) + ")");
        }

        pm.param("radius",Integer.toString(p.getRadius()));
        if(p.getRadius()>0)
        {

            pm.sortType(POISearchSortType.DISTANCE);
        }
        pm.param("keyword",p.getKeyword());
        if(p.getRegion()!=null ) pm.param("city", p.getRegion());



        boolean success = mPoiSearch.searchAdvanced(pm);

        if (!success) {
            //提示请求失败
        }
    }


    public void getPoiByKindName(PoiSearchParam p) {//String sKey, GeoPoint gp, int scope, int pageRows, int pageIndex,String sCity) {
//        GeoPoint location = new GeoPoint((int)(39.93864*3.6E6), (int)(116.57848*3.6E6));
        //附近查询

        //boolean success = mPoiSearch.searchNearby(new POINearbySearchOption().keyword(sKey)
        //        .location(gp).radius(scope).pageCapacity(pageRows).pageNum(pageIndex).sortType(POISearchSortType.DISTANCE)
        //        .orderBy(POISearchOrderBy.ASC));

        POIAdvancedSearchOption pm = new POIAdvancedSearchOption();
        pm.pageCapacity(p.getPageRows()).pageNum(p.getPageIndex()).sortType(POISearchSortType.DISTANCE)
                .orderBy(POISearchOrderBy.ASC);
        if(p.getCurrentLocation()!=null) {
            pm.param("area", "POINT(" + Double.toString(p.getCurrentLocation().getLongitudeE6() / 3.6E6) + " "
                    + Double.toString(p.getCurrentLocation().getLatitudeE6() / 3.6E6) + ")");
        }

        pm.param("radius", Integer.toString(p.getRadius()));
        pm.param("kindname", p.getKindName());
        if (p.getRegion() != null) pm.param("city", p.getRegion());

        boolean success = mPoiSearch.searchAdvanced(pm);

        if (!success) {
            //提示请求失败
        }
    }

    public void getPoiByKindCode(PoiSearchParam p) {//String sKey, GeoPoint gp, int scope, int pageRows, int pageIndex,String sCity) {
//        GeoPoint location = new GeoPoint((int)(39.93864*3.6E6), (int)(116.57848*3.6E6));
        //附近查询

        //boolean success = mPoiSearch.searchNearby(new POINearbySearchOption().keyword(sKey)
        //        .location(gp).radius(scope).pageCapacity(pageRows).pageNum(pageIndex).sortType(POISearchSortType.DISTANCE)
        //        .orderBy(POISearchOrderBy.ASC));

        POIAdvancedSearchOption pm = new POIAdvancedSearchOption();
        pm.pageCapacity(p.getPageRows()).pageNum(p.getPageIndex()).sortType(POISearchSortType.DISTANCE)
                .orderBy(POISearchOrderBy.ASC);
        if(p.getCurrentLocation()!=null) {
            pm.param("area", "POINT(" + Double.toString(p.getCurrentLocation().getLongitudeE6() / 3.6E6) + " "
                    + Double.toString(p.getCurrentLocation().getLatitudeE6() / 3.6E6) + ")");
        }

        pm.param("radius", Integer.toString(p.getRadius()));
        pm.param("kind", p.getKindCode());
        if (p.getRegion() != null) pm.param("city", p.getRegion());

        boolean success = mPoiSearch.searchAdvanced(pm);

        if (!success) {
            //提示请求失败
        }
    }


    public void getPoiAdvance()
    {
        //kind:7880 公共厕所
        //city:110000 北京
        boolean success = mPoiSearch.searchAdvanced(new POIAdvancedSearchOption().param("city", "110000")
                .param("kind", "7880").pageCapacity(10).pageNum(1).sortType(POISearchSortType.DISTANCE)
                .orderBy(POISearchOrderBy.ASC));
        if(!success)
        {
            //提示请求失败
        }
    }


    public void getPoibyAudio(final GeoPoint gp) {
        startRecongnise(new IAudioRecongniseListener() {
            @Override
            public void onRecongnised(String s) {
                Log.d(LOG_TAG, "GetPoi for: " + s);
                if (s.length() > 0) {
                    updateView(RET_RECONGNISE, s);
                    getPoi(s, gp);
                }
            }

            @Override
            public void onError(AudioRecongniseError audioRecongniseError, int i,String sError) {
                play("语音识别失败,请重试", null);
                updateView(RET_ERROR, "语音识别失败,请重试");
            }

            @Override
            public void onStatusChanged(AudioRecongniseStatus audioRecongniseStatus) {

            }
        });

    }






    @Override
    public void onGetReverseGeoCodeResult(ReverseGeoCodeResult result) {
        if(result==null) return;

        //显示结果
        String sCity="";
        String sLoc="";

        //boolean bGet=false;
        try {

            //获取逆地理编码状态码
            if(result.status != 0){

                // play("没有符合条件的兴趣点");
                // updateView(RET_ERROR, "没有符合条件的兴趣点");
                return;
            }

            StringBuilder b=new StringBuilder();
            //StringBuilder t=new StringBuilder();
            //b.append("  点击选择城市\r\n  " );
            if(result.adminregion!=null)
            {
                if(result.adminregion.provname!=null)
                {
                    if(result.adminregion.provname.indexOf("北京")==-1 &&
                       result.adminregion.provname.indexOf("上海")==-1 &&
                        result.adminregion.provname.indexOf("天津")==-1 &&
                        result.adminregion.provname.indexOf("重庆")==-1 )

                    b.append(result.adminregion.provname);
                }
                if(result.adminregion.cityname!=null)
                {
                    b.append(result.adminregion.cityname);
                    //t.append(result.adminregion.cityname);
                }
                if(result.adminregion.distname!=null)
                {
                    if(b.indexOf(result.adminregion.distname)==-1)
                    b.append(result.adminregion.distname);
                    //t.append(result.adminregion.distname);
                }
            }

            sCity=b.toString();

            StringBuilder l=new StringBuilder();
            //l.append("  ");
            if (result.land!=null && result.land.distance >= 100) {
                if(result.road!=null &&  result.road.name!=null) l.append(result.road.name);
                if(result.land!=null) {
                    if (result.land.name != null)
                    {
                        l.append(result.land.name);
                        //t.append(",").append(result.land.name).append("附近");
                        //bGet=true;
                    }
                    //l.append("\r\n  ");
                    if (result.land.direction != null) l.append(result.land.direction);
                    if (result.land.distance>0) l.append( String.format("%.0f米附近",result.land.distance));
                }

            }
            else if(result.land!=null) {
                if(result.road!=null &&  result.road.name!=null)
                {
                    l.append(result.road.name);
                    //t.append(",").append(result.land.name).append("附近");
                    //bGet=true;
                }
                if (result.land.name != null) l.append(result.land.name);
                l.append("附近");
            }




            sLoc = l.toString();

            mCurrentReverseGeoCodeResult=result;

            updateView(RET_REVERSEGEOCODE,sCity,sLoc,result);


        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        //mMessageBox.setText(sMsg);
        //updateMsg(sCity,sLoc);

    }

    @Override
    public void onGetGeoCodeResult(GeoCodeResult result) {
        if(result==null) return;
        if(result.status != 0){
            String sMsg="地址匹配失败";

            play(sMsg,null);
            updateView(RET_ERROR, sMsg);
            Log.e(LOG_TAG,"GetGeoCodeResult status error: "+result.status);
            return;
        }
        else
            updateView(RET_GEOCODE,result);


    }



    @Override
    public void onGetPOISearchResult(POISearchResult result) {

        mPoiResponseCount-=1;
        if(result==null) return;
        if(result.status !=0 || result.pois == null || result.pois.size()==0){


            String sMsg=null;
            Log.e(LOG_TAG,"GetPOISearchResult status error: "+result.status);
            //play(sMsg,null);
            sMsg=getPoiSearchError(result.status);
            if(mPoiResponseCount==0)  updateView(RET_ERROR, sMsg);
            return;
        }
        else {

            if(mPoiResponseCount==0) updateView(RET_POI, result);
        }
    }



}
