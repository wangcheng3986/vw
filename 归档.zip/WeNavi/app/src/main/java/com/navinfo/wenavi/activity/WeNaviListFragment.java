package com.navinfo.wenavi.activity;

import android.app.Activity;
import android.app.ListFragment;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mirrorlink.android.commonapi.Defs;
import com.navinfo.mirrorlink.IMirrorLinkManager;
import com.navinfo.mirrorlink.MirrorLinkBaseActivity;
import com.navinfo.mirrorlink.MirrorLinkEvent;
import com.navinfo.wenavi.controller.AudioController;
import com.navinfo.wenavi.controller.BaseController;
import com.navinfo.wenavi.controller.IController;
import com.navinfo.wenavi.model.IMessage;
import com.navinfo.wenavi.model.IMessageCenter;
import com.navinfo.wenavi.model.WeNaviApplication;
import com.navinfo.wenavi.util.WeNaviUtil;

/**
 * Created by Doone on 2015/3/26.
 */
public abstract  class WeNaviListFragment extends ListFragment implements  IView{

    private static final String LOG_TAG=WeNaviBaseFragment.class.getCanonicalName();


    private IController mController = null;

    private IViewManager mViewManager=null;


    private Class<?> mRootPageClass=null;

    private Object parameters=null;

    private WeNaviAlertDialog dlgPop=null;


    ///////////////////////////////////////


    @Override
    public Object getParameters() {
        return parameters;
    }

    @Override
    public void setParameters(Object parameters) {
        this.parameters = parameters;
    }


    @Override
    public void setViewManager(IViewManager m) {
        mViewManager=m;
    }

    @Override
    public IViewManager getViewManager() {
        return mViewManager;
    }


    @Override
    public String getViewTag() {
        return this.getClass().getCanonicalName();
    }


    public void setRootPage(Class<?> r)
    {
        mRootPageClass=r;
    }


    /**
     * 跳转到新页面
     * @param c 新页面类型
     */
    public void toPage(Class<?> c)
    {
        if(getViewManager()!=null)
            getViewManager().setCurrentPage(c,null,null);
    }

    public void toPage(Class<?> c,Bundle arg)
    {
        if(getViewManager()!=null)
            getViewManager().setCurrentPage(c,arg,null);
    }

    public void toPage(Class<?> c,Object pm)
    {
        if(getViewManager()!=null)
            getViewManager().setCurrentPage(c,null,pm);
    }


    public void toPage(Class<?> c,Bundle arg,Object pm)
    {
        if(getViewManager()!=null)
            getViewManager().setCurrentPage(c,arg,pm);
    }

    /**
     * 跳转到分支的根页面
     *
     */
    public void toRootPage()
    {
        if(getViewManager()!=null)
            getViewManager().toRootPage(null);
    }


    public void toRootPage(Bundle pm)
    {
        if(getViewManager()!=null)
            getViewManager().toRootPage(pm);
    }


    /**
     * 创建分支并跳转到分支页面，分支页面将最终返回本页面
     * @param c 分支页面类型
     *
     */
    public void toBranchPage(Class<?> c)
    {
        if(getViewManager()!=null) getViewManager().toBranchPage(c,null,null);
    }

    public void toBranchPage(Class<?> c,Bundle pm)
    {
        if(getViewManager()!=null) getViewManager().toBranchPage(c,pm,null);
    }


    /**
     *  当UI处于分支中时，该回掉在UI resume时调用
     */
    public void onUiBranch()
    {

    }

    /**
     * 内壁交互消息处理
     * @param m 消息
     */
    protected void onInternalMessage(IMessage m)
    {

    }

    /**
     * 发送内部交互消息
     * @param m 消息
     */
    protected  void sendInternalMessage(IMessage m)
    {
        IController c=getController();
        if(c!=null)
        {
            IMessageCenter center=(IMessageCenter)c.getObject(IMessageCenter.class.getCanonicalName());
            if(center!=null) center.sendMessage(m);
        }
    }

    protected IMessage queryMessage()
    {
        IController c=getController();
        if(c!=null)
        {
            IMessageCenter center=(IMessageCenter)c.getObject(IMessageCenter.class.getCanonicalName());
            if(center!=null)
                return center.queryMessage(this.getClass().getCanonicalName());
        }
        return null;
    }

    protected  void handleMessage()
    {
        IMessage m=queryMessage();
        while(m!=null)
        {
            onInternalMessage(m);
            m=queryMessage();
        }
    }


    ////////控制器方法/////////////////////////////////////////////////////////////////////////////////
    /**
     * 返回需要控制器Contoller类型，Activity在创建时将自动获取该类型控制器
     *
     * @return Controller 类名
     */
    protected String getControllerName() {
        return AudioController.class.getCanonicalName();
    }


    @Override
    public IController getController() {
        //设置视图控制器
        if (mController == null) {
            String sControllerName = getControllerName();
            if (sControllerName != null && sControllerName.length() > 0) {
                IController c = ((WeNaviApplication) getActivity().getApplicationContext()).getController(sControllerName);
                if (c != null) c.attachView(this);
            }
        }
        return mController;
    }

    @Override
    public void setController(IController c) {
        mController = c;
    }


    @Override
    public  void onActionUpdate(Object... datas)
    {
        if(datas.length>0) {
            if (datas[0].getClass().getCanonicalName().equals(String.class.getCanonicalName())) {
                String sCms = (String) (datas[0]);
                if (sCms.equals(BaseController.RET_RESTORE_VIEW_STATUS) && datas.length>1)
                    restoreViewStatus((Bundle)datas[1]);
                else if(sCms.equals(BaseController.RET_STARUS))
                {

                    if(datas.length>1) {
                        final String sMsg = (String) datas[1];
                        /*getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                showPopMessage("状态", sMsg);
                            }
                        });*/
                    }
                }
                else if(sCms.equals(BaseController.RET_ERROR))
                {
                    if(datas.length>1)
                    {
                        final  String sError=(String)datas[1];
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                showInfoamtion("注意",sError,null);

                            }
                        });
                    }
                }

            }
        }

    }


    /**
     * 提交业务功能请求给Controller
     *
     * @param actionDatas 功能参数
     */
    @Override
    public void submitAction(Object... actionDatas) {
        if (mController != null) mController.executeAction(actionDatas);
    }


    /**
     * 恢复视图状态
     * @param status 视图状态信息
     */
    public abstract void restoreViewStatus(Bundle status);

    /**
     * 返回视图状态状态信息供控制器临时保存
     * @return {@Bundle} 视图状态信息
     */
    public abstract Bundle getViewStatus();



    public void doSaveViewStatus()
    {
        Bundle status=getViewStatus();
        if(status!=null) submitAction(BaseController.CMD_SAVE_VIEW_STATUS,status);
    }


    ///////Fragment///////////////////////////////////////////////////////////

    MirrorLinkBaseActivity getMirrorLinkActivity()
    {
        Activity a=getActivity();
        if(a instanceof MirrorLinkBaseActivity)
        {
            return (MirrorLinkBaseActivity)a;
        }

        return null;
    }



    /**
     * 返回Fragment需要加载的布局ID
     * @return 布局ID
     */
    protected abstract int getFragmentLayoutID();


    /**
     * 绑定UI控件,布局加载完成后调用,用于将布局控件绑定到本对象实例成员
     * @param v 加载布局后生成的视图对象
     */
    protected abstract void bindUIControl(View v);

    public void showPopMessage(String sTitle,String sInfo)
    {
        if(dlgPop==null) dlgPop= new WeNaviAlertDialog((WeNaviBaseActivity)this.getActivity());

        if(dlgPop!=null)
            dlgPop.showPopMessage(sTitle,sInfo);
    }


    public void hidePopMessage()
    {
        if(dlgPop!=null) dlgPop.hide();
    }


    public void showInfoamtion(String sTitle,String sInfo,DialogInterface.OnClickListener l)
    {
        hidePopMessage();
        WeNaviAlertDialog d = new WeNaviAlertDialog((WeNaviBaseActivity)this.getActivity());
        d.showMessage(sTitle,sInfo,l);
    }


    public void showConfirm(String sTitle,String sInfo,DialogInterface.OnClickListener l)
    {
        hidePopMessage();
        WeNaviAlertDialog d = new WeNaviAlertDialog((WeNaviBaseActivity)this.getActivity());
        d.showConfirm(sTitle,sInfo,l);
    }




    @Nullable
    @Override
    public final View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        int nID=getFragmentLayoutID();
        if(nID<=0) return null;

        getController();

        Log.e(LOG_TAG, this.hashCode() + " onCreateView called");
        View v = inflater.inflate(getFragmentLayoutID(),container,false);
        /*if(v!=null) {
            updateUiTextSize(v);
            bindUIControl(v);
        }*/
        return v;

    }


    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }


    protected void updateUiTextSize(View v)
    {
        //统一调整文字大小
        if(v==null) v=getView();
        if(v!=null) {
            WeNaviUtil.updateUiTextSize((WeNaviBaseActivity) getActivity(), (ViewGroup) v);
        }
    }





    public void resizeControl(ViewGroup group,float fHFactor,float fVFactor)
    {
        int count = group.getChildCount();
        View v;
        for (int i = 0; i < count; i++) {
            v = group.getChildAt(i);
            if (v instanceof ViewGroup)
                resizeControl((ViewGroup) v,fHFactor,fVFactor);
            else
            {
                ViewGroup.LayoutParams lp = v.getLayoutParams();
                if(lp!=null)
                {
                    lp.width=(int)(v.getWidth()*fHFactor);
                    lp.height=(int)(v.getHeight()*fVFactor);
                    v.setLayoutParams(lp);
                }
            }
        }

    }


    ///// 生命周期管理 //////////////////////////////////////////////////////////////////////////

    // protected void onRestart() {
    //
    //     if(mController!=null) mController.onViewRestart();
    // }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        Log.e(this.getClass().getCanonicalName(),this.hashCode()+" onAttach");
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e(this.getClass().getCanonicalName(),this.hashCode()+" onCreate");
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        View v=getView();
        if(v!=null) {
            updateUiTextSize(v);
            bindUIControl(v);
        }
        Log.e(this.getClass().getCanonicalName(),this.hashCode()+" onActivityCreated");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        Log.e(this.getClass().getCanonicalName(),this.hashCode()+" onDetach");
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.e(this.getClass().getCanonicalName(),this.hashCode()+" onSaveInstanceState");
    }

    @Override
    public void onViewStateRestored(Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
        Log.e(this.getClass().getCanonicalName(),this.hashCode()+" onViewStateRestored");
    }

    @Override
    public void onStart() {
        super.onStart();
        if(getController()!=null) getController().onViewStart();
        Log.e(this.getClass().getCanonicalName(),this.hashCode()+" onStart");
    }



    @Override
    public void onResume() {
        super.onResume();

        if(getViewManager()!=null &&
                getViewManager().isInUiBranch())
            onUiBranch();




        if(getViewManager()!=null)
        {
            getViewManager().setCurrentView(this);
            getViewManager().updateUICategory();
        }

        updateUiTextSize(null);

        handleMessage();



        if(getController()!=null)
        {
            mController.attachView(this);
            mController.onViewResume();
        }
        else
            Log.e(LOG_TAG, "Controller NULL!!!!");





        Log.e(this.getClass().getCanonicalName(),this.hashCode()+" onResume");
    }

    @Override
    public void onPause() {
        super.onPause();
        if(getController()!=null) getController().onViewPause();

        hidePopMessage();

        Log.e(this.getClass().getCanonicalName(), this.hashCode()+" onPause");
    }

    @Override
    public void onStop() {
        super.onStop();
        if(getController()!=null) getController().onViewStop();
        Log.e(this.getClass().getCanonicalName(),this.hashCode()+" onStop");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.e(this.getClass().getCanonicalName(), this.hashCode()+" onDestroyView");


        if(getController()!=null) getController().onViewDestroy();
    }

    @Override
    public void onDestroy() {
        Log.e(this.getClass().getCanonicalName(), this.hashCode()+" onDestroy");
        super.onDestroy();

        doSaveViewStatus();
        if(getController()!=null) getController().onViewDestroy();


    }

    protected Bundle getOnBackArguments() {
        return  null;
    }


    @Override
    public void onBack()
    {
        Log.e(this.getClass().getCanonicalName(), this.hashCode()+" onBack");
        if(getController()!=null) getController().onViewBack();

        if(getViewManager()!=null)  getViewManager().onBack(getOnBackArguments());
        //finish();


    }

    ////////////////////////////////////////////////////////////////////////////////////////////
    /// MirrorLink Support, all these function will be called by Activity
    ////////////////////////////////////////////////////////////////////////////////////////////


    /**
     * 返回MirrorLink连接 需要报告的 App类型信息
     * @return  @Defs.ContextInformation MirrorLink App类型
     */

    public int getAppCategory() {
        return Defs.ContextInformation.APPLICATION_CATEGORY_NAVIGATION;
    }

    /**
     * 返回MirrorLink连接 需要报告的 帧缓存类型信息
     * @return MirrorLink 帧缓存类型
     */

    public int getFrameCategory() {
        return Defs.ContextInformation.VISUAL_CONTENT_CATEGORY_GRAPHICS_VECTOR;
    }

    /**
     * 返回MirrorLink连接 需要报告的 App是否处理帧缓存阻塞事件
     * @return true 处理 false 不处理
     */

    public boolean isHandleFramebufferBlock() {
        return false;
    }

    /**
     * 返回MirrorLink连接 需要报告的 音频类型信息
     * @return  MirrorLink 音频类型
     */

    public int[] getAudioCategory() {
        return new int[]{0x80000000};//Defs.ContextInformation.};
    }

    /**
     * 返回MirrorLink连接 需要报告的 App是否有音频输出
     * @return true 有 false 无
     */

    public boolean hasAudio() {
        return true;
    }

    /**
     * 返回MirrorLink连接 需要报告的 App是否处理音频阻塞事件
     * @return true 处理 false 不处理
     */

    public boolean isHandleAudioBlock() {
        return false;
    }

    /**
     * MirrorLink 车机客户端显示属性改变事件
     * @param manager  MirrorLink 显示管理器
     */

    public void onMirrorLinkDeviceDisplayChanged(final IMirrorLinkManager manager){
        if(getActivity()!=null) {
            getActivity().runOnUiThread(new Runnable() {
                public void run() {

                    //更新当前UI文字大小
                    updateUiTextSize(null);
                }
            });
        }
    }

    /**
     * MirrorLink 会话状态改变事件，需通过MirrorLinkConnectionManager 获取会话状态
     * 缺省处理将根据会话状态调整屏幕方向，会话建立将自动横屏，会话断开将退出横屏
     * @param manager MirrorLinkConnectionManager
     */

    public void onMirrorLinkSessionChanged(IMirrorLinkManager manager) {


        if(getActivity()!=null) {
            getActivity().runOnUiThread(new Runnable() {
                public void run() {

                    //更新当前UI文字大小
                    updateUiTextSize(null);
                }
            });
        }

    }




    //MirrorLinkContextManager Interactors

    /**
     * MirrorLink 车机客户端帧缓存阻塞事件
     * @param manager MirrorLinkContextManager
     */

    public void onFramebufferBlocked(IMirrorLinkManager manager)
    {

    }

    /**
     * MirrorLink 车机客户音频阻塞事件
     * @param manager MirrorLinkContextManager
     */

    public void onAudioBlocked(IMirrorLinkManager manager)
    {

    }

    /**
     * MirrorLink 车机客户端帧缓存阻塞解除事件
     * @param manager MirrorLinkContextManager
     */

    public void onFramebufferUnblocked(IMirrorLinkManager manager)
    {

    }


    /**
     * MirrorLink 车机客户端音频阻塞解除事件
     * @param manager MirrorLinkContextManager
     */

    public void onAudioUnblocked(IMirrorLinkManager manager){}



    //MirrorLinkDeviceManager Interactors
    /**
     * MirrorLink 车机客户端夜间模式事件，需通过MirrorLinkDeviceManager 获取当前是否为夜间模式
     * 需要针对夜间模式进行UI适配时请重载该方法
     * @param manager MirrorLinkDeviceManager
     */

    public void onNightModeChanged(IMirrorLinkManager manager)
    {

    }

    /**
     * MirrorLink 车机客户端话筒状态事件，需通过MirrorLinkDeviceManager 获取车机话筒当前前状态
     * 语音识别需要关注该事件则请重载该方法
     * @param manager MirrorLinkDeviceManager
     */

    public void onMicrophoneStatusChanged(IMirrorLinkManager manager)
    {

    }


    /**
     * MirrorLink 车机客户端驾驶模式事件，需通过MirrorLinkDeviceManager 获取车机当前是否进入驾驶模式
     * 需要针对驾驶模式进行功能限制时请重载该方法
     * @param manager MirrorLinkDeviceManager
     */

    public void onDriveModeChange(IMirrorLinkManager manager)
    {

    }



    /**
     * MirrorLink 车机客户端旋钮平移事件回调
     * @param nKnobID 旋钮ID
     * @param dir 平移方向
     */
    public void onMirrorLinkClientKnobKeyShift(int nKnobID,MirrorLinkEvent.KnobShiftDirection dir)
    {

    }


    /**
     * MirrorLink 车机客户端旋钮按压事件回调
     * @param nKnobID 旋钮ID
     */
    public void onMirrorLinkClientKnobKeyPush(int nKnobID)
    {

    }

    /**
     * MirrorLink 车机客户端旋钮按旋转件回调
     * @param nKnobID 旋钮ID
     * @param dir 旋转方向
     */
    public void onMirrorLinkClientKnobKeyRotate(int nKnobID,MirrorLinkEvent.KnobRotateAxis axis,MirrorLinkEvent.KnobRotateDirection dir)
    {

    }

    /**
     * MirrorLink 车机客户端旋钮拉拔事件回调
     * @param nKnobID 旋钮ID
     */
    public void onMirrorLinkClientKnobKeyPull(int nKnobID)
    {

    }


    /**
     * MirrorLink 车机客户端ITU按钮按压事件回调
     * @param keyid  ITU按钮ID
     */
    public void onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey keyid)
    {

    }

    /**
     * MirrorLink 车机客户端车机设备按钮按压事件回调
     * @param keyid 按钮ID
     */
    public void onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey keyid)
    {

    }

    /**
     * MirrorLink 车机客户端功能键按压事件回调
     * @param nKeyID 按钮ID
     */
    public void onMirrorLinkClientFunctionKeyDown(int nKeyID)
    {

    }


    /**
     * MirrorLink 车机客户端多媒体按键按压事件回调
     * @param keyid 按钮ID
     */
    public void onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey keyid)
    {

    }


    ///////////////////////////////////////////////////////////////////////////
    /// MirrorLink resource

    public boolean isMirrorLinkSessionEstablished()
    {
        MirrorLinkBaseActivity a=getMirrorLinkActivity();
        if(a!=null) return a.isMirrorLinkSessionEstablished();
        return false;
    }


    public IMirrorLinkManager getMirrorLinkManager(String sName)
    {
        MirrorLinkBaseActivity a=getMirrorLinkActivity();
        if(a!=null) return a.getMirrorLinkManager(sName);
        return null;
    }

}
