package com.navinfo.wenavi.model;

import android.os.Bundle;

import java.util.Date;

/**
 * Created by Doone on 2015/3/21.
 */
public  class WeNaviInternalMessage implements  IMessage {

    Bundle message=null;




    public WeNaviInternalMessage(Bundle msg)
    {
        message=msg;
    }

    public WeNaviInternalMessage(Object sender, Object receiver,String sMsgType,Bundle content)
    {

        message=new Bundle();
        message.putString("Sender",sender.getClass().getCanonicalName());
        message.putString("Receiver",receiver.getClass().getCanonicalName());
        message.putString("MessageType",sMsgType);
        message.putBundle("Content",content);
    }


    public WeNaviInternalMessage(String sender, String receiver,String sMsgType,Bundle content)
    {
        message=new Bundle();
        message.putString("Sender",sender);
        message.putString("Receiver",receiver);
        message.putString("MessageType",sMsgType);
        message.putBundle("Content",content);
    }


    public WeNaviInternalMessage(Class<?> sender, Class<?> receiver,String sMsgType,Bundle content)
    {
        message=new Bundle();
        message.putString("Sender",sender.getCanonicalName());
        message.putString("Receiver",receiver.getCanonicalName());
        message.putString("MessageType",sMsgType);
        message.putBundle("Content",content);
    }

    @Override
    public Bundle toBundle()
    {
        return message;
    }


    @Override
    public String getSender()
    {
        if(message!=null)
        {
            if(message.containsKey("Sender")) return message.getString("Sender");
        }
        return null;
    }

    @Override
    public void setSender(String sSender)
    {
        if(message!=null)
        {
            message.putString("Sender",sSender);

        }
    }


    @Override
    public String getReceiver()
    {
        if(message!=null)
        {
            if(message.containsKey("Receiver")) return message.getString("Receiver");
        }
        return null;
    }


    @Override
    public void setReceiver(String sReceiver)
    {
        if(message!=null)
        {
            message.putString("Receiver",sReceiver);

        }
    }


    @Override
    public String getMessageType()
    {
        if(message!=null)
        {
            if(message.containsKey("MessageType")) return message.getString("MessageType");
        }
        return null;
    }


    @Override
    public String setMessageType(String sType)
    {
        if(message!=null)
        {
            message.putString("MessageType",sType);

        }
        return null;
    }


    @Override
    public Bundle getContent()
    {
        if(message!=null)
        {
            if(message.containsKey("Content")) return message.getBundle("Content");
        }
        return null;
    }




    public String getTitle() {
        if(message!=null)
        {
            if(message.containsKey("Title")) return message.getString("Title");
        }
        return null;
    }

    public void setTitle(String title) {
        if(message!=null)
        {
            message.putString("Title",title);
        }
    }

    public int getLongitude() {
        if(message!=null)
        {
            if(message.containsKey("Longitude")) return message.getInt("Longitude");
        }
        return 0;

    }

    public void setLongitude(int longitude) {
        if(message!=null)
        {
             message.putInt("Longitude",longitude);
        }
    }

    public int getLatitude() {
        if(message!=null)
        {
            if(message.containsKey("Latitude")) return message.getInt("Latitude");
        }
        return 0;

    }

    public void setLatitude(int latitude) {
        if(message!=null)
        {
            message.putInt("Latitude",latitude);
        }
    }

    public String getLocation() {
        if(message!=null)
        {
            if(message.containsKey("Location")) return message.getString("Location");
        }
        return null;
    }

    public void setLocation(String location) {
        if(message!=null)
        {
            message.putString("Location",location);
        }
    }

    public Date getAddTime() {
        if(message!=null)
        {
            if(message.containsKey("AddTime"))
            {
                return new Date(message.getLong("AddTime"));

            }
        }
        return new Date();
    }

    public void setAddTime(Date addTime) {
        if(message!=null)
        {
            if(message.containsKey("AddTime"))   message.putLong("AddTime",addTime.getTime());
        }
    }

    public String getIdSearchKey() {
        if(message!=null)
        {
            if(message.containsKey("IdSearchKey")) return message.getString("IdSearchKey");
        }
        return null;

    }

    public void setIdSearchKey(String idSearchKey) {

        if(message!=null)
        {
            message.putString("IdSearchKey",idSearchKey);
        }

    }


    public String getKeyword() {
        if(message!=null)
        {
            if(message.containsKey("Keyword")) return message.getString("Keyword");
        }
        return null;

    }

    public void setKeyword(String keyword) {

        if(message!=null)
        {
            message.putString("Keyword",keyword);
        }

    }


    public String getPoiCode() {
        if(message!=null)
        {
            if(message.containsKey("PoiCode")) return message.getString("PoiCode");
        }
        return null;

    }

    public void setPoiCode(String v) {

        if(message!=null)
        {
            message.putString("PoiCode",v);
        }

    }


    public String getCityCode() {
        if(message!=null)
        {
            if(message.containsKey("CityCode")) return message.getString("CityCode");
        }
        return null;

    }

    public void setCityCode(String v) {

        if(message!=null)
        {
            message.putString("CityCode",v);
        }

    }

}