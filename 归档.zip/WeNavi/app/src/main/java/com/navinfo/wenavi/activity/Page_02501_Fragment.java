package com.navinfo.wenavi.activity;

import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.mirrorlink.android.commonapi.Defs;
import com.navinfo.mirrorlink.IMirrorLinkManager;
import com.navinfo.mirrorlink.MirrorLinkEvent;
import com.navinfo.sdk.mapapi.map.MapView;
import com.navinfo.sdk.naviapi.NaviInfo;
import com.navinfo.sdk.naviapi.NaviState;
import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.controller.IController;
import com.navinfo.wenavi.controller.MapViewController;
import com.navinfo.wenavi.controller.NaviController;
import com.navinfo.wenavi.controller.Page_01401_Controller;
import com.navinfo.wenavi.controller.Page_04201_Controller;
import com.navinfo.wenavi.controller.RouteController;
import com.navinfo.wenavi.entity.NaviDesitination;
import com.navinfo.wenavi.entity.RoutePlanParam;
import com.navinfo.wenavi.model.IMessage;
import com.navinfo.wenavi.model.WeNaviInternalMessage;
import com.navinfo.wenavi.util.WeNaviDefine;
import com.navinfo.wenavi.util.WeNaviUtil;

/**
 * Created by Doone on 2015/3/8.
 */
public class Page_02501_Fragment extends WeNaviBaseFragment implements DialogInterface.OnClickListener {

    private final static String LOG_TAG = Page_02501_Fragment.class.getCanonicalName();

    Button mBtBack = null;
    ImageButton btDir = null;


    Button mBtCurrentLoc = null;
    Button mBtNear = null;
    MapView mMapView = null;
    TextView txtNextRoad = null;
    TextView txtCurrentRoad = null;
    TextView txtRemainder = null;
    TextView txtRemainderDis = null;
    TextView txtSpeed = null;
    TextView txtStatus = null;
    ImageView imStar = null;


    Button btZoomin = null;
    Button btZoomout = null;
    ImageButton btCompass = null;
    ToggleButton btTraffic = null;
    MapScaler ctMapScaler = null;


    @Override
    protected String getControllerName() {
        return NaviController.class.getCanonicalName();
    }


    @Override
    public int getFrameCategory() {
        return Defs.ContextInformation.VISUAL_CONTENT_CATEGORY_GRAPHICS_VECTOR;
    }

    @Override
    public void onActionUpdate(Object... datas) {
        if (datas.length > 0) {
            if (datas[0].getClass().equals(String.class)) {
                String sCms = (String) (datas[0]);
                //Log.e(LOG_TAG, "Command= " + sCms);
                if (sCms.equals(NaviController.RET_UPDATE_DATA_WHEN_NAVIGATE) && datas.length > 3) {
                    int status = (int) (datas[1]);
                    NaviInfo data = (NaviInfo) (datas[2]);//getController().getObject(NaviInfo.class.getCanonicalName());
                    int error = (int) (datas[3]);
                    updateViewWithNaviData(status, data, error);
                } else if (sCms.equals(NaviController.RET_ROUTE_PLAN_SUCCESS)) {
                    submitAction(NaviController.CMD_START_NAVIGATE);
                } else if (sCms.equals(NaviController.RET_ERROR) && datas.length > 1) {
                    String sError = (String) (datas[1]);
                    showError(sError);
                } else if (sCms.equals(NaviController.RET_STARUS) && datas.length > 1) {
                    String sStatus = (String) (datas[1]);
                    showStatus(sStatus);
                } else if (sCms.equals(NaviController.RET_UPDATE_SATELLITE) && datas.length > 1) {
                    int nCount = (int) (datas[1]);
                    showSatellite(nCount);
                } else if (sCms.equals(NaviController.RET_CAR_STOP)) {
                    txtSpeed.setText("0km/h");
                    if (mBtNear.isEnabled()) mBtNear.setVisibility(View.VISIBLE);
                    btZoomin.setVisibility(View.INVISIBLE);
                    btZoomout.setVisibility(View.INVISIBLE);

                } else if (sCms.equals(NaviController.RET_CAR_MOVING)) {
                    if (!((WeNaviBaseActivity) getActivity()).isInDriveMode())//!isMirrorLinkSessionEstablished())
                    {
                        if (mBtNear.isEnabled()) mBtNear.setVisibility(View.VISIBLE);
                        btZoomin.setVisibility(View.INVISIBLE);
                        btZoomout.setVisibility(View.INVISIBLE);
                    }

                } else if (sCms.equals(NaviController.RET_CAR_RUNING)) {
                    if (!((WeNaviBaseActivity) getActivity()).isInDriveMode())//!isMirrorLinkSessionEstablished())
                    {
                        if (mBtNear.isEnabled()) mBtNear.setVisibility(View.INVISIBLE);
                        btZoomin.setVisibility(View.INVISIBLE);
                        btZoomout.setVisibility(View.INVISIBLE);
                    }
                } else if (sCms.equals(NaviController.RET_GPS_OK)) {
                    imStar.setImageResource(R.drawable.ui_02501_1_satellite_1);

                } else if (sCms.equals(NaviController.RET_GPS_DISABLED)) {

                    showConfirm("提示", "请在位置设置中打开GPS", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //int which = (int) o;
                            if (which != 0) return;
                            Intent intent = new Intent();
                            intent.setAction(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            try {
                                Page_02501_Fragment.this.getActivity().startActivity(intent);


                            } catch (ActivityNotFoundException ex) {

                                // The Android SDK doc says that the location settings activity
                                // may not be found. In that case show the general settings.

                                // General settings activity
                                intent.setAction(Settings.ACTION_SETTINGS);
                                try {
                                    Page_02501_Fragment.this.getActivity().startActivity(intent);
                                } catch (Exception e) {
                                }
                            }

                        }
                    });


                } else super.onActionUpdate(datas);

            }
        }

    }


    @Override
    public void onPause() {
        Log.e("cc", "activity onPause");
        super.onPause();

    }

    @Override
    public void onResume() {
        Log.e("cc", "activity onResume");
        if (mMapView != null) {
            FrameLayout l = (FrameLayout) getView().findViewById(R.id.mapframe);
            if (mMapView.getParent() != null) {
                FrameLayout v = (FrameLayout) mMapView.getParent();
                if (v != l) {
                    v.removeAllViews();
                    l.addView(mMapView);
                }

            }
        }


        submitAction(MapViewController.CMD_BIND_COMPASS, btCompass);
        submitAction(MapViewController.CMD_BIND_MAPSCALER, ctMapScaler);
        submitAction(MapViewController.CMD_BIND_ZOOMIN, btZoomin);
        submitAction(MapViewController.CMD_BIND_ZOOMOUT, btZoomout);
        submitAction(MapViewController.CMD_BIND_TRAFFIC, btTraffic);
        //submitAction(MapViewController.CMD_BIND_CURLOC,mBtCurrentLoc);


        Bundle c = getArguments();
        if (c != null) {
            WeNaviInternalMessage m = new WeNaviInternalMessage(c);

            if (m != null) {

                GeoPoint p = new GeoPoint(m.getLatitude(), m.getLongitude());

                submitAction(RouteController.CMD_ADD_PASS_POINT, p);


            }

        }


        RoutePlanParam rpm = (RoutePlanParam) getController().getObject(RoutePlanParam.class.getCanonicalName());
        if (rpm != null) {
            if(rpm.isSimulateNavi()) mBtNear.setVisibility(View.VISIBLE);
            if (rpm.getPassPoints() != null && rpm.getPassPoints().size() > 0) {
                mBtNear.setEnabled(false);
                mBtNear.setVisibility(View.INVISIBLE);
            }
        }

        checkDriveModeChange();

        super.onResume();
        //submitAction(NaviController.CMD_START_SIMULATE_NAVIGATE);

    }

    @Override
    public void onBack() {
        //if(getController().)
        NaviController c = (NaviController) getController();
        if (c != null && c.isNavigating()) {
            WeNaviAlertDialog d = new WeNaviAlertDialog((WeNaviBaseActivity) getActivity());
            d.showConfirm(getResources().getString(R.string.alert_title_cancel),
                    getResources().getString(R.string.alert_message_terminate_navi),
                    Page_02501_Fragment.this
            );
        } else
            super.onBack();


    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        if (which == 0 || which == -1) {
            submitAction(NaviController.CMD_STOP_NAVIGATE);
            super.onBack();
        }
    }


    @Override
    protected int getFragmentLayoutID() {
        return R.layout.page_02501;
    }


    /**
     * 初始化控件为不可用,页面初始化时调用
     */
    @Override
    public  void onDisableControl()
    {
        mBtBack.setEnabled(false);
        //mBtNear.setEnabled(false);

    }

    /**
     * 初始化控件为可用,页面初始化完成后被延时调用
     */
    @Override
    public  void onEnableControl()
    {
        mBtBack.setEnabled(true);
        //mBtNear.setEnabled(true);
    }


    @Override
    protected void bindUIControl(View v) {


        mBtBack = (Button) v.findViewById(R.id.btBack);

        btDir = (ImageButton) v.findViewById(R.id.btDir);
        mBtNear = (Button) v.findViewById(R.id.btNear);
        mBtNear.setVisibility(View.INVISIBLE);


        mBtCurrentLoc = (Button) v.findViewById(R.id.btCurrentLoc);
        txtNextRoad = (TextView) v.findViewById(R.id.txtNextRoad);
        txtCurrentRoad = (TextView) v.findViewById(R.id.txtCurrentRoad);
        txtRemainder = (TextView) v.findViewById(R.id.txtRemainder);
        txtRemainderDis = (TextView) v.findViewById(R.id.txtRemainDis);
        txtSpeed = (TextView) v.findViewById(R.id.txtSpeed);
        txtStatus = (TextView) v.findViewById(R.id.txtStatus);
        imStar = (ImageView) v.findViewById(R.id.imStar);

        btDir.setVisibility(View.INVISIBLE);
        txtNextRoad.setVisibility(View.INVISIBLE);
        txtCurrentRoad.setVisibility(View.INVISIBLE);


        btZoomin = (Button) v.findViewById(R.id.btMapZoomin);
        btZoomout = (Button) v.findViewById(R.id.btMapZoomout);
        btZoomin.setVisibility(View.GONE);
        btZoomout.setVisibility(View.GONE);
        btCompass = (ImageButton) v.findViewById(R.id.btCompass);
        btTraffic = (ToggleButton) v.findViewById(R.id.btMapTraffic);

        ctMapScaler = (MapScaler) v.findViewById(R.id.ctMapScaler);

        showSatellite(0);


        IController c = getController();

        if (c != null) {
            mMapView = (MapView) c.getObject(MapView.class.getCanonicalName()); // findViewById(R.id.mpView);

            if (mMapView != null) {
                FrameLayout l = (FrameLayout) v.findViewById(R.id.mapframe);
                if (mMapView.getParent() != null) {
                    FrameLayout fv = (FrameLayout) mMapView.getParent();
                    if (fv != l) {
                        fv.removeAllViews();
                        l.addView(mMapView);
                    }
                } else
                    l.addView(mMapView);

            }


        }


        mBtBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(Page_0102_Activity.this.getApplicationContext(),
                //        String.format("mBtBack clicked"), Toast.LENGTH_LONG).show();

                onBack();
            }
        });

        mBtNear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                submitAction(NaviController.CMD_STOP_NAVIGATE);

                WeNaviInternalMessage m = new WeNaviInternalMessage(
                        Page_02501_Fragment.this.getClass(),
                        Page_02201_Fragment.class,
                        WeNaviDefine.MSG_REQUEST_LOCATION,
                        null);

                toBranchPage(Page_02201_Fragment.class, m.toBundle());
            }
        });


    }


    @Override
    protected void onInternalMessage(IMessage m) {

        if (m.getMessageType().equals(WeNaviDefine.MSG_RESPONSE_LOCATION)) {
            //reepomseLocationMessg=m;
            Bundle c = m.getContent();
            if (c != null) {
                if (c.containsKey("Longitude") && c.containsKey("Latitude")) {
                    GeoPoint p = new GeoPoint(c.getInt("Latitude"), c.getInt("Longitude"));
                    submitAction(RouteController.CMD_ADD_PASS_POINT, p);
                }
            }

        }

    }

    private int GetNaviCrossingIconTypeID(int type) {
        String pngName = getActivity().getPackageName() + ":drawable/navigation"
                + type;
        return getResources().getIdentifier(pngName, null, null);
    }


    private void showError(String sError) {
        txtRemainder.setText(sError);
    }


    private void showStatus(String sStatus) {
        //txtStatus.setText(sStatus);
    }


    private void showSatellite(int nCount) {
        String s = String.format("%d", nCount);
        txtStatus.setText(s);
    }


    private void searchNearGas()


    {
        WeNaviAlertDialog d = new WeNaviAlertDialog((WeNaviBaseActivity) this.getActivity());
        final DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    submitAction(NaviController.CMD_STOP_NAVIGATE);
                    WeNaviInternalMessage m = new WeNaviInternalMessage(
                            Page_02501_Fragment.this.getClass(),
                            Page_01401_Fragment.class,
                            WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME,
                            null);
                    m.setKeyword("停车场");
                    toPage(Page_01401_Fragment.class, m.toBundle());
                }
            }
        };
        d.showRecommendPark(listener);

//        d.showConfirm("推荐","您即将到达目的地，是否为您推荐停车场?",new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                if(which!=0) return;
//
//                submitAction(NaviController.CMD_STOP_NAVIGATE);
//                WeNaviInternalMessage m=new WeNaviInternalMessage(
//                        Page_02501_Fragment.this.getClass(),
//                        Page_01401_Fragment.class,
//                        WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME,
//                        null);
//                m.setKeyword("停车场");
//                toPage(Page_01401_Fragment.class, m.toBundle());
//
//
//
//            }
//        });
    }

    private boolean bNotifySearch = false;

    private void updateViewWithNaviData(int status, NaviInfo data, int dwError) {

        String str = null;


        switch (status) {
            case NaviState.NAVI_NET_REQUEST: {

                //网络请求开始
                str = "规划开始";

                Log.e(LOG_TAG, str + " " + status);
                txtRemainder.setText(str);

            }
            break;
            case NaviState.NAVI_NET_FINISH: {

                //网络请求结束
                str = "规划结束";
                Log.e(LOG_TAG, str + " " + status);
                txtRemainder.setText(str);
            }
            break;
            case NaviState.NAVI_ERROR: {
                Log.e(LOG_TAG, "CCCCCCCCCCAAA--callback 2 = " + dwError);
                //error
                str = "状态：error " + dwError;
                Log.e(LOG_TAG, str + " " + status);
                txtRemainder.setText(str);
            }
            break;
            case NaviState.NAVI_ORDINARYNAVI: {
                //Log.e("","CCCCCCCCCCAAA--callback 3");
                //导航中
                //str = "状态：导航中";
                Log.e(LOG_TAG, str + " " + status);
                txtRemainder.setText(str);
            }
            break;
            case NaviState.NAVI_NAVISTART: {
                //导航开始
                // Log.e("","CCCCCCCCCCAAA--callback 4");
                str = "导航开始";
                Log.e(LOG_TAG, str + " " + status);
                txtRemainder.setText(str);
            }
            break;
            case NaviState.NAVI_NAVIFINISH: {
                //导航结束
                //Log.e("","CCCCCCCCCCAAA--callback 5");
                str = "导航结束";
                Log.e(LOG_TAG, str + " " + status);
                txtRemainder.setText(str);
            }
            break;
            case NaviState.NAVI_YAWNAVI: {
                //导航结束
                //Log.e("","CCCCCCCCCCAAA--callback 5");
                str = "偏航";
                Log.e(LOG_TAG, str + " " + status);
                txtRemainder.setText(str);
            }
            break;
            default: {
                //str = "状态：其他状态";
                Log.e(LOG_TAG, str + " " + status);
                txtRemainder.setText(str);
            }
        }
       /* if (status == 6){
            onBack();
            return;
        }*/

        if (data != null) {


            Log.e("CCC", "data.cueIcon=" + data.cueIcon);
            if (data.cueIcon >= 0) {

                int id = GetNaviCrossingIconTypeID(data.cueIcon);
                btDir.setImageResource(id);
                if (btDir.getVisibility() == View.INVISIBLE)
                    btDir.setVisibility(View.VISIBLE);

            }

            str = WeNaviUtil.convertMeters(data.surplusDistance);
            txtRemainderDis.setText(str);

            str = WeNaviUtil.convertTime(data.surplusTime);
            txtRemainder.setText(str);

            double speed = (data.speed * 3600) / 1000;
            str = Math.round(speed) + "km/h";
            txtSpeed.setText(str);


            if (data.surplusDistance <= 500 && !bNotifySearch) {
                bNotifySearch = true;
                searchNearGas();
            }


            if (data.routeName != null) {
                str = data.routeName;
                txtCurrentRoad.setText(str);

                if (txtCurrentRoad.getVisibility() == View.INVISIBLE)
                    txtCurrentRoad.setVisibility(View.VISIBLE);

            }

            if (data.nextRouteName != null) {
                str = data.nextRouteName;
                txtNextRoad.setText(str);
                if (txtNextRoad.getVisibility() == View.INVISIBLE)
                    txtNextRoad.setVisibility(View.VISIBLE);
            }


        }

    }


    @Override
    public void onMirrorLinkClientKnobKeyShift(int nKnobID, MirrorLinkEvent.KnobShiftDirection dir) {

        submitAction(MapViewController.CMD_SHIFT_MAP, dir);
    }

    @Override
    public void onMirrorLinkClientKnobKeyRotate(int nKnobID, MirrorLinkEvent.KnobRotateAxis axis, MirrorLinkEvent.KnobRotateDirection dir) {
        //super.onMirrorLinkClientKnobKeyRotate(nKnobID, axis, dir);
        submitAction(MapViewController.CMD_SCALE_MAP, dir);
    }


    @Override
    public void restoreViewStatus(Bundle status) {

    }

    @Override
    public Bundle getViewStatus() {
        return null;
    }


    @Override
    public void onDriveModeChange(IMirrorLinkManager manager) {
        super.onDriveModeChange(manager);

        checkDriveModeChange();


    }


    void checkDriveModeChange() {
        if (((WeNaviBaseActivity) getActivity()).isInDriveMode()) {
            if (mBtNear.isEnabled()) mBtNear.setVisibility(View.INVISIBLE);
            btZoomin.setVisibility(View.INVISIBLE);
            btZoomout.setVisibility(View.INVISIBLE);

        } else {
            if (mBtNear.isEnabled()) mBtNear.setVisibility(View.VISIBLE);
            btZoomin.setVisibility(View.INVISIBLE);
            btZoomout.setVisibility(View.INVISIBLE);
        }
    }
}
