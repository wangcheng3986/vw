package com.navinfo.wenavi.model;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.navinfo.wenavi.R;
import com.navinfo.wenavi.activity.AlertDialog;
import com.navinfo.wenavi.controller.Page_04201_Controller;
import com.navinfo.wenavi.controller.RouteController;
import com.navinfo.wenavi.entity.NaviDesitination;
import com.navinfo.wenavi.entity.NaviHistory;
import com.navinfo.wenavi.util.WeNaviUtil;

import java.util.List;

/**
 * Created by cc on 15/3/24.
 */
public class Page_04201_ListAdapter {
    private MyCommonListAdapter mCommonListAdapter = null;
    private MyHistoryListAdapter mHistoryListAdapter = null;
    private List<NaviDesitination> mCommonList = null;
    private List<NaviHistory> mHistoryList  = null;
    private onItemListClickListener mListener = null;

    public Page_04201_ListAdapter(Context context) {
        mCommonListAdapter = new MyCommonListAdapter(context);
        mHistoryListAdapter = new MyHistoryListAdapter(context);
    }

    public MyCommonListAdapter getCommonListAdapter() {
        return mCommonListAdapter;
    }

    public MyHistoryListAdapter getHistoryListAdapter() {
        return mHistoryListAdapter;
    }

    public void setCommonList(List<NaviDesitination> mCommonList) {
        this.mCommonList = mCommonList;
    }

    public void setHistoryList(List<NaviHistory> mHistoryList) {
        this.mHistoryList = mHistoryList;
    }

    public void setListener(onItemListClickListener mListener) {
        this.mListener = mListener;
    }

    public  class MyCommonListAdapter extends BaseAdapter {

        private class commonViewHolder {
            TextView key;
            TextView name;
            Button edit;
            View item;
        }
        private Context mContext = null;
        private commonViewHolder holderCommon;


        public MyCommonListAdapter(Context context) {
            super();
            mContext = context;
        }

        @Override
        public View getView(int index, View convertView, ViewGroup parent) {
            if (convertView != null) {
                holderCommon = (commonViewHolder) convertView.getTag();
            } else {
                //convertView = View.inflate(mContext, R.layout.page_04201_listitem, null);

                AbsListView.LayoutParams pm = new AbsListView.LayoutParams(
                        AbsListView.LayoutParams.MATCH_PARENT,
                        WeNaviUtil.dip2px(mContext, 58.5f));


                LinearLayout layout = new LinearLayout(mContext);
                layout.setOrientation(LinearLayout.HORIZONTAL);
                layout.setLayoutParams(pm);
                layout.setBackgroundResource(R.drawable.p2401_listitem_color);



                TextView key = new TextView(mContext);
                key.setTextColor(mContext.getResources().getColorStateList(R.drawable.p2401_listitem_white_yellow));
                key.setTextSize(20);
                key.setText("公司：");
                key.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);

                LinearLayout.LayoutParams pms = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        WeNaviUtil.dip2px(mContext, 58.5f)
                );
                pms.setMargins(WeNaviUtil.dip2px(mContext, 22.5f), 0, 0, 0);
                pms.gravity = Gravity.CENTER;
                key.setLayoutParams(pms);


                key.setTag("key");
                layout.addView(key);


                TextView name = new TextView(mContext);
                name.setTextColor(mContext.getResources().getColorStateList(R.drawable.p2401_listitem_white_yellow));
                name.setTextSize(20);
                name.setText("公司：");
                name.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);

                pms = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        WeNaviUtil.dip2px(mContext, 58.5f)
                );
                pms.setMargins(WeNaviUtil.dip2px(mContext, 14f), 0, 0, 0);
                pms.gravity = Gravity.CENTER;
                pms.weight=1;
                name.setLayoutParams(pms);

                name.setSingleLine(true);
                name.setEllipsize(TextUtils.TruncateAt.END);
                name.setTag("name");
                layout.addView(name);


                Button b = new Button(mContext);
                b.setBackgroundResource(R.drawable.p04201_list_edit);
                pms = new LinearLayout.LayoutParams(
                        WeNaviUtil.dip2px(mContext, 55f),
                        WeNaviUtil.dip2px(mContext, 55f)
                );
                pms.setMargins(0, 0, 0, WeNaviUtil.dip2px(mContext, 4f));
                pms.gravity=Gravity.RIGHT;
                b.setLayoutParams(pms);
                b.setTag("button");
                layout.addView(b);




                convertView = layout;




                holderCommon = new commonViewHolder();
                holderCommon.key = key;//(TextView)convertView.findViewById(R.id.key);
                holderCommon.name = name;// (TextView)convertView.findViewById(R.id.name);
                holderCommon.edit = b;// (Button)convertView.findViewById(R.id.edit);
                holderCommon.item = layout;//(View)convertView.findViewById(R.id.commin_item);
                convertView.setTag(holderCommon);
            }

            holderCommon.key.setText(mCommonList.get(index).getTitle()+":");
            holderCommon.name.setText(mCommonList.get(index).getLocation());
            holderCommon.edit.setOnClickListener(new ButtonListener(index));
            holderCommon.item.setOnClickListener(new ItemListener(index));
            return convertView;
        }
        @Override
        public int getCount() {
            if (mCommonList == null){
                return  0;
            }
            return mCommonList.size();
        }
        @Override
        public Object getItem(int index) {
            if (mCommonList == null){
                return  null;
            }
            return mCommonList.get(index);
        }

        @Override
        public long getItemId(int id) {
            return id;
        }

        /**
         * 监听按钮touch事件
         * **/
        class ButtonListener implements View.OnClickListener {
            private int mIndex;
            ButtonListener(int index) {
                mIndex = index;
            }
            @Override
            public void onClick(View v) {
                int id=v.getId();
                //设置新地点
                if (id == holderCommon.edit.getId()){

                    mListener.onClick(1, mIndex, 1);
//                    toSearchPage(mCommonList.get(mIndex));

                }
            }
        }

        /**
         * 监听item touch事件
         * **/
        class ItemListener implements View.OnClickListener {
            private int mIndex;
            ItemListener(int index) {
                mIndex = index;
            }
            @Override
            public void onClick(View v) {
                int id=v.getId();
                if (id == holderCommon.item.getId()){
                    mListener.onClick(1, mIndex, 0);
//                    if (mCommonList.get(mIndex).getLongitude() == 0 || mCommonList.get(mIndex).getLatitude() == 0){
//                        toSearchPage(mCommonList.get(mIndex));
//                        return;
//                    }
//                    NaviHistory h=new NaviHistory();
//                    h.setRouteType(RouteController.CMD_ROUTE_PLAN_TIME);
//                    h.setLongitudeEnd(mCommonList.get(mIndex).getLongitude());
//                    h.setLatitudeEnd(mCommonList.get(mIndex).getLatitude());
//                    toNavi(h , false);
                }
            }
        }
    }

    public  class MyHistoryListAdapter extends BaseAdapter {
        private class historyViewHolder {
            Button btn ;
            TextView text;
            View item;
        }
        private Context mContext = null;
        private View mView = null;
        LayoutInflater inflater;

        final int VIEW_TYPE = 2;
        final int TYPE_1 = 0;
        final int TYPE_2 = 1;


        public MyHistoryListAdapter(Context context) {
            super();
            mContext = context;
            inflater = LayoutInflater.from(mContext);
        }

        //每个convert view都会调用此方法，获得当前所需要的view样式
        @Override
        public int getItemViewType(int position) {
            if(position == 0)
                return TYPE_1;
            else
                return TYPE_2;
        }

        @Override
        public int getViewTypeCount() {
            return 2;
        }


        @Override
        public View getView(int index, View convertView, ViewGroup parent) {
            int type = getItemViewType(index);
            historyViewHolder holder1 = null;
            historyViewHolder holder2 = null;

            //无convertView，需要new出各个控件
            if(convertView == null)
            {

                //按当前所需的样式，确定new的布局
                switch(type)
                {
                    case TYPE_1:
                        //convertView = inflater.inflate(R.layout.page_04201_listitem2, parent, false);
                    {
                        AbsListView.LayoutParams pm = new AbsListView.LayoutParams(
                                AbsListView.LayoutParams.MATCH_PARENT,
                                WeNaviUtil.dip2px(mContext, 58.5f));


                        LinearLayout layout = new LinearLayout(mContext);
                        layout.setOrientation(LinearLayout.HORIZONTAL);
                        layout.setLayoutParams(pm);
                        layout.setBackgroundResource(R.drawable.p2401_listitem_color);


                        Button b = new Button(mContext);
                        b.setBackgroundResource(R.drawable.ui_02201_1_icon_history);
                        LinearLayout.LayoutParams pms = new LinearLayout.LayoutParams(
                                WeNaviUtil.dip2px(mContext, 23.5f),
                                WeNaviUtil.dip2px(mContext, 23.5f)
                        );
                        pms.setMargins(WeNaviUtil.dip2px(mContext, 22.5f), 0, 0, 0);
                        pms.gravity=Gravity.CENTER;
                        b.setLayoutParams(pms);

                        b.setTag("button");
                        layout.addView(b);


                        TextView name = new TextView(mContext);

                        name.setTextColor(mContext.getResources().getColorStateList(R.drawable.p2401_listitem_white_yellow));
                        name.setTextSize(20);
                        name.setText("历史纪录");
                        //name.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);

                        pms = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        );
                        pms.setMargins(WeNaviUtil.dip2px(mContext, 8.5f), 0, 0, 0);
                        pms.gravity = Gravity.CENTER;
                        pms.weight=1;
                        name.setLayoutParams(pms);

                        name.setTag("name");
                        layout.addView(name);

                        convertView = layout;


                        holder1 = new historyViewHolder();
                        holder1.btn = b;//(Button)convertView.findViewById(R.id.button);
                        holder1.text = name;// (TextView)convertView.findViewById(R.id.text);
                        holder1.item = layout;//(View)convertView.findViewById(R.id.history_item);
                        convertView.setTag(holder1);
                    }
                        break;
                    case TYPE_2:
                        //convertView = inflater.inflate(R.layout.page_04201_listitem3, parent, false);
                    {
                        AbsListView.LayoutParams pm = new AbsListView.LayoutParams(
                                AbsListView.LayoutParams.MATCH_PARENT,
                                WeNaviUtil.dip2px(mContext, 58.5f));


                        LinearLayout layout = new LinearLayout(mContext);
                        layout.setOrientation(LinearLayout.HORIZONTAL);
                        layout.setLayoutParams(pm);
                        layout.setBackgroundResource(R.drawable.p2401_listitem_color);



                        TextView name = new TextView(mContext);
                        name.setTextColor(mContext.getResources().getColorStateList(R.drawable.p2401_listitem_white_yellow));
                        name.setTextSize(20);
                        name.setText("");
                        name.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);

                        LinearLayout.LayoutParams pms = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        );
                        pms.setMargins(WeNaviUtil.dip2px(mContext, 54.5f), 0, 0, 0);
                        pms.gravity = Gravity.CENTER;
                        pms.weight=1;
                        name.setLayoutParams(pms);
                        name.setSingleLine(true);
                        name.setEllipsize(TextUtils.TruncateAt.END);
                        name.setTag("name");
                        layout.addView(name);


                        Button b = new Button(mContext);
                        b.setBackgroundResource(R.drawable.p04201_list_del);
                        pms = new LinearLayout.LayoutParams(
                                WeNaviUtil.dip2px(mContext, 55f),
                                WeNaviUtil.dip2px(mContext, 55f)
                        );
                        pms.setMargins(0, 0, 0, WeNaviUtil.dip2px(mContext, 4f));
                        b.setLayoutParams(pms);
                        b.setTag("button");
                        layout.addView(b);




                        convertView = layout;


                        holder2 = new historyViewHolder();
                        holder2.btn = b;//(Button)convertView.findViewById(R.id.button);
                        holder2.text = name;// (TextView)convertView.findViewById(R.id.text);
                        holder2.item = layout;//(View)convertView.findViewById(R.id.history_item);
                        convertView.setTag(holder2);
                    }
                        break;
                }
            }
            else
            {
                //有convertView，按样式，取得不用的布局
                switch(type)
                {
                    case TYPE_1:
                        holder1 = (historyViewHolder) convertView.getTag();
                        break;
                    case TYPE_2:
                        holder2 = (historyViewHolder) convertView.getTag();
                        break;
                }
            }
            //设置资源
            if(type == TYPE_2)
            {
                holder2.text.setText(mHistoryList.get(index-1).getEndLocation());
                holder2.btn.setOnClickListener(new ButtonListener(index));
                holder2.item.setOnClickListener(new ItemListener(index));
            }
            return convertView;
        }
        @Override
        public int getCount() {
            if (mHistoryList == null){
                return  1;
            }
            return mHistoryList.size()+1;
        }
        @Override
        public Object getItem(int index) {
            if (index == 0){
                return null;
            }
            else if (mHistoryList == null){
                return  null;
            }

            return mHistoryList.get(index+1);
        }

        @Override
        public long getItemId(int id) {
            return id;
        }

        /**
         * 监听按钮touch事件
         * **/
        class ButtonListener implements View.OnClickListener {
            private int mIndex;
            ButtonListener(int index) {
                mIndex = index;
            }
            @Override
            public void onClick(View v) {
                mListener.onClick(0, mIndex, 1);
//                AlertDialog dlg = AlertDialog.builder("提示","您确认删除这条纪录么?",Page_04201_Fragment.this.getActivity(),
//                        new AlertDialog.OnClickListener(){
//
//                            @Override
//                            public void onClick(Object o) {
//                                int which = (int)o;
//                                if(which!=0) return;
//                                //删除一条纪录
//                                submitAction(Page_04201_Controller.CMD_DEL_A_HISTORY,mHistoryList.get(mIndex-1).getMyId());
//                                mHistoryList.remove(mIndex - 1);
//                                mHistoryListAdapter.notifyDataSetChanged();
//                                if(mHistoryList != null && mHistoryList.size() > 0){
//                                    mLastNavigationText.setText(mHistoryList.get(0).getStartLocation());
//                                }else{
//                                    mLastNavigationText.setText("");
//                                }
//                            }
//                        });
//
//                dlg.show(v);
            }
        }

        /**
         * 监听item touch事件
         * **/
        class ItemListener implements View.OnClickListener {
            private int mIndex;
            ItemListener(int index) {
                mIndex = index;
            }
            @Override
            public void onClick(View v) {
                mListener.onClick(0, mIndex, 0);
//                toNavi(mHistoryList.get(mIndex-1), false);
            }
        }
    }

    public interface onItemListClickListener{
        /**
         * 列表单击事件监听
         * @param type 0为历史纪录列表，1为常用列表
         * @param index 列表项序号
         * @param event 事件类型 0为item，1为btn
         */
        public void onClick(int type, int index, int event);
    }

}
