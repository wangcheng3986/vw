package com.navinfo.wenavi.entity;

import android.os.Parcelable;

import com.orm.SugarRecord;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by Doone on 2015/3/10.
 * 导航目的地数据实体
 */
public class NaviDesitination extends SugarRecord<NaviDesitination>  {

    String title;
    int longitude;
    int latitude;
    String location;
    Date addTime;
    String idSearchKey;



    public NaviDesitination()
    {
        this.idSearchKey = "k"+this.hashCode();
        this.addTime = new Date();
    }

    public NaviDesitination(String title, int longitude, int latitude, String location) {
        this.title = title;
        this.longitude = longitude;
        this.latitude = latitude;
        this.location = location;
        this.addTime = new Date();
        this.idSearchKey = "k"+this.hashCode();
    }



    public String getIdSearchKey() {
        return this.idSearchKey;
    }

    public void setIdSearchKey(String key) {
        this.idSearchKey = key;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getLongitude() {
        return longitude;
    }

    public void setLongitude(int longitude) {
        this.longitude = longitude;
    }

    public int getLatitude() {
        return latitude;
    }

    public void setLatitude(int latitude) {
        this.latitude = latitude;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getAddTime() {
        return addTime;
    }

    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    public boolean equal(NaviDesitination o) {
        return (this.getLongitude() == o.getLongitude()
                && this.getLatitude() == o.getLatitude());
    }

}
