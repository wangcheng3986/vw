package com.navinfo.wenavi.activity;

import android.app.Activity;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;

import com.navinfo.wenavi.R;
import com.navinfo.wenavi.model.CustomDialog;

/**
 * Created by cc on 15/3/24.
 */
public class AlertDialog extends CustomDialog{
    public final static int BTN_OK = 0;
    public final static int BTN_CANCEL = 1;
    private Button mOK = null;
    private Button mCancel = null;
    private TextView mTitle = null;
    private TextView mPrompt = null;

    public AlertDialog(Activity activity, int resource, boolean message) {
        super(activity, resource);
        mOK = (Button) getView().findViewById(R.id.btOk);

        mTitle = (TextView) getView().findViewById(R.id.txtTitle);
        mPrompt = (TextView) getView().findViewById(R.id.txtMessage);

        mOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getOnClickListener() != null){
                    getOnClickListener().onClick(BTN_OK);
                }
                hide();
            }
        });

        if (!message){
            mCancel = (Button) getView().findViewById(R.id.btCancel);
            mCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (getOnClickListener() != null){
                        getOnClickListener().onClick(BTN_CANCEL);
                    }
                    hide();
                }
            });
        }
    }

    public void setText(String sTitle,String sInfo){
        mTitle.setText(sTitle);
        mPrompt.setText(sInfo);
    }


    public static AlertDialog builder(String sTitle,String sInfo, Activity activity){
        AlertDialog dlg = new AlertDialog(activity, R.layout.dialog_message,true);
        dlg.setOnClickListener(null);
        dlg.setText(sTitle,sInfo);
        return dlg;
    }

    public static AlertDialog builder(String sTitle,String sInfo, Activity activity, CustomDialog.OnClickListener l){
        AlertDialog dlg = new AlertDialog(activity, R.layout.dialog_confirm,false);
        dlg.setOnClickListener(l);
        dlg.setText(sTitle,sInfo);
        return dlg;
    }
}
