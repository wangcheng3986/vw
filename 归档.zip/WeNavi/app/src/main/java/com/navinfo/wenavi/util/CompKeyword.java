package com.navinfo.wenavi.util;

import com.navinfo.wenavi.entity.NaviKeyWord;

import java.util.Comparator;

/**
 * Created by min on 2015/3/13.
 */
public class CompKeyword implements Comparator{


    @Override
    public int compare(Object arg0, Object arg1) {
        NaviKeyWord keyWord0=(NaviKeyWord)arg0;
        NaviKeyWord keyWord1=(NaviKeyWord)arg1;
        int flag=keyWord0.getSearchTime().compareTo(keyWord1.getSearchTime());
        return flag;
    }
}
