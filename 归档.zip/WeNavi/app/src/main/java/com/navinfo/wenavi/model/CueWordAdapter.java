package com.navinfo.wenavi.model;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.navinfo.wenavi.R;
import com.navinfo.wenavi.activity.WeNaviBaseActivity;
import com.navinfo.wenavi.entity.CueWordEntity;
import com.navinfo.wenavi.util.WeNaviUtil;

/**
 * Created by rotorliu on 2015/3/27.
 */
public class CueWordAdapter extends BaseAdapter {
    private Context mContext = null;
    private CueWordEntity[] mlist = null;
    private ICueWordListViewInteractor mCueWordListViewInteractor=null;
    private LayoutInflater mInflater=null;
    private String delName(String s){
        String ret = s;
        if(s.contains("&amp;")){
            ret=s.replace("&amp;","&");
        }
        if(s.contains("&lt;")){
            ret = s.replace("&lt;","<");
        }
        if(s.contains("&gt;")){
            ret = s.replace("&gt;",">");
        }
        if(s.contains("&quot;")){
            ret = s.replace("&quot;","''");
        }
        return ret;
    }

    public interface ICueWordListViewInteractor
    {
        void onItemClick(CueWordEntity p);

        void onItemClick(CueWordEntity p, int index);
    }

    public CueWordAdapter(){
        //this.mContext = context;
        //this.mlist = list;

    }

    public void setContext(Context c)
    {
        this.mContext=c;
         mInflater = LayoutInflater.from(mContext);
    }

    public void setCueWordListViewInteractor(ICueWordListViewInteractor interactor)
    {
        mCueWordListViewInteractor=interactor;
    }

    public void setData(CueWordEntity[] list)
    {
        this.mlist = list;
    }

    @Override
    public int getCount() {
        int count = 0;
        if (null != mlist)
        {
            count = mlist.length;
        }
        return count;
    }

    @Override
    public CueWordEntity getItem(int position) {
        CueWordEntity item = null;

        if (null != mlist)
        {
            item = mlist[position];
        }

        return item;
    }

    @Override
    public long getItemId(int position) {

        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        //ViewHolder viewHolder = null;

        if (null == convertView)
        {


            //Log.e(this.getClass().getCanonicalName(),"Inflater "+mInflater.hashCode()+ " Context"+mContext.hashCode());

            //convertView = mInflater.inflate(R.layout.page_02201_call_word_item, null);



            AbsListView.LayoutParams pm=new AbsListView.LayoutParams(
                    AbsListView.LayoutParams.MATCH_PARENT,
                    WeNaviUtil.dip2px(mContext, 50));


            LinearLayout layout=new LinearLayout(mContext);
            layout.setOrientation(LinearLayout.HORIZONTAL);
            layout.setLayoutParams(pm);
            layout.setBackgroundResource(R.drawable.list_item_bg);



            TextView name=new TextView(mContext);
            name.setTextColor(mContext.getResources().getColorStateList(R.drawable.p2401_listitem_txtcolor));
            name.setTextSize(20);
            name.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
            LinearLayout.LayoutParams pm1=new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    WeNaviUtil.dip2px(mContext, 50)
            );
            pm1.setMargins( WeNaviUtil.dip2px(mContext, 50),0,5,0);
            name.setLayoutParams(pm1);



            //name.setId()
            name.setTag("name");
            layout.addView(name);

            convertView=layout;

            //if(convertView!=null) setFontSize((ViewGroup)convertView,getDefaultTextSize());



            convertView.setTag(name);
        }


        final CueWordEntity item = getItem(position);
        if (null != item)
        {
            TextView name  = (TextView) convertView.findViewWithTag("name");//.findViewById(R.id.tv_call_word_item_name);
            String n = delName(item.getName());
            name.setText(n);
            convertView.setTag(item);
            WeNaviUtil.updateUiTextSize((WeNaviBaseActivity)mContext,(ViewGroup)convertView);
        }

         convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Object tag=v.getTag();
                if(tag!=null && (tag instanceof CueWordEntity))
                {
                    if(mCueWordListViewInteractor!=null)
                        mCueWordListViewInteractor.onItemClick((CueWordEntity)tag,position);
                }
            }

        });



        return convertView;
    }

}
