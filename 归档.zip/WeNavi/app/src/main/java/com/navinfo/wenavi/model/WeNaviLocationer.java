package com.navinfo.wenavi.model;

import android.content.Context;

import com.navinfo.sdk.location.NavinfoLocationClient;

/**
 * Created by Doone on 2015/3/21.
 */
public class WeNaviLocationer extends NavinfoLocationClient {

    private boolean isRunning=false;
    public WeNaviLocationer(Context context) {
        super(context);
    }

    @Override
    public void start() {
        if(isRunning) return;

        super.start();
        isRunning=true;
    }

    @Override
    public void stop() {

        if(!isRunning) return;

        super.stop();
        isRunning=false;
    }
}
