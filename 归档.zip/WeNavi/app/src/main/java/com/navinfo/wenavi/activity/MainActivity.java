package com.navinfo.wenavi.activity;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.os.Bundle;

import com.navinfo.audio.IAudioGenerateListerner;
import com.navinfo.audio.IAudioGenerator;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.controller.AudioController;

/**
 * Created by Doone on 2015/3/7.
 */
public class MainActivity extends  WeNaviBaseActivity {

    @Override
    protected String getControllerName() {
        return AudioController.class.getCanonicalName();
    }

    @Override
    public void onActionUpdate(Object... datas) {

    }

    @Override
    protected void onLoadUi(Configuration configuration) {
        if(getCurrentView()!=null) return;

        setContentView(R.layout.activity_main);


        //setCurrentPage(Page_02201_Fragment.class,null);


    }



    @Override
    public int getLayoutIdForFragment() {
        return R.id.layoutfragment;
    }




    @Override
    protected void onResume() {
        super.onResume();
        //mAudioRecongniser.launch();


        //else
        //    mAudioRecongniser.startRecongnise(Page_01_Activity.this);
        //if(getCurrentPageClass()!=null) setCurrentPage(getCurrentPageClass());

        //FragmentManager fm=getFragmentManager();
        if(getCurrentFragment()==null)//fm.getBackStackEntryCount()==0 || getCurrentView()==null)
            setCurrentPage(Page_00000_Fragment.class,null,null);


    }

    @Override
    protected void onPause() {

        super.onPause();
    }




    @Override
    public  void onBack(final Bundle pm) {

        /*if(isInHomePage()) {

            WeNaviAlertDialog d = new WeNaviAlertDialog(this);
            d.showConfirm(getResources().getString(R.string.alert_title_exit),
                    getResources().getString(R.string.alert_message_exit),
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (which == 0 || which == -1) {
                                IAudioGenerator p=(IAudioGenerator)getController().getObject(IAudioGenerator.class.getCanonicalName());
                                p.play(getResources().getString(R.string.audio_command_bay), new IAudioGenerateListerner() {
                                    @Override
                                    public void onError(String sError) {
                                        MainActivity.this.doBack(pm);
                                    }

                                    @Override
                                    public void onPlayFinished() {
                                        MainActivity.this.doBack(pm);
                                    }
                                });
                            }
                        }
                    }
            );
        }
        else
            doBack(pm);*/
        super.onBack(pm);

    }


    void doBack(Bundle pm)
    {
        super.onBack(pm);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //mAudioRecongniser.stop();
    }




}
