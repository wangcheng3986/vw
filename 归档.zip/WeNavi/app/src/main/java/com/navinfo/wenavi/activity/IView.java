package com.navinfo.wenavi.activity;

import android.os.Bundle;

import com.mirrorlink.android.commonapi.Defs;
import com.navinfo.mirrorlink.IMirrorLinkManager;
import com.navinfo.mirrorlink.MirrorLinkEvent;
import com.navinfo.wenavi.controller.IController;

/**
 * Created by Doone on 2015/2/4.
 * 视图接口
 */
public interface IView {

    /**
     * 返回本视图的控制器接口
     * @return IController 实例
     */
    public IController getController();

    /**
     * 设置本视图的控制器接口
     * @param c IController 实例
     */
    public void setController(IController c);

    /**
     * 更新视图UI，由COntroller调用
     * @param datas  待更新数据
     */
    public void onActionUpdate(Object ... datas);


    /**
     * 提交业务功能请求给控制器
     * @param actionDatas 功能参数
     */
    public void submitAction(Object ... actionDatas);


    /**
     * 设置视图管理器
     * @param m 视图管理器对象
     */
    public void setViewManager(IViewManager m);


    /**
     * 返回视图管理器对象
     * @return IViewManager
     */
    public IViewManager getViewManager();

    /**
     * 返回视图标记
     * @return 视图标记
     */
    public String getViewTag();


    public Object getParameters();//



    public void setParameters(Object parameters);


    /**
     * 回退操作
     */
    public void onBack();


    //===============================================


    /**
     * 返回MirrorLink连接 需要报告的 App类型信息
     * @return  @Defs.ContextInformation MirrorLink App类型
     */

     int getAppCategory();

    /**
     * 返回MirrorLink连接 需要报告的 帧缓存类型信息
     * @return MirrorLink 帧缓存类型
     */

     int getFrameCategory();

    /**
     * 返回MirrorLink连接 需要报告的 App是否处理帧缓存阻塞事件
     * @return true 处理 false 不处理
     */

     boolean isHandleFramebufferBlock();

    /**
     * 返回MirrorLink连接 需要报告的 音频类型信息
     * @return  MirrorLink 音频类型
     */

     int[] getAudioCategory();

    /**
     * 返回MirrorLink连接 需要报告的 App是否有音频输出
     * @return true 有 false 无
     */

     boolean hasAudio();

    /**
     * 返回MirrorLink连接 需要报告的 App是否处理音频阻塞事件
     * @return true 处理 false 不处理
     */

     boolean isHandleAudioBlock();
    /**
     * MirrorLink 车机客户端显示属性改变事件
     * @param manager  MirrorLink 显示管理器
     */

     void onMirrorLinkDeviceDisplayChanged(final IMirrorLinkManager manager);

    /**
     * MirrorLink 会话状态改变事件，需通过MirrorLinkConnectionManager 获取会话状态
     * 缺省处理将根据会话状态调整屏幕方向，会话建立将自动横屏，会话断开将退出横屏
     * @param manager MirrorLinkConnectionManager
     */

     void onMirrorLinkSessionChanged(IMirrorLinkManager manager);




    //MirrorLinkContextManager Interactors

    /**
     * MirrorLink 车机客户端帧缓存阻塞事件
     * @param manager MirrorLinkContextManager
     */

     void onFramebufferBlocked(IMirrorLinkManager manager);

    /**
     * MirrorLink 车机客户音频阻塞事件
     * @param manager MirrorLinkContextManager
     */

     void onAudioBlocked(IMirrorLinkManager manager);

    /**
     * MirrorLink 车机客户端帧缓存阻塞解除事件
     * @param manager MirrorLinkContextManager
     */

     void onFramebufferUnblocked(IMirrorLinkManager manager);

    /**
     * MirrorLink 车机客户端音频阻塞解除事件
     * @param manager MirrorLinkContextManager
     */

     void onAudioUnblocked(IMirrorLinkManager manager);


    //MirrorLinkDeviceManager Interactors
    /**
     * MirrorLink 车机客户端夜间模式事件，需通过MirrorLinkDeviceManager 获取当前是否为夜间模式
     * 需要针对夜间模式进行UI适配时请重载该方法
     * @param manager MirrorLinkDeviceManager
     */

     void onNightModeChanged(IMirrorLinkManager manager);

    /**
     * MirrorLink 车机客户端话筒状态事件，需通过MirrorLinkDeviceManager 获取车机话筒当前前状态
     * 语音识别需要关注该事件则请重载该方法
     * @param manager MirrorLinkDeviceManager
     */

     void onMicrophoneStatusChanged(IMirrorLinkManager manager);


    /**
     * MirrorLink 车机客户端驾驶模式事件，需通过MirrorLinkDeviceManager 获取车机当前是否进入驾驶模式
     * 需要针对驾驶模式进行功能限制时请重载该方法
     * @param manager MirrorLinkDeviceManager
     */

     void onDriveModeChange(IMirrorLinkManager manager);



    /**
     * MirrorLink 车机客户端旋钮平移事件回调
     * @param nKnobID 旋钮ID
     * @param dir 平移方向
     */
     void onMirrorLinkClientKnobKeyShift(int nKnobID,MirrorLinkEvent.KnobShiftDirection dir);


    /**
     * MirrorLink 车机客户端旋钮按压事件回调
     * @param nKnobID 旋钮ID
     */
     void onMirrorLinkClientKnobKeyPush(int nKnobID);

    /**
     * MirrorLink 车机客户端旋钮按旋转件回调
     * @param nKnobID 旋钮ID
     * @param dir 旋转方向
     */
     void onMirrorLinkClientKnobKeyRotate(int nKnobID,MirrorLinkEvent.KnobRotateAxis axis,MirrorLinkEvent.KnobRotateDirection dir);

    /**
     * MirrorLink 车机客户端旋钮拉拔事件回调
     * @param nKnobID 旋钮ID
     */
     void onMirrorLinkClientKnobKeyPull(int nKnobID);


    /**
     * MirrorLink 车机客户端ITU按钮按压事件回调
     * @param keyid  ITU按钮ID
     */
     void onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey keyid);

    /**
     * MirrorLink 车机客户端车机设备按钮按压事件回调
     * @param keyid 按钮ID
     */
     void onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey keyid);

    /**
     * MirrorLink 车机客户端功能键按压事件回调
     * @param nKeyID 按钮ID
     */
     void onMirrorLinkClientFunctionKeyDown(int nKeyID);


    /**
     * MirrorLink 车机客户端多媒体按键按压事件回调
     * @param keyid 按钮ID
     */
     void onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey keyid);




}
