package com.navinfo.wenavi.controller;

import android.content.Context;

import com.navinfo.wenavi.model.POITypeModel;
import com.navinfo.wenavi.model.Repository;

/**
 * Created by liubao on 15/3/21.
 */
public class Page_01301_Controller extends GisController {

    public static final String CMD_LOAD_POI_TYPE="CMD_LOAD_POI_TYPE";

    public static final String CMD_SEARCH_POI_TYPE_BY_NAME="CMD_SEARCH_POI_TYPE_BY_NAME";

    public static final String RET_UPDATE_POI_TYPE_LIST="RET_UPDATE_POI_TYPE_LIST";

    public Page_01301_Controller(Context context) {
        super(context);
        POITypeModel model =(POITypeModel) getContext().getModel(POITypeModel.class.getName());
        model.loadPOIType();
    }

    @Override
    public void executeAction(Object... actionDatas) {
        if (actionDatas.length > 0) {
            if (actionDatas[0].getClass().equals(String.class)) {
                String sCms = (String) (actionDatas[0]);

                POITypeModel model =(POITypeModel) getContext().getModel(POITypeModel.class.getName());
                switch (sCms)
                {
                    case CMD_LOAD_POI_TYPE:
                        model.loadPOIType();
                        break;
                    case CMD_SEARCH_POI_TYPE_BY_NAME:
                        if(actionDatas.length > 1) {
                            String typeName = (String)(actionDatas[1]);
                            updateView(RET_UPDATE_POI_TYPE_LIST,model.getPoiTypeEntitities(typeName));
                        }
                        break;
                    default:
                        super.executeAction(actionDatas);
                        break;
                }
            }
        }
    }
}
