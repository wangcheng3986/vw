package com.navinfo.wenavi.activity;

import android.annotation.TargetApi;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.navinfo.audio.AudioRecongniseError;
import com.navinfo.audio.IAudioGenerateListerner;
import com.navinfo.audio.IAudioGenerator;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.controller.AudioController;
import com.navinfo.wenavi.controller.IController;
import com.navinfo.wenavi.controller.Page_01401_Controller;
import com.navinfo.wenavi.entity.AppConfig;
import com.navinfo.wenavi.model.Repository;
import com.navinfo.wenavi.model.WeNaviInternalMessage;
import com.navinfo.wenavi.util.NetWork;
import com.navinfo.wenavi.util.WeNaviDefine;

/**
 * Created by Doone on 2015/3/7.
 */
public class Page_00000_Fragment extends WeNaviBaseFragment {
    public static int mwidth;
    public static int mheight;
    private final static String LOG_TAG = Page_00000_Fragment.class.getCanonicalName();

    Button mBtGo = null; //行车道航
    Button mBtMap = null; //周边查询
    Button mBtNavi = null; //戴航记录
    Button mBtGas = null; //加油站

    Button mBtAbouit;//关于

    Button btAudio = null; //语音
    boolean mIsReconising = false;

    boolean mFirstTime = true;

    int mWidth = 2560;//全屏横向分辨率
    int mMH = 198;//横向间距
    int mMP = 70;//纵向间距
    int mMC = 28;//中间间距
    int mAudioWidth = 624;//语音按钮宽

    int mGridWidth = 1054;//四个功能按钮宽度
    int mGridHigh = 622;//四个功能按钮高度


    //免责声明
    private Button btnDisclaimer;
    private LinearLayout linearLayoutDisclaimer;
    private CheckBox checkBoxDisclaimer;

    @Override
    public boolean onHandlerMessage(Message msg) {
        switch (msg.what) {
            case 0:
            {
                showConfirm("提示", "网络不可用，请设置！",new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //int which = (int) o;
                        if (which != 0) return;
                        try {
                            Intent intent = new Intent(Settings.ACTION_SETTINGS);
                            startActivityForResult(intent, 0);
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }

                    }
                });

            }
            return true;

        }
        return super.onHandlerMessage(msg);
    }

    @Override
    public void onActionUpdate(Object... datas) {
        if (datas.length > 0) {
            if (datas[0].getClass().equals(String.class)) {
                String sCms = (String) (datas[0]);
                //Log.e(LOG_TAG,"GisController Command= "+sCms);
                if (sCms.equals(AudioController.RET_RECONGNISE_FINISHED)) { //识别结束
                    onRecongniseFinished();
                } else if (sCms.equals(AudioController.RET_RECONGNISE) && datas.length > 1) { //识别结果
                    onRecongnised((String) datas[1]);
                } else if (sCms.equals(AudioController.RET_RECONGNISE_ERROR) && datas.length > 3) { //识别错误
                    onRecongniseError((AudioRecongniseError) datas[1], (int) datas[2], (String) datas[3]);
                } else if (sCms.equals(AudioController.RET_RECORD_START)) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {
                                btAudio.setBackgroundResource(R.drawable.ui_00000_sound);
                                //btAudio.invalidate();
                            }
                        });

                    }

                } else if (sCms.equals(AudioController.RET_RECONGNISE_START)) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(new Runnable() {
                            public void run() {
                                btAudio.setBackgroundResource(R.drawable.ui_00000_sound_2);
                                //btAudio.invalidate();
                            }
                        });

                    }

                }
                /*else if (sCms.equals(AudioController.RET_NEWWORK_DISABLED)){
                    Log.d("","network is enabled");
                    showAlertDlg();

                }*/
                else super.onActionUpdate(datas);

            }
        }
    }


    public void onRecongniseFinished() {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                public void run() {
                    btAudio.setEnabled(true);
                    btAudio.setBackgroundResource(R.drawable.main_speech_bg);
                }
            });
        }

    }

    public void onRecongniseError(AudioRecongniseError e, int errCode, final String sError) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                public void run() {
                    btAudio.setEnabled(true);
                    btAudio.setBackgroundResource(R.drawable.main_speech_bg);
                    // btAudio.setChecked(false);

                    //Toast.makeText(getActivity(), "语音识别错误:" + sError, Toast.LENGTH_LONG).show();

                }
            });

        }

    }


    public void onRecongnised(final String sText) {

        IController c=getController();
        IAudioGenerator p=null;
        if(c!=null)
            p = (IAudioGenerator) c.getObject(IAudioGenerator.class.getCanonicalName());

        if (sText.indexOf(getResources().getString(R.string.audio_command_go)) != -1) {


            // p = (IAudioGenerator) getController().getObject(IAudioGenerator.class.getCanonicalName());
            if(p!=null) {
                p.play(getResources().getString(R.string.audio_command_enter) +
                        getResources().getString(R.string.audio_command_go), new IAudioGenerateListerner() {
                    @Override
                    public void onError(String sError) {

                    }

                    @Override
                    public void onPlayFinished() {
                        if (getActivity() != null) {
                            getActivity().runOnUiThread(new Runnable() {
                                public void run() {
                                    // btAudio.setEnabled(true);
                                    // btAudio.setChecked(false);

                                    //toPage(Page_02201_Fragment.class);
                                    mBtGo.performClick();
                                }
                            });
                        }
                    }

                });

            }


        } else if (sText.indexOf(getResources().getString(R.string.audio_command_map)) != -1) {
            //IAudioGenerator p = (IAudioGenerator) getController().getObject(IAudioGenerator.class.getCanonicalName());
            if(p!=null)
            {
                p.play(getResources().getString(R.string.audio_command_enter) +
                        getResources().getString(R.string.audio_command_map), new IAudioGenerateListerner() {
                    @Override
                    public void onError(String sError) {

                    }

                    @Override
                    public void onPlayFinished() {
                        if (getActivity() != null) {
                            getActivity().runOnUiThread(new Runnable() {
                                public void run() {
                                    // btAudio.setEnabled(true);
                                    // btAudio.setChecked(false);

                                    //toPage(Page_01101_Fragment.class);
                                    //toPage(Page_01301_Fragment.class);
                                    mBtMap.performClick();
                                }
                            });
                        }
                    }

                });
            }


        }
        else if (sText.indexOf(getResources().getString(R.string.audio_command_gas)) != -1) {
            //IAudioGenerator p = (IAudioGenerator) getController().getObject(IAudioGenerator.class.getCanonicalName());
            if(p!=null)
            {
                p.play(getResources().getString(R.string.audio_command_enter) +
                        getResources().getString(R.string.audio_command_gas), new IAudioGenerateListerner() {
                    @Override
                    public void onError(String sError) {

                    }

                    @Override
                    public void onPlayFinished() {
                        if (getActivity() != null) {
                            getActivity().runOnUiThread(new Runnable() {
                                public void run() {
                                    // btAudio.setEnabled(true);
                                    // btAudio.setChecked(false);

                                    //toPage(Page_01101_Fragment.class);
                                    //toPage(Page_01301_Fragment.class);

                                    mBtGas.performClick();
                                }
                            });
                        }
                    }

                });
            }


        }
        else if (sText.indexOf(getResources().getString(R.string.audio_command_navigate)) != -1) {
            //IAudioGenerator p = (IAudioGenerator) getController().getObject(IAudioGenerator.class.getCanonicalName());
            if(p!=null) {
                p.play(getResources().getString(R.string.audio_command_enter) +
                        getResources().getString(R.string.audio_command_navigate), new IAudioGenerateListerner() {
                    @Override
                    public void onError(String sError) {

                    }

                    @Override
                    public void onPlayFinished() {
                        if (getActivity() != null) {
                            getActivity().runOnUiThread(new Runnable() {
                                public void run() {
                                    mBtNavi.performClick();
                                }
                            });
                        }
                    }

                });
            }


        }
       else {

            if (getActivity() != null) {
                getActivity().runOnUiThread(new Runnable() {
                    public void run() {
                        WeNaviInternalMessage m=new WeNaviInternalMessage(
                                Page_00000_Fragment.class,
                                Page_02201_Fragment.class,
                                WeNaviDefine.MSG_REQUEST_KEYWORD,
                                null);
                        m.setKeyword(sText);
                        toPage(Page_02201_Fragment.class,m.toBundle());
                    }
                });
            }


        }
    }


    @Override
    protected int getFragmentLayoutID() {
        return R.layout.page_00000;
    }



    /**
     * 初始化控件为不可用,页面初始化时调用
     */
    @Override
    public  void onDisableControl()
    {
        //mBtGo.setEnabled(false);

    }

    /**
     * 初始化控件为可用,页面初始化完成后被延时调用
     */
    @Override
    public  void onEnableControl()
    {
        //mBtGo.setEnabled(true);
    }


    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    protected void bindUIControl(View v) {

        checkBoxDisclaimer = (CheckBox) v.findViewById(R.id.cb_ui0000_accept);

        checkBoxDisclaimer.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

            }
        });

        linearLayoutDisclaimer = (LinearLayout) v.findViewById(R.id.ll_ui00000_disclaimer);
        btnDisclaimer = (Button) v.findViewById(R.id.bt_ui00000_accept);
        btnDisclaimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linearLayoutDisclaimer.setVisibility(View.GONE);
                WeNaviBaseActivity.aBooleanAccept = true;
                if (WeNaviBaseActivity.aBooleanAccept) {
                    AppConfig c = Repository.getAppConfig("discalaimerHasShowed");
                    if (c == null) {
                        c = new AppConfig();
                        c.setParamName("discalaimerHasShowed");
                        c.setParamValue("Y");
                        c.save();

                    }
                }

            }
        });


        mBtGo = (Button) v.findViewById(R.id.buttonGo);// 右上角
        mBtMap = (Button) v.findViewById(R.id.buttonMap); //左上角
        mBtNavi = (Button) v.findViewById(R.id.buttonNavigate); //右下角

        mBtGas = (Button) v.findViewById(R.id.buttonGas);

        btAudio = (Button) v.findViewById(R.id.btAudio);

        mBtAbouit = (Button) v.findViewById(R.id.bt_ui00000_about);
        mBtAbouit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPage(Page_06201_Fragment.class);
            }
        });

        LinearLayout mfl = (LinearLayout) v.findViewById(R.id.layoutroot);
        if (mfl != null) {

            //以下暂时的一些切图尺寸
            DisplayMetrics metric = new DisplayMetrics();
            getActivity().getWindowManager().getDefaultDisplay().getMetrics(metric);
            int width = metric.widthPixels;  // 屏幕宽度（像素）
            int height = metric.heightPixels;  // 屏幕高度（像素）
            mwidth = width;
            mheight = height;
            float density = metric.density;  // 屏幕密度（0.75 / 1.0 / 1.5）
            int densityDpi = metric.densityDpi;  // 屏幕密度DPI（120 / 160 / 240）
            Log.d(LOG_TAG, "width=" + width);//width=1794
            Log.d(LOG_TAG, "height=" + height);//height=1080

            if ((width * 9) != (height * 16)) {

                //重新布局
                FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(mAudioWidth * width / mWidth, mAudioWidth * width / mWidth);
                params.gravity = Gravity.CENTER;
                btAudio.setLayoutParams(params);


                FrameLayout frameLayout = (FrameLayout) v.findViewById(R.id.fl_page_00000);
                ViewGroup.LayoutParams layoutParams = frameLayout.getLayoutParams();
                LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(width-(int)(98*density)-(int)(21*density),height-(int)(57.5*density));

                lp1.setMargins(0, 85, 0,70);
                lp1.gravity = Gravity.CENTER;
                frameLayout.setLayoutParams(lp1);

            }

//            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(mAudioWidth*width/mWidth,mAudioWidth*width/mWidth);
//            params.gravity = Gravity.CENTER;
//            btAudio.setLayoutParams(params);
//
//
//
//            mfl.setPadding(mMH*width/mWidth,mMP*width/mWidth,mMH*width/mWidth,mMP*width/mWidth);
//
//
//            //left,top,right,bott
//            LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(mGridWidth*width/mWidth,mGridHigh*width/mWidth);
//            lp1.setMargins(0,0,mMC*width/mWidth,mMC*width/mWidth);
//            mBtMap.setLayoutParams(lp1);
//
//            LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(mGridWidth*width/mWidth,mGridHigh*width/mWidth);
//            lp2.setMargins(mMC*width/mWidth,0,0,mMC*width/mWidth);
//            mBtGo.setLayoutParams(lp2);
//
//            LinearLayout.LayoutParams lp3 = new LinearLayout.LayoutParams(mGridWidth*width/mWidth,mGridHigh*width/mWidth);
//            lp3.setMargins(0,mMC*width/mWidth,mMC*width/mWidth,0);
//            mBtGas.setLayoutParams(lp3);
//
//            LinearLayout.LayoutParams lp4 = new LinearLayout.LayoutParams(mGridWidth*width/mWidth,mGridHigh*width/mWidth);
//            lp4.setMargins(mMC*width/mWidth,mMC*width/mWidth,0,0);
//            mBtNavi.setLayoutParams(lp4);


        }


        mBtGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //toPage(Page_02201_Fragment.class);
                toPage(Page_02201_Fragment.class);


            }
        });


        mBtMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(Page_01_Activity.this.getApplicationContext(),
                //        String.format("BtMap clicked"), Toast.LENGTH_LONG).show();

                //
                //toPage(Page_01101_Fragment.class);

                toPage(Page_01301_Fragment.class);

            }
        });


        mBtNavi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                toPage(Page_04201_Fragment.class);

            }
        });

        mBtGas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(getActivity().getApplicationContext(),
               //         String.format("mBtGas clicked"), Toast.LENGTH_LONG).show();
                WeNaviInternalMessage m=new WeNaviInternalMessage(
                        Page_00000_Fragment.this.getClass(),
                        Page_01401_Fragment.class,
                        WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME,
                        null);

                //m.set(Page_01401_Controller.POI_SEARCH_TYPE_KEYWORD);
                m.setKeyword("加油站");

                toPage(Page_01401_Fragment.class, m.toBundle());

            }
        });


        btAudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*SoundPool p = new SoundPool(16, AudioManager.STREAM_NOTIFICATION, 0);
                int hitOkSfx = p.load(getActivity(), R.raw.ding, 0);
                int state = p.play(hitOkSfx, 1, 1, 1, 0, 1);
                if (state != 0) {


                }
                Log.e(LOG_TAG, "hitOkSfx=" + hitOkSfx + " State=" + state);*/

                submitAction(AudioController.CMD_START_RECONGNISE_AFTER_NOTIFY,
                        getResources().getString(R.string.audio_command_say),
                        AudioController.HCI_NOMAL_RECONGNISER);
            }
        });


    }

    @Override
    public void onBack() {

         showConfirm(getResources().getString(R.string.alert_title_exit),
                getResources().getString(R.string.alert_message_exit),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0 || which == -1) {

                            Page_00000_Fragment.this.mBtMap.setEnabled(false);
                            Page_00000_Fragment.this.mBtNavi.setEnabled(false);
                            Page_00000_Fragment.this.mBtGo.setEnabled(false);
                            Page_00000_Fragment.this.mBtGas.setEnabled(false);
                            Page_00000_Fragment.this.btAudio.setEnabled(false);
                            Page_00000_Fragment.this.mBtAbouit.setEnabled(false);


                            if(NetWork.isConnected(getActivity())) {
                                IAudioGenerator p = (IAudioGenerator) getController().getObject(IAudioGenerator.class.getCanonicalName());
                                p.play(getResources().getString(R.string.audio_command_bay), new IAudioGenerateListerner() {
                                    @Override
                                    public void onError(String sError) {
                                        //Page_00000_Fragment.this.doBack();
                                    }

                                    @Override
                                    public void onPlayFinished() {
                                        //Page_00000_Fragment.this.doBack();
                                    }
                                });
                            }

                            Page_00000_Fragment.this.doBack();
                        }
                    }
                }
        );


    }


    void doBack()
    {
        super.onBack();
    }

    @Override
    public void onResume() {
        super.onResume();
        //mAudioRecongniser.launch();


        AppConfig c = Repository.getAppConfig("discalaimerHasShowed");
        if (c != null) {
            if (c.getParamValue().equals("Y")) {
                linearLayoutDisclaimer.setVisibility(View.GONE);
            } else {
                if (WeNaviBaseActivity.aBooleanAccept) {
                    linearLayoutDisclaimer.setVisibility(View.GONE);
                }
            }
        }

        btAudio.setEnabled(true);
        btAudio.setBackgroundResource(R.drawable.main_speech_bg);
        if (mFirstTime) {
            mFirstTime = false;
            submitAction(AudioController.CMD_PLAY, getResources().getString(R.string.audio_command_welcome_audio));
            submitAction(AudioController.CMD_IS_NEWWORK_ENABLED);
        }

    }

    @Override
    public void onPause() {

        //mAudioRecongniser.stop();
        super.onPause();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        //mAudioRecongniser.stop();
    }

    @Override
    public void restoreViewStatus(Bundle status) {
        if (status.containsKey("isFirstTime")) {
            mFirstTime = status.getBoolean("isFirstTime");
        }
    }

    @Override
    public Bundle getViewStatus() {
        Bundle status = new Bundle();
        status.putBoolean("isFirstTime", mFirstTime);
        return status;
    }



    private void showAlertDlg(){

        messageHandler.sendEmptyMessageDelayed(0,1000);

    }
}
