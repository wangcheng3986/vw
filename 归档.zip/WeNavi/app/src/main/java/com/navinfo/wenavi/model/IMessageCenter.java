package com.navinfo.wenavi.model;

/**
 * Created by Doone on 2015/3/21.
 */
public  interface IMessageCenter {

    public void sendMessage(IMessage m);

    public IMessage queryMessage(String receiver);


}