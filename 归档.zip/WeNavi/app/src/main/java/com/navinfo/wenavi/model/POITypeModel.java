package com.navinfo.wenavi.model;

import java.util.ArrayList;
import java.util.List;
import android.content.Context;
import android.util.Log;

import com.navinfo.sdk.mapapi.search.core.POIKind;
import com.navinfo.sdk.mapapi.search.core.POIPKind;
import com.navinfo.sdk.mapapi.search.core.POISKind;
import com.navinfo.sdk.mapapi.search.poikind.OnGetPOIKindSearchResultListener;
import com.navinfo.sdk.mapapi.search.poikind.POIKindSearchResult;
import com.navinfo.sdk.mapapi.search.poikind.POIKindSearcher;
import com.navinfo.wenavi.entity.POITypeEntity;

/**
 * Created by liubao on 15/3/16.
 * POI类别的查询Model，负责POI类别的查询以及POI类别查询器的创建及销毁管理
 */
public class POITypeModel extends BaseModel {

    private static POIKindSearcher searcher = POIKindSearcher.newInstance();
    private static List<POISKind> poiSKindList;

    public static List<POISKind> getPOIpoiSKindList() {
        return poiSKindList;
    }

    public POITypeModel(Context c) {

        super(c);

        searcher.setOnGetPOIKindSearchResultListener(new OnGetPOIKindSearchResultListener() {
            @Override
            public void onGetPOIKindSearchResult(POIKindSearchResult poiKindSearchResult) {
                poiSKindList = poiKindSearchResult.skinds;
                if(poiSKindList!=null) Log.e(POITypeModel.class.getCanonicalName(),"POIKind result "+poiSKindList.size());
            }
        });
    }

    public void loadPOIType() {
        if(poiSKindList == null){
            searcher.search();
        }
//        POIKind kind1 = new POIKind();
//        kind1.code = "4080";
//        kind1.name = "加油站";
//        POIKind kind2 = new POIKind();
//        kind2.code = "7200";
//        kind2.name = "医院";
//        POIKind kind3 = new POIKind();
//        kind3.code = "8080";
//        kind3.name = "医院";
//        POIKind kind4 = new POIKind();
//        kind4.code = "1602";
//        kind4.name = "咖啡店";
//        POIKind kind5 = new POIKind();
//        kind5.code = "7880";
//        kind5.name = "厕所";
//        POIPKind pkind = new POIPKind();
//        pkind.name = "示例";
//        pkind.kinds = new ArrayList<POIKind>(5);
//        pkind.kinds.add(kind1);
//        pkind.kinds.add(kind2);
//        pkind.kinds.add(kind3);
//        pkind.kinds.add(kind4);
//        pkind.kinds.add(kind5);
//        POISKind skind = new POISKind();
//        skind.name = "示例";
//        skind.pkinds = new ArrayList<POIPKind>(1);
//        skind.pkinds.add(pkind);
//        poiSKindList = new ArrayList<POISKind>(1);
//        poiSKindList.add(skind);
    }

    public POITypeEntity[] getTopPoiTypeEntities(){
        if(poiSKindList != null){
            ArrayList<POITypeEntity> typeEntityList = new ArrayList<POITypeEntity>(poiSKindList.size());

            for (int i = 0; i < poiSKindList.size(); i++) {
                POISKind skind = poiSKindList.get(i);
                if(skind != null){
                    POITypeEntity entity = new POITypeEntity(null, skind.name, 1);
                    typeEntityList.add(entity);
                }
            }
            return typeEntityList.toArray(new POITypeEntity[0]);
        }

        return null;
    }

    public POITypeEntity[] getSubPoiTypeEntities(POITypeEntity parentEntity) {
        //TODO:调用POITypeSearcher获取
        return null;
    }

    public POITypeEntity[] getPoiTypeEntitities(String typeName) {

        if(poiSKindList != null){
            ArrayList<POITypeEntity> typeEntityList = new ArrayList<POITypeEntity>(poiSKindList.size());

            for (int i = 0; i < poiSKindList.size(); i++) {
                POISKind skind = poiSKindList.get(i);
                if(skind != null){
                    for (int j = 0; j < skind.pkinds.size(); j++) {
                        POIPKind pkind = skind.pkinds.get(j);
                        if(pkind != null){
                            for (int k = 0; k < pkind.kinds.size(); k++) {
                                POIKind kind = pkind.kinds.get(k);
                                if(kind != null){
                                    POITypeEntity entity = new POITypeEntity(kind.code, kind.name, 3);
                                    if(kind.name.contains(typeName) || (typeName == null || typeName.trim() == "")) {
                                        if (typeEntityList.contains(entity)) {
                                            POITypeEntity exitEntity = typeEntityList.get(typeEntityList.indexOf(entity));
                                            String existCode = exitEntity.getTypeCode();
                                            existCode = existCode + "," + entity.getTypeCode();
                                            if (existCode.startsWith(",")) {
                                                existCode = existCode.substring(1);
                                            }
                                            exitEntity.setTypeCode(existCode);
                                        } else {
                                            typeEntityList.add(entity);
                                        }
                                    }else{

                                    }
                                }
                            }
                        }
                    }
                }
            }
            return typeEntityList.toArray(new POITypeEntity[0]);
        }

        return null;
    }


    @Override
    public void destroy() {
        //TODO:销毁POITypeSearcher
    }

    @Override
    public void loadModel() {
        //TODO:创建POITypeSearcher
    }

}
