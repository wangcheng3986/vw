package com.navinfo.wenavi.model;

import android.os.Bundle;

/**
 * Created by Doone on 2015/3/21.
 */
public  interface IMessage {

    public Bundle toBundle();


    public String getSender();

    public void setSender(String sSender);


    public String getReceiver();

    public void setReceiver(String sReceiver);


    public String getMessageType();

    public String setMessageType(String sType);


    public Bundle getContent();
}