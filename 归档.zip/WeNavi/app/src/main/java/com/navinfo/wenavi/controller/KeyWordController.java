package com.navinfo.wenavi.controller;

import android.content.Context;

import com.navinfo.sdk.mapapi.search.poi.POISearcher;

/**
 * Created by min on 2015/3/10.
 * 本页面提供关键字搜索、语音识别、历史记录查询等业务逻辑服务
 *
 */
public class KeyWordController extends GisController {

    //关键字查询功能代码
    public static final String KEY_WORD_SEARCH = "KEY_WORD_SEARCH";

    //语音识别
    public static final String AUDIO_RECOGNIZE = "AUDIO_RECOGNIZE";

    //历史记录
    public static final String HIS_RECORD_SEARCH = "HIS_RECORD_SEARCH";

    private POISearcher searcher = null;

    public KeyWordController(Context context) {
        super(context);

        searcher = POISearcher.newInstance();
    }





    @Override
    public void executeAction(Object... actionDatas) {
        if (actionDatas.length>0){
            if(actionDatas[0].getClass().equals(String.class)){
                String s = (String)actionDatas[0];
                if(s.equals(KEY_WORD_SEARCH)){

                }else if(s.equals(AUDIO_RECOGNIZE)){

                }else if(s.equals(HIS_RECORD_SEARCH)){

                }
                else{
                    super.executeAction(actionDatas);
                }
            }
        }



        //super.executeAction(actionDatas);
    }


    @Override
    public void onRecongnised(String s) {
        super.onRecongnised(s);
    }
}
