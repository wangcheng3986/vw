package com.navinfo.wenavi.entity;

import java.io.Serializable;

/**
 * Created by liubao on 15/3/16.
 * POIType实体类
 */
public class POITypeEntity implements Serializable {
    private String typeCode;
    private String typeName;
    private int typeGrade;

    /**
     * 实例化一个POIType实体对象
     */
    public POITypeEntity() {}

    /**
     * 实例化一个POIType实体对象
     * @param typeCode 类别编码
     * @param typeName 类别名称
     * @param typeGrade 类别等级
     */
    public POITypeEntity(String typeCode, String typeName, int typeGrade) {
        this.typeCode = typeCode;
        this.typeName = typeName;
        this.typeGrade = typeGrade;
    }


    /**
     * 获取类别编码
     * @return 类别编码
     */
    public String getTypeCode() {
        return typeCode;
    }

    /**
     * 设置类别编码
     * @param typecode 类别编码
     */
    public void setTypeCode(String typecode) {
        this.typeCode = typecode;
    }

    /**
     * 获取类别名称
     * @return 类别名称
     */
    public String getTypeName() {
        return typeName;
    }

    /**
     * 设置类别名称
     * @param typename 类别名称
     */
    public void setTypeName(String typename) {
        this.typeName = typename;
    }

    /**
     * 获取类别等级
     * @return 类别等级
     */
    public int getTypeGrade() {
        return typeGrade;
    }

    /**
     * 设置类别等级
     * @param typegrade 类别等级
     */
    public void setTypeGrade(int typegrade) {
        this.typeGrade = typegrade;
    }

    @Override
    public boolean equals(Object o){
        POITypeEntity poiTypeEntity = (POITypeEntity)o;
        if(poiTypeEntity != null){
            return this.getTypeName().trim().equals(poiTypeEntity.getTypeName().trim());
        }

        return false;
    }
}
