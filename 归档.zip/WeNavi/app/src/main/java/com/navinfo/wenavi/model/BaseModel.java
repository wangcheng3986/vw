package com.navinfo.wenavi.model;

import android.content.Context;

/**
 * Created by Doone on 2015/2/5.
 * Model 抽象基类
 */
public abstract class BaseModel implements IModel{

    private WeNaviApplication mContext=null;

    public BaseModel(Context c)
    {
        mContext=(WeNaviApplication)c;
    }

    public WeNaviApplication getContext() {

        return mContext;
    }


    @Override
    public Object getObject(String sName) {
        return null;
    }

    @Override
    public void destroy() {

    }

    @Override
    public boolean saveObject(Object o) {
        return false;
    }

    @Override
    public void loadModel() {

    }

    @Override
    public boolean saveModel() {
        return false;
    }
}
