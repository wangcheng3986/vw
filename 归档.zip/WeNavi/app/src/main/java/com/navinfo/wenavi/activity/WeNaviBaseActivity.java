package com.navinfo.wenavi.activity;


import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mirrorlink.android.commonapi.Defs;
import com.navinfo.audio.AudioRecongniseError;
import com.navinfo.audio.AudioRecongniseStatus;
import com.navinfo.audio.IAudioGenerator;
import com.navinfo.audio.IAudioRecongniseListener;
import com.navinfo.audio.IAudioRecongniser;
import com.navinfo.mirrorlink.IMirrorLinkManager;
import com.navinfo.mirrorlink.MirrorLinkBaseActivity;
import com.navinfo.mirrorlink.MirrorLinkConnectionManager;
import com.navinfo.mirrorlink.MirrorLinkContextManager;
import com.navinfo.mirrorlink.MirrorLinkDeviceManager;
import com.navinfo.mirrorlink.MirrorLinkDisplayManager;

import com.navinfo.mirrorlink.MirrorLinkEvent;
import com.navinfo.mirrorlink.MirrorLinkNotificationManager;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.controller.AudioController;
import com.navinfo.wenavi.controller.IController;
import com.navinfo.wenavi.model.WeNaviApplication;
import com.navinfo.wenavi.util.WeNaviUtil;

import java.util.Stack;

/**
 * Created by Doone on 2015/1/28.
 * 视图基类，继承MirrorLinkBaseActivity
 */
public abstract class WeNaviBaseActivity extends MirrorLinkBaseActivity implements IViewManager, IView {

    private final static String LOG_TAG = WeNaviBaseActivity.class.getCanonicalName();

    protected IController mController = null;
    protected IView mCurrentView = null;

    protected String mHomePageTag = null;

    protected Class<?> mCurrentPageClass = null;

    Stack<Class<?>> mPageStack = new Stack<Class<?>>();

    Stack<Class<?>> mBranchPageStack = new Stack<Class<?>>();


    //免责声明下次不再显示
    public static Boolean aBooleanAccept = true;


    //控制器相关实现方法========================================================

    /**
     * 返回需要控制器Contoller类型，Activity在创建时将自动获取该类型控制器
     *
     * @return Controller 类名
     */
    protected String getControllerName() {
        return AudioController.class.getCanonicalName();
    }


    @Override
    public IController getController() {
        //设置视图控制器
        if (mController == null) {
            String sControllerName = getControllerName();
            if (sControllerName != null && sControllerName.length() > 0) {
                IController c = ((WeNaviApplication) getApplicationContext()).getController(sControllerName);
                if (c != null) c.attachView(this);
            }
        }
        return mController;
    }

    @Override
    public void setController(IController c) {
        mController = c;
    }

    @Override
    public abstract void onActionUpdate(Object... datas);


    @Override
    public Object getParameters() {
        return null;
    }


    @Override
    public void setParameters(Object parameters) {

    }

    /**
     * 提交业务功能请求给Controller
     *
     * @param actionDatas 功能参数
     */
    @Override
    public void submitAction(Object... actionDatas) {
        if (mController != null) mController.executeAction(actionDatas);
    }

    //////////////////////////////////////////////////////////////////////////////////////////


    ////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.e(this.getClass().getCanonicalName(), "onCreate");
        super.onCreate(savedInstanceState);

        /**
         * 设置为横屏
         */
       /* if(getRequestedOrientation()!= ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE){
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }*/

        //设置视图控制器
        String sControllerName = getControllerName();
        if (sControllerName != null && sControllerName.length() > 0) {
            IController c = ((WeNaviApplication) getApplicationContext()).getController(sControllerName);
            if (c != null) c.attachView(this);
        }


        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

    }


    /////////////UI 加载及UI文字动态适配//////////////////////////////////////////////
    protected abstract void onLoadUi(Configuration configuration);

    @Override
    protected final void loadUi(Configuration configuration) {
        if (configuration != null) return;

        if (getCurrentView() == null) {
            onLoadUi(configuration);
            updateUiTextSize();
        }

    }


    protected void updateUiTextSize() {
        //统一调整文字大小
        final ViewGroup root = (ViewGroup) findViewById(R.id.layoutroot);
        if (root != null) WeNaviUtil.updateUiTextSize(this, root);
        //setFontSize(root,getDefaultTextSize());
    }


    ///// 生命周期管理 //////////////////////////////////////////////////////////////////////////
    @Override
    protected void onRestart() {
        super.onRestart();
        if (mController != null) mController.onViewRestart();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mController != null) mController.onViewStart();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (getController() != null) {
            mController.attachView(this);
            mController.onViewResume();
        } else
            Log.e(LOG_TAG, "Controller NULL!!!!");

        Log.e(this.getClass().getCanonicalName(), "onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mController != null) mController.onViewPause();

        Log.e(this.getClass().getCanonicalName(), "onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mController != null) mController.onViewStop();
    }

    @Override
    protected void onDestroy() {
        Log.e(this.getClass().getCanonicalName(), "onDestroy");
        super.onDestroy();
        if (mController != null) mController.onViewDestroy();


    }


    public void onBackKeyDown() {
        Log.e(this.getClass().getCanonicalName(), "onBackKeyDown");
        if (getCurrentView() != null) getCurrentView().onBack();
        else onBack();
    }


    ///////////媒体音量控制/////////////////////////////////////////////////////////////////
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {


        //WeNaviAlertDialog d = new WeNaviAlertDialog(WeNaviBaseActivity.this);
        //d.showMessage("车机按键","按键值:"+keyCode,null);


        if (keyCode == KeyEvent.KEYCODE_BACK) {
            onBackKeyDown();

            return true;
        }


        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
                keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {

            //音量控制,初始化定义
            AudioManager audioManager = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);

            //最大音量
            int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

            //当前音量
            int currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);

            switch (keyCode) {
                // 音量减小
                case KeyEvent.KEYCODE_VOLUME_DOWN:

                    currentVolume -= 1;
                    if (currentVolume <= 0) currentVolume = 0;
                    break;
                // 音量增大
                case KeyEvent.KEYCODE_VOLUME_UP:
                    currentVolume += 1;
                    if (currentVolume > maxVolume) currentVolume = maxVolume;
                    break;
            }

            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, currentVolume, 1);

            return true;
        }

        return super.onKeyDown(keyCode, event);
    }


    //// MirrorLink 接口相关实现方法//////////////////////////////////////////////////


    /**
     * 是否为 MirrorLink连接维护Activity, 仅App的主Activity必须设为true
     *
     * @return true 是
     */
    @Override
    protected boolean isMirrorLinkMaster() {
        return false;
    }

    /**
     * 返回MirrorLink连接 需要报告的 App类型信息
     *
     * @return @Defs.ContextInformation MirrorLink App类型
     */
    @Override
    public int getAppCategory() {
        IView f = (IView) getCurrentFragment();
        if (f != null) return f.getAppCategory();
        return Defs.ContextInformation.APPLICATION_CATEGORY_NAVIGATION;
    }

    /**
     * 返回MirrorLink连接 需要报告的 帧缓存类型信息
     *
     * @return MirrorLink 帧缓存类型
     */
    @Override
    public int getFrameCategory() {
        IView f = (IView) getCurrentFragment();
        if (f != null) return f.getFrameCategory();
        return Defs.ContextInformation.VISUAL_CONTENT_CATEGORY_GRAPHICS_VECTOR;
    }

    /**
     * 返回MirrorLink连接 需要报告的 App是否处理帧缓存阻塞事件
     *
     * @return true 处理 false 不处理
     */
    @Override
    public boolean isHandleFramebufferBlock() {
        IView f = (IView) getCurrentFragment();
        if (f != null) return f.isHandleFramebufferBlock();
        return false;
    }

    /**
     * 返回MirrorLink连接 需要报告的 音频类型信息
     *
     * @return MirrorLink 音频类型
     */
    @Override
    public int[] getAudioCategory() {
        IView f = (IView) getCurrentFragment();
        if (f != null) return f.getAudioCategory();
        return new int[]{0x80000000 /*Defs.ContextInformation.VISUAL_CONTENT_CATEGORY_MISC*/};
    }

    /**
     * 返回MirrorLink连接 需要报告的 App是否有音频输出
     *
     * @return true 有 false 无
     */
    @Override
    public boolean hasAudio() {
        IView f = (IView) getCurrentFragment();
        if (f != null) return f.hasAudio();
        return true;
    }

    /**
     * 返回MirrorLink连接 需要报告的 App是否处理音频阻塞事件
     *
     * @return true 处理 false 不处理
     */
    @Override
    public boolean isHandleAudioBlock() {
        IView f = (IView) getCurrentFragment();
        if (f != null) return f.isHandleAudioBlock();
        return false;
    }

    /**
     * MirrorLink 车机客户端显示属性改变事件
     *
     * @param manager MirrorLink 显示管理器
     */
    @Override
    public void onMirrorLinkDeviceDisplayChanged(final IMirrorLinkManager manager) {
        IView f = (IView) getCurrentFragment();
        if (f != null) f.onMirrorLinkDeviceDisplayChanged(manager);
        runOnUiThread(new Runnable() {
            public void run() {
                //更新当前UI文字大小
                updateUiTextSize();

                MirrorLinkDisplayManager m = (MirrorLinkDisplayManager) manager;
                int w = m.getClientPixelWidth();
                int h = m.getClientPixelHeight();
                Log.e(LOG_TAG, String.format("Callback1 屏幕像素:%d x %d", w, h));
                //Toast.makeText(WeNaviBaseActivity.this, String.format("车机屏幕像素:%d x %d", w, h), Toast.LENGTH_LONG).show();
            }
        });
    }

    /**
     * MirrorLink 会话状态改变事件，需通过MirrorLinkConnectionManager 获取会话状态
     * 缺省处理将根据会话状态调整屏幕方向，会话建立将自动横屏，会话断开将退出横屏
     *
     * @param manager MirrorLinkConnectionManager
     */
    @Override
    public void onMirrorLinkSessionChanged(IMirrorLinkManager manager) {
        super.onMirrorLinkSessionChanged(manager);

        IView f = (IView) getCurrentFragment();
        if (f != null) f.onMirrorLinkSessionChanged(manager);


        MirrorLinkConnectionManager mg = (MirrorLinkConnectionManager) manager;
        if (mg.isMirrolinkSessionEstablished()) {


            //设置支持车机消息显示机制
            MirrorLinkNotificationManager m = (MirrorLinkNotificationManager) getMirrorLinkContext()
                    .getMirrorLinkManager(MirrorLinkNotificationManager.class.getCanonicalName());
            if (m != null) m.setNotificationSupported(true);
        }

        runOnUiThread(new Runnable() {
            public void run() {

                //更新当前UI文字大小
                updateUiTextSize();
            }
        });

    }


    //MirrorLinkContextManager Interactors

    /**
     * MirrorLink 车机客户端帧缓存阻塞事件
     *
     * @param manager MirrorLinkContextManager
     */
    @Override
    public void onFramebufferBlocked(IMirrorLinkManager manager) {
        IView f = (IView) getCurrentFragment();
        if (f != null) f.onFramebufferBlocked(manager);

        /*final MirrorLinkContextManager m = (MirrorLinkContextManager) manager;
        if (m.isFramebufferBlocked()) {
            runOnUiThread(new Runnable() {
                public void run() {
                    String sInfo = String.format("FramebufferBlocked with reason %d", m.getFramebufferBlockedReason());
                    Toast.makeText(WeNaviBaseActivity.this, sInfo, Toast.LENGTH_LONG).show();
                }
            });
        }*/
    }

    /**
     * MirrorLink 车机客户音频阻塞事件
     *
     * @param manager MirrorLinkContextManager
     */
    @Override
    public void onAudioBlocked(IMirrorLinkManager manager) {
        IView f = (IView) getCurrentFragment();
        if (f != null) f.onAudioBlocked(manager);

        final MirrorLinkContextManager m = (MirrorLinkContextManager) manager;
        /*if (m.isAudioBlocked()) {
            runOnUiThread(new Runnable() {
                public void run() {
                    String sInfo = String.format("AudioBlocked with reason %d", m.getAudioBlockedReason());
                    Toast.makeText(WeNaviBaseActivity.this, sInfo, Toast.LENGTH_LONG).show();
                }
            });
        }*/

    }

    /**
     * MirrorLink 车机客户端帧缓存阻塞解除事件
     *
     * @param manager MirrorLinkContextManager
     */
    @Override
    public void onFramebufferUnblocked(IMirrorLinkManager manager) {
        IView f = (IView) getCurrentFragment();
        if (f != null) f.onFramebufferUnblocked(manager);
    }


    /**
     * MirrorLink 车机客户端音频阻塞解除事件
     *
     * @param manager MirrorLinkContextManager
     */
    @Override
    public void onAudioUnblocked(IMirrorLinkManager manager) {
        IView f = (IView) getCurrentFragment();
        if (f != null) f.onAudioUnblocked(manager);
    }


    //MirrorLinkDeviceManager Interactors

    /**
     * MirrorLink 车机客户端夜间模式事件，需通过MirrorLinkDeviceManager 获取当前是否为夜间模式
     * 需要针对夜间模式进行UI适配时请重载该方法
     *
     * @param manager MirrorLinkDeviceManager
     */
    @Override
    public void onNightModeChanged(IMirrorLinkManager manager) {
        IView f = (IView) getCurrentFragment();
        if (f != null) f.onNightModeChanged(manager);

        /*final String sInfo = String.format("MirrorLink车机客户端%s夜间模式", isInNightMode() ? "进入" : "退出");
        runOnUiThread(new Runnable() {
            public void run() {

                Toast.makeText(WeNaviBaseActivity.this, sInfo, Toast.LENGTH_LONG).show();
            }
        });*/
    }

    /**
     * MirrorLink 车机客户端话筒状态事件，需通过MirrorLinkDeviceManager 获取车机话筒当前前状态
     * 语音识别需要关注该事件则请重载该方法
     *
     * @param manager MirrorLinkDeviceManager
     */
    @Override
    public void onMicrophoneStatusChanged(IMirrorLinkManager manager) {
        IView f = (IView) getCurrentFragment();
        if (f != null) f.onMicrophoneStatusChanged(manager);

        MirrorLinkDeviceManager m = (MirrorLinkDeviceManager) manager;
        /*final String sInfo = String.format("MirrorLink车机客户端话筒%s", m.isMicrophoneOn() ? "开启" : "关闭");
        runOnUiThread(new Runnable() {
            public void run() {

                Toast.makeText(WeNaviBaseActivity.this, sInfo, Toast.LENGTH_LONG).show();
            }
        });*/
    }


    /**
     * MirrorLink 车机客户端驾驶模式事件，需通过MirrorLinkDeviceManager 获取车机当前是否进入驾驶模式
     * 需要针对驾驶模式进行功能限制时请重载该方法
     *
     * @param manager MirrorLinkDeviceManager
     */
    @Override
    public void onDriveModeChange(IMirrorLinkManager manager) {

        IView f = (IView) getCurrentFragment();
        if (f != null) f.onDriveModeChange(manager);

        /*final String sInfo = String.format("MirrorLink车机客户端%s驾驶模式", isInDriveMode() ? "进入" : "退出");
        runOnUiThread(new Runnable() {
            public void run() {

                Toast.makeText(WeNaviBaseActivity.this, sInfo, Toast.LENGTH_LONG).show();
            }
        });*/
    }


    /**
     * MirrorLink Server 回调，接收处理MirrorLink Server发送给App的事件
     *
     * @param manager       MirrorLink 管理器
     * @param sCallbackType 回调类型
     */
    @Override
    public void onMirrorLinkServerCall(final IMirrorLinkManager manager, final String sCallbackType, final Object... pms) {
        super.onMirrorLinkServerCall(manager, sCallbackType);
        /*runOnUiThread(new Runnable() {
            public void run() {
                String sInfo = String.format("Callback %s with %s", sCallbackType, manager.getClass().getCanonicalName());
                Toast.makeText(WeNaviBaseActivity.this, sInfo, Toast.LENGTH_LONG).show();
            }
        });*/
    }


    /**
     * MirrorLink 车机客户端旋钮平移事件回调
     *
     * @param nKnobID 旋钮ID
     * @param dir     平移方向
     */
    @Override
    public void onMirrorLinkClientKnobKeyShift(int nKnobID, MirrorLinkEvent.KnobShiftDirection dir) {
        IView f = (IView) getCurrentFragment();
        if (f != null) f.onMirrorLinkClientKnobKeyShift(nKnobID, dir);

    }


    /**
     * MirrorLink 车机客户端旋钮按压事件回调
     *
     * @param nKnobID 旋钮ID
     */
    @Override
    public void onMirrorLinkClientKnobKeyPush(int nKnobID) {
        IView f = (IView) getCurrentFragment();
        if (f != null) f.onMirrorLinkClientKnobKeyPush(nKnobID);

    }

    /**
     * MirrorLink 车机客户端旋钮按旋转件回调
     *
     * @param nKnobID 旋钮ID
     * @param dir     旋转方向
     */
    @Override
    public void onMirrorLinkClientKnobKeyRotate(int nKnobID, MirrorLinkEvent.KnobRotateAxis axis, MirrorLinkEvent.KnobRotateDirection dir) {
        IView f = (IView) getCurrentFragment();
        if (f != null) f.onMirrorLinkClientKnobKeyRotate(nKnobID, axis, dir);

    }

    /**
     * MirrorLink 车机客户端旋钮拉拔事件回调
     *
     * @param nKnobID 旋钮ID
     */
    @Override
    public void onMirrorLinkClientKnobKeyPull(int nKnobID) {
        IView f = (IView) getCurrentFragment();
        if (f != null) f.onMirrorLinkClientKnobKeyPull(nKnobID);
    }


    /**
     * MirrorLink 车机客户端ITU按钮按压事件回调
     *
     * @param keyid ITU按钮ID
     */
    @Override
    public void onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey keyid) {
        IView f = (IView) getCurrentFragment();
        if (f != null) f.onMirrorLinkClientITUkeyDown(keyid);
    }

    /**
     * MirrorLink 车机客户端车机设备按钮按压事件回调
     *
     * @param keyid 按钮ID
     */
    @Override
    public void onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey keyid) {

        IView f = (IView) getCurrentFragment();
        if (f != null) f.onMirrorLinkClientDeviceKeyDown(keyid);

        if (keyid == MirrorLinkEvent.DeviceKey.Device_Backward && isInHomePage())
            onBack();
        else
            super.onMirrorLinkClientDeviceKeyDown(keyid);


    }

    /**
     * MirrorLink 车机客户端功能键按压事件回调
     *
     * @param nKeyID 按钮ID
     */
    @Override
    public void onMirrorLinkClientFunctionKeyDown(int nKeyID) {
        IView f = (IView) getCurrentFragment();
        if (f != null) f.onMirrorLinkClientFunctionKeyDown(nKeyID);
    }


    /**
     * MirrorLink 车机客户端多媒体按键按压事件回调
     *
     * @param keyid 按钮ID
     */
    @Override
    public void onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey keyid) {
        IView f = (IView) getCurrentFragment();
        if (f != null) f.onMirrorLinkCkientMultimediaKeyDown(keyid);
    }


    /////////////////////////////////////////////////////////////////////////////////////
    /// Fragment 管理
    /////////////////////////////////////////////////////////////////////////////////////


    /**
     * 设置视图管理器
     *
     * @param m 视图管理器对象
     */
    @Override
    public void setViewManager(IViewManager m) {

    }


    /**
     * 返回视图管理器对象
     *
     * @return IViewManager
     */
    @Override
    public IViewManager getViewManager() {
        return null;
    }

    /**
     * 返回视图标记
     *
     * @return 视图标记
     */
    @Override
    public String getViewTag() {
        return this.getClass().getCanonicalName();
    }


    @Override
    public void onBack() {

    }


    @Override
    public void onBack(Bundle pm) {
        //if (mController != null) mController.onViewBack();

        /*Log.e(this.getClass().getCanonicalName(),this.hashCode() + " ViewManager onBack");
        if(isInHomePage()) {
            finish();
        }
        FragmentManager fm = getFragmentManager();
        FragmentTransaction tx = fm.beginTransaction();
        fm.popBackStackImmediate();
        return;*/


        if (isInHomePage()) {
            finish();
        } else {
            if (mController != null) mController.onViewBack();


            boolean bHasPop = false;
            if (mBranchPageStack.size() > 0) {
                Class<?> p = mBranchPageStack.pop();
                bHasPop = true;
                Log.e(LOG_TAG, p.getCanonicalName() + " BranchPageStack poped " + mBranchPageStack.size());

            }


            if (mBranchPageStack.size() > 0) {

                Class<?> c = mBranchPageStack.peek();
                if (c != null) {
                    setCurrentBranchPage(c, pm);
                    return;
                }
            }


            if (mPageStack.size() > 0 && !bHasPop) {
                Class<?> p = mPageStack.pop();
                Log.e(LOG_TAG, p.getCanonicalName() + " PageStack poped " + mPageStack.size());

            }


            if (mPageStack.size() > 0) {

                Class<?> c = mPageStack.peek();
                if (c != null) setCurrentPage(c, pm, null);
            }

        }


    }


    @Override
    public boolean isInHomePage() {
        IView v = getCurrentView();
        if (v != null) {
            String sCurrentViewTag = v.getViewTag();
            if (mHomePageTag != null && mHomePageTag.equals(sCurrentViewTag))
                return true;
        }
        return false;
    }


    @Override
    public boolean isInUiBranch() {
        return mBranchPageStack.size() > 0;
    }

    public void addToBackStack(Class<?> c) {
        mCurrentPageClass = c;
        if (!mPageStack.contains(c)) {
            mPageStack.push(c); //入堆栈
            Log.e(LOG_TAG, c.getCanonicalName() + " pushed " + mPageStack.size());
        } else {
            //将在C之上的清掉

            int i = mPageStack.indexOf(c);
            while (mPageStack.size() > i + 1) {
                Log.e(LOG_TAG, "PageStack size: " + mPageStack.size() + " index:" + i);
                Class<?> p = mPageStack.pop();
                Log.e(LOG_TAG, p.getCanonicalName() + " poped " + mPageStack.size());

            }
        }
    }


    public void addToBranchBackStack(Class<?> c) {
        mCurrentPageClass = c;
        if (!mBranchPageStack.contains(c)) {
            mBranchPageStack.push(c); //入堆栈
            Log.e(LOG_TAG, c.getCanonicalName() + " BranchPageStack pushed " + mBranchPageStack.size());
        } else {
            //将在C之上的清掉

            int i = mBranchPageStack.indexOf(c);
            while (mBranchPageStack.size() > i + 1) {
                Log.e(LOG_TAG, "BranchPageStack size: " + mBranchPageStack.size() + " index:" + i);
                Class<?> p = mBranchPageStack.pop();
                Log.e(LOG_TAG, p.getCanonicalName() + " BranchPageStack poped " + mBranchPageStack.size());

            }
        }
    }


    public Class<?> getCurrentPageClass() {
        return mCurrentPageClass;
    }


    public Fragment getCurrentFragment() {
        return (Fragment) getCurrentView();
    }

    /**
     * 返回Fragment应该存放的LayoutID
     *
     * @return LayoutID
     */
    public abstract int getLayoutIdForFragment();


    @Override
    public void setCurrentView(IView v) {
        mCurrentView = v;
    }

    @Override
    public IView getCurrentView() {
        return mCurrentView;
    }


    public void setCurrentPageTest(Class<?> c, Bundle arg, Object pm) {


        FragmentManager fm = getFragmentManager();
        FragmentTransaction tx = fm.beginTransaction();

        Fragment fCurrent = fm.findFragmentByTag(c.getCanonicalName());

        if (fCurrent != null)
            tx.replace(getLayoutIdForFragment(), fCurrent, c.getCanonicalName());
        else {
            try {
                Object o = c.newInstance();
                if (o instanceof Fragment) {

                    fCurrent = (Fragment) o;
                    tx.add(getLayoutIdForFragment(), fCurrent, c.getCanonicalName());
                    // if(mHomePageTag==null) tx.add(getLayoutIdForFragment(), (Fragment)fCurrent,
                    //         ((IView)fCurrent).getViewTag());
                }
            } catch (Exception e) {
                Log.e(LOG_TAG, e.getMessage());
                e.printStackTrace();
            }
        }

        if (arg != null && fCurrent != null) fCurrent.setArguments(arg);
        if (pm != null && fCurrent != null) ((IView) fCurrent).setParameters(pm);


        if (fCurrent != null) {
            ((IView) fCurrent).setViewManager(this);


            tx.addToBackStack(null);


            //tx.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);// 设置动画
            tx.commit();
        }


        addToBackStack(c);
        if (mHomePageTag == null) mHomePageTag = c.getCanonicalName();

        Log.e(LOG_TAG, "setCurrentPage " + c.getCanonicalName());

        return;
    }

    @Override
    public void setCurrentPage(Class<?> c, Bundle arg, Object pm) {
        try {

            if (mBranchPageStack.size() > 0) {
                toBranchPage(c, arg,pm);
                return;
            }

            Log.e(LOG_TAG, "requst setCurrentPage " + c.getCanonicalName());
            FragmentManager fm = getFragmentManager();
            Fragment f = fm.findFragmentByTag(c.getCanonicalName());
            if (f == null) {
                Object o = c.newInstance();
                if (o instanceof IView) {
                    setCurrentPage((IView) o, arg, pm);

                }
            } else
                setCurrentPage((IView) f, arg, pm);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public void setCurrentPage(IView v, Bundle arg, Object pm) {
        if (v instanceof Fragment) {
            Fragment fragment = (Fragment) v;

            //处理快速点击可能出现的java.lang.IllegalStateException: Fragment already added:
            if (!fragment.isAdded()) {
                v.setViewManager(this);
                FragmentManager fm = getFragmentManager();

                FragmentTransaction tx = fm.beginTransaction();
                Fragment fCurrent = getCurrentFragment();

                if (fCurrent != null) tx.remove(fCurrent);
                //if(mHomePageTag==null) tx.add(getLayoutIdForFragment(), (Fragment) v, v.getViewTag());


                tx.replace(getLayoutIdForFragment(), fragment, v.getViewTag());
                //tx.replace(getLayoutIdForFragment(), (Fragment) v, v.getViewTag());
                //tx.addToBackStack(null);

                if (arg != null) (fragment).setArguments(arg);

                if (pm != null && v != null) ((IView) v).setParameters(pm);

                //tx.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);// 设置动画
                tx.commit();

                addToBackStack(v.getClass());
                if (mHomePageTag == null) mHomePageTag = v.getViewTag();
            }


            Log.e(LOG_TAG, v.hashCode() + " setCurrentPage " + v.getViewTag());
        }

    }


    /**
     * 设置当前页面，保留Fagment堆栈
     *
     * @param c 当前页面
     */
    @Override
    public void toBranchPage(Class<?> c, Bundle arg,Object pm) {
        try {
            Log.e(LOG_TAG, "requst toBranchPage " + c.getCanonicalName());
            //FragmentManager fm = getFragmentManager();
            //Fragment f = fm.findFragmentByTag(c.getCanonicalName());
            //if (f == null) {
            Object o = c.newInstance();
            if (o instanceof IView) {
                setCurrentBranchPage((IView) o,arg, pm);

            }
            //}

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    @Override
    public void toRootPage(Bundle pm) {
        /*FragmentManager fm=getFragmentManager();
        if(fm.getBackStackEntryCount()>1) {
            fm.popBackStackImmediate()
            return;
        }*/

        if (mBranchPageStack.size() > 0) {
            mBranchPageStack.clear();

            if (mPageStack.size() > 0) {

                Class<?> c = mPageStack.peek();
                if (c != null) setCurrentPage(c, pm, null);
            }

        }
    }

    public void setCurrentBranchPage(Class<?> c, Bundle pm) {
        try {


            Log.e(LOG_TAG, "requst setCurrentBranchPage " + c.getCanonicalName());
            //FragmentManager fm = getFragmentManager();
            //Fragment f = fm.findFragmentByTag(c.getCanonicalName());
            //if (f == null) {
            Object o = c.newInstance();
            if (o instanceof IView) {
                setCurrentBranchPage((IView) o, pm,null);

            }
            //}

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setCurrentBranchPage(IView v, Bundle arg,Object pm) {
        if (v instanceof Fragment) {
            Fragment fragment = (Fragment) v;
            if (!fragment.isAdded()) {
                v.setViewManager(this);
                FragmentManager fm = getFragmentManager();

                FragmentTransaction tx = fm.beginTransaction();
                Fragment fCurrent = getCurrentFragment();

                if (fCurrent != null) {
                    tx.remove(fCurrent);
                }


                tx.replace(getLayoutIdForFragment(), fragment, v.getViewTag());

                if (arg != null) (fragment).setArguments(arg);
                if(pm!=null) ((IView)fragment).setParameters(pm);
                //tx.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);// 设置动画
                tx.commit();

                if (fCurrent != null) fCurrent = null;
                addToBranchBackStack(v.getClass());
                if (mHomePageTag == null) mHomePageTag = v.getViewTag();
            }


            Log.e(LOG_TAG, "setCurrentBranchPage " + v.getViewTag());
        }


    }


    /**
     * 更新UI分类信息到MirrorLink Server
     */
    @Override
    public void updateUICategory() {
        this.setMirrorLinkContext();
    }


}
