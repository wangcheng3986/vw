package com.navinfo.wenavi.controller;

import com.navinfo.wenavi.activity.IView;
import com.navinfo.wenavi.model.IModel;

/**
 * Created by Doone on 2015/2/3.
 * 控制器接口
 */
public interface IController {


    /**
     * 返回Controller 缺省需要的IModel 类全名
     * @return IModel 类全名
     */
    String getDefaultModelName();


    /**
     * 如果Controller 缺省需要的IModel 类全名不为空将尝试获取该类实例并返回
     * @return IModel 对象
     */
    public IModel getDefaultModel();


    /**
     * IView Restart 时由IView调用
     */
    public void onViewRestart();


    /**
     * IView Start 时由IView调用
     */
    public void onViewStart();


    /**
     * IView Pause 时由IView调用
     */
    public void onViewPause();


    /**
     * IView Resume 时由IView调用
     */
    public void onViewResume();


    /**
     * IView Stop 时由IView调用
     */
    public void onViewStop();

    /**
     * IView Destroy 时由IView调用
     */
    public void onViewDestroy();


    /**
     * IView Back 关闭 时由IView调用
     */
    public void onViewBack();


    /**
     * 绑定IView
     * @param v 被绑定的IView
     */
    public void attachView(IView v);


    /**
     * 解除与IView的绑定
     */
    public void dettachView();


    /**
     * 返回绑定的IView
     * @return IView对象
     */
    public IView getView();

    /**
     * 销毁Controller，由创建者调用
     */
    public void destroy();


    /**
     * 功能业务处理，由IView调用发起业务处理
     * @param actionDatas  功能业务参数列表，通常参数0 为业务识别码
     */
    public void  executeAction(Object... actionDatas);

    /**
     * 更新视图
     * @param datas 视图更新数据
     */
    public void updateView(Object... datas);


    /**
     * 获取指定类全名对象实例
     * @param sName 对象类全名
     * @return 对象实例
     */
    public Object getObject(String sName);

}
