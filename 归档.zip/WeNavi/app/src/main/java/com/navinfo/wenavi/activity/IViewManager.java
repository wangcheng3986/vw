package com.navinfo.wenavi.activity;

import android.os.Bundle;

/**
 * Created by Doone on 2015/3/8.
 * 视图管理器接口定义
 */
public interface IViewManager {

    /**
     * 设置当前视图
     * @param v IView对象
     */
    public void setCurrentView(IView v);

    /**
     * 返回当前视图
     * @return IView对象
     */
    public IView getCurrentView();



    /**
     * 设置当前页面
     * @param c {@Class<?>}
     * @param arg  Bundle 参数
     * @param pm 参数
     */
    public void setCurrentPage(Class<?> c,Bundle arg,Object pm);





    /**
     * 设置当前页面,分支模式，该页面将只能返回到 设置之前的当前页面
     * @param c {@Class<?>}
     * @param pm 参数
     */
    public void toBranchPage(Class<?> c, Bundle arg,Object pm);


    /**
     * 跳转到根页面
     * @param pm 参数
     */
    public void toRootPage(Bundle pm);


    /**
     * 返回UI是否处在分支模式
     * @return true 是
     */
    public boolean isInUiBranch();


    /**
     * 当前视图是否为首页
     * @return true 是
     */
    public boolean isInHomePage();


    /**
     * 更新UI分类信息到MirrorLink Server
     */
    public void updateUICategory();


    /**
     * 返回上一级或退出App
     */
    public void onBack(Bundle pm);



}
