package com.navinfo.wenavi.model;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;

import com.navinfo.sdk.mapapi.search.core.POIInfo;
import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.activity.WeNaviBaseActivity;
import com.navinfo.wenavi.controller.MapViewController;
import com.navinfo.wenavi.util.WeNaviUtil;

import java.util.List;

/**
 * Created by Doone on 2015/3/18.
 */
public class PoiListAdapter   extends BaseAdapter {
    private Context mContext = null;
    private List<POIInfo> mlist = null;
    private IPoiListViewInteractor mPoiListViewInteractor=null;

    private int selected=-1 ;

    public void setSelected(int selected) {
        this.selected = selected;
    }

    private String delName(String s){
        String ret = s;
        if(s.contains("&amp;")){
            ret=s.replace("&amp;","&");
        }
        if(s.contains("&lt;")){
            ret = s.replace("&lt;","<");
        }
        if(s.contains("&gt;")){
            ret = s.replace("&gt;",">");
        }
        if(s.contains("&quot;")){
            ret = s.replace("&quot;","''");
        }
        return ret;
    }

    public interface IPoiListViewInteractor
    {
        void onItemClick(POIInfo p);

        void onItemClick(POIInfo p,int index);
    }

    public PoiListAdapter(){
        //this.mContext = context;
        //this.mlist = list;
    }

    public void setContext(Context c)
    {
        this.mContext=c;
    }

    public void setPoiListViewInteractor(IPoiListViewInteractor interactor)
    {
        mPoiListViewInteractor=interactor;
    }

    public void setData(List<POIInfo> list)
    {
        this.mlist = list;
    }

    @Override
    public int getCount() {
        int count = 0;
        if (null != mlist)
        {
            count = mlist.size();
        }
        return count;
    }

    @Override
    public POIInfo getItem(int position) {
        POIInfo item = null;

        if (null != mlist)
        {
            item = mlist.get(position);
        }

        return item;
    }

    @Override
    public long getItemId(int position) {

        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        //ViewHolder viewHolder = null;
        TextView name = null;
        TextView distance = null;
        if (null == convertView)
        {

            //LayoutInflater mInflater = LayoutInflater.from(mContext);
            //convertView = mInflater.inflate(R.layout.page_01401_result_item, null);

            //if(convertView!=null) setFontSize((ViewGroup)convertView,getDefaultTextSize());
            AbsListView.LayoutParams pm=new AbsListView.LayoutParams(
                    AbsListView.LayoutParams.MATCH_PARENT,
                    WeNaviUtil.dip2px(mContext, 55));


            LinearLayout layout=new LinearLayout(mContext);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setLayoutParams(pm);



            name=new TextView(mContext);

//            name.setTextColor(mContext.getResources().getColorStateList(R.drawable.text_ui01401_01_name_onclick));
            name.setTextSize(19);
            name.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams pms=new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                   LinearLayout.LayoutParams.WRAP_CONTENT
            );
            pms.setMargins( WeNaviUtil.dip2px(mContext, 12.5f), WeNaviUtil.dip2px(mContext, 1),6,0);
            pms.weight=1;
            name.setLayoutParams(pms);

            name.setTag("name");
            layout.addView(name);

            distance=new TextView(mContext);

//            distance.setTextColor(mContext.getResources().(R.drawable.ui01404_list));
            distance.setTextSize(21);
            distance.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
            distance.setPadding(WeNaviUtil.dip2px(mContext, 5f), 0,WeNaviUtil.dip2px(mContext, 6f),WeNaviUtil.dip2px(mContext, 5));
            pms=new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            pms.weight=1;
            pms.gravity=Gravity.RIGHT;
            distance.setLayoutParams(pms);

            distance.setTag("dis");
            layout.addView(distance);

            convertView=layout;


        }

        convertView.setBackgroundResource(R.drawable.list_item_bg);
        final POIInfo item = getItem(position);
        if (null != item)
        {
            name  = (TextView) convertView.findViewWithTag("name");//findViewById(R.id.txtName);
            distance = (TextView) convertView.findViewWithTag("dis");
                   // .findViewById(R.id.txtDis);

            name.setText(delName(item.name));
            distance.setText(WeNaviUtil.convertMetersKM((int) item.distance));

            convertView.setTag(item);
            WeNaviUtil.updateUiTextSize((WeNaviBaseActivity)mContext,(ViewGroup)convertView);
        }

         convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selected = position;
                setListTap(true);
                Object tag=v.getTag();
                if(tag!=null && (tag instanceof POIInfo))
                {
                    if(mPoiListViewInteractor!=null)
                        mPoiListViewInteractor.onItemClick((POIInfo)tag,position);
                }
            }

        });

        if(selected == position){
            name.setTextColor(mContext.getResources().getColor(R.color.yellow_text_map));
            distance.setTextColor(mContext.getResources().getColor(R.color.yellow_text_map));
            convertView.setBackgroundResource(R.drawable.list_item_selected);
        }else {
            name.setTextColor(mContext.getResources().getColor(R.color.white_text));
            distance.setTextColor(mContext.getResources().getColor(R.color.blue_text));
            convertView.setBackgroundResource(R.drawable.list_item_normal);
        }

        return convertView;
    }

    boolean listTap = false;

    public void setListTap(boolean listTap) {
        this.listTap = listTap;
    }

    public boolean isListTap() {
        return listTap;
    }
}
