package com.navinfo.wenavi.entity;

import com.orm.SugarRecord;

/**
 * Created by Doone on 2015/3/10.
 * App 配置数据实体
 */
public class AppConfig extends SugarRecord<AppConfig> {
    String paramName;
    String paramValue;
    String memo;


    public AppConfig()
    {

    }

    public AppConfig(String paramName, String paramValue, String memo) {
        this.paramName = paramName;
        this.paramValue = paramValue;
        this.memo = memo;
    }

    public String getParamName() {
        return paramName;
    }

    public void setParamName(String paramName) {
        this.paramName = paramName;
    }

    public String getParamValue() {
        return paramValue;
    }

    public void setParamValue(String paramValue) {
        this.paramValue = paramValue;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }
}
