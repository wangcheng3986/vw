package com.navinfo.wenavi.model;

import android.content.Context;

import com.navinfo.wenavi.entity.AdminRegionEntity;
import com.navinfo.wenavi.entity.CueWordEntity;

/**
 * Created by zhangyang on 15/3/14.
 * 提示词的查询Model，负责提示词的查询以及提示词查询器的创建及销毁管理
 */
public class CueWordModel extends BaseModel {

    public CueWordModel(Context c) {
        super(c);
    }

    public CueWordEntity[] getCueWords(String keyword,String regioncode) {
        //TODO:调用MapSDK的AWSearch功能获得结果
        //测试数据
        AdminRegionEntity regionEntity = new AdminRegionEntity();
        regionEntity.setName("regionEntityname");
        regionEntity.setCityCode("42010");
        regionEntity.setCityName("武汉");
        regionEntity.setCode("123");
        regionEntity.setProadCode("123");
        regionEntity.setProadName("光谷大道");

        CueWordEntity[] entities = new CueWordEntity[1];
        CueWordEntity entity1 = new CueWordEntity();
        entity1.setId("1");
        entity1.setName("name1");
        entity1.setAdminregion(regionEntity);
        CueWordEntity entity2 = new CueWordEntity();
        entity2.setId("1");
        entity2.setName("name2");
        entity2.setAdminregion(regionEntity);
//        entities[0] =entity1;
//        entities[1] = entity2;

        if(keyword.equals("aa")){
            entities[0] =entity1;
        }else if(keyword.equals("aab")){
            entities[0] = entity2;
        }else {
            return null;
        }

        return entities;
    }

    @Override
    public void destroy() {
        //TODO:销毁AWSearcher
    }

    @Override
    public void loadModel() {
        //TODO:创建AWSearcher
    }

}
