package com.navinfo.wenavi.entity;

import com.navinfo.wenavi.entity.AdminRegionEntity;

/**
 * Created by liubao on 15/3/14.
 * 提示词实体类
 */
public class CueWordEntity {

    private String id;
    private String name;
    private AdminRegionEntity adminregion;

    /**
     * 实例化一个提示词实体对象
     */
    public CueWordEntity() {

    }

    /**
     * 实例化一个提示词实体对象
     * @param id ID
     * @param name 名称
     * @param adminregion 政区
     */
    public CueWordEntity(String id, String name, AdminRegionEntity adminregion) {

        this.id = id;
        this.name = name;
        this.adminregion = adminregion;
    }

    /**
     * 获取ID
     * @return ID
     */
    public String getId() {
        return id;
    }

    /**
     * 设置ID
     * @param id ID
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取名称
     * @return 名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置名称
     * @param name 名称
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取政区
     * @return 政区
     */
    public AdminRegionEntity getAdminregion() {
        return adminregion;
    }

    /**
     * 设置政区
     * @param adminregion 政区
     */
    public void setAdminregion(AdminRegionEntity adminregion) {
        this.adminregion = adminregion;
    }
}
