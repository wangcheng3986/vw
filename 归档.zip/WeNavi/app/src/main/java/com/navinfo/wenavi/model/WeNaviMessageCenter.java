package com.navinfo.wenavi.model;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;

/**
 * Created by Doone on 2015/3/21.
 */
public  class WeNaviMessageCenter implements IMessageCenter {

    HashMap<String,Queue<IMessage>> mMessageStorege=new HashMap<String,Queue<IMessage>>();


    @Override
    public void sendMessage(IMessage m) {
        Queue<IMessage> aMsg=null;
        String sReceiver=m.getReceiver();
        if(mMessageStorege.containsKey(sReceiver))
            aMsg=mMessageStorege.get(sReceiver);
        else {
            aMsg = new LinkedList<IMessage>();
            mMessageStorege.put(sReceiver,aMsg);
        }
        if(aMsg!=null) aMsg.offer(m);
    }

    @Override
    public IMessage queryMessage(String receiver) {

        Queue<IMessage> aMsg=null;
        if(mMessageStorege.containsKey(receiver)) {
            aMsg = mMessageStorege.get(receiver);
            if(aMsg!=null && aMsg.size()>0)
            {
                return aMsg.poll();
            }
        }


        return null;
    }
}
