package com.navinfo.wenavi.controller;

import android.content.Context;
import android.location.Location;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import com.navinfo.audio.IAudioGenerateListerner;
import com.navinfo.sdk.mapapi.map.LocationData;
import com.navinfo.sdk.mapapi.search.geocode.GeoCodeResult;
import com.navinfo.sdk.mapapi.search.geocode.GeoCoder;
import com.navinfo.sdk.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.navinfo.sdk.mapapi.search.geocode.ReverseGeoCodeOption;
import com.navinfo.sdk.mapapi.search.geocode.ReverseGeoCodeResult;
import com.navinfo.sdk.naviapi.NaviInfo;
import com.navinfo.sdk.naviapi.NaviManager;
import com.navinfo.sdk.naviapi.NaviState;
import com.navinfo.sdk.naviapi.NavigationListener;
import com.navinfo.sdk.naviapi.routeplan.RoutePlanData;
import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;
import com.navinfo.wenavi.entity.NaviHistory;
import com.navinfo.wenavi.model.NLocationGPS;
import com.navinfo.wenavi.model.NLocationGPSListener;
import com.navinfo.wenavi.model.Repository;
import com.navinfo.wenavi.entity.RoutePlanParam;
import com.navinfo.wenavi.util.WeNaviUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Doone on 2015/2/6.
 * 导航引导控制器
 */
public class NaviController extends RouteController implements NavigationListener, NLocationGPSListener{


    public static final String LOG_TAG=NaviController.class.getCanonicalName();

    /**
     * 功能代码: 开始导航引导， 需提供GeoPoint 终点， GeoPoint 起点
     * 允许起点不提供，默认采用当前位置为起点
     */
    public static final String CMD_START_NAVIGATE="CMD_START_NAVIGATE";


    /**
     * 功能代码: 开始导航引导， 需提供GeoPoint 终点， GeoPoint 起点
     * 允许起点不提供，默认采用当前位置为起点
     */
    public static final String CMD_START_SIMULATE_NAVIGATE="CMD_START_SIMULATE_NAVIGATE";


    /**
     * 功能代码: 停止导航引导
     */
    public static final String CMD_STOP_NAVIGATE="CMD_STOP_NAVIGATE";


    /**
     * 视图刷新代码:导航过程中刷新数据
     */
    public static final String RET_UPDATE_DATA_WHEN_NAVIGATE="RET_UPDATE_DATA_WHEN_NAVIGATE";


    /**
     * 视图刷新代码:导航结束
     */
    public static final String RET_NAVIGATE_FINISHED="RET_NAVIGATE_FINISHED";



    /**
     * 视图刷新代码:刷新卫星数量
     */
    public static final String RET_UPDATE_SATELLITE="RET_UPDATE_SATELLITE";




    /**
     * 视图刷新代码:GPS定位成功
     */
    public static final String RET_GPS_OK="RET_GPS_OK";



    /**
     * 视图刷新代码:GPS定位失败
     */
    public static final String RET_GPS_FAIL="RET_GPS_FAIL";



    /**
     * 视图刷新代码:刷新 速度0
     */
    public static final String RET_CAR_STOP="RET_SPEED_ZERO";


    /**
     * 视图刷新代码:刷新 速度>20
     */
    public static final String RET_CAR_RUNING="RET_CAR_RUNING";


    /**
     * 视图刷新代码:刷新 速度<=20
     */
    public static final String RET_CAR_MOVING="RET_CAR_MOVING";


    /**
     * 视图刷新代码:提示GPS未开启
     */
    public static final String RET_GPS_DISABLED="RET_GPS_DISABLED";


    public static String NAVI_DESITINATION_LOCATION="";




    private boolean mNavigating=false; //是否正在导航引导
    private boolean mIsSimulateNavi=false;//是否模拟导航
    //gps定位
    private NLocationGPS mLocationGPS = null;
    private boolean mGpsStarted = false;

    private Thread mAudioPlayer=null;
    private boolean  bPlaying=false;
    private Object oLockforAudio=new Object();
    private List<String> mlsAudioString=new ArrayList<String>();

    private boolean mFirstEntrance = true;

    private boolean mIsNotifyGpsOk=false;


    boolean mNeedSaveNaviHistory=true;

    public NaviController(Context context) {
        super(context);
        isNeedShowMyLocation=false;
        mLocationGPS = getGPSLocationClient();
        mLocationGPS.setNLocationGPSListener(this);
    }



    public boolean isNavigating()
    {
        return mNavigating;
    }



    public boolean isSimulateNavi()
    {
        return  mIsSimulateNavi;
    }

    @Override
    public Object getObject(String sName) {

        return super.getObject(sName);
    }


    @Override
    protected ShowParam getShowBuiltInZoomControls(DisplayMetrics dm) {

        ShowParam pm=new ShowParam();
        pm.isShow=false;

        int l=getMapView().getLeft();
        int r=getMapView().getRight();
        int t=getMapView().getTop();
        int h=getMapView().getHeight();
        int w=getMapView().getWidth();
        pm.y = t + h / 2 -getMapView().getBuiltInZoomControlsHeight() / 2;
        pm.x = l + w - getMapView().getBuiltInZoomControlsWidth() - dpToPixel(dm,5);

        return pm;

    }



    @Override
    protected ShowParam getShowTrafficControl(DisplayMetrics dm) {

        ShowParam pm=new ShowParam();
        pm.isShow=false;
        pm.x=-1; //使用默认位置
        pm.y=-1; //使用默认位置

        int l=getMapView().getLeft();
        int r=getMapView().getRight();
        int t=getMapView().getTop();
        int h=getMapView().getHeight();
        int w=getMapView().getWidth();
        pm.y =t + h/2
                - getMapView().getTrafficControlIconHeight()
                - dpToPixel(dm,  5);
        pm.x =l + dpToPixel(dm,5);

        return pm;

    }

    @Override
    protected ShowParam getShowCompassControl(DisplayMetrics dm) {
        ShowParam pm=new ShowParam();
        pm.isShow=false;

        int l=getMapView().getLeft();
        int r=getMapView().getRight();
        int t=getMapView().getTop();
        int h=getMapView().getHeight();
        int w=getMapView().getWidth();
        pm.y =t + h/2
                + getMapView().getCompassPositionHeight()/2
                + dpToPixel(dm,  5);
        pm.x =l + getMapView().getCompassPositionWidth()/2
                + dpToPixel(dm,5);


        return pm;
    }

    private int mNaviStyle=NaviManager.NaviStyle_Street;
    @Override
    void bindCompass(ImageButton btCompass) {
        mBindCompass=btCompass;
        if(mBindCompass!=null)
        {
            mBindCompass.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isNavigating()) {
                        if (mNaviStyle == NaviManager.NaviStyle_Street)
                            mNaviStyle = NaviManager.NaviStyle_North;
                        else
                            mNaviStyle = NaviManager.NaviStyle_Street;

                        getNaviManager().setNavigatorStyle(mNaviStyle);
                    }
                    else
                     NaviController.this.northMap();
                }
            });
        }
        //getNaviManager().s
        //super.bindCompass(btCompass);
    }

    @Override
    public void onViewStart() {
        super.onViewStart();

        mlsAudioString.clear();

    }



    @Override
    public void redoLastRoutePlan() {

        RoutePlanParam rpm=(RoutePlanParam)getObject(RoutePlanParam.class.getCanonicalName());
        if(rpm!=null)
        {
            if(rpm.getRouteType()!=null && rpm.getStartPoint()!=null && rpm.getEndPoint()!=null)
            {
                LocationData loc= getLocationData();
                GeoPoint pStart=rpm.getStartPoint();
                //优先取当手机位置前点
                if(loc!=null && loc.pt!=null) pStart=loc.pt;
                startRoutrPlan(rpm.getRouteType(),pStart,rpm.getEndPoint(),rpm.getPassPoints());

                if (!mGpsStarted){
                    mIsNotifyGpsOk=false;
                    getLocationClient().stop();
                    if (!mLocationGPS.isGPSEnabled()){

                        updateView(RET_GPS_DISABLED);
                    }

                    mGpsStarted = true;
                    mLocationGPS.startGPS(1000,0);

                }

            }

        }
        //super.redoLastRoutePlan();
    }

    @Override
    public void onViewResume() {
        super.onViewResume();
        Log.e("cc"," navi ctrl onViewResume");
        mNeedSaveNaviHistory=true;
        //第一次进入
        if(mFirstEntrance)
        {
            Log.d("cc"," navi ctrl mFirstEntrance");
            getNaviManager().regNavigationListener(this);
            mFirstEntrance = false;
            //恢复最后一次路径规划
            redoLastRoutePlan();

        }else{
            Log.e("cc"," navi ctrl not mFirstEntrance");
            getNaviManager().isInBackground(false);
        }
    }

    @Override
    public void onViewPause() {
        super.onViewPause();
        Log.e("cc"," navi ctrl onViewPause");
        getNaviManager().isInBackground(true);
    }

    @Override
    public void onViewStop() {
        Log.e("cc"," navi ctrl onViewStop");

        super.onViewStop();
    }

    @Override
    public void onViewBack() {

        stopNavigation();
        super.onViewBack();
    }



    @Override
    public void addPassPoint(GeoPoint p) {
        super.addPassPoint(p);
        mNeedSaveNaviHistory=false;
    }

    @Override
    public void executeAction(Object... actionDatas) {
        if(actionDatas.length>0) {
            if (actionDatas[0].getClass().getCanonicalName() == String.class.getCanonicalName()) {
                String sCms = (String) (actionDatas[0]);

                if (sCms == CMD_START_SIMULATE_NAVIGATE)
                {
                    startNavigation(true);
                }
                else if (sCms == CMD_START_NAVIGATE)
                {
                    RoutePlanParam rpm=(RoutePlanParam)getObject(RoutePlanParam.class.getCanonicalName());
                    if(rpm!=null) startNavigation(rpm.isSimulateNavi());
                    else startNavigation(false);
                }
                else if (sCms == CMD_STOP_NAVIGATE)
                {
                    stopNavigation();
                }

                else
                    super.executeAction(actionDatas);
            }
        }

    }


    private void AddAudioString(String s)
    {
        synchronized (oLockforAudio){

            mlsAudioString.add(s);
            //if(mAudioPlayer!=null) mAudioPlayer.notify();
            oLockforAudio.notify();
        }
    }


    private String getNextAudioString()
    {
        synchronized (oLockforAudio){
            if(mlsAudioString.size()>0) {
                String s = mlsAudioString.get(0);
                mlsAudioString.remove(0);
                return s;
            }
        }

        return null;
    }


    //开始导航
    public void startNavigation(boolean simulate)
    {
        if(mNavigating) return;

        mNavigating = true;

        if(mAudioPlayer==null) {
            mAudioPlayer = new Thread(new Runnable() {
                @Override
                public void run() {

                    Log.d(LOG_TAG,"AudioPlay Thread Start...");

                    try {
                        bPlaying = false;
                        while (mNavigating) {
                            if (!bPlaying) {
                                String s = getNextAudioString();
                                if (s != null) {
                                    bPlaying = true;
                                    Log.d(LOG_TAG,"Audio:"+s);
                                    getAudioGenerator().play(s, new IAudioGenerateListerner() {
                                        @Override
                                        public void onError(String s) {
                                            bPlaying = false;

                                        }

                                        @Override
                                        public void onPlayFinished() {
                                            bPlaying = false;

                                        }
                                    });
                                }
                            }

                            synchronized (oLockforAudio) {
                                oLockforAudio.wait(1000);
                            }
                            //Thread.sleep(1000);
                        }


                        getAudioGenerator().stop();
                        if(mlsAudioString.size()>0) mlsAudioString.clear();


                        //将剩余的语句播放完毕后再退出
                        while (mlsAudioString.size()>0) {
                            if (!bPlaying) {
                                String s = getNextAudioString();
                                if (s != null) {
                                    bPlaying = true;
                                    Log.d(LOG_TAG,"Audio:"+s);
                                    getAudioGenerator().play(s, new IAudioGenerateListerner() {
                                        @Override
                                        public void onError(String s) {
                                            bPlaying = false;

                                        }

                                        @Override
                                        public void onPlayFinished() {
                                            bPlaying = false;

                                        }
                                    });
                                }
                            }
                            Thread.sleep(10);
                        }
                    }
                    catch(Exception e) {
                        Log.e(LOG_TAG,e.getMessage());

                    }

                    Log.d(LOG_TAG,"AudioPlay Thread teminated");


                }
            });

            mAudioPlayer.start();
        }
        mIsSimulateNavi=simulate;
        getNaviManager().launchNavigator(simulate);

        //saveNaviHistory();
        getStartLocation(mStartPoit);

        if(!simulate)
        {
            LocationData location =getLocationData();
            if(location!=null)
            getNaviManager().setNavigatorGPS(location.pt.getLongitudeE6(),
                    location.pt.getLatitudeE6(),
                    location.speed,
                    0);

            mNotifyMoving=false;
            mNotifyRunning=false;

        }

    }

    //停止导航
    public void stopNavigation()
    {
        Log.e("cc","stopNavigation");
        if(mNavigating) getNaviManager().quitNavigator();
        mNavigating = false;
        mAudioPlayer=null;
        mFirstEntrance = true;

        if (mGpsStarted){
            mGpsStarted = false;
            mLocationGPS.stopGPS();
        }
    }


    void saveNaviHistory()
    {
        if(!mNeedSaveNaviHistory) return;

        RoutePlanParam rpm = (RoutePlanParam) getObject(RoutePlanParam.class.getCanonicalName());
        if (rpm != null) {
            String sEndLocation=rpm.getEndLaocation();
            if(sEndLocation!=null && sEndLocation.length()>0)
                mEndLocation=sEndLocation;
        }

        RoutePlanData d=getRoutePlanData();
        if(d==null || mStartPoit==null ||
          mEndPoit==null || mStartLocation==null ||
        mEndLocation==null || mPlanType==null) return;

        NaviHistory n=new NaviHistory(mPlanType,
                mStartPoit.getLongitudeE6(),
                mStartPoit.getLatitudeE6(),
                mStartLocation,
                mEndPoit.getLongitudeE6(),
                mEndPoit.getLatitudeE6(),
                mEndLocation,
                d.commonDistance,
                mIsSimulateNavi);

        Repository.addNaviHistory(n);

    }


    public NLocationGPS getGPSLocationClient(){
        if(mLocationGPS==null) {
            mLocationGPS=(NLocationGPS)getDefaultModel().getObject(NLocationGPS.class.getCanonicalName());
        }

        return mLocationGPS;
    }

    private boolean mNotifyRunning=false;
    private boolean mNotifyMoving=false;
    /**
     * 位置回调
     * @param location 经纬度
     */
    public void onLocationChanged(Location location){
        Log.e("cc","onLocationChanged");
        if (mNavigating && !mIsSimulateNavi ){
            getNaviManager().setNavigatorGPS(location.getLongitude()*3.6E6,
                    location.getLatitude()* 3.6E6,
                    location.getSpeed(),
                    location.getBearing());



            LocationData locData = getLocationData();
            if(locData!=null)
            {
                GeoPoint p = new GeoPoint((int) (location.getLatitude() * 3.6E6),
                        (int) (location.getLongitude() * 3.6E6));

                locData.pt = p;
                //如果不显示定位精度圈，将accuracy赋值为0即可
                locData.accuracy = location.getBearing();
            }



            if(!mIsNotifyGpsOk )
            {
                mIsNotifyGpsOk=true;
                AddAudioString("GPS定位成功");
                updateView(RET_GPS_OK);
            }

            float fSpeed=location.getSpeed()*3.6f;
            if(fSpeed<1.0f)
            {
                updateView(RET_CAR_STOP);
                mNotifyMoving=false;
                mNotifyRunning=false;
            }
            else if((fSpeed-10.0f)<0.001f && !mNotifyMoving)
            {
                mNotifyMoving=true;
                mNotifyRunning=false;
                updateView(RET_CAR_MOVING);

            }
            else if(fSpeed>10.0f && !mNotifyRunning)
            {
                mNotifyMoving=false;
                mNotifyRunning=true;
                updateView(RET_CAR_RUNING);
            }


            //Toast.makeText(mContext, " location = "+ location.getLongitude()*3.6E6+","+
            //        location.getLatitude()* 3.6E6 , Toast.LENGTH_SHORT).show();
        }
    }
    /**
     * 卫星数目回调
     * @param count 卫星数量
     */
    public void onSatelliteCountChanged(int count){
        Log.e("cc","onSatelliteCountChanged count="+count);
        //Toast.makeText(mContext, "Satellite count = "+ count, Toast.LENGTH_SHORT).show();
        updateView(RET_UPDATE_SATELLITE,count);

    }


    @Override
    public void onNavigationListener(int iStatus, NaviInfo naviInfo, int iError) {
        //mNaviInfo = naviInfo;
        updateView(RET_UPDATE_DATA_WHEN_NAVIGATE, iStatus, naviInfo, iError);
        if(iStatus==NaviState.NAVI_NAVIFINISH) mNavigating = false;


         if(naviInfo != null ){

            if(naviInfo.voiceString != null )
            {
                AddAudioString(naviInfo.voiceString);
            }
        }
    }


    GeoPoint mStartPoit=null;
    GeoPoint mEndPoit=null;
    String mPlanType=null;

    @Override
    public void startRoutrPlan(String sCms, GeoPoint start, GeoPoint end, List<GeoPoint> lsPassPoints) {
        super.startRoutrPlan(sCms, start, end, lsPassPoints);

        mStartPoit=start;
        mEndPoit=end;
        mPlanType=sCms;


    }

    String mStartLocation=null;
    public void getStartLocation(GeoPoint p)
    {
        GeoCoder  Search = GeoCoder.newInstance();
        Search.setOnGetGeoCodeResultListener(new OnGetGeoCoderResultListener() {
            @Override
            public void onGetReverseGeoCodeResult(ReverseGeoCodeResult reverseGeoCodeResult) {
                mStartLocation= WeNaviUtil.toLocationString(reverseGeoCodeResult);

                NaviController.this.getEndLocation(NaviController.this.mEndPoit);
            }

            @Override
            public void onGetGeoCodeResult(GeoCodeResult geoCodeResult) {

            }
        });
        boolean success = Search.reverseGeoCode(new ReverseGeoCodeOption().location(p));
    }


    String mEndLocation=null;
    public void getEndLocation(GeoPoint p)
    {
        GeoCoder  Search = GeoCoder.newInstance();
        Search.setOnGetGeoCodeResultListener(new OnGetGeoCoderResultListener() {
            @Override
            public void onGetReverseGeoCodeResult(ReverseGeoCodeResult reverseGeoCodeResult) {
                mEndLocation=WeNaviUtil.toLocationString(reverseGeoCodeResult);
                NaviController.this.saveNaviHistory();
            }

            @Override
            public void onGetGeoCodeResult(GeoCodeResult geoCodeResult) {

            }
        });
        boolean success = Search.reverseGeoCode(new ReverseGeoCodeOption().location(p));
    }




}
