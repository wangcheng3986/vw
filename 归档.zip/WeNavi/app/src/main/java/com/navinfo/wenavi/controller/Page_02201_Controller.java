package com.navinfo.wenavi.controller;

import android.content.Context;

import com.navinfo.audio.IAudioGenerateListerner;
import com.navinfo.sdk.mapapi.map.LocationData;
import com.navinfo.sdk.mapapi.search.adminarea.AdminAreaRecord;
import com.navinfo.sdk.mapapi.search.awsearch.AWSearchOption;
import com.navinfo.sdk.mapapi.search.awsearch.AWSearchResult;
import com.navinfo.sdk.mapapi.search.awsearch.AWSearcher;
import com.navinfo.sdk.mapapi.search.awsearch.OnGetAWSearchResultListener;
import com.navinfo.sdk.mapapi.search.poi.POISearchResult;
import com.navinfo.sdk.mapapi.search.poi.POISearcher;
import com.navinfo.wenavi.entity.AdminAreaEntity;
import com.navinfo.wenavi.entity.AppConfig;
import com.navinfo.wenavi.entity.NaviKeyWord;
import com.navinfo.wenavi.entity.CueWordEntity;
import com.navinfo.wenavi.model.Repository;


import java.util.List;

/**
 * Created by Doone on 2015/3/12.
 * 行车导航关键字搜索控制器
 */
public class Page_02201_Controller extends GisController  {


    /**
     * 功能代码: 查询历史关键字
     */
    public static final String CMD_GET_KEYWORDHISTORY = "CMD_GET_KEYWORDHISTORY";

    /**
     * 视图刷新代码: 历史关键字列表，附带 List<{@NaviKeyWord}>
     */
    public static final String RET_KEYWORDHISTORY = "RET_REVERSEGEOCODE";


    /**
     * 功能代码:增加历史关键字，附带 String
     */
    public static final String CMD_ADD_KEYWORD = "CMD_ADD_KEYWORD";


    /**
     * 功能代码:删除单个历史关键字，附带 String
     */
    public static final String CMD_DELETE_KEYWORD = "CMD_DELETE_KEYWORD";


    /**
     * 功能代码:返回当前行政区
     */
    public static final String CMD_GET_CURRENT_AREA = "CMD_GET_CURRENT_AREA";


    /**
     * 功能代码:设置当前行政区
     */
    public static final String CMD_SET_CURRENT_AREA = "CMD_SET_CURRENT_AREA";



    /**
     * 功能代码:删除所有历史关键字
     */
    public static final String CMD_DELETE_ALL_KEYWORD = "CMD_DELETE_ALL_KEYWORD";
    protected POISearcher mPoiSearch = null;
    /**
     * POI查询类别 周边查询
     */
    public static final String POI_SEARCH_TYPE_NEAR="POI_SEARCH_TYPE_NEAR";
    /**
     * 功能代码: 查询提示词
     */
    public static final String CMD_GET_CUEWORD = "CMD_GET_CUEWORD";

    public static final String RET_CUEWORD = "RET_CUEWORD";
    //播放识别错误
    public static final String CMD_PLAY_RECOGNIZE_ERROR = "CMD_PLAY_RECOGNIZE_ERROR";

    //错误播放结束
    public static final String RET_PLAY_ERROR_FINISH = "RET_PLAY_ERROR_FINISH";


    public static final String RET_CURRENT_AREA = "RET_CURRENT_AREA";


    /**
     * 当前选择的行政区
     */
    AdminAreaEntity mAdminRecord = null;

    public Page_02201_Controller(Context context) {
        super(context); // 初始化POI搜索模块，注册事件监听
        mPoiSearch = POISearcher.newInstance();
    }
    // 定位相关
    private LocationData locData = null;

    @Override
    public void executeAction(Object... actionDatas) {
        if (actionDatas.length > 0) {
            if (actionDatas[0].getClass().getCanonicalName().equals(String.class.getCanonicalName())) {
                String sCms = (String) (actionDatas[0]);
                if (sCms.equals(CMD_GET_KEYWORDHISTORY)) {
                    queryNaviKeyWordHistory();
                } else if (sCms.equals(CMD_ADD_KEYWORD) && actionDatas.length > 3) {
                    addNaviKeyWord((String) actionDatas[1],
                            (String) actionDatas[2],
                            (String) actionDatas[3]);
                } else if (sCms.equals(CMD_DELETE_KEYWORD) && actionDatas.length > 1) {
                    deleteNaviKeyWord((NaviKeyWord) actionDatas[1]);

                } else if (sCms.equals(CMD_DELETE_ALL_KEYWORD)) {
                    deleteAllNaviKeyWord();
                }
                else if(sCms.equals(CMD_GET_CURRENT_AREA))
                {
                    updateView(RET_CURRENT_AREA, getCurrentAdminArea());
                }
                else if(sCms.equals(CMD_SET_CURRENT_AREA) && actionDatas.length>1)
                {
                    setCurrentAdminArea((AdminAreaEntity)actionDatas[1]);
                }
                else if (sCms.equals(CMD_GET_CUEWORD)) {
                    queryCueWord((String) actionDatas[1], (String) actionDatas[2]);
                } else if (sCms.equals(CMD_PLAY_RECOGNIZE_ERROR)) {
                    play("对不起，未能识别目的地，请重说一遍", new IAudioGenerateListerner() {
                        @Override
                        public void onError(String s) {

                        }

                        @Override
                        public void onPlayFinished() {
                            updateView(RET_PLAY_ERROR_FINISH);

                        }
                    });
                }/*else if (sCms.equals(CMD_SEARCH_POI)) {
                    if (actionDatas.length == 5) {

                        searchPoi((String) actionDatas[1], (String) actionDatas[2],
                                (int)actionDatas[3],(int)actionDatas[4]);
                    }else if(actionDatas.length==6){
                        searchPoi((String) actionDatas[1], (int) actionDatas[2],
                                (String)actionDatas[3],(int)actionDatas[4],(int)(actionDatas[5]));
                    }
                }*/ else super.executeAction(actionDatas);

            }
        }

    }


    public void queryNaviKeyWordHistory() {
        //Repository rp=(Repository)getObject(Repository.class.getCanonicalName());
        List<NaviKeyWord> lsKeyWord = Repository.getNaviKeyWords();
        if (lsKeyWord != null) updateView(RET_KEYWORDHISTORY, lsKeyWord);

    }


    public void queryCueWord(String sWord, String sRegion) {
        //Repository rp=(Repository)getObject(Repository.class.getCanonicalName());
        //CueWordModel m=(CueWordModel)getObject(CueWordModel.class.getName());
//        CueWordModel m=(CueWordModel) getContext().getModel(CueWordModel.class.getName());
//        if(m!=null) {
//            CueWordEntity[] lsCueWord=m.getCueWords(sWord,sRegion);
//            if(lsCueWord!=null) updateView(RET_CUEWORD,lsCueWord);
//
//        }

        checkNetWork();

        final AWSearcher awSearcher = AWSearcher.newInstance();

        awSearcher.search(new AWSearchOption().param("pykw", sWord).param("city", sRegion).pageCapacity(10).pageNum(0));
        awSearcher.setOnGetAWSearchResultListener(new OnGetAWSearchResultListener() {
            @Override
            public void onGetAWSearchResult(AWSearchResult awSearchResult) {
                CueWordEntity[] cueWordEntities;
                if (awSearchResult != null && awSearchResult.pois != null && awSearchResult.pois.size() > 0) {
                    cueWordEntities = new CueWordEntity[awSearchResult.pois.size()];

                    for (int i = 0; i < awSearchResult.pois.size(); i++) {
                        CueWordEntity entity = new CueWordEntity();
                        entity.setName(awSearchResult.pois.get(i).name);
                        cueWordEntities[i] = entity;
                    }
                    updateView(RET_CUEWORD, cueWordEntities);
                }

            }
        });
    }


    public void addNaviKeyWord(String sKeyWord,String sCity,String sCityCode) {
        Repository.addNaviKeyWord(sKeyWord,sCity,sCityCode,0,0);

    }



    public void deleteNaviKeyWord(NaviKeyWord KeyWord) {
        KeyWord.delete();
    }


    public void deleteAllNaviKeyWord() {
        Repository.deleteAllNaviKeyWord();
    }


    public AdminAreaEntity getCurrentAdminArea()
    {

        if(mAdminRecord==null)
        {
            String sCode="110000";
            AppConfig cityCode = Repository.getAppConfig("CurrentCityCode");
            if(cityCode!=null) sCode=cityCode.getParamValue();
            if(sCode != null){
                mAdminRecord = Repository.getAdminAreaByCode(sCode);
            }
        }

        if (mAdminRecord == null){
            mAdminRecord = new AdminAreaEntity();
            mAdminRecord.setCode("110000");
            mAdminRecord.setName("北京市");
        }
        return mAdminRecord;
    }



    public  void setCurrentAdminArea(AdminAreaEntity area)
    {
        mAdminRecord=area;
        updateView(RET_CURRENT_AREA, mAdminRecord);
    }
}
