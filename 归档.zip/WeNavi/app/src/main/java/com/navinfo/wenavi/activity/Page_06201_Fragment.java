package com.navinfo.wenavi.activity;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.navinfo.wenavi.R;

/**
 *
 */
public class Page_06201_Fragment extends WeNaviBaseFragment implements View.OnClickListener{


    private Button mBtBack;
    private Button mBtMz;
    private Button mBtFw;

    public Page_06201_Fragment() {
        // Required empty public constructor
    }


    @Override
    public void restoreViewStatus(Bundle status) {

    }

    @Override
    public Bundle getViewStatus() {
        return null;
    }

    @Override
    protected int getFragmentLayoutID() {
        return R.layout.page_06201;
    }

    /**
     * 初始化控件为不可用,页面初始化时调用
     */
    @Override
    public  void onDisableControl()
    {


    }

    /**
     * 初始化控件为可用,页面初始化完成后被延时调用
     */
    @Override
    public  void onEnableControl()
    {

    }

    @Override
    protected void bindUIControl(View v) {
        mBtBack = (Button) v.findViewById(R.id.btn_06201_back);

        mBtBack.setOnClickListener(this);
        mBtMz = (Button) v.findViewById(R.id.btn_disclaimer);

        mBtMz.setOnClickListener(this);
        mBtFw = (Button) v.findViewById(R.id.btn_service);

        mBtFw.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_06201_back:
                onBack();
                break;
            case R.id.btn_disclaimer:
                toPage(Page_06202_Fragment.class);
                break;
            case R.id.btn_service:
                toPage(Page_06203_Fragment.class);
                break;
            default:
                break;
        }
    }
}
