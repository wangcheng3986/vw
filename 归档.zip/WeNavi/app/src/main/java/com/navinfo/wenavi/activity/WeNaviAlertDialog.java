package com.navinfo.wenavi.activity;

import android.app.AlertDialog;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


import com.navinfo.mirrorlink.FramebufferContentConfig;
import com.navinfo.mirrorlink.IMirrorLinkManager;
import com.navinfo.mirrorlink.IMirrorLinkServerCallback;
import com.navinfo.mirrorlink.MirrorLinkConnectionManager;
import com.navinfo.mirrorlink.MirrorLinkContextManager;
import com.navinfo.mirrorlink.MirrorLinkManager;
import com.navinfo.mirrorlink.MirrorLinkNotificationManager;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.controller.RouteController;
import com.navinfo.wenavi.model.CustomDialog;
import com.navinfo.wenavi.model.WeNaviApplication;
import com.navinfo.wenavi.util.WeNaviUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Doone on 2015/2/16.
 * 消息对话框
 * 支持显示提示信息和确认信息
 * 支持使用车机本地消息UI显示提示信息和确认信息(如果车机ML客户端支持)
 */
public class WeNaviAlertDialog extends CustomDialog {


    private WeNaviBaseActivity mContext = null;

    public WeNaviAlertDialog(WeNaviBaseActivity activity) {
        super(activity);
        this.mContext = activity;
    }


    void updateUiCategory() {
        mContext.updateUICategory();


    }


    /**
     * 显示提示信息
     *
     * @param sTitle   标题
     * @param sMessage 消息内容
     * @param l        确认按钮事件接收器
     */
    public void showMessage(String sTitle, String sMessage, final DialogInterface.OnClickListener l) {


        boolean bShowed = false;


        if (!bShowed) {

            updateUiCategory();

            LoadDialog(R.layout.dialog_message);
            if (getView() == null) {
                return;
            }
            //setOnClickListener(l);

            TextView title = (TextView) getView().findViewById(R.id.txtTitle);
            title.setText(sTitle);

            TextView message = (TextView) getView().findViewById(R.id.txtMessage);
            message.setText(sMessage);

            Button ok = (Button) getView().findViewById(R.id.btOk);
            ok.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (l != null) l.onClick(null, 0);
                    WeNaviAlertDialog.this.hide();
                }
            });

            showAtLocation(mContext.findViewById(mContext.getLayoutIdForFragment()), Gravity.CENTER, 0, 0);


        }

    }


    /**
     * 显示提示信息
     *
     * @param sTitle   标题
     * @param sMessage 消息内容
     *                 用户点击后消失,或通过 hide() 主动关闭
     */
    public void showPopMessage(String sTitle, String sMessage) {


        updateUiCategory();

        LoadDialog(R.layout.dailog_message_pop);
        if (getView() == null) {
            return;
        }
        //setOnClickListener(l);

        TextView title = (TextView) getView().findViewById(R.id.txtTitle);
        title.setText(sTitle);

        TextView message = (TextView) getView().findViewById(R.id.txtMessage);
        message.setText(sMessage);

        showAtLocation(mContext.findViewById(mContext.getLayoutIdForFragment()), Gravity.CENTER, 0, 0);

    }

    public void showRecommendPark(final DialogInterface.OnClickListener l) {
        LoadDialog(R.layout.dialog_park);
        View v = getView();
        if (v != null) {

            Button ok = (Button) v.findViewById(R.id.btOk);
            ok.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    l.onClick(null, 0);
                    WeNaviAlertDialog.this.hide();
                }
            });

            Button cancel = (Button) v.findViewById(R.id.btCancel);
            cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    WeNaviAlertDialog.this.hide();
                }
            });

            showAtLocation(mContext.findViewById(mContext.getLayoutIdForFragment()), Gravity.CENTER, 0, 0);
        }
    }

    /**
     * 显示确认信息
     *
     * @param sTitle   标题
     * @param sMessage 消息内容
     * @param l        消息按钮事件接收器
     */
    public void showConfirm(String sTitle, String sMessage, final DialogInterface.OnClickListener l) {


        LoadDialog(R.layout.dialog_confirm);

        //setOnClickListener(l);
        View v = getView();
        if (v != null) {
            TextView title = (TextView) v.findViewById(R.id.txtTitle);
            title.setText(sTitle);

            TextView message = (TextView) v.findViewById(R.id.txtMessage);
            message.setText(sMessage);


            Button ok = (Button) v.findViewById(R.id.btOk);
            ok.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (l != null) l.onClick(null, 0);
                    WeNaviAlertDialog.this.hide();
                }
            });

            Button cancel = (Button) v.findViewById(R.id.btCancel);
            cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (l != null) l.onClick(null, 1);
                    WeNaviAlertDialog.this.hide();
                }
            });

            showAtLocation(mContext.findViewById(mContext.getLayoutIdForFragment()), Gravity.CENTER, 0, 0);






        /*boolean bShowed = false;


        if (!bShowed) {

            //if (mManager != null) mManager.removeCallback(this);

            final AlertDialog dlg = new AlertDialog.Builder(mContext).create();
           // .setTitle(sTitle)
           // .setMessage(sMessage)
           // .setPositiveButton("确定",l)
           //         .setNegativeButton("取消",l).create();
            dlg.show();


           Window window = dlg.getWindow();

            window.setContentView(R.layout.dialog_confirm);
            //final ViewGroup root = (ViewGroup) window.findViewById(R.id.layoutroot);
            //if (root != null) WeNaviUtil.updateUiTextSize(mContext, root);

            TextView title = (TextView) window.findViewById(R.id.txtTitle);
            title.setText(sTitle);

            TextView message = (TextView) window.findViewById(R.id.txtMessage);
            message.setText(sMessage);

            Button ok = (Button) window.findViewById(R.id.btOk);
            ok.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (l != null) l.onClick(dlg, 0);
                    dlg.dismiss();
                }
            });

            Button cancel = (Button) window.findViewById(R.id.btCancel);
            cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (l != null) l.onClick(dlg, 1);
                    dlg.cancel();
                }
            });


        }*/

        }

    }

    public void showSetScope(String sType, final DialogInterface.OnClickListener l) {


        LoadDialog(R.layout.dialog_set_scope);

        if (getView() == null) {
            return;
        }
        Button btTime = (Button) getView().findViewById(R.id.rbTime);
        Button btHighWay = (Button) getView().findViewById(R.id.rbHighWay);
        Button btDis = (Button) getView().findViewById(R.id.rbDis);
        Button btFree = (Button) getView().findViewById(R.id.rbFree);
        Button btWf = (Button) getView().findViewById(R.id.btntf);


        final ImageButton imOne = (ImageButton) getView().findViewById(R.id.imOne);
        final ImageButton imTwo = (ImageButton) getView().findViewById(R.id.imTwo);
        final ImageButton imThree = (ImageButton) getView().findViewById(R.id.imThree);
        final ImageButton imFour = (ImageButton) getView().findViewById(R.id.imFour);
        final ImageButton imFive = (ImageButton) getView().findViewById(R.id.imFive);

        if (sType.equals("0"))
            imOne.setImageResource(R.drawable.ui_02402_btn_selected);
        else if (sType.equals("1"))
            imTwo.setImageResource(R.drawable.ui_02402_btn_selected);
        else if (sType.equals("2"))
            imThree.setImageResource(R.drawable.ui_02402_btn_selected);
        else if (sType.equals("3"))
            imFour.setImageResource(R.drawable.ui_02402_btn_selected);
        else if (sType.equals("4"))
            imFive.setImageResource(R.drawable.ui_02402_btn_selected);

        View.OnClickListener btClick = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int nID = v.getId();
                int index = 0;
                imOne.setImageResource(R.drawable.ui_02402_btn_non_selected);
                imTwo.setImageResource(R.drawable.ui_02402_btn_non_selected);
                imThree.setImageResource(R.drawable.ui_02402_btn_non_selected);
                imFour.setImageResource(R.drawable.ui_02402_btn_non_selected);
                imFive.setImageResource(R.drawable.ui_02402_btn_non_selected);

                if (nID == R.id.imOne || nID == R.id.rbTime) {
                    imOne.setImageResource(R.drawable.ui_02402_btn_selected);
                    index = 0;
                } else if (nID == R.id.imTwo || nID == R.id.rbHighWay) {
                    imTwo.setImageResource(R.drawable.ui_02402_btn_selected);
                    index = 1;
                } else if (nID == R.id.imThree || nID == R.id.rbDis) {
                    imThree.setImageResource(R.drawable.ui_02402_btn_selected);
                    index = 2;
                } else if (nID == R.id.imFour || nID == R.id.rbFree) {
                    imFour.setImageResource(R.drawable.ui_02402_btn_selected);
                    index = 3;
                } else if (nID == R.id.imFive || nID == R.id.btntf) {
                    imFive.setImageResource(R.drawable.ui_02402_btn_selected);
                    index = 4;
                }

                if (l != null) l.onClick(null, index);
                WeNaviAlertDialog.this.hide();
            }

        };

        btTime.setOnClickListener(btClick);
        btHighWay.setOnClickListener(btClick);
        btDis.setOnClickListener(btClick);
        btFree.setOnClickListener(btClick);
        btWf.setOnClickListener(btClick);
        imOne.setOnClickListener(btClick);
        imTwo.setOnClickListener(btClick);
        imThree.setOnClickListener(btClick);
        imFour.setOnClickListener(btClick);
        imFive.setOnClickListener(btClick);

        showAtLocation(mContext.findViewById(mContext.getLayoutIdForFragment()), Gravity.CENTER, 0, 0);


    }

    public void showRouteType(String sType, final DialogInterface.OnClickListener l) {


        LoadDialog(R.layout.dialog_routetype);
        if (getView() == null) {
            return;
        }
        Button btTime = (Button) getView().findViewById(R.id.rbTime);
        Button btHighWay = (Button) getView().findViewById(R.id.rbHighWay);
        Button btDis = (Button) getView().findViewById(R.id.rbDis);
        Button btFree = (Button) getView().findViewById(R.id.rbFree);


        final ImageButton imTime = (ImageButton) getView().findViewById(R.id.imTime);
        final ImageButton imHighWay = (ImageButton) getView().findViewById(R.id.imHighWay);
        final ImageButton imDis = (ImageButton) getView().findViewById(R.id.imDis);
        final ImageButton imFree = (ImageButton) getView().findViewById(R.id.imFree);

        if (sType.equals(RouteController.CMD_ROUTE_PLAN_TIME))
            imTime.setImageResource(R.drawable.ui_02402_btn_selected);
        else if (sType.equals(RouteController.CMD_ROUTE_PLAN_HIGHWAY))
            imHighWay.setImageResource(R.drawable.ui_02402_btn_selected);
        else if (sType.equals(RouteController.CMD_ROUTE_PLAN_DISTANCE))
            imDis.setImageResource(R.drawable.ui_02402_btn_selected);
        else if (sType.equals(RouteController.CMD_ROUTE_PLAN_FREECHARGE))
            imFree.setImageResource(R.drawable.ui_02402_btn_selected);

        View.OnClickListener btClick = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int nID = v.getId();

                imTime.setImageResource(R.drawable.ui_02402_btn_non_selected);
                imHighWay.setImageResource(R.drawable.ui_02402_btn_non_selected);
                imDis.setImageResource(R.drawable.ui_02402_btn_non_selected);
                imFree.setImageResource(R.drawable.ui_02402_btn_non_selected);


                if (nID == R.id.rbTime || nID == R.id.imTime)
                    imTime.setImageResource(R.drawable.ui_02402_btn_selected);
                else if (nID == R.id.rbHighWay || nID == R.id.imHighWay)
                    imHighWay.setImageResource(R.drawable.ui_02402_btn_selected);
                else if (nID == R.id.rbDis || nID == R.id.imDis)
                    imDis.setImageResource(R.drawable.ui_02402_btn_selected);
                else if (nID == R.id.rbFree || nID == R.id.imFree)
                    imFree.setImageResource(R.drawable.ui_02402_btn_selected);


                if (l != null) l.onClick(null, v.getId());
                WeNaviAlertDialog.this.hide();

            }

        };

        btTime.setOnClickListener(btClick);
        btHighWay.setOnClickListener(btClick);
        btDis.setOnClickListener(btClick);
        btFree.setOnClickListener(btClick);
        imTime.setOnClickListener(btClick);
        imHighWay.setOnClickListener(btClick);
        imDis.setOnClickListener(btClick);
        imFree.setOnClickListener(btClick);


        showAtLocation(mContext.findViewById(mContext.getLayoutIdForFragment()), Gravity.CENTER, 0, 0);


    }

}
