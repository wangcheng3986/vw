package com.navinfo.wenavi.model;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.navinfo.sdk.mapapi.search.adminarea.AdminArea;
import com.navinfo.sdk.mapapi.search.adminarea.AdminAreaListener;
import com.navinfo.sdk.mapapi.search.adminarea.AdminAreaRecord;
import com.navinfo.sdk.mapapi.search.adminarea.AdminAreaResult;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.entity.AdminAreaEntity;
import com.navinfo.wenavi.util.AdminAreaComparator;
import com.navinfo.wenavi.util.WeNaviUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Created by cc on 15/3/19.
 * //行政区数据体
 */
public class Page_02401_Model  extends BaseModel{

    //行政区搜索引起
    private AdminArea mAdminArea = null;
    //结果列表
    private List<AdminAreaEntity> mProvinceList = null;
    private Context mContext = null;

    private OnAdminAreaRecordListener mOnAdminAreaRecordListener = null;
    private Page_02401_ListAdapter mListAdapter = null;

    ArrayList<AdminAreaRecord> mResult;


    public Page_02401_Model(Context context){
        super(context);
        mContext = context;
        //检查数据库
        CheckAdminAreaToDatabase();
    }

    private void requestAdminArea(){
        //创建引擎
        mAdminArea = new AdminArea(new AdminAreaListener() {

            @Override
            public void onGetAdminAreaListener(AdminAreaResult adminAreaResult) {
                Log.d("updateDatabase","onGetAdminAreaListener-status="+adminAreaResult.status);
                if (adminAreaResult.citylist != null) {
                    //初始化行政区数据
                    mResult= mAdminArea.getAdminAreaRecord(adminAreaResult.citylist);
                    //实例化该任务，调用方法启动
                    DatabaseTask task=new DatabaseTask();
                    task.execute();

                }else{
                    mAdminArea.request();
                }
            }
        });
        mAdminArea.request();
    }

    //检查数据库
    private void CheckAdminAreaToDatabase(){
        Log.d("updateDatabase","CheckAdminAreaToDatabase-1");
        mProvinceList =  Repository.getSubAdminAreaByCode("PROVINCE");
        if ( (mProvinceList == null || mProvinceList.size() == 0)){
            Log.d("updateDatabase","CheckAdminAreaToDatabase-requestAdminArea");
            requestAdminArea();
        }else{
            Log.d("updateDatabase","CheckAdminAreaToDatabase-exist");
            long tm = mProvinceList.get(0).getAddTime().getTime();
            long cur_tm = new Date().getTime();
            long offset = (cur_tm - tm);
            if ( offset > 2592000000L ){
                Log.d("updateDatabase","CheckAdminAreaToDatabase-exist old request");
                requestAdminArea();
            }
        }
    }

    /**
     * 更新数据库
     * @param list
     * @return
     */
    private List<AdminAreaEntity>  updateDatabase(ArrayList<AdminAreaRecord> list ,int type, String parent){
        Log.d("updateDatabase","updateDatabase-"+type+","+parent);
        if (list != null) {
            //处理省级
            if (type == AdminAreaRecord.PROVINCE){
                ArrayList<AdminAreaEntity> province = new ArrayList<AdminAreaEntity> ();
                for (AdminAreaRecord record : list){
                    Log.d("updateDatabase","updateDatabase-PROVINCE list-"+record.name);
                    AdminAreaEntity temp = new AdminAreaEntity();
                    temp.setType(record.type);
                    temp.setPy(record.py);
                    temp.setParentCode(parent);
                    temp.setName(record.name);
                    temp.setCode(record.code);
                    temp.setLat(record.point.getLatitudeE6());
                    temp.setLon(record.point.getLongitudeE6());
                    province.add(temp);
                    Repository.insertAdminArea(temp);

                    updateDatabase(record.childCities, AdminAreaRecord.CITY ,record.code);
                }
                AdminAreaComparator mAdminAreaComparator = new AdminAreaComparator();
                Collections.sort(province, mAdminAreaComparator);
                return  province;
            }else if(type == AdminAreaRecord.CITY){
                for (AdminAreaRecord record : list){
                    Log.d("updateDatabase","updateDatabase-CITY list-"+record.name);
                    AdminAreaEntity temp = new AdminAreaEntity();
                    temp.setType(record.type);
                    temp.setPy(record.py);
                    temp.setParentCode(parent);
                    temp.setName(record.name);
                    temp.setCode(record.code);
                    temp.setLat(record.point.getLatitudeE6());
                    temp.setLon(record.point.getLongitudeE6());
                    Repository.insertAdminArea(temp);

                    updateDatabase(record.childRegions, AdminAreaRecord.REGION,record.code);
                }
            }else if(type == AdminAreaRecord.REGION){
                for (AdminAreaRecord record : list){
                    Log.d("updateDatabase","updateDatabase-REGION list-"+record.name);
                    AdminAreaEntity temp = new AdminAreaEntity();
                    temp.setType(record.type);
                    temp.setPy(record.py);
                    temp.setParentCode(parent);
                    temp.setName(record.name);
                    temp.setCode(record.code);
                    temp.setLat(record.point.getLatitudeE6());
                    temp.setLon(record.point.getLongitudeE6());
                    Repository.insertAdminArea(temp);
                }
            }
        }
        return null;
    }

    /**
     * 获取下级行政区
     * @param code
     * @return
     */
    public List<AdminAreaEntity> getSubAdminAreaList(String code){
         return Repository.getSubAdminAreaByCode(code);
    }


    /**
     * 获取省级行政区
     * @param listener
     * @return
     */
    public List<AdminAreaEntity> getProvinceRecords(OnAdminAreaRecordListener listener){
        mOnAdminAreaRecordListener = listener;
        return mProvinceList;
    }

    public interface OnAdminAreaRecordListener {
        /**
         * 行政区搜索回调
         * @param list 省级行政区数据列表
         */
        public void onAdminAreaRecordResponse(List<AdminAreaEntity> list);
    }



    private class DatabaseTask extends AsyncTask<Void, Integer, Integer> {

        DatabaseTask(){}

        @Override
        /**
         * 在后台运行并处理后台操作
         */
        protected Integer doInBackground(Void... params) {
            // TODO Auto-generated method stub
            Repository.deleteAllAdminArea();
            mProvinceList = updateDatabase(mResult ,AdminAreaRecord.PROVINCE, "PROVINCE");
            publishProgress(100);
            return 100;
        }
        /**
         * 将后台操作与主UI线程联系起来的方法,数据更新时调用
         * @param progress  完成度
         */
        protected void onProgressUpdate(Integer... progress){
        }
        /**
         * 将后台操作与主UI线程联系起来的方法，完成时调用
         * @param result  结果
         */
        protected void onPostExecute(Integer result){
            //回调消息
            if (mOnAdminAreaRecordListener != null){
                mOnAdminAreaRecordListener.onAdminAreaRecordResponse(mProvinceList);
            }
        }

    }


    public Page_02401_ListAdapter getPage_02401_ListAdapter(Context context)
    {
        if(mListAdapter==null)
        {
            mListAdapter=new Page_02401_ListAdapter(context);
        }

        return mListAdapter;
    }


    public class Page_02401_ListAdapter extends BaseAdapter {
        private class buttonViewHolder {
            TextView py;
            TextView name;
        }
        private buttonViewHolder holder;
        private String mCurrentPY = "";
        private List<AdminAreaEntity> mShowDataList = null;
        private Context mContext = null;

        public void setCurrentPY(String py) {
            this.mCurrentPY = py;
        }

        public void setShowAdminAreaRecordList(List<AdminAreaEntity> list) {
            this.mShowDataList = list;
        }

        public Page_02401_ListAdapter(Context context) {
            super();
            this.mContext = context;
        }

        @Override
        public View getView(int index, View convertView, ViewGroup parent) {
            if (convertView != null) {
                holder = (buttonViewHolder) convertView.getTag();
            } else {
                AbsListView.LayoutParams pm=new AbsListView.LayoutParams(
                        AbsListView.LayoutParams.MATCH_PARENT,
                        AbsListView.LayoutParams.MATCH_PARENT);


                LinearLayout layout=new LinearLayout(mContext);
                layout.setOrientation(LinearLayout.HORIZONTAL);
                layout.setLayoutParams(pm);
                layout.setMinimumHeight(WeNaviUtil.dip2px(mContext, 56));
                layout.setBackgroundResource(R.drawable.p2401_listitem_color);

                TextView pykey=new TextView(mContext);
                pykey.setTextColor(mContext.getResources().getColorStateList(R.drawable.p2401_listitem_txtcolor));
                pykey.setTextSize(19);
                pykey.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
                LinearLayout.LayoutParams pm1=new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        WeNaviUtil.dip2px(mContext, 56)
                );
                pm1.gravity=Gravity.CENTER;
                pm1.setMargins( WeNaviUtil.dip2px(mContext, 28),0,0,0);
                pykey.setLayoutParams(pm1);
                //name.setId()
                pykey.setTag("pykey");
                layout.addView(pykey);


                TextView name=new TextView(mContext);
                name.setTextColor(mContext.getResources().getColorStateList(R.drawable.p2401_listitem_txtcolor));
                name.setTextSize(19);
                name.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
                pm1=new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        WeNaviUtil.dip2px(mContext, 56)
                );
                pm1.gravity=Gravity.CENTER;
                pm1.setMargins( WeNaviUtil.dip2px(mContext, 14),0,0,0);
                name.setLayoutParams(pm1);
                //name.setId()
                name.setTag("name");
                layout.addView(name);


                convertView=layout;



                holder = new buttonViewHolder();
                convertView.setTag(holder);
            }
            holder.py = (TextView)convertView.findViewWithTag("pykey");//.findViewById(R.id.pykey);
            holder.name =  (TextView)convertView.findViewWithTag("name");//.findViewById(R.id.name);
            if (mCurrentPY.length() == 0){
                holder.py.setText(mShowDataList.get(index).getPy().substring(0,1));
            }else{
                holder.py.setText(mCurrentPY);
            }

            holder.name.setText(mShowDataList.get(index).getName());
            return convertView;
        }
        @Override
        public int getCount() {
            if (mShowDataList == null){
                return 0;
            }
            return mShowDataList.size();
        }
        @Override
        public Object getItem(int index) {
            if (mShowDataList == null){
                return null;
            }
            return  mShowDataList.get(index);
        }

        @Override
        public long getItemId(int id) {
            return id;
        }
    }

}
