package com.navinfo.wenavi.model;

import android.location.Location;

/**
 * gps定位监听
 * Created by cc on 15/3/4.
 */
public interface NLocationGPSListener {
    /**
     * 位置回调
     * @param location 经纬度
     */
    public void onLocationChanged(Location location);
    /**
     * 卫星数目回调
     * @param count 卫星数量
     */
    public void onSatelliteCountChanged(int count);
}
