package com.navinfo.wenavi.model;

import com.navinfo.wenavi.entity.KeywordEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by min on 2015/3/10.
 */
public class NaviKeywordModel {
    private List<KeywordEntity> list=new ArrayList<KeywordEntity>();

    public List<KeywordEntity> getHisKeyWords() {
        return list;
    }

    public void addHisKeyWord(KeywordEntity entity){
        list.add(entity);

    }

    public void delHisKeyWord(KeywordEntity entity){
        list.remove(entity);
    }
}
