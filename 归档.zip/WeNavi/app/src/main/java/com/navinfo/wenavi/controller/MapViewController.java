package com.navinfo.wenavi.controller;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ToggleButton;

import com.navinfo.mirrorlink.MirrorLinkEvent;
import com.navinfo.sdk.api.Const;
import com.navinfo.sdk.location.NavinfoLocation;
import com.navinfo.sdk.location.NavinfoLocationClient;
import com.navinfo.sdk.location.NavinfoLocationClientOption;
import com.navinfo.sdk.location.NavinfoLocationListener;
import com.navinfo.sdk.mapapi.map.Geometry;
import com.navinfo.sdk.mapapi.map.Graphic;
import com.navinfo.sdk.mapapi.map.GraphicsOverlay;
import com.navinfo.sdk.mapapi.map.LocationData;
import com.navinfo.sdk.mapapi.map.MKMapStatus;
import com.navinfo.sdk.mapapi.map.MKMapStatusChangeListener;
import com.navinfo.sdk.mapapi.map.MKMapTouchListener;
import com.navinfo.sdk.mapapi.map.MKMapViewListener;
import com.navinfo.sdk.mapapi.map.MapController;
import com.navinfo.sdk.mapapi.map.MapPoi;
import com.navinfo.sdk.mapapi.map.MapView;
import com.navinfo.sdk.mapapi.map.MyLocationOverlay;
import com.navinfo.sdk.mapapi.map.ScaleInfo;
import com.navinfo.sdk.mapapi.map.Symbol;

import com.navinfo.sdk.mapapi.search.poi.POISearchResult;

import com.navinfo.sdk.mapapi.utils.DistanceUtil;
import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.activity.MapScaler;
import com.navinfo.wenavi.util.WeNaviUtil;
import com.tencent.map.geolocation.TencentLocation;

/**
 * Created by Doone on 2015/2/27.
 */
public class MapViewController extends GisController implements NavinfoLocationListener,
        MKMapViewListener,
        MKMapStatusChangeListener,
        MKMapTouchListener,
        ViewTreeObserver.OnGlobalLayoutListener{

    private final static String LOG_TAG = MapViewController.class.getCanonicalName();

    /**
     * 功能代码: 显示当前位置
     */
    public static final String CMD_CURRENT_LOCATION="CMD_CURRENT_LOCATION";

    /**
     * 功能代码: 开始定位
     */
    public static final String CMD_START_LOCATION="CMD_START_LOCATION";

    /**
     * 功能代码: 停止定位
     */
    public static final String CMD_STOP_LOCATION="CMD_STOP_LOCATION";



    /**
     * 功能代码: 打开距离指示器
     */
    public static final String CMD_OPEN_DISTANCE_OVERLAY="CMD_OPEN_DISTANCE_OVERLAY";


    /**
     * 功能代码: 关闭距离指示器
     */
    public static final String CMD_CLOSE_DISTANCE_OVERLAY="CMD_CLOSE_DISTANCE_OVERLAY";


    /**
     * 功能代码: 平移地图,附带参数 MirrorLinkEvent.KnobShiftDirection
     */
    public static final String CMD_SHIFT_MAP="CMD_SHIFT_MAP";


    /**
     * 功能代码: 缩放地图,附带参数 MirrorLinkEvent.KnobRotateDirection
     */
    public static final String CMD_SCALE_MAP="CMD_SCALE_MAP";


    /***
     * 功能代码: 单次放大地图
     */
    public static final String CMD_ZOOMIN_MAP="CMD_ZOOMIN_MAP";


    /***
     * 功能代码: 单次缩小地图
     */
    public static final String CMD_ZOOMOUT_MAP="CMD_ZOOMOUT_MAP";


    /***
     * 功能代码: 恢复地图指北
     */
    public static final String CMD_NORTH_MAP="CMD_NORTH_MAP";


    /***
     * 功能代码: 打开路况图层
     */
    public static final String CMD_OPEN_TRAFFIC="CMD_OPEN_TRAFFIC";



    /***
     * 功能代码: 关闭路况图层
     */
    public static final String CMD_CLOSE_TRAFFIC="CMD_CLOSE_TRAFFIC";


    /***
     * 功能代码: 绑定指南针控件,附带ImageButton
     */
    public static final String CMD_BIND_COMPASS="CMD_BIND_COMPASS";

    /***
     * 功能代码: 绑定放大控件,附带ImageButton
     */
    public static final String CMD_BIND_ZOOMIN="CMD_BIND_ZOOMIN";


    /***
     * 功能代码: 绑定缩小控件,附带ImageButton
     */
    public static final String CMD_BIND_ZOOMOUT="CMD_BIND_ZOOMOUT";


    /***
     * 功能代码: 绑定当前位置控件,附带ImageButton
     */
    public static final String CMD_BIND_CURLOC="CMD_BIND_CURLOC";



    /***
     * 功能代码: 绑定交通流量控件,附带ToggleButton
     */
    public static final String CMD_BIND_TRAFFIC="CMD_BIND_TRAFFIC";


    /***
     * 功能代码: 绑定MAPSCALER比例尺控件,附带MapScaler
     */
    public static final String CMD_BIND_MAPSCALER="CMD_BIND_MAPSCALER";



    /**
     * 功能代码: 设置地图中心， 附带GenPoint 作为中心点
     */
    public static final String CMD_SET_MAP_CENTER="CMD_SET_MAP_CENTER";

    /**
     * 视图刷新代码: 位置更新，附带 NavinfoLocation 对象
     */
    public static final String RET_LOCATION="RET_LOCATION";



    /**
     * 视图刷新代码: 地图点击， 附带 GeoPoint 对象
     */
    public static final String RET_MAP_CLICKED="RET_MAP_CLICKED";

    /**
     * 视图刷新代码: 地图移动结束
     */
    public static final String RET_MAP_MOVEFINISH="RET_MAP_MOVEFINISH";


    /**
     * 视图刷新代码: 地图渲染结束
     */
    public static final String RET_MAP_ANIMATIONFINISH="RET_MAP_ANIMATIONFINISH";

    /**
     * 视图刷新代码: 地图状态改变
     */
    public static final String RET_MAP_STATUS_CHANGED="RET_MAP_STATUS_CHANGED";


    /**
     * 视图刷新代码: 地图加载完毕
     */
    public static final String RET_MAP_LOADFINISH="RET_MAP_LOADFINISH";


    /**
     * 视图刷新代码: 地图中心点与当前位置距离， 附带 int ，距离 米
     */
    public static final String RET_DISTANCE_TO_CURRENT_LOC="RET_DISTANCE_TO_CURRENT_LOC";


    /**
     * 视图刷新代码: 错误信息， 附带 Error String对象
     */
    public static final String RET_DISTANCE_INDICATOR_OPENED="RET_DISTANCE_INDICATOR_OPENED";




    public static final String PROPERTY_IS_MAP_LOADED="PROPERTY_IS_MAP_LOADED";



    // 定位
    private NavinfoLocationClient mLocClient=null;
    private NavinfoLocationClientOption locOption=null;



    boolean isNeedAutoMoveCenter = true;// 是否手动触发请求定位
    boolean isFirstLoc = true;// 是否首次定位

    private MapView mMapView=null;
    private MapController mMapController = null;
    // 定位相关
    private LocationData locData = null;
    // 定位图层
    private MyLocationOverlay mMyLocationOverlay = null;


    private GraphicsOverlay mGraphicOverlay=null;
    private Graphic mGraphicLine=null;

    protected boolean isNeedShowMyLocation=true;

    protected boolean isNeedLocation=true;


    protected  boolean isSetMapkitLayout=false;

    protected  boolean isMapLoaded=false;

    protected int maxZoomLevel;
    protected int minZoomLevel;


    protected ImageButton mBindCompass=null;
    protected Bitmap compassBitmap=null;
    protected MapScaler mBindMapScaler=null;
    protected Button mButtonZoomin=null;
    protected Button mButtonZoomout=null;
    protected Button mButtonCurLoc=null;
    protected ToggleButton mButtonTraffic=null;
    private GeoPoint mCenterGeoPoint = null;

    protected Handler mHandler =new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 0:
                {
                    if(mGraphicOverlay==null) {
                        return ;
                    }
                    GeoPoint geoPoints[] = new GeoPoint[2];

                    geoPoints[0] = mMapView.getMapCenter();
                    if (locData != null && locData.pt!=null)
                        geoPoints[0] = locData.pt;
                    geoPoints[1] = mCenterGeoPoint;

                    if(mGraphicOverlay!=null && mMapView.getOverlays().contains(mGraphicOverlay))
                    {
                        Geometry GeometryLine = mGraphicLine.getGeometry();
                        GeometryLine.setPolyLine(geoPoints);
                        mGraphicOverlay.updateData(mGraphicLine);
                        int distance = (int) DistanceUtil.getDistance(geoPoints[0], geoPoints[1]);
                        updateView(RET_DISTANCE_TO_CURRENT_LOC,distance);
                    }
                }
                    break;
                default:
                    break;
            }
        }
    };

    public MapViewController(Context context)
    {
        super(context);



        mMapView=getMapView();

        ViewTreeObserver vto2 = mMapView.getViewTreeObserver();
        vto2.addOnGlobalLayoutListener(this);


        mMyLocationOverlay=getMyLoactionOverlay();



        locData=getLocationData();


        compassBitmap= BitmapFactory.decodeResource(getContext().getResources(), R.drawable.ui_01401_map_compass);

    }


    @Override
    public void onGlobalLayout() {
        //mMapView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
        //textView.append("\n\n"+imageView.getHeight()+","+imageView.getWidth());

        if(!isSetMapkitLayout)
        {
            setMapkitLayout();
            isSetMapkitLayout=true;
        }
    }


    public boolean isMapLoaded()
    {
        return isMapLoaded;
    }


    protected int dpToPixel(DisplayMetrics dm,int dp)
    {
        int px = dp * (dm.densityDpi / 160);
        return px;
    }

    protected  void setMapkitLayout()
    {
        if(mMapView!=null) {
            WindowManager manager = (WindowManager) Const.getAppContext().getSystemService(Context.WINDOW_SERVICE);
            DisplayMetrics dm = new DisplayMetrics();
            manager.getDefaultDisplay().getMetrics(dm);

            //px = dp * (dm.densityDpi / 160)

            //设置显示缩放按钮
            ShowParam pm=getShowBuiltInZoomControls(dm);
            mMapView.ShowBuiltInZoomControls(pm.isShow);
            if(pm.isShow && pm.x>=0 && pm.y >=0)
                mMapView.setBuiltInZoomControlsPosition(pm.y, pm.x);


            //设置显示比例尺
            pm=getShowScaleControl(dm);
            mMapView.ShowScaleControl(pm.isShow);
            if(pm.isShow && pm.x>=0 && pm.y >=0)
                mMapView.setScaleControlPosition(pm.y, pm.x);


            //设置显示实时路况开关
            pm=getShowTrafficControl(dm);
            mMapView.ShowTrafficControl(pm.isShow);
            if(pm.isShow && pm.x>=0 && pm.y >=0)
                mMapView.setTrafficControlPosition(pm.y, pm.x);

            //设置显示指南针
            pm=getShowCompassControl(dm);
            mMapView.ShowCompassControl(pm.isShow);
            if(pm.isShow && pm.x>=0 && pm.y >=0)
                mMapView.setCompassPosition(pm.y, pm.x);



        }
    }

    /**
     *  MapView内建控件显示控制参数类
     */
    public class  ShowParam
    {
        public boolean isShow=false;
        public int x=0;
        public int y=0;
    }

    /**
     * 显示MapView内建缩放控件参数
     * @param dm {@link android.util.DisplayMetrics}
     * @return  {@link com.navinfo.wenavi.controller.MapViewController.ShowParam}
     */
    protected ShowParam getShowBuiltInZoomControls(DisplayMetrics dm )
    {
        ShowParam pm=new ShowParam();
        pm.isShow=false;

        int l=mMapView.getLeft();
        int r=mMapView.getRight();
        int t=mMapView.getTop();
        int h=mMapView.getHeight();
        int w=mMapView.getWidth();
        pm.y = t + h / 2 -mMapView.getBuiltInZoomControlsHeight() / 2;
        pm.x = l + w - mMapView.getBuiltInZoomControlsWidth() - dpToPixel(dm,5);

        return pm;
    }


    /**
     * 显示MapView内建比例尺控件参数
     * @param dm {@link android.util.DisplayMetrics}
     * @return  {@link com.navinfo.wenavi.controller.MapViewController.ShowParam}
     */
    protected ShowParam getShowScaleControl(DisplayMetrics dm )
    {
        ShowParam pm=new ShowParam();
        pm.isShow=false;

        int l=mMapView.getLeft();
        int r=mMapView.getRight();
        int t=mMapView.getTop();
        int h=mMapView.getHeight();
        int w=mMapView.getWidth();

        pm.y = t + h - dpToPixel(dm, 50);
        pm.x = l + dpToPixel(dm,  170);


        return pm;
    }


    /**
     * 显示MapView内建实时交通控件参数
     * @param dm {@link android.util.DisplayMetrics}
     * @return  {@link com.navinfo.wenavi.controller.MapViewController.ShowParam}
     */
    protected ShowParam getShowTrafficControl(DisplayMetrics dm )
    {
        ShowParam pm=new ShowParam();
        pm.isShow=false;
        pm.x=-1; //使用默认位置
        pm.y=-1; //使用默认位置

        int l=mMapView.getLeft();
        int r=mMapView.getRight();
        int t=mMapView.getTop();
        int h=mMapView.getHeight();
        int w=mMapView.getWidth();
        pm.y =t +  dpToPixel(dm,  5);
        pm.x =l + w - mMapView.getTrafficControlIconWdith() - dpToPixel(dm,5);

        return pm;
    }


    /**
     * 显示MapView内建指南针控件参数
     * @param dm {@link android.util.DisplayMetrics}
     * @return  {@link com.navinfo.wenavi.controller.MapViewController.ShowParam}
     */
    protected ShowParam getShowCompassControl(DisplayMetrics dm )
    {
        ShowParam pm=new ShowParam();
        pm.isShow=false;

        int l=mMapView.getLeft();
        int r=mMapView.getRight();
        int t=mMapView.getTop();
        int h=mMapView.getHeight();
        int w=mMapView.getWidth();
        pm.y =t + mMapView.getTrafficControlIconHeight() + dpToPixel(dm,  30);
        pm.x =l + w + dpToPixel(dm,  10) - mMapView.getCompassPositionWidth();


        return pm;
    }


    private void prepareMapView()
    {
        if(mMapView!=null) {

            ViewTreeObserver vto2 = mMapView.getViewTreeObserver();
            vto2.addOnGlobalLayoutListener(this);

            //注册监听器
            mMapView.regMapViewListener(this);
            mMapView.regMapTouchListner(this);
            mMapView.regMapStatusChangeListner(this);

        }
    }

    public void openLocation()
    {
        //开始定位
        locOption = new NavinfoLocationClientOption();
        locOption.setLocMode(NavinfoLocationClientOption.LocationMode.Hight_Accuracy);
        locOption.setCoordinateType(NavinfoLocationClientOption.COORDINATE_TYPE_GCJ02);
        locOption.setRequestLevel(NavinfoLocationClientOption.REQUEST_LEVEL_GEO);
        locOption.setMillis(1000);

        mLocClient = getLocationClient();
        mLocClient.setLocOption(locOption);
        mLocClient.setNiLocationListener(this);
    }






    public void showMyLocation()
    {

        // 定位图层初始化
        //myLocationOverlay = ((WeNaviApplication) getApplicationContext()).getMyLoactionOverlay();//new locationOverlay(mMapView);
        if (mMyLocationOverlay !=null && !mMapView.getOverlays().contains(mMyLocationOverlay))
            mMapView.getOverlays().add(mMyLocationOverlay);
        if (mMyLocationOverlay!=null)  mMyLocationOverlay.setVisibility(true);
    }



    public void hideMyLocation()
    {

        if (mMyLocationOverlay!=null && mMapView.getOverlays().contains(mMyLocationOverlay))
            //mMapView.getOverlays().remove(mMyLocationOverlay);
            mMyLocationOverlay.setVisibility(false);

        //if(mMyLocationOverlay!=null) mMyLocationOverlay.destroy();
        //mMyLocationOverlay=null;

    }

    @Override
    public Object getObject(String sName) {
        if(sName==PROPERTY_IS_MAP_LOADED)
            return isMapLoaded();
        return super.getObject(sName);
    }

    @Override
    public void onViewPause() {
        super.onViewPause();

        if(isNeedShowMyLocation) hideMyLocation();
        if(isNeedLocation) mLocClient.stop();

        mMapView.setKeepScreenOn(false);
        mMapView.onPause();


          mBindCompass=null;

          mBindMapScaler=null;
          mButtonZoomin=null;
          mButtonZoomout=null;
          mButtonCurLoc=null;
          mButtonTraffic=null;
    }

    @Override
    public void onViewResume() {
        super.onViewResume();


        prepareMapView();
        if(isNeedShowMyLocation) showMyLocation();
        if(isNeedLocation) openLocation();

        mMapView.onResume();
        mMapView.setKeepScreenOn(true);
        startLocation();

        setMapkitLayout();

    }


    @Override
    public void onViewBack() {
        super.onViewBack();

        stopLocation();
        mMapView.onPause();

    }

    @Override
    public void destroy() {

        closeDistanceOverlay();

        super.destroy();
    }

    @Override
    public void executeAction(Object... actionDatas) {
        if(actionDatas.length>0)
        {
            if(actionDatas[0].getClass().equals(String.class))
            {
                String sCms=(String)(actionDatas[0]);

                if(sCms.equals(CMD_CURRENT_LOCATION)) getCurrentLocation();

                else if(sCms.equals(CMD_START_LOCATION)) startLocation();

                else if(sCms.equals(CMD_STOP_LOCATION)) stopLocation();

                else if(sCms.equals(CMD_SHIFT_MAP))
                {
                    if(actionDatas.length>1 &&
                            actionDatas[1].getClass().equals(MirrorLinkEvent.KnobShiftDirection.class) ) {
                        shiftMap((MirrorLinkEvent.KnobShiftDirection)actionDatas[1]);
                    }

                }
                else if(sCms.equals(CMD_SCALE_MAP)) {
                    if (actionDatas.length > 1 &&
                            actionDatas[1].getClass().equals(MirrorLinkEvent.KnobRotateDirection.class)) {
                        scaleMap((MirrorLinkEvent.KnobRotateDirection) actionDatas[1]);
                    }

                }
                else if(sCms.equals(CMD_OPEN_DISTANCE_OVERLAY)) openDistanceOverlay();
                else if(sCms.equals(CMD_CLOSE_DISTANCE_OVERLAY)) closeDistanceOverlay();
                else if(sCms.equals(CMD_GET_REVERSEGEOCODE))
                {
                    if(actionDatas.length>1 &&
                            actionDatas[1].getClass().equals(GeoPoint.class) ) {
                        getReverseGeoCode((GeoPoint)actionDatas[1]);
                    }
                    else
                    {
                        getReverseGeoCode(mMapView.getMapCenter());
                    }
                }
                else if(sCms.equals(CMD_SET_MAP_CENTER))
                {
                    if (actionDatas.length > 1 &&
                            actionDatas[1].getClass().equals(GeoPoint.class))
                    {
                        isNeedAutoMoveCenter = false;
                        getMapView().getController().setCenter((GeoPoint)actionDatas[1]);
                    }

                }
                else if(sCms.equals(CMD_ZOOMIN_MAP))
                    zoomIn();
                else if(sCms.equals(CMD_ZOOMOUT_MAP))
                    zoomOut();
                else if(sCms.equals(CMD_OPEN_TRAFFIC))
                    openTraffic();
                else if(sCms.equals(CMD_CLOSE_TRAFFIC))
                    closeTraffic();
                else if(sCms.equals(CMD_NORTH_MAP))
                    northMap();
                else if(sCms.equals(CMD_BIND_COMPASS))
                {
                    if (actionDatas.length > 1) bindCompass((ImageButton)actionDatas[1]);
                }
                else if(sCms.equals(CMD_BIND_MAPSCALER))
                {
                    if (actionDatas.length > 1) bindMapScaler((MapScaler) actionDatas[1]);
                }
                else if(sCms.equals(CMD_BIND_ZOOMIN))
                {
                    if (actionDatas.length > 1) bindZoomin((Button)actionDatas[1]);
                }
                else if(sCms.equals(CMD_BIND_ZOOMOUT))
                {
                    if (actionDatas.length > 1) bindZoomout((Button)actionDatas[1]);
                }
                else if(sCms.equals(CMD_BIND_CURLOC))
                {
                    if (actionDatas.length > 1) bindCurLocation((Button)actionDatas[1]);
                }
                else if(sCms.equals(CMD_BIND_TRAFFIC))
                {
                    if (actionDatas.length > 1) bindTraffic((ToggleButton)actionDatas[1]);
                }
                else if (sCms.equals(CMD_GET_AUDIO_POI)) {
                    Log.d(LOG_TAG, "actionDatas.length=" + actionDatas.length);
                    GeoPoint p = getMapView().getMapCenter();
                    LocationData d = getLocationData();
                    if (d != null && d.pt != null) {
                        p = d.pt;
                    }

                    getPoibyAudio(p);

                }
                else super.executeAction(actionDatas);

            }
        }
    }



    public NavinfoLocationClient getLocationClient(){
        if(mLocClient==null) {
            mLocClient=(NavinfoLocationClient)getDefaultModel().getObject(NavinfoLocationClient.class.getCanonicalName());
        }

        return mLocClient;
    }


    public MapView getMapView(){
        if(mMapView == null){
            mMapView = (MapView)getDefaultModel().getObject(MapView.class.getCanonicalName());
        }
        return mMapView;
    }



    /**
     * 当前位置显示对象
     * @return MyLocationOverlay 实例
     */
    public MyLocationOverlay getMyLoactionOverlay(){
        if(mMyLocationOverlay==null) {
            mMyLocationOverlay=(MyLocationOverlay)getDefaultModel().getObject(MyLocationOverlay.class.getCanonicalName());
        }

        /*if(mMyLocationOverlay==null) {
            mMyLocationOverlay=new MyLocationOverlay(getMapView());
        }*/
        return mMyLocationOverlay;

    }

    public LocationData getLocationData()
    {
        if(locData==null)
        {
            locData=(LocationData)getDefaultModel().getObject(LocationData.class.getCanonicalName());
            if (mLocClient != null){
                NavinfoLocation data = mLocClient.getLastKnownLocation();
                GeoPoint p = new GeoPoint((int) (data.getLatitude() * 3.6E6), (int) (data.getLongitude() * 3.6E6));
                locData.pt = p;
                //如果不显示定位精度圈，将accuracy赋值为0即可
                locData.accuracy = data.getAccuracy();
            }
        }
        return locData;
    }






    public void getCurrentLocation()
    {
        if (getLocationData().pt != null){
            getMapView().getController().animateTo( getLocationData().pt);
        }

    }


    public void startLocation()
    {

        mLocClient.start();
    }


    public void stopLocation()
    {
        mLocClient.stop();
    }


    public void zoomIn()
    {
        if(isMapLoaded())
        {
            getMapView().getController().zoomIn();
        }
    }


    public void zoomOut()
    {
        if(isMapLoaded())
        {
            getMapView().getController().zoomOut();
        }
    }


    public void openTraffic()
    {
        if(isMapLoaded())
        {
            getMapView().setTraffic(true);
        }
    }


    public void closeTraffic()
    {
        if(isMapLoaded())
        {
            getMapView().setTraffic(false);
        }
    }


    public void northMap()
    {
        if(isMapLoaded())
        {
            //TODO:
            MKMapStatus mkStatus = mMapView.getMapStatus();
            mkStatus.mRotate = 0;
            getMapView().getController().setMapStatusWithAnimation(mkStatus);
        }
    }





    @Override
    public void onLocationChanged(NavinfoLocation location, int error,
                                  String reason) {

        if (error == TencentLocation.ERROR_OK) {
            Log.d(LOG_TAG, location.toString());
//				Toast.makeText(LocationDemo.this, location.getProvider(), Toast.LENGTH_SHORT).show();

            GeoPoint p = new GeoPoint((int) (location.getLatitude() * 3.6E6), (int) (location.getLongitude() * 3.6E6));
            locData.pt = p;
            //如果不显示定位精度圈，将accuracy赋值为0即可
            locData.accuracy = location.getAccuracy();

            mMapController = mMapView.getController();
            if(mMapController.isMapLoadFinish()){

                //更新定位数据
                if(mMyLocationOverlay!=null)
                    mMyLocationOverlay.setData(locData);
                //更新图层数据执行刷新后生效
                mMapView.refresh();
                //是手动触发请求或首次定位时，移动到定位点
                if (isNeedAutoMoveCenter && isFirstLoc) {
                    //移动地图到定位点
                    getMapView().getController().animateTo( locData.pt);

                }

                // 首次定位完成
                isFirstLoc = false;


            }

            updateView(RET_LOCATION,location);

        } else {
            Log.d("定位信息返回：", reason + error);
        }
    }

    @Override
    public void onStatusUpdate(String s, int i, String s2) {

        //wifi network定位状态
    }


    @Override
    public void onMapClick(GeoPoint geoPoint) {
        updateView(RET_MAP_CLICKED,geoPoint);

    }

    @Override
    public void onMapDoubleClick(GeoPoint geoPoint) {

    }

    @Override
    public void onMapLongClick(GeoPoint geoPoint) {

    }

    @Override
    public void onTouchEvent() {

    }

    @Override
    public void onMapMoveFinish() {
        updateView(RET_MAP_MOVEFINISH);

    }

    @Override
    public void onClickMapPoi(MapPoi mapPoi) {

    }

    @Override
    public void onMapAnimationFinish() {
        updateView(RET_MAP_ANIMATIONFINISH);

    }

    @Override
    public void onMapLoadFinish() {

        isMapLoaded=true;
        maxZoomLevel = getMapView().getMaxZoomLevel();
        minZoomLevel = getMapView().getMinZoomLevel();
        //mMapView.getController().setZoom(12);
        // mLocClient.start();
        updateView(RET_MAP_LOADFINISH);


    }



    public void openDistanceOverlay()
    {
        Log.d("overlay","openDistanceOverlay--1");
        if(!isMapLoaded){
            return;
        }

        if (mGraphicOverlay == null ){
            mGraphicOverlay = new GraphicsOverlay(mMapView);
            mGraphicOverlay.setOverlayPriority(6);
            mMapView.getOverlays().add(mGraphicOverlay);
            mMapView.regMapStatusChangeListner(this);

            GeoPoint geoPoints[] = new GeoPoint[2];

            geoPoints[0] = mMapView.getMapCenter();
            geoPoints[1] = geoPoints[0];

            if (locData != null && locData.pt!=null)
                geoPoints[0] = locData.pt;

            Geometry GeometryLine = new Geometry();
            GeometryLine.setPolyLine(geoPoints);
            Symbol mSymbol = new Symbol();
            mSymbol.setLineSymbol(new Symbol.Color(0xff0000ff), WeNaviUtil.dip2px(getContext(),2));
            // mSymbol.setLineArrow(new Symbol.Color(0xff0000ff), true);
            mGraphicLine = new Graphic(GeometryLine, mSymbol);

            mGraphicOverlay.setData(mGraphicLine);

            int distance = (int) DistanceUtil.getDistance(geoPoints[0], geoPoints[1]);
            updateView(RET_DISTANCE_TO_CURRENT_LOC,distance);
        }

        Log.d("overlay","openDistanceOverlay--3");



    }


    public void updateDistanceOverlay(GeoPoint p)
    {
        if (p != null ){
            mCenterGeoPoint = p;
//        mHandler.removeMessages(0);
            mHandler.sendEmptyMessageDelayed(0,200);
        }
    }


    public void closeDistanceOverlay()
    {

        if (mGraphicOverlay != null){
            Log.d("overlay","closeDistanceOverlay");
            mGraphicOverlay.removeAll();
            mMapView.getOverlays().remove(mGraphicOverlay);
            mGraphicOverlay = null;
            mGraphicLine = null;
            mMapView.refresh();
        }
    }

    void bindCompass(ImageButton btCompass)
    {
        mBindCompass=btCompass;
        mBindCompass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MapViewController.this.northMap();
            }
        });
    }


    void bindMapScaler(MapScaler scaler)
    {
        mBindMapScaler=scaler;
    }



    void bindZoomin(Button btZoomin)
    {
        mButtonZoomin=btZoomin;
        mButtonZoomin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MapViewController.this.zoomIn();
            }
        });
    }


    void bindZoomout(Button btZoomout)
    {
        mButtonZoomout=btZoomout;
        mButtonZoomout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MapViewController.this.zoomOut();
            }
        });
    }


    void bindCurLocation(Button btCurLoc)
    {
        mButtonCurLoc=btCurLoc;
        mButtonCurLoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MapViewController.this.getCurrentLocation();
            }
        });
    }


    void bindTraffic(ToggleButton btTraffic)
    {
        mButtonTraffic=btTraffic;
        mButtonTraffic.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) MapViewController.this.openTraffic();
                else MapViewController.this.closeTraffic();
            }
        });
    }

    @Override
    public void onMapStatusChange(MKMapStatus mkMapStatus) {

        updateView(RET_MAP_STATUS_CHANGED,mkMapStatus);
        /*
		 当地图旋转角度发生变化时设置外置指南针的旋转角度
        Matrix mMatrix = new Matrix();
        mMatrix.setRotate(mapStatus.mRotate);
        Bitmap mBitmap = Bitmap.createBitmap(compassBitmap, 0, 0, compassBitmap.getWidth(), compassBitmap.getHeight(), mMatrix, true);
        compass.setImageBitmap(mBitmap);
         */
        if(mBindCompass!=null)
        {
            Matrix matrix = new Matrix();

            float scaleWidth = ((float) mBindCompass.getWidth()) / compassBitmap.getWidth();
            float scaleHeight = ((float) mBindCompass.getHeight()) / compassBitmap.getHeight();
            matrix.postScale(scaleWidth, scaleHeight);
            Bitmap mBitmap= Bitmap.createBitmap(compassBitmap, 0, 0,compassBitmap.getWidth(),compassBitmap.getHeight(), matrix, true);

            //旋转
            matrix=new Matrix();
            matrix.setRotate(mkMapStatus.mRotate);
            Bitmap mBitmap1=Bitmap.createBitmap(mBitmap, 0, 0,mBitmap.getWidth(),mBitmap.getHeight(), matrix, true);
            mBindCompass.setBackgroundColor(Color.argb(0,0,0,0));
            mBindCompass.setImageBitmap(mBitmap1);
            mBitmap.recycle();




        }

            ScaleInfo info =  mMapView.getScaleInfo();
            if(mBindMapScaler!=null && info != null){
                mBindMapScaler.setScaleWidthAndMeters(mMapView.getHeight(), info.scalePixels, info.scaleMeters);
                mBindMapScaler.invalidate();
            }



        updateDistanceOverlay(mMapView.getMapCenter());


    }



    /// Map control

    public void shiftMap(MirrorLinkEvent.KnobShiftDirection dir)
    {
        int w=mMapView.getWidth();
        int h=mMapView.getHeight();

        if(dir== MirrorLinkEvent.KnobShiftDirection.ShiftDown)
        {
            mMapView.getController().setCenterToPixel(w/2,0);
        }
        else if(dir==MirrorLinkEvent.KnobShiftDirection.ShiftUp)
        {
            mMapView.getController().setCenterToPixel(w/2,h);
        }
        else if(dir==MirrorLinkEvent.KnobShiftDirection.ShiftLeft)
        {
            mMapView.getController().setCenterToPixel(w,h/2);
        }
        else if(dir==MirrorLinkEvent.KnobShiftDirection.ShiftRight)
        {
            mMapView.getController().setCenterToPixel(0,h/2);
        }
        else if(dir==MirrorLinkEvent.KnobShiftDirection.ShiftDownLeft)
        {
            mMapView.getController().setCenterToPixel(w,0);
        }
        else if(dir==MirrorLinkEvent.KnobShiftDirection.ShiftDownRight)
        {
            mMapView.getController().setCenterToPixel(0,0);
        }
        else if(dir==MirrorLinkEvent.KnobShiftDirection.ShiftUpLeft)
        {
            mMapView.getController().setCenterToPixel(w,h);
        }
        else if(dir==MirrorLinkEvent.KnobShiftDirection.ShiftUpRight)
        {
            mMapView.getController().setCenterToPixel(0,h);
        }
    }


    public void scaleMap(MirrorLinkEvent.KnobRotateDirection dir)
    {
        if(dir==MirrorLinkEvent.KnobRotateDirection.RotateRight) { //放大
            mMapView.getController().zoomIn();
        }
        else if(dir==MirrorLinkEvent.KnobRotateDirection.RotateLeft) { //缩小
            mMapView.getController().zoomOut();
        }

    }
}
