package com.navinfo.wenavi.util;

import android.util.Log;

import com.navinfo.wenavi.entity.AdminAreaEntity;

import java.util.Comparator;

/**
 * Created by cc on 15/3/22.
 */
public class AdminAreaComparator implements Comparator<AdminAreaEntity> {

    @Override
    public int compare(AdminAreaEntity lhs, AdminAreaEntity rhs) {

        int flag = lhs.getPySingle().substring(0, 1).compareTo(rhs.getPySingle().substring(0, 1));
        return flag;

    }


}
