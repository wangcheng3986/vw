package com.navinfo.wenavi.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import android.content.Context;
import android.location.GpsSatellite;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.navinfo.sdk.mapapi.utils.Encryption;
import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;

/**
 * Created by cc on 15/3/4.
 */
public class NLocationGPS {

    private Context mContext;
    private LocationManager mLocationManager;
    private String mProvider = LocationManager.GPS_PROVIDER;
    private NLocationGPSListener mGPSListener;

    public NLocationGPS(Context context) {
        Log.e("gps","construct");

        mContext = context;
        mLocationManager = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);
    }


    public void startGPS(long minTime, float minDistance) {
        Log.e("gps","startGPS");
        //Toast.makeText(mContext, "开始定位"+minDistance+ ","+minTime, Toast.LENGTH_SHORT).show();
        mLocationManager.requestLocationUpdates(mProvider, minTime, minDistance, mLocationListener);
        mLocationManager.addGpsStatusListener(mStatusListener);
    }

    public  void  stopGPS(){
        Log.e("gps","stopGPS");
        //Toast.makeText(mContext, "停止定位", Toast.LENGTH_SHORT).show();
        mLocationManager.removeUpdates(mLocationListener);
        mLocationManager.removeGpsStatusListener(mStatusListener);


    }


    public void setNLocationGPSListener(NLocationGPSListener listener){

        Log.e("gps","setNLocationGPSListener");
        mGPSListener = listener;
    }

    public boolean isGPSEnabled() {
        return mLocationManager.isProviderEnabled(mProvider);
    }


    /**
     * 卫星状态监听器
     */
    private List<GpsSatellite> numSatelliteList = new ArrayList<GpsSatellite>(); // 卫星信号

    private final GpsStatus.Listener mStatusListener = new GpsStatus.Listener() {
        public void onGpsStatusChanged(int event) { // GPS状态变化时的回调，如卫星数
            Log.e("gps","onGpsStatusChanged,event ="+ event);
            if ( mGPSListener == null ){
                return;
            }

            GpsStatus status = mLocationManager.getGpsStatus(null); //取当前状态
            int satelliteCount = 0;
            if (status == null) {
                //搜索到卫星个数：0
                satelliteCount = 0;
            } else if (event == GpsStatus.GPS_EVENT_SATELLITE_STATUS) {
                int maxSatellites = status.getMaxSatellites();
                Iterator<GpsSatellite> it = status.getSatellites().iterator();
                numSatelliteList.clear();
                int count = 0;
                while (it.hasNext() && count <= maxSatellites) {
                    GpsSatellite s = it.next();
                    numSatelliteList.add(s);
                    count++;
                }
                satelliteCount = numSatelliteList.size();
                //搜索到卫星个数： numSatelliteList.size()

            }
            Log.e("gps","onGpsStatusChanged,satelliteCount ="+ satelliteCount);
            mGPSListener.onSatelliteCountChanged(satelliteCount);

        }
    };

    private final LocationListener mLocationListener =   new  LocationListener(){

        @Override
        public void onLocationChanged(Location location) {
            // TODO Auto-generated method stub
            //Toast.makeText(mContext, "定位成功", Toast.LENGTH_SHORT).show();
            //Toast.makeText(mContext, location.toString(), Toast.LENGTH_SHORT).show();
            Log.e("gps","onLocationChanged,location ="+ location.toString());
            if (mGPSListener == null){
                return;
            }
            if (    (location.getLatitude() > 1.0) && (location.getLongitude() > 1.0)
                    && (location.getSpeed() < 300)){
                    //&& (location.getBearing() > -0.5) ) {

                GeoPoint pt = new GeoPoint((int)(location.getLatitude()* 3.6E6),
                        (int)(location.getLongitude()* 3.6E6) );
                GeoPoint ptResult = Encryption.EncryptionGps(pt);
                location.setLatitude((ptResult.getLatitudeE6()*1.0)/3.6E6);
                location.setLongitude((ptResult.getLongitudeE6()*1.0)/3.6E6);
                mGPSListener.onLocationChanged(location);
            }
        }

        @Override
        public void onProviderDisabled(String provider) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onProviderEnabled(String provider) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onStatusChanged(String provider, int status,
        Bundle extras) {
            // TODO Auto-generated method stub

        }

    };
}

