package com.navinfo.wenavi.model;

import com.navinfo.audio.IAudioRecongniseListener;
import com.navinfo.audio.hci.HCIAudio;
import com.navinfo.audio.hci.HCIAudioRecongniser;
import com.navinfo.mirrorlink.MirrorLinkDeviceManager;
import com.sinovoice.hcicloudsdk.common.asr.AsrRecogResult;
import com.sinovoice.hcicloudsdk.recorder.ASRCommonRecorder;

/**
 * Created by Doone on 2015/1/29.
 * */

public class WeNaviAudioReconiser extends HCIAudioRecongniser {

    MirrorLinkDeviceManager mManager=null;

    public WeNaviAudioReconiser(HCIAudio audio) {
        super(audio);

        mManager=(MirrorLinkDeviceManager)((WeNaviApplication)audio.getBaseContext()).getMirrorLinkContext().getMirrorLinkManager(MirrorLinkDeviceManager.class.getCanonicalName());
    }

    @Override
    public void startRecongnise(IAudioRecongniseListener l) {
        if(mManager!=null && !mManager.isMicrophoneOn())
            mManager.setMicrophoneOpen(true,true);
        super.startRecongnise(l);
    }

    @Override
    public void stop() {
        if(mManager!=null && mManager.isMicrophoneOn())
            mManager.setMicrophoneOpen(false,false);
        super.stop();
    }

    @Override
    public void destroy() {
        if(mManager!=null && mManager.isMicrophoneOn())
            mManager.setMicrophoneOpen(false,false);
        super.destroy();
    }

    @Override
    public void onRecorderEventRecogFinsh(ASRCommonRecorder.RecorderEvent recorderEvent, AsrRecogResult asrRecogResult) {
        if(mManager!=null && mManager.isMicrophoneOn())
            mManager.setMicrophoneOpen(false,false);
        super.onRecorderEventRecogFinsh(recorderEvent, asrRecogResult);
    }

    @Override
    public void onRecorderEventError(ASRCommonRecorder.RecorderEvent recorderEvent, int i) {
        if(mManager!=null && mManager.isMicrophoneOn())
            mManager.setMicrophoneOpen(false,false);
        super.onRecorderEventError(recorderEvent, i);
    }
}
