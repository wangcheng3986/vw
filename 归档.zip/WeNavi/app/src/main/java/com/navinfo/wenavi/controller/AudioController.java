package com.navinfo.wenavi.controller;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.util.Log;

import com.navinfo.audio.AudioRecongniseError;
import com.navinfo.audio.AudioRecongniseStatus;
import com.navinfo.audio.IAudioGenerateListerner;
import com.navinfo.audio.IAudioGenerator;
import com.navinfo.audio.IAudioRecongniseListener;
import com.navinfo.audio.IAudioRecongniser;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.activity.AlertDialog;
import com.navinfo.wenavi.activity.IView;
import com.navinfo.wenavi.activity.WeNaviBaseFragment;
import com.navinfo.wenavi.model.WeNaviModel;
import com.navinfo.wenavi.util.NetWork;

/**
 * Created by Doone on 2015/2/4.
 * 语音识别与合成控制器，
 *
 * 功能使用示例：
 *
 * 开始识别:
 * IView.getController().handle(CMD_START_RECONGNISE);
 *
 * 合成播放:
 * IView.getController().handle(CMD_PLAY,"合成内容");
 *
 *
 * 识别成功:
 * IView void updateView(Object ... datas)
 * {
 *      if(datas.length>0) {
 *         if (datas[0].getClass().getCanonicalName() == String.class.getCanonicalName()) {
 *          String sCms = (String) (datas[0]);
 *          if(sCms== AudioController.RET_RECONGNISE) { //识别OK
 *           if(datas.length>1 && datas[1].getClass().getCanonicalName() == String.class.getCanonicalName())
 *            {
 *              //获取识别结果
 *              String sResult=(String)datas[1];
 *
 *              //后续逻辑
 *              //....
 *            }
 *          }
 *      }
 * }
 *
 *
 */
public class AudioController extends BaseController implements IAudioGenerateListerner,
        IAudioRecongniseListener{

    private final static String LOG_TAG=AudioController.class.getCanonicalName();
    /**
     * 功能代码:开始语音识别,可附带 识别类别（String),识别侦听器 IAudioRecongniseListener
     */
    public static final String CMD_START_RECONGNISE="CMD_START_RECONGNISE";


    /**
     * 功能代码:播放提示信息后开始语音识别,可附带 提示内容(String),识别类别（String)
     */
    public static final String CMD_START_RECONGNISE_AFTER_NOTIFY="CMD_START_RECONGNISE_AFTER_NOTIFY";

    /**
     * 功能代码:结束语音识别
     */
    public static final String CMD_STOP_RECONGNISE="CMD_STOP_RECONGNISE";


    /**
     * 功能代码:语音合成播放，需提供播放内容
     */
    public static final String CMD_PLAY="CMD_PLAY";

    /**
     * 功能代码:语音合成停止播放
     */
    public static final String CMD_STOP_PLAY="CMD_STOP_PLAY";

    /**
     * 功能代码:语音合成暂停播放
     */
    public static final String CMD_PAUSE_PLAY="CMD_PAUSE_PLAY";

    /**
     * 功能代码:语音合成恢复播放
     */
    public static final String CMD_RESUME_PLAY="CMD_RESUME_PLAY";



    /**
     * View更新代码:语音识别开始录音
     */
    public static final String RET_RECORD_START="RET_RECORD_START";


    /**
     * View更新代码:语音识别开始识别
     */
    public static final String RET_RECONGNISE_START="RET_RECONGNISE_START";



    /**
     * View更新代码:语音识别结果，提供识别内容
     */
    public static final String RET_RECONGNISE="RET_RECONGNISE";



    /**
     * View更新代码:语音识别结束
     */
    public static final String RET_RECONGNISE_FINISHED="RET_RECONGNISE_FINISHED";



    /**
     * View更新代码:语音识别错误
     */
    public static final String RET_RECONGNISE_ERROR="RET_RECONGNISE_ERROR";


    public static final String HCI_NOMAL_RECONGNISER="HCI_NOMAL_RECONGNISER";

    public static final String HCI_POI_RECONGNISER="HCI_POI_RECONGNISER";







    private IAudioGenerator mAudioGenerator=null;
    private IAudioRecongniser mAudioRecongniser=null;
    private IAudioRecongniser mPoiAudioRecongniser=null;

    IAudioRecongniseListener mLastAudioRecongniseListener=null;
    IAudioGenerateListerner mLastAudioGenerateListerner=null;

    private boolean mIsPlaying=false;

    private String mAudioReconiserType=HCI_NOMAL_RECONGNISER;

    private  SoundPool mSoundPool=null;
    private  int mAudioIndex=0;

    private boolean mHasNotified=false;

    @Override
    public String getDefaultModelName() {
        return WeNaviModel.class.getCanonicalName();
    }

    public AudioController(Context context) {
        super(context);

        //AudioAttributes.Builder ab=new AudioAttributes.Builder();
        //AudioAttributes a=ab.setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        //        .setUsage(AudioAttributes.USAGE_NOTIFICATION).build();
        //SoundPool.Builder b=new SoundPool.Builder();
        //SoundPool p=b.setMaxStreams(16).setAudioAttributes(a).build();


        if(mSoundPool==null)
        {
            mSoundPool = new SoundPool(16, AudioManager.STREAM_NOTIFICATION, 0);
            mAudioIndex = mSoundPool.load(getContext(), R.raw.ding, 0);
        }



    }

    public void setAudioReconiserType(String sType)
    {
        mAudioReconiserType=sType;
    }

    protected  IAudioRecongniser getAudioReconiserByType()
    {
        if(mAudioReconiserType==HCI_NOMAL_RECONGNISER) return getAudioRecongniser();
        else if(mAudioReconiserType==HCI_POI_RECONGNISER) return getPoiAudioRecongniser();
        return null;
    }


    public  IAudioRecongniser getAudioRecongniser(){
        if(mAudioRecongniser==null)
            mAudioRecongniser= (IAudioRecongniser)(getDefaultModel().getObject(IAudioRecongniser.class.getCanonicalName()));
        return mAudioRecongniser;
    }



    public  IAudioRecongniser getPoiAudioRecongniser(){
        if(mPoiAudioRecongniser==null)
            mPoiAudioRecongniser= (IAudioRecongniser)(getDefaultModel().getObject(IAudioRecongniser.class.getCanonicalName()+"_POI"));
        return mPoiAudioRecongniser;
    }


    public IAudioGenerator getAudioGenerator(){
        if(mAudioGenerator==null)
        {
            mAudioGenerator=(IAudioGenerator)(getDefaultModel().getObject(IAudioGenerator.class.getCanonicalName()));
        }
        return mAudioGenerator;
    }

    @Override
    public void onViewPause() {
        IAudioRecongniser r=getAudioReconiserByType();
        if(r!=null) r.stop();
        super.onViewPause();
    }

    @Override
    public void onViewResume() {
        super.onViewResume();

    }

    @Override
    public void executeAction(Object... actionDatas) {
        if(actionDatas.length>0) {
            if (actionDatas[0].getClass().getCanonicalName().equals(String.class.getCanonicalName())) {
                String sCms = (String) (actionDatas[0]);
                if(sCms.equals(CMD_START_RECONGNISE))
                {
                    if(actionDatas.length>2)
                        startRecongnise((String)actionDatas[1],(IAudioRecongniseListener)actionDatas[2]);
                    else if(actionDatas.length>1)
                        startRecongnise((String)actionDatas[1],null);
                    else
                        startRecongnise(null);

                }
                else if(sCms.equals(CMD_START_RECONGNISE_AFTER_NOTIFY))
                {
                    if(actionDatas.length>3)
                        startRecongniseAfterNotify((String) actionDatas[1], (String) actionDatas[2], (IAudioRecongniseListener) actionDatas[3]);
                    else if(actionDatas.length>2)
                        startRecongniseAfterNotify((String) actionDatas[1], (String) actionDatas[2], null);
                    else if(actionDatas.length>1)
                        startRecongniseAfterNotify((String) actionDatas[1],null,null);
                    else
                        startRecongnise(null);

                }
                else if(sCms.equals(CMD_STOP_RECONGNISE)) cancelRecongnise();
                else if(sCms.equals(CMD_PLAY))
                {
                    if(actionDatas.length>1 &&
                            actionDatas[1].getClass().getCanonicalName().equals(String.class.getCanonicalName()))
                        play((String) actionDatas[1],null);
                }
                else if(sCms.equals(CMD_PAUSE_PLAY)) pausePlay();
                else if(sCms.equals(CMD_RESUME_PLAY)) resumePlay();
                else if(sCms.equals(CMD_STOP_PLAY)) stopPlay();

                else super.executeAction(actionDatas);


            }
        }

    }

    public void startRecongniseAfterNotify(String sNotify,final String sType,final IAudioRecongniseListener l)
    {
        try {
            if(sNotify!=null &&  !mHasNotified)
            {
                mHasNotified=true;
                getAudioGenerator().play(sNotify,new IAudioGenerateListerner() {
                    @Override
                    public void onError(String s) {
                        startRecongnise( sType, l);
                    }

                    @Override
                    public void onPlayFinished() {
                        startRecongnise( sType, l);
                    }
                });
            }
            else
                startRecongnise( sType, l);

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }


    public void startRecongnise(String sType,IAudioRecongniseListener l)
    {
        try {



            if(sType!=null) setAudioReconiserType(sType);
            startRecongnise(l);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void startRecongnise(IAudioRecongniseListener l)
    {
        try {
            if(!checkNetWork()) return;

            mLastAudioRecongniseListener = l;
            IAudioRecongniser r = getAudioReconiserByType();



            if(mSoundPool!=null && mAudioIndex!=0)
            {
                int state = mSoundPool.play(mAudioIndex, 0.7f, 0.7f, 0, 0, 1);
                if (state != 0) {

                    Thread.sleep(1000);


                }
                Log.e(LOG_TAG, "hitOkSfx=" + mAudioIndex + " State=" + state);

                //p.release();
            }

            if (r != null) {
                r.startRecongnise(this);
                //updateView(RET_RECONGNISE_START);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void cancelRecongnise()
    {
        getAudioRecongniser().stop();
    }

    public void play(String sText,IAudioGenerateListerner l)
    {
        mLastAudioGenerateListerner=l;
        mIsPlaying=true;
        getAudioGenerator().play(sText,this);
    }

    public void stopPlay()
    {
        getAudioGenerator().stop();
        mIsPlaying=false;
    }

    public void pausePlay()
    {
        getAudioGenerator().pause();
        mIsPlaying=false;
    }

    public void resumePlay()
    {
        mIsPlaying=true;
        getAudioGenerator().resume();
    }


    @Override
    public void onError(String s) {
        if(mLastAudioGenerateListerner!=null)
            mLastAudioGenerateListerner.onError(s);


    }

    @Override
    public void onPlayFinished() {
        mIsPlaying=false;
        if(mLastAudioGenerateListerner!=null)
             mLastAudioGenerateListerner.onPlayFinished();
    }

    @Override
    public void onRecongnised(String s) {
        updateView(RET_RECONGNISE_FINISHED);
        updateView(RET_RECONGNISE,s);
        if(mLastAudioRecongniseListener!=null)
            mLastAudioRecongniseListener.onRecongnised(s);
    }

    @Override
    public void onError(AudioRecongniseError audioRecongniseError, int i,String sError) {

        updateView(RET_RECONGNISE_FINISHED);
        updateView(RET_RECONGNISE_ERROR,audioRecongniseError,i,sError);
        if(mLastAudioRecongniseListener!=null)
            mLastAudioRecongniseListener.onError(audioRecongniseError,i,sError);

    }

    @Override
    public void onStatusChanged(AudioRecongniseStatus audioRecongniseStatus) {
       if(audioRecongniseStatus==AudioRecongniseStatus.RECONGNISE_NOINPUT ||
              // audioRecongniseStatus==AudioRecongniseStatus.RECONGNISE_NOSTATUS ||
               audioRecongniseStatus==AudioRecongniseStatus.RECONGNISE_RECONGNISE_FINISHED)
           updateView(RET_RECONGNISE_FINISHED);
        else if(audioRecongniseStatus==AudioRecongniseStatus.RECONGNISE_START_RECORD)
           updateView(RET_RECORD_START);
       else if(audioRecongniseStatus==AudioRecongniseStatus.RECONGNISE_START_RECONGNISE)
           updateView(RET_RECONGNISE_START);

        if(mLastAudioRecongniseListener!=null)
            mLastAudioRecongniseListener.onStatusChanged(audioRecongniseStatus);

    }


}
