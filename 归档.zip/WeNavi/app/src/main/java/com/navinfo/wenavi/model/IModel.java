package com.navinfo.wenavi.model;

/**
 * Created by Doone on 2015/2/5.
 */
public interface IModel {

    /**
     * 获取数据对象
     * @param sName 对象类全名称
     * @return 对象实例
     */
    public Object getObject(String sName);


    /**
     * 保存对象
     * @param o 要保存的对象
     * @return true 保存成功
     */
    public boolean saveObject(Object o);


    /**
     * 加载Model，Model创建者负责调用该方法
     */
    public void loadModel();


    /**
     * 保存Model
     * @return true 保存成功
     */
    public boolean saveModel();


    /**
     * 销毁Model
     */
    public void destroy();


}
