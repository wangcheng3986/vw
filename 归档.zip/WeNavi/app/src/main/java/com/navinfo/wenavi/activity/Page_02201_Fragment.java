package com.navinfo.wenavi.activity;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;

import android.os.Handler;
import android.os.Message;
import android.support.v7.widget.LinearLayoutCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.navinfo.sdk.mapapi.search.adminarea.AdminAreaRecord;
import com.navinfo.sdk.mapapi.search.core.POIInfo;
import com.navinfo.sdk.mapapi.search.poi.POISearchResult;
import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;
import com.navinfo.wenavi.R;

import com.navinfo.wenavi.controller.AudioController;
import com.navinfo.wenavi.controller.Page_02201_Controller;
import com.navinfo.wenavi.controller.Page_04201_Controller;
import com.navinfo.wenavi.entity.AdminAreaEntity;
import com.navinfo.wenavi.entity.AppConfig;
import com.navinfo.wenavi.entity.NaviKeyWord;
import com.navinfo.wenavi.entity.CueWordEntity;
import com.navinfo.wenavi.model.CueWordAdapter;
import com.navinfo.wenavi.model.CustomDialog;
import com.navinfo.wenavi.model.IMessage;
import com.navinfo.wenavi.entity.PoiSearchParam;
import com.navinfo.wenavi.model.Repository;
import com.navinfo.wenavi.model.WeNaviApplication;
import com.navinfo.wenavi.model.WeNaviInternalMessage;
import com.navinfo.wenavi.util.CompKeyword;
import com.navinfo.wenavi.util.WeNaviDefine;
import com.navinfo.wenavi.util.WeNaviUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * 搜索导航
 */
public class Page_02201_Fragment extends WeNaviBaseFragment implements CueWordAdapter.ICueWordListViewInteractor { //}  WeNaviBaseFragment {
    private final static String LOG_TAG = Page_02201_Fragment.class.getCanonicalName();
    //提示词
    private PopupWindow mPop;

    //回退，语音，搜索，地图定位
    private Button mBtBack, mBtSound, mBtSearch, mBtLocation, mBtDeleteAll;
    private EditText mEtKeyword;
    private String mkeyword;
    //行政区域
    private TextView mTvCity;

    //搜索，历史纪录
    private LinearLayout mLLparent,mLlSearch, mLlHis;
    //记录
    private ListView mLV;

    private List<NaviKeyWord> lsKeyWord;
    private List<String> mKeyWords = new ArrayList<String>();
    private CueWordEntity[] mCallWords;

    private HistoryRecordAdapter adapterh;

    //声音有关
    private SoundPool soundPool;
    private int hitOkSfx;
    //提示
    private PopupWindow popupWindow;
    private View viewLine;
    private boolean cwClicked = false;//是否选择提示词


    //记录历史时间
    private long h;

    //行政区代码
    private String mAdminCode = "110000";

    AdminAreaEntity mAdminRecord = null;
    Page_02401_Dialog  mAdminDialog=null;

    @Override
    public boolean onHandlerMessage(Message msg) {
        int tag = msg.what;
        switch (tag) {
            case 1:
                submitAction(AudioController.CMD_START_RECONGNISE_AFTER_NOTIFY,
                        null,
                        AudioController.HCI_POI_RECONGNISER);
                return true;
            case 2:
                Bundle bundle = msg.getData();
                String kw = (String) bundle.get("kw");
                mBtSound.setEnabled(true);
                mEtKeyword.setText(kw);
                mBtSound.setBackgroundResource(R.drawable.ui_01201_btn_sounds_normal);
                return true;
            case 3:
                //识别失败，没有内容
                submitAction(Page_02201_Controller.CMD_PLAY_RECOGNIZE_ERROR);


                mBtSound.setBackgroundResource(R.drawable.ui_01201_btn_sounds_normal);
                return true;

            case 4:
                //识别失败，没有内容
                submitAction(Page_02201_Controller.CMD_PLAY_RECOGNIZE_ERROR);

                mBtSound.setBackgroundResource(R.drawable.ui_01201_btn_sounds_normal);
                return true;
            case 5:
                showCueWords();
                return true;
            case 6:
                mBtSound.setBackgroundResource(R.drawable.ui_01201_btn_sounds_pressed);
                return true;
            case 7:
                //mBtSound.setBackgroundResource(R.drawable.ui_btn_sound/Users/cc/workspace/MirrorLink/WeNavi/app/src/main/java/com/navinfo/wenavi/activity/Page_02501_Fragment.javas_pressed);
                mBtSound.setEnabled(true);
                return true;
            case 8:
                //mBtSound.setBackgroundResource(R.drawable.ui_btn_sounds_pressed);
                hidePopMessage();
                //toPage(Page_01401_Fragment.class);
                mBtSearch.performClick();

                return true;
            case 9:
                //mBtSound.setBackgroundResource(R.drawable.ui_btn_sounds_pressed);
                popupWindow.dismiss();
                break;
            case 10:



        }
        return super.onHandlerMessage(msg);
    }

    @Override
    public void onSetListAdaptor() {
        if(mLlHis.getVisibility()==View.VISIBLE) {
            // adapter = new HistoryRecordAdapter(Page_02201_Fragment.this.getActivity(), mKeyWords);
            setListAdapter(adapterh);

        }
        else
        {
            CueWordAdapter adapter = (CueWordAdapter) getController().
                    getObject(CueWordAdapter.class.getCanonicalName());
            adapter.setContext(Page_02201_Fragment.this.getActivity());
            adapter.setCueWordListViewInteractor(Page_02201_Fragment.this);
            setListAdapter(adapter);
        }

        if(mAdminDialog!=null) mAdminDialog.onSetListAdaptor();
    }

    @Override
    public void onRemoveListAdaptor() {
        setListAdapter(null);
        if(mAdminDialog!=null) mAdminDialog.onRemoveListAdaptor();
    }


    ListView getListView()
    {
        return  mLV;
    }

    void setListAdapter(ListAdapter d)
    {
        getListView().setAdapter(d);
    }

    /**
     * 显示提示词
     */
    private void showCueWords() {
        mLlHis.setVisibility(View.GONE);
        CueWordAdapter adapter = (CueWordAdapter) getController().
                getObject(CueWordAdapter.class.getCanonicalName());
        adapter.setContext(Page_02201_Fragment.this.getActivity());
        adapter.setCueWordListViewInteractor(Page_02201_Fragment.this);
        adapter.setData(mCallWords);
        setListAdapter(adapter);
    }

    TextWatcher mWatcher = new TextWatcher() {
        private CharSequence temp;
        private int editStart;
        private int editEnd;

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            temp = s;

        }


        @Override
        public void beforeTextChanged(CharSequence s, int start, int count,
                                      int after) {

        }

        @Override
        public void afterTextChanged(Editable s) {

            editStart = mEtKeyword.getSelectionStart();
            editEnd = mEtKeyword.getSelectionEnd();
            String input = mEtKeyword.getText().toString();
            //输入字符个数
            int length = temp.length();
            if (length >= 2) {
                if(mAdminRecord!=null) mAdminCode=mAdminRecord.getCode();
                submitAction(Page_02201_Controller.CMD_GET_CUEWORD, input, mAdminCode);

                //超过两个字符显示提示词
//                handler.sendEmptyMessage(5);
            } else {
                mLlHis.setVisibility(View.VISIBLE);
                // adapter = new HistoryRecordAdapter(Page_02201_Fragment.this.getActivity(), mKeyWords);
                setListAdapter(adapterh);
            }
        }
    };

    public void initHistoryData(List<NaviKeyWord> list) {

        CompKeyword compKeyword = new CompKeyword();
        Collections.sort(list, compKeyword);

    }

    /**
     * 初始化控件为不可用,页面初始化时调用
     */
    @Override
    public  void onDisableControl()
    {
        mBtBack.setEnabled(false);
        mBtSearch.setEnabled(false);
        mBtLocation.setEnabled(false);

    }

    /**
     * 初始化控件为可用,页面初始化完成后被延时调用
     */
    @Override
    public  void onEnableControl()
    {
        mBtBack.setEnabled(true);
        mBtSearch.setEnabled(true);
        mBtLocation.setEnabled(true);
    }


    @Override
    protected void bindUIControl(View v) {
        mLLparent = (LinearLayout) v.findViewById(R.id.layoutroot);
        mLLparent.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (popupWindow != null && popupWindow.isShowing()) {
//                    if(null!=v.findViewById(R.id.et_ui_02201_keyword).isto)
//                    popupWindow.dismiss();
                }

                return false;
            }
        });
        //声音
        soundPool = new SoundPool(16, AudioManager.STREAM_NOTIFICATION, 0);
        hitOkSfx = soundPool.load(this.getActivity(), R.raw.ding, 0);
        mTvCity = (TextView) v.findViewById(R.id.btCity);
        //pop
        viewLine = v.findViewById(R.id.view1);
        mBtLocation = (Button) v.findViewById(R.id.btn_02201_map_location);

        mLlHis = (LinearLayout) v.findViewById(R.id.llHistoryTitle);

        mLV = (ListView) v.findViewById(android.R.id.list);//(R.id.lv_02201_show_his);

        //mLV = (ListView)getListView(); //v.findViewById(android.R.id.list);//(R.id.lv_02201_show_his);
        //mLV.setAdapter(adapter);

        adapterh = new HistoryRecordAdapter(this.getActivity());
        setListAdapter(adapterh);

        mBtSearch = (Button) v.findViewById(R.id.btn_02201_search);
        mBtBack = (Button) v.findViewById(R.id.btn_02201_back);
        mEtKeyword = (EditText) v.findViewById(R.id.et_ui_02201_keyword);
        mBtSound = (Button) v.findViewById(R.id.btn_02201_sound);
        mBtDeleteAll = (Button) v.findViewById(R.id.btn_02201_delete_all);

        mBtLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

    //Log.d("mAdminRecord","mAdminRecord"+mAdminRecord.getCode()+","+ mAdminRecord.getLat()+","+mAdminRecord.getLon());
                if (requestLocationMessg != null) {
                    requestLocationMessg.setReceiver(Page_02301_Fragment.class.getCanonicalName());
                    //sendInternalMessage(requestLocationMessg);
                    Page_02201_Fragment.this.toPage(Page_02301_Fragment.class, requestLocationMessg.toBundle(),mAdminRecord);
                } else{
                    Page_02201_Fragment.this.toPage(Page_02301_Fragment.class,mAdminRecord);
                }
            }
        });


        mBtDeleteAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (lsKeyWord != null && lsKeyWord.size() > 0) {
                    showConfirm("删除", "确实要删除所有历史记录么?", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            if (which == 0) {
                                submitAction(Page_02201_Controller.CMD_DELETE_ALL_KEYWORD);
                                adapterh.setData(null);
                                adapterh.notifyDataSetChanged();
                            }

                        }

                    });
                }
                /*long c = System.currentTimeMillis();
                long d = c - h;
                h = c;
                if (d > 2000) {
                    Toast.makeText(Page_02201_Fragment.this.getActivity(), "再次点击会删除全部记录", Toast.LENGTH_LONG).show();
                } else {
                    submitAction(Page_02201_Controller.CMD_DELETE_ALL_KEYWORD);
                    mKeyWords.clear();
                    adapter.notifyDataSetChanged();
                }*/
            }
        });

        mBtSound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mBtSound.setEnabled(false);
                messageHandler.sendEmptyMessage(1);
//                int state = soundPool.play(hitOkSfx,1,1,0,0,1);
//                Message message = new Message();
//                message.what = 1;
//                if(state!=0){
//                    handler.sendMessageDelayed(message,1000);
//                }
            }
        });


        mBtSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mBtSearch.getTag() != null) return;
                String keyword = mEtKeyword.getText().toString().trim();
                if (keyword.length() > 0) {


                    mEtKeyword.setEnabled(false);
                    mBtSearch.setTag(1);
                    mBtSearch.setText("查询中...");

                    PoiSearchParam pm = (PoiSearchParam) getController().getObject(PoiSearchParam.class.getCanonicalName());
                    if (pm != null) {
                        pm.reset();
                        pm.setSearchType(WeNaviDefine.MSG_SEARCH_POI_BY_KEYWORD);
                        pm.setKeyword(keyword);
                        pm.setPageIndex(1);
                        pm.setPageRows(Page_01401_Fragment.PAGE_ROWS);
                        pm.setRadius(0);
                        pm.setRegion(mAdminCode);

                    }


                    submitAction(Page_02201_Controller.CMD_SEARCH_POI, pm);

                } else {
                    showInfoamtion("提示", "请您输入目的地", null);

                }
                //搜索页面


            }
        });

        mBtBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //关闭软键盘
                View view = Page_02201_Fragment.this.getActivity().getWindow().peekDecorView();
                if (view != null) {
                    InputMethodManager inputmanger = (InputMethodManager) Page_02201_Fragment.this.getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                    inputmanger.hideSoftInputFromWindow(view.getWindowToken(), 0);
                }
                onBack();

            }
        });


        mEtKeyword.addTextChangedListener(mWatcher);


        mLV = getListView();
        mLV.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                switch (scrollState) {
                    case AbsListView.OnScrollListener.SCROLL_STATE_FLING:
                        break;
                    case AbsListView.OnScrollListener.SCROLL_STATE_IDLE:
                        break;
                    case AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:

                        if (mLV.getLastVisiblePosition() == (mLV.getCount() - 1)) {
                        }
                        if (mLV.getFirstVisiblePosition() == 0) {
                        }
                        break;
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });


        mTvCity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (mAdminDialog == null) {
                    mAdminDialog = new Page_02401_Dialog(Page_02201_Fragment.this.getActivity(),
                            (WeNaviApplication)
                                    Page_02201_Fragment.this.getActivity().getApplication());


                    mAdminDialog.setOnClickListener(new CustomDialog.OnClickListener() {

                        @Override
                        public void onClick(Object o) {
                            AdminAreaEntity record = (AdminAreaEntity) o;
                            mAdminRecord = record;
                            if (record != null) {
                                submitAction(Page_02201_Controller.CMD_SET_CURRENT_AREA,mAdminRecord);

                            }


                        }
                    });
                }

                if (mAdminDialog != null) mAdminDialog.showAtLocation(v, Gravity.NO_GRAVITY, 0, 0);


            }
        });



        /*AppConfig city = Repository.getAppConfig("CurrentCity");
        if(city!=null) mTvCity.setText(city.getParamValue());

        AppConfig cityCode = Repository.getAppConfig("CurrentCityCode");
        if(cityCode!=null) mAdminCode=cityCode.getParamValue();
        if(mAdminCode != null){
            mAdminRecord = Repository.getAdminAreaByCode(mAdminCode);

        }*/


    }

    private IMessage requestLocationMessg = null;

    @Override
    protected void onInternalMessage(IMessage m) {

        if (m.getMessageType().equals(WeNaviDefine.MSG_REQUEST_LOCATION))
            requestLocationMessg = m;
        //super.onInternalMessage(m);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }


    @Override
    public void onResume() {
        Bundle pm = getArguments();
        if (pm != null) {

            WeNaviInternalMessage m = new WeNaviInternalMessage(pm);
            if (m.getMessageType() == WeNaviDefine.MSG_REQUEST_KEYWORD) {
                mEtKeyword.setText(m.getKeyword());
            } else requestLocationMessg = m;
        }

        super.onResume();

        submitAction(Page_02201_Controller.CMD_GET_CURRENT_AREA);


        submitAction(Page_02201_Controller.CMD_GET_KEYWORDHISTORY);
    }

    private void searchByCueWord(CueWordEntity p) {
        String keyword = p.getName();
        if (keyword.length() > 0) {

            mEtKeyword.setText(keyword);

            PoiSearchParam pm = (PoiSearchParam) getController().getObject(PoiSearchParam.class.getCanonicalName());
            if (pm != null) {
                pm.reset();
                pm.setSearchType(WeNaviDefine.MSG_SEARCH_POI_BY_KEYWORD);
                pm.setKeyword(keyword);
                pm.setPageIndex(1);
                pm.setPageRows(Page_01401_Fragment.PAGE_ROWS);
                pm.setRadius(0);
                pm.setRegion(mAdminCode);

            }

            if (requestLocationMessg != null) {
                requestLocationMessg.setReceiver(Page_01401_Fragment.class.getCanonicalName());

                //sendInternalMessage(requestLocationMessg);
                toPage(Page_01401_Fragment.class, requestLocationMessg.toBundle());

            } else {
                submitAction(Page_02201_Controller.CMD_SEARCH_POI, pm);
            }
        } else {
            showInfoamtion("错误", "请输入目的地", null);

        }
    }

    @Override
    public void onItemClick(CueWordEntity p) {
        searchByCueWord(p);
    }

    @Override
    public void onItemClick(CueWordEntity p, int index) {
        searchByCueWord(p);
    }

    class HistoryRecordAdapter extends BaseAdapter {
        private Context mContext = null;
        //private List<String> mlist = new ArrayList<String>();
        private  List<NaviKeyWord> mlist=null;
        LayoutInflater mInflater;

        public HistoryRecordAdapter(Context context){//}, List<String> list) {
            this.mContext = context;
            //this.mlist = list;
            //mInflater = LayoutInflater.from(mContext);
        }


        public void setData(List<NaviKeyWord> laData)
        {
            mlist=laData;
        }

        @Override
        public int getCount() {
            int count = 0;
            if (null != mlist) {
                count = mlist.size();
            }

            return count;
        }

        @Override
        public NaviKeyWord getItem(int position) {
            NaviKeyWord item = null;

            if (null != mlist) {
                item = mlist.get(position);
            }

            return item;
        }

        @Override
        public long getItemId(int position) {

            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder = null;

            if (null == convertView) {
                viewHolder = new ViewHolder();
                //mInflater = LayoutInflater.from(mContext);
                //convertView = mInflater.inflate(R.layout.page_02201_keyword_item, null);

//                if(convertView!=null) setFontSize((ViewGroup)convertView,getDefaultTextSize());
                AbsListView.LayoutParams pm=new AbsListView.LayoutParams(
                        AbsListView.LayoutParams.MATCH_PARENT,
                        AbsListView.LayoutParams.MATCH_PARENT);

                LinearLayout layout=new LinearLayout(getActivity());
                layout.setOrientation(LinearLayout.HORIZONTAL);
                layout.setLayoutParams(pm);
                layout.setBackgroundResource(R.drawable.list_item_bg);

                TextView name=new TextView(getActivity());
//                Drawable drawable = Page_02201_Fragment.this.getResources().getDrawable(R.drawable.ui_01401_1_map_points_big);
                name.setTextColor(mContext.getResources().getColorStateList(R.drawable.p2401_listitem_white_yellow));

                name.setTextSize(20);

                LinearLayout.LayoutParams pm1=new LinearLayout.LayoutParams(
                        50,
                        WeNaviUtil.dip2px(mContext, 50)
                );
                pm1.weight=1;

                pm1.setMargins( WeNaviUtil.dip2px(mContext, 50),20,0,0);
                name.setLayoutParams(pm1);

                //name.setLayoutParams(pm1);

                Button  delete=new Button(getActivity());
                //Drawable b=getResources().getDrawable(R.drawable.ui_02201_1_btn_delete);
                delete.setBackgroundResource(R.drawable.ui_02201_1_btn_delete);

                LinearLayout.LayoutParams pm2=new LinearLayout.LayoutParams(
                        WeNaviUtil.dip2px(mContext, 50),
                        WeNaviUtil.dip2px(mContext, 50));
                delete.setLayoutParams(pm2);


                //Drawable b=getResources().getDrawable()

                layout.addView(name);
                layout.addView(delete);

                convertView=layout;



                viewHolder.name = name;//(TextView) convertView.findViewById(R.id.tv_keyword_item_name);
                viewHolder.delete = delete;//(Button) convertView.findViewById(R.id.tv_keyword_item_name_delete);

                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }


            final NaviKeyWord item = getItem(position);

            if (null != item) {
                StringBuilder sb=new StringBuilder();
                if(item.getCityName()!=null && item.getCityName().length()>0)
                    sb.append(item.getCityName()).append(",");
                sb.append(item.getSearchKeyWord());

                viewHolder.name.setText(sb.toString());

            }
            viewHolder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    //点击删除按钮
                    showConfirm("提示","您确认要删除这条记录么?",new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if(which!=0) return;
                            //删除一条纪录
                            submitAction(Page_02201_Controller.CMD_DELETE_KEYWORD, item);
                            submitAction(Page_02201_Controller.CMD_GET_KEYWORDHISTORY);
                        }
                    });


//                    adapter.notifyDataSetChanged();
                }
            });
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    NaviKeyWord item=getItem(position);
                    if(item!=null) {

                        mAdminCode = item.getCityCode();
                        if(mAdminCode != null){
                            mAdminRecord = Repository.getAdminAreaByCode(mAdminCode);
                            if (mAdminRecord != null){
                                submitAction(Page_02201_Controller.CMD_SET_CURRENT_AREA,mAdminRecord);
                            }
                        }
                        mEtKeyword.setText(item.getSearchKeyWord());

                    }
//                    name.setTextColor(Color.parseColor("#fed999"));
                }
            });


            return convertView;
        }

        private final class ViewHolder {
            TextView name;
            Button delete;

        }

    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

    }

    @Override
    public void onStop() {
        super.onStop();
        if (popupWindow != null && popupWindow.isShowing()) {
            popupWindow.dismiss();
        }


        //软键盘关闭
        InputMethodManager methodManager = (InputMethodManager) this.getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        methodManager.hideSoftInputFromWindow(mEtKeyword.getWindowToken(), 0);
    }

    @Override
    public void onDetach() {
        super.onDetach();


    }

    @Override
    protected String getControllerName() {
        return Page_02201_Controller.class.getCanonicalName();
    }


    void  updateArea(AdminAreaEntity a)
    {
        if(a!=null) {
            if(a.getCode()!=null)
                mAdminCode = a.getCode();
            if(a.getName()!=null)
                mTvCity.setText(a.getName());
        }

    }

    /*
   * 父类方法继承
   *
   * */
    @Override
    public void onActionUpdate(Object... datas) {

        if (datas.length > 0) {
            if (datas[0].getClass().getCanonicalName() == String.class.getCanonicalName()) {
                String sCms = (String) (datas[0]);

                if (sCms.equals(Page_02201_Controller.RET_KEYWORDHISTORY)) {
                    lsKeyWord = (List<NaviKeyWord>) datas[1];
                    //数据刷新
                    if (null != lsKeyWord) {

                        adapterh.setData(lsKeyWord);
                        /*mKeyWords.clear();
                        for (int i = 0; i < lsKeyWord.size(); i++) {
                            mKeyWords.add(lsKeyWord.get(i).getSearchKeyWord());
                        }*/

                        adapterh.notifyDataSetChanged();
                    }
                } else if (sCms.equals(AudioController.RET_RECORD_START)) {
                    messageHandler.sendEmptyMessage(6);

                } else if (sCms.equals(AudioController.RET_RECONGNISE_START)) {
                    messageHandler.sendEmptyMessage(7);

                } else if (sCms.equals(AudioController.RET_RECONGNISE)) {
                    String kw = (String) datas[1];
                    if (null != kw & kw.length() > 0) {
                        Message message = new Message();
                        message.what = 2;
                        Bundle b = new Bundle();
                        b.putString("kw", kw);
                        message.setData(b);
                        messageHandler.sendMessage(message);
                    } else {
                        messageHandler.sendEmptyMessage(3);
                    }


                } else if (sCms.equals(AudioController.RET_RECONGNISE_ERROR)) {

                    if (datas[2] != null) {
                        messageHandler.sendEmptyMessage(4);
                    }
                } else if (sCms.equals(Page_02201_Controller.RET_CUEWORD)) {
                    CueWordEntity[] lsCueWord = (CueWordEntity[]) datas[1];
                    if (lsCueWord != null) {
                        mCallWords = lsCueWord;
                        messageHandler.sendEmptyMessage(5);
                    }
                } else if (sCms.equals(Page_02201_Controller.RET_PLAY_ERROR_FINISH)) {
                    messageHandler.sendEmptyMessage(7);
                } else if (sCms.equals(Page_02201_Controller.RET_POI)) {
                    //handler.sendEmptyMessage(8);
                    if (datas.length > 1) {
                        showPoi((POISearchResult) datas[1]);
                        //AdminAreaRecord
                        submitAction(Page_02201_Controller.CMD_ADD_KEYWORD,
                                mEtKeyword.getText().toString(),
                                mTvCity.getText(),
                                mAdminCode);
                    }

                }
                else if(sCms.equals(Page_02201_Controller.RET_CURRENT_AREA) && datas.length>1)
                {
                    mAdminRecord=(AdminAreaEntity)datas[1];
                    updateArea(mAdminRecord);

                }
                else if (sCms.equals(Page_02201_Controller.RET_ERROR)) {
                    mBtSearch.setTag(null);
                    mEtKeyword.setEnabled(true);
                    mBtSearch.setText("搜索");
                    final String sError = (String) datas[1];
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {


                            showInfoamtion("注意", sError, null);


                        }
                    });
                } else super.onActionUpdate(datas);

            }
        }


    }

    void showPoi(POISearchResult poi) {
        hidePopMessage();
        if (requestLocationMessg != null) {
            requestLocationMessg.setReceiver(Page_01401_Fragment.class.getCanonicalName());

            //sendInternalMessage(requestLocationMessg);
            toPage(Page_01401_Fragment.class, requestLocationMessg.toBundle(), poi);

        } else
            toPage(Page_01401_Fragment.class, poi);

    }


    @Override
    protected int getFragmentLayoutID() {
        return R.layout.page_02201;
    }



    /*
    * 语音识别回调
    *
    * */
//    @Override
//    public void onRecongnised(String s) {
//
//    }
//
//    @Override
//    public void onError(AudioRecongniseError audioRecongniseError, int i) {
//
//    }
//
//    @Override
//    public void onStatusChanged(AudioRecongniseStatus audioRecongniseStatus) {
//
//    }


    //恢复数据
    @Override
    public void restoreViewStatus(Bundle status) {

    }

    //存数据
    @Override
    public Bundle getViewStatus() {
        return null;
    }
}
