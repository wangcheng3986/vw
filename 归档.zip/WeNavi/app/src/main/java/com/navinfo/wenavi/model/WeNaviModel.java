package com.navinfo.wenavi.model;

import android.content.Context;
import android.os.Bundle;

import com.navinfo.audio.IAudioGenerator;
import com.navinfo.audio.IAudioRecongniser;
import com.navinfo.audio.hci.HCIAudio;
import com.navinfo.audio.hci.HCIAudioGenerator;

//import com.navinfo.audio.pq.PQAudioGenerator;
import com.navinfo.sdk.location.NavinfoLocationClient;
import com.navinfo.sdk.mapapi.map.LocationData;
import com.navinfo.sdk.mapapi.map.MapView;
import com.navinfo.sdk.mapapi.map.MyLocationOverlay;
import com.navinfo.sdk.naviapi.NaviManager;
import com.navinfo.wenavi.entity.PoiSearchParam;
import com.navinfo.wenavi.entity.RoutePlanParam;

/**
 * Created by Doone on 2015/2/5.
 * 语音、地图、导航相关对象实例创建及销毁管理
 * 该Model应该单实例
 */
public class WeNaviModel extends  BaseModel  {

    private HCIAudio mHCIAudio=null;
    private IAudioGenerator mAudioGenerator=null;
    private IAudioRecongniser mAudioRecongniser=null;
    private IAudioRecongniser mPoiAudioRecongniser=null;

    // 定位
    private NavinfoLocationClient mLocClient=null;
    private MapView mMapView=null;

    // 定位相关
    private LocationData locData = null;
    // 定位图层
    private MyLocationOverlay mMyLocationOverlay = null;

    private NaviManager mNaviManager = null;


    // 最后一次路径规划参数
    private RoutePlanParam routePalanParam=null;

    //POI搜索参数
    private PoiSearchParam poiSearchParam=null;

    //POI搜索列别适配器
    private PoiListAdapter mKeywordPoiList=null;

    private Page_04201_ListAdapter mPage_04201_ListAdapter = null;

    //POI搜索设置
    private Bundle mPoiSearchSet=null;


    //gps定位管理对象
    private NLocationGPS mNLocationGPS = null;


    private static  WeNaviModel mInstance=null;

    public static WeNaviModel getInstance(Context c)
    {
        if(mInstance==null) mInstance=new WeNaviModel(c);
        return  mInstance;
    }

    private WeNaviModel(Context c) {
        super(c);

        mHCIAudio=new HCIAudio(getContext());
        mHCIAudio.initHci();

    }

    public Bundle getPoiSearchSet()
    {
        if(mPoiSearchSet==null) mPoiSearchSet=new Bundle();
        return mPoiSearchSet;
    }


    public PoiListAdapter getKeyWordPoiListAdaptor()
    {
        if(mKeywordPoiList==null)
        {
            mKeywordPoiList=new PoiListAdapter();
        }

        return mKeywordPoiList;
    }


    PoiTypeAdapter mPoiTypeAdapter=null;
    public PoiTypeAdapter getPoiTypeAdapterAdaptor()
    {
        if(mPoiTypeAdapter==null)
        {
            mPoiTypeAdapter=new PoiTypeAdapter();
        }

        return mPoiTypeAdapter;
    }

    CueWordAdapter mCueWordAdapter=null;
    public CueWordAdapter getCueWordAdapterAdaptor()
    {
        if(mCueWordAdapter==null)
        {
            mCueWordAdapter=new CueWordAdapter();
        }

        return mCueWordAdapter;
    }

    public Page_04201_ListAdapter getListAdapter() {
        if(mPage_04201_ListAdapter==null)
        {
            mPage_04201_ListAdapter=new Page_04201_ListAdapter(getContext());
        }
        return mPage_04201_ListAdapter;
    }

    /**
     * 常规语音识别接口
     * @return IAudioRecongniser实例
     */
    public  IAudioRecongniser getAudioRecongniser(){
        if(mAudioRecongniser==null) {
           // mAudioRecongniser = new WeNaviAudioReconiser(getContext());
            mAudioRecongniser = new WeNaviAudioReconiser(mHCIAudio);
            //mAudioRecongniser.setRecongniseMode(WeNaviAudioReconiser.CLOUD_GRAMMAR_MODE);
        }

        mAudioRecongniser.setRecongniseMode(WeNaviAudioReconiser.CLOUD_NOMAL_MODE);
        return mAudioRecongniser;
    }


    /**
     * POI语音识别接口
     * @return IAudioRecongniser实例
     */
    public  IAudioRecongniser getPoiAudioRecongniser(){

        return getAudioRecongniser();

        //IAudioRecongniser r=getAudioRecongniser();
        //r.setRecongniseMode(WeNaviAudioReconiser.CLOUD_POI_MODE);
        //return r;
       /* if(mPoiAudioRecongniser==null) {
            //mPoiAudioRecongniser = new WeNaviAudioReconiser(getContext());
            mPoiAudioRecongniser = new WeNaviAudioReconiser(mHCIAudio);
            mPoiAudioRecongniser.setRecongniseMode(WeNaviAudioReconiser.CLOUD_POI_MODE);
        }
        return mPoiAudioRecongniser;*/
    }

    /**
     * 语音合成接口
     * @return IAudioGenerator实例
     */
    public IAudioGenerator getAudioGenerator(){
        if(mAudioGenerator==null)
        {
            mAudioGenerator=new HCIAudioGenerator(mHCIAudio,0.65f);
            //mAudioGenerator=new PQAudioGenerator(getContext(),0.65f);
        }
        return mAudioGenerator;
    }

    /**
     * 定位数据对象
     * @return LocationData 实例
     */
    public LocationData getLocData()
    {
        if(locData==null)
            locData=new LocationData();
        return locData;
    }


    /**
     * 定位器对象
     * @return NavinfoLocationClient 实例
     */
    public NavinfoLocationClient getLocationClient(){
        if(mLocClient==null) {
            mLocClient=new WeNaviLocationer(getContext());//new NavinfoLocationClient(getContext());
        }

        return mLocClient;
    }


    /**
     * 单一gps定位对象
     * @return NLocationGPS对象
     */
    public NLocationGPS getGPSLocationClient(){
        if(mNLocationGPS == null) {
            mNLocationGPS = new NLocationGPS(getContext());
        }

        return mNLocationGPS;
    }


    /**
     * 地图视图对象
     * @return MapView 实例
     */
    public MapView getMapView(){
        if(mMapView == null){
            mMapView = new MapView(getContext());
        }
        return mMapView;
    }


    /**
     * 当前位置显示对象
     * @return MyLocationOverlay 实例
     */
    public MyLocationOverlay getMyLoactionOverlay(){
        if(mMyLocationOverlay==null) {
            mMyLocationOverlay=new MyLocationOverlay(getMapView());
        }

        return mMyLocationOverlay;

    }


    /**
     * 导航管理器
     * @return NaviManager 对象
     */
    public NaviManager getNaviManager()
    {
        if(mNaviManager == null){
            mNaviManager = new NaviManager(getMapView(),getContext());
        }
        return mNaviManager;

    }

    /**
     * 路径规划参数
     * @return {@link com.navinfo.wenavi.entity.RoutePlanParam}
     */
    public  RoutePlanParam getRoutePalanParam()
    {
        if(routePalanParam==null)
            routePalanParam=new RoutePlanParam();
        return routePalanParam;
    }



    private IMessageCenter messageCenter=null;
    public IMessageCenter getMessageCenter()
    {
        if(messageCenter==null) messageCenter=new WeNaviMessageCenter();
        return messageCenter;
    }


    public PoiSearchParam getPoiSearchParam()
    {
        if(poiSearchParam==null)
        {
            poiSearchParam=new PoiSearchParam();
        }
        return  poiSearchParam;
    }


    @Override
    public Object getObject(String sName) {
        if(sName.equals(IAudioGenerator.class.getCanonicalName()))
        {
            return getAudioGenerator();
        }
        else if(sName.equals(IAudioRecongniser.class.getCanonicalName()))
        {
            return getAudioRecongniser();
        }
        else if(sName.equals(IAudioRecongniser.class.getCanonicalName()+"_POI"))
        {
            return getPoiAudioRecongniser();
        }
        else if(sName.equals(MapView.class.getCanonicalName()))
        {
            return getMapView();
        }
        else if(sName.equals(NavinfoLocationClient.class.getCanonicalName()))
        {
            return getLocationClient();
        }
        else if(sName.equals(MyLocationOverlay.class.getCanonicalName()))
        {
            return getMyLoactionOverlay();
        }
        else if(sName.equals(LocationData.class.getCanonicalName()))
        {
            return getLocData();
        }
        else if(sName.equals(NaviManager.class.getCanonicalName()))
        {
            return getNaviManager();
        }
        else if(sName.equals(RoutePlanParam.class.getCanonicalName()))
        {
            return getRoutePalanParam();
        }
        else if (sName.equals(NLocationGPS.class.getCanonicalName()))
        {
            return getGPSLocationClient();
        }
        else if(sName.equals(PoiListAdapter.class.getCanonicalName()+"_Keyword"))
        {
            return getKeyWordPoiListAdaptor();
        }
        else if(sName.equals("POISearchSet"))
        {
            return getPoiSearchSet();
        }
        else if(sName.equals(IMessageCenter.class.getCanonicalName()))
        {
            return getMessageCenter();
        }
        else if(sName.equals(Page_04201_ListAdapter.class.getCanonicalName()))
        {
            return getListAdapter();
        }
        else if(sName.equals(PoiTypeAdapter.class.getCanonicalName()))
        {
            return getPoiTypeAdapterAdaptor();
        }
        else if(sName.equals(PoiSearchParam.class.getCanonicalName()))
        {
            return getPoiSearchParam();
        }
        else if(sName.equals(CueWordAdapter.class.getCanonicalName()))
        {
            return getCueWordAdapterAdaptor();
        }

        else
            return super.getObject(sName);
    }

    @Override
    public void destroy() {
        if(mAudioRecongniser!=null)
            mAudioRecongniser.destroy();

        if(mPoiAudioRecongniser!=null)
            mPoiAudioRecongniser.destroy();

        if(mAudioGenerator!=null)
            mAudioGenerator.destroy();


        if(mHCIAudio!=null) mHCIAudio.destory();

        if(mLocClient!=null)
            mLocClient.stop();

        if (mNLocationGPS != null){
            mNLocationGPS.stopGPS();
            mNLocationGPS = null;
        }

        if(mNaviManager!=null)
            mNaviManager.destroy();


        if(mMyLocationOverlay!=null)
            mMyLocationOverlay.destroy();

        if(mKeywordPoiList!=null)
            mKeywordPoiList=null;

        mPage_04201_ListAdapter = null;

        if(mMapView != null){
            mMapView.destroy();
            mMapView = null;
        }



        super.destroy();



    }








}
