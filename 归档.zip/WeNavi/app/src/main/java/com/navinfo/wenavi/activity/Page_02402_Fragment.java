package com.navinfo.wenavi.activity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.mirrorlink.android.commonapi.Defs;
import com.navinfo.mirrorlink.MirrorLinkEvent;
import com.navinfo.sdk.mapapi.map.LocationData;
import com.navinfo.sdk.mapapi.map.MapView;
import com.navinfo.sdk.naviapi.routeplan.RoutePlanData;
import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.controller.MapViewController;
import com.navinfo.wenavi.controller.NaviController;
import com.navinfo.wenavi.controller.RouteController;
import com.navinfo.wenavi.entity.RoutePlanParam;
import com.navinfo.wenavi.model.WeNaviInternalMessage;
import com.navinfo.wenavi.util.WeNaviUtil;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Doone on 2015/3/8.
 */
public class Page_02402_Fragment extends WeNaviBaseFragment{
    private final static String LOG_TAG = Page_02402_Fragment.class.getCanonicalName();

    Button mBtBack=null;
    Button mBtGo=null;
    Button btSimula=null;
    Button btRouteType=null;


    RadioButton btTime=null;
    RadioButton btHighWay=null;
    RadioButton btDis=null;
    RadioButton btFree=null;

    Button mBtCurrentLoc=null;
    MapView mMapView=null;
    TextView txtView=null;
    TextView txtRoutetype=null;


    Button btZoomin=null;
    Button btZoomout=null;
    ImageButton btCompass=null;
    ToggleButton btTraffic=null;
    MapScaler ctMapScaler=null;

    LinearLayout routeTypeSelector=null;
    RadioGroup rgRouteType=null;


    boolean mFirstTime=true;
    private String mDefaultRouteType=null;

    int mClieckCount=0;
    Timer mTimmer = null;

    class timerOutTak extends TimerTask {

        @Override
        public void run() {
            mClieckCount=0;
            Log.e(LOG_TAG,"ClieckCount Timer timeouted, ClieckCount reseted");
        }

    }



    @Override
    protected String getControllerName() {
        return RouteController.class.getCanonicalName();
    }


    @Override
    public void onActionUpdate(Object... datas) {

        if(datas.length>0) {
            if (datas[0].getClass().getCanonicalName().equals(String.class.getCanonicalName())) {
                String sCms = (String) (datas[0]);
                //Log.e(LOG_TAG, "GisController Command= " + sCms);
                if (sCms.equals(RouteController.RET_ROUTE_PLAN_SUCCESS)) {


                    RoutePlanData data = (RoutePlanData) getController().getObject(RoutePlanData.class.getCanonicalName());
                    if (data != null) {
                        String str = "里程:" + WeNaviUtil.convertMeters(data.commonDistance)
                                + " 耗时:" + WeNaviUtil.convertTime(data.commonTime);
                        txtView.setText(str);

                    }
                }
                else if (sCms.equals(RouteController.RET_ROUTE_PLAN_START) ||
                        sCms.equals(RouteController.RET_ROUTE_PLAN_FINISH) ||
                        sCms.equals(RouteController.RET_ROUTE_PLAN_FAIL)) {
                    showStatus(sCms);
                }
                else if (sCms.equals(RouteController.RET_DEFAULT_ROUTETYPE)) {
                    if(datas.length>1) updateRouteType((String)datas[1]);
                }

                //else if (sCms == NaviController.RET_ROUTE_PLAN_START ||
                else super.onActionUpdate(datas);
            }
        }

    }

    void updateRouteType(String sType)
    {
        Log.e(LOG_TAG,"RouteType:"+sType);
        mDefaultRouteType=sType;



        /*if(sType.equals(RouteController.CMD_ROUTE_PLAN_TIME)) btTime.setChecked(true);
        else if(sType.equals(RouteController.CMD_ROUTE_PLAN_HIGHWAY)) btHighWay.setChecked(true);
        else if(sType.equals(RouteController.CMD_ROUTE_PLAN_DISTANCE)) btDis.setChecked(true);
        else if(sType.equals(RouteController.CMD_ROUTE_PLAN_FREECHARGE)) btFree.setChecked(true);*/

        showType(sType);
        if(mFirstTime) {
            //btTime.performClick();
            // btTime.setChecked(true);
             submitAction(sType);
            mFirstTime = false;
        }
        else
            submitAction(NaviController.CMD_RELOAD_LAST_ROUTE_PLAN);
    }


    void showType(String sType)
    {
        String sText=null;
        if(sType.equals(RouteController.CMD_ROUTE_PLAN_TIME))
            sText=getResources().getString(R.string.button_text_page_010201_time);
        else if(sType.equals(RouteController.CMD_ROUTE_PLAN_HIGHWAY))
            sText=getResources().getString(R.string.button_text_page_010201_highway);
        else if(sType.equals(RouteController.CMD_ROUTE_PLAN_DISTANCE))
            sText=getResources().getString(R.string.button_text_page_010201_distance);
        else if(sType.equals(RouteController.CMD_ROUTE_PLAN_FREECHARGE))
            sText=getResources().getString(R.string.button_text_page_010201_freecharge);
        if(sText!=null) txtRoutetype.setText(sText);
    }

    void showStatus(String sStatus)
    {
        String str = null;
        if(sStatus == NaviController.RET_ROUTE_PLAN_START)
        {
            str = "规划中...";
            txtView.setText(str);
        }
        else if(sStatus == NaviController.RET_ROUTE_PLAN_FINISH)
        {
            str = "规划完毕";
            txtView.setText(str);
        }
        else if(sStatus == NaviController.RET_ROUTE_PLAN_FAIL)
        {
            str = "规划失败";
            txtView.setText(str);
        }

    }



    @Override
    protected int getFragmentLayoutID() {
        return R.layout.page_02402;
    }


    /**
     * 初始化控件为不可用,页面初始化时调用
     */
    @Override
    public  void onDisableControl()
    {
        mBtBack.setEnabled(false);
        mBtGo.setEnabled(false);
        btRouteType.setEnabled(false);
        btSimula.setEnabled(false);

    }

    /**
     * 初始化控件为可用,页面初始化完成后被延时调用
     */
    @Override
    public  void onEnableControl()
    {
        mBtBack.setEnabled(true);
        mBtGo.setEnabled(true);
        btRouteType.setEnabled(true);
        btSimula.setEnabled(true);
    }

    @Override
    protected void bindUIControl(View v) {

        mBtBack=(Button)v.findViewById(R.id.btBack);
        mBtGo=(Button)v.findViewById(R.id.btGo);
        btSimula=(Button)v.findViewById(R.id.btSimula);
        btRouteType=(Button)v.findViewById(R.id.btRouteType);
        txtRoutetype=(TextView)v.findViewById(R.id.textRouteType);

        mBtCurrentLoc = (Button) v.findViewById(R.id.btCurrentLoc);
        txtView=(TextView)v.findViewById(R.id.textView);

        //routeTypeSelector=(LinearLayout)v.findViewById(R.id.routeTypeSelector);
        //rgRouteType=(RadioGroup)v.findViewById(R.id.rgRouteType);;


        btZoomin = (Button) v.findViewById(R.id.btMapZoomin);
        btZoomout = (Button) v.findViewById(R.id.btMapZoomout);
        btCompass = (ImageButton) v.findViewById(R.id.btCompass);
        btTraffic = (ToggleButton) v.findViewById(R.id.btMapTraffic);

        ctMapScaler=(MapScaler)v.findViewById(R.id.ctMapScaler);

         //btTime=(RadioButton)v.findViewById(R.id.rbTime);
         //btHighWay=(RadioButton)v.findViewById(R.id.rbHighWay);
         //btDis=(RadioButton)v.findViewById(R.id.rbDis);
         //btFree=(RadioButton)v.findViewById(R.id.rbFree);






        if(getController()!=null) {
            mMapView = (MapView) getController().getObject(MapView.class.getCanonicalName()); // findViewById(R.id.mpView);

            if(mMapView!=null) {
                FrameLayout l = (FrameLayout) v.findViewById(R.id.mapframe);
                if (mMapView.getParent() != null) {
                    FrameLayout fv = (FrameLayout) mMapView.getParent();
                    if(fv!=l) {
                        fv.removeAllViews();
                        l.addView(mMapView);
                    }
                }
                else
                    l.addView(mMapView);

            }


            RoutePlanData data=(RoutePlanData)getController().getObject(RoutePlanData.class.getCanonicalName());
            if(data!=null)
            {
                String str = "里程:"+ WeNaviUtil.convertMeters(data.commonDistance)+
                         " 耗时:"+ WeNaviUtil.convertTime(data.commonTime);
                txtView.setText(str);

            }


            txtView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mClieckCount==0)
                    {
                        mTimmer = new Timer();
                        mTimmer.schedule(new timerOutTak(),10000);
                        Log.e(LOG_TAG,"ClieckCount Timer start for 10000ms");
                    }
                    else if(mClieckCount>=8)
                        btSimula.setVisibility(View.VISIBLE);

                    mClieckCount+=1;
                    Log.e(LOG_TAG,"ClieckCount "+mClieckCount);
                }
            });


        }


        //routeTypeSelector.setVisibility(View.INVISIBLE);

        btRouteType.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //showRouteType
                if(mDefaultRouteType==null) mDefaultRouteType=RouteController.CMD_ROUTE_PLAN_TIME;
                WeNaviAlertDialog dlg=new WeNaviAlertDialog((WeNaviBaseActivity)Page_02402_Fragment.this.getActivity());
                dlg.showRouteType(mDefaultRouteType,new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(which==R.id.rbTime||which==R.id.imTime) mDefaultRouteType=RouteController.CMD_ROUTE_PLAN_TIME;
                        else if(which==R.id.rbHighWay||which==R.id.imHighWay) mDefaultRouteType=RouteController.CMD_ROUTE_PLAN_HIGHWAY;
                        else if(which==R.id.rbDis||which==R.id.imDis) mDefaultRouteType=RouteController.CMD_ROUTE_PLAN_DISTANCE;
                        else if(which==R.id.rbFree||which==R.id.imFree) mDefaultRouteType=RouteController.CMD_ROUTE_PLAN_FREECHARGE;

                        showType(mDefaultRouteType);
                        submitAction(mDefaultRouteType);

                    }
                });
            }
        });

        mBtBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(Page_0102_Activity.this.getApplicationContext(),
                //        String.format("mBtBack clicked"), Toast.LENGTH_LONG).show();



                onBack();

            }
        });

        btSimula.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                RoutePlanParam rpm=(RoutePlanParam)getController().getObject(RoutePlanParam.class.getCanonicalName());
                if(rpm!=null) rpm.setSimulateNavi(true); //startNavigation(rpm.isSimulateNavi());


                toPage(Page_02501_Fragment.class);
                //Intent intent = new Intent(Page_010201_Activity.this, Page_01020101_Activity.class);
                //Page_010201_Activity.this.startActivity(intent);

            }
        });


        mBtGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startNavi();

            }
        });


        mBtCurrentLoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                submitAction(MapViewController.CMD_CURRENT_LOCATION);

            }
        });



    }






    void startNavi()
    {
        RoutePlanParam rpm=(RoutePlanParam)getController().getObject(RoutePlanParam.class.getCanonicalName());
        if(rpm!=null) rpm.setSimulateNavi(false); //startNavigation(rpm.isSimulateNavi());


        toPage(Page_02501_Fragment.class);
        //Intent intent = new Intent(getActivity(), Page_01020101_Activity.class);
        //getActivity().startActivity(intent);
    }


    int i=0;
    @Override
    public void onResume() {

        try {

            super.onResume();

            if (mMapView != null) {
                FrameLayout l = (FrameLayout) getView().findViewById(R.id.mapframe);
                if (mMapView.getParent() != null) {
                    FrameLayout v = (FrameLayout) mMapView.getParent();
                    if (v != l) {
                        v.removeAllViews();
                        l.addView(mMapView);
                    }

                }
            }

            submitAction(MapViewController.CMD_BIND_COMPASS,btCompass);
            submitAction(MapViewController.CMD_BIND_MAPSCALER,ctMapScaler);
            submitAction(MapViewController.CMD_BIND_ZOOMIN,btZoomin);
            submitAction(MapViewController.CMD_BIND_ZOOMOUT,btZoomout);
            submitAction(MapViewController.CMD_BIND_TRAFFIC,btTraffic);
            submitAction(MapViewController.CMD_BIND_CURLOC,mBtCurrentLoc);


            submitAction(MapViewController.CMD_NORTH_MAP);
            LocationData loc=(LocationData) getController().getObject(LocationData.class.getCanonicalName());
            if(loc!=null && loc.pt!=null) submitAction(MapViewController.CMD_SET_MAP_CENTER, loc.pt);


            Bundle c = getArguments();
            if (c != null) {
                WeNaviInternalMessage m=new WeNaviInternalMessage(c);
                if (m !=null) {

                    GeoPoint start=mMapView.getMapCenter();
                    loc=(LocationData) getController().getObject(LocationData.class.getCanonicalName());//getLocationData();
                    if(loc!=null && loc.pt!=null) start=loc.pt;

                    GeoPoint end=new GeoPoint(m.getLatitude(),m.getLongitude());

                    RoutePlanParam rpm=(RoutePlanParam) getController().getObject(RoutePlanParam.class.getCanonicalName());
                    if(rpm!=null){
                        rpm.setStartPoint(start);
                        rpm.setEndPoint(end);
                        rpm.clearPassPoints();
                        rpm.setRouteType(m.getTitle());
                        //submitAction(m.getTitle());
                        updateRouteType(m.getTitle());
                    }
                }

            }
            else
                submitAction(RouteController.CMD_QUERY_DEFAULT_ROUTETYPE);




        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        ++i;
        Log.e(LOG_TAG, "onResome"+i);

    }


    @Override
    public void onMirrorLinkClientKnobKeyShift(int nKnobID, MirrorLinkEvent.KnobShiftDirection dir) {

        submitAction(MapViewController.CMD_SHIFT_MAP,dir);
    }

    @Override
    public void onMirrorLinkClientKnobKeyRotate(int nKnobID, MirrorLinkEvent.KnobRotateAxis axis, MirrorLinkEvent.KnobRotateDirection dir) {
        //super.onMirrorLinkClientKnobKeyRotate(nKnobID, axis, dir);
        submitAction(MapViewController.CMD_SCALE_MAP,dir);
    }

    @Override
    public void onMirrorLinkClientKnobKeyPush(int nKnobID) {
        startNavi();
        //super.onMirrorLinkClientKnobKeyPush(nKnobID);
    }

    @Override
    public void onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey keyid) {

        if(keyid==MirrorLinkEvent.MultimediaKey.Multimedia_Play)
        {
            startNavi();
        }
        else super.onMirrorLinkCkientMultimediaKeyDown(keyid);
    }


    @Override
    public void onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey keyid) {
        if(keyid==MirrorLinkEvent.DeviceKey.Device_Ok)
        {
            startNavi();
        }
        else super.onMirrorLinkClientDeviceKeyDown(keyid);
    }


    @Override
    public int getFrameCategory() {
        return Defs.ContextInformation.VISUAL_CONTENT_CATEGORY_GRAPHICS_VECTOR;
    }


    @Override
    public void restoreViewStatus(Bundle status) {

    }

    @Override
    public Bundle getViewStatus() {
        return null;
    }
}
