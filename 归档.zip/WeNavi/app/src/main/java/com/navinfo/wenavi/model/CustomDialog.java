package com.navinfo.wenavi.model;

import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import com.navinfo.wenavi.activity.WeNaviBaseActivity;
import com.navinfo.wenavi.util.WeNaviUtil;

/**
 * Created by cc on 15/3/24.
 */
public class CustomDialog {
    private View mShowView;
    private PopupWindow mPopupWindow = null;
    private Activity mActivity;
    private OnClickListener mOnClickListener = null;
    int mResource=0;
    boolean mIsBuild=false;

    public CustomDialog(Activity activity,int resource){
        mActivity = activity;

        LoadDialog(resource);
    }


    public CustomDialog(Activity activity){
        mActivity = activity;
        mIsBuild=false;

    }



    public void LoadDialog(int resource)
    {

        if (mActivity != null){
            mShowView = mActivity.getLayoutInflater().inflate(resource, null);
            WeNaviUtil.updateUiTextSize((WeNaviBaseActivity)mActivity, (ViewGroup)mShowView);
            mPopupWindow = new PopupWindow(mShowView, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            mPopupWindow.setFocusable(true);
            ColorDrawable dw = new ColorDrawable(0xffffff);
            mPopupWindow.setBackgroundDrawable(dw);
            mPopupWindow.setOutsideTouchable(true);
        }else{
            Log.e("ccc","alert LoadDialog err");
        }
    }

    public View getView() {
        return mShowView;
    }

    public PopupWindow getPopupWindow() {
        return mPopupWindow;
    }

    public Activity getActivity() {
        return mActivity;
    }

    /**
     * @param parent the parent view
     */
    public  void show(View parent){

        if (!mPopupWindow.isShowing()) {
            mPopupWindow.showAtLocation(parent, Gravity.NO_GRAVITY, 220, 110);
        }

    }

    /*
    * @param parent a parent view to get the {@link android.view.View#getWindowToken()} token from
    * @param gravity the gravity which controls the placement of the popup window
    * @param x the popup's x location offset
    * @param y the popup's y location offset
    */
    public void showAtLocation(View parent, int gravity, int x, int y) {

        if (!mPopupWindow.isShowing()) {
            mPopupWindow.showAtLocation(parent, gravity,x,y);
        }
    }


    public void hide(){
        if (mPopupWindow.isShowing()) {
            mPopupWindow.dismiss();
        }
    }

//    public void setBackgroundDrawable(Drawable background) {
//        mBackground = background;
//    }
//    pw.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//    pw.setOutsideTouchable(false); // 设置是否允许在外点击使其消失，到底有用没？
//    pw.setAnimationStyle(R.style.PopupAnimation); // 设置动画

    /**
     * Interface definition for a callback to be invoked when a view is clicked.
     */
    public interface OnClickListener {
        /**
         * Called when dialog's button has been clicked.
         *
         * @param o The selected data that was clicked.
         */
        void onClick(Object o);
    }

    /**
     * Register a callback to be invoked when this view is clicked.
     *
     * @param l The callback that will run
     *
     */
    public void setOnClickListener(OnClickListener l) {
        mOnClickListener = l;
    }

    public OnClickListener getOnClickListener() {
        return mOnClickListener;
    }
}
