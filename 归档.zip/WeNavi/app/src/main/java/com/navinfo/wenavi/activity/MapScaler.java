package com.navinfo.wenavi.activity;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import com.navinfo.wenavi.R;

import java.text.NumberFormat;

/**
 * Created by Doone on 2015/3/12.
 * 地图比例尺控件
 */
public class MapScaler extends View {


    private Drawable mScaleDrawable;
    private Paint mPaint = new Paint();//画笔

    private int mScaleWidth = 102;
    private static final int MIN_SCALEWIDTH = 19;//最小比例尺宽度
    private String mScaleMeters = "";
    private int mScaleHeight = 10;

    private int mScaleLeft = 50;
    private int mScaleRight = 0;
    private int mScaleTop = 0;
    private int mScaleBottom = 0;
    private float mScaleText_X = 0;
    private float mScaleText_Y = 0;
    private float mTextsize = 0;
    private float density;
    private String[] mScaleMeasures = new String[] { "米", "公里" };


    public MapScaler(Context context, AttributeSet attrs) {
        super(context, attrs);

        mScaleDrawable = getResources().getDrawable(R.drawable.map_scale);
        density = context.getResources().getDisplayMetrics().density;
        mScaleHeight = mScaleDrawable.getIntrinsicHeight();
        if (density > 1.5f &&  density <= 2.0f) {
            mTextsize = 17f;
        }else if(density > 1.0f && density <= 1.5f){
            mTextsize = 15f;
        }else if(density <= 1.0){
            mTextsize = 13f;
        }else if (density > 2.0f && density <= 3.0) {
            mTextsize = 32f;
        }else{
            mTextsize = 40f;
        }

        mPaint.setTextSize(mTextsize);
        mPaint.setARGB(255, 0, 0, 0);
        mPaint.setTextAlign(Paint.Align.LEFT);
        mPaint.setAntiAlias(true);
    }


    public void setScaleWidthAndMeters(int map_height,int width, int meters) {
        Log.d("scale","scale width="+width+",meters="+meters);
        //dip值 =设备密度/160* pixel值
        try {
            Log.d("scale","density="+density);
            if (width >= MIN_SCALEWIDTH) {
                mScaleWidth = px2dip(width, density);
            }
        } catch (Exception e) {
            mScaleWidth = px2dip(MIN_SCALEWIDTH, density);;
        }
        Log.d("scale","mScaleWidth="+mScaleWidth);
        mScaleMeters = GetMapScaleMeters(meters);
        calcScalePosition ();
        postInvalidate();
    }
    /**
     * 将px值转换为dip或dp值，保证尺寸大小不变
     *
     * @param pxValue
     * @param scale（DisplayMetrics类中属性density）
     * @return
     */
    public static int px2dip(float pxValue, float scale) {
        return (int) (pxValue * scale + 0.5f);
    }


    private String GetMapScaleMeters(int scalemeters){
        String scaleMetersDisplayed = String.valueOf(scalemeters);
        String scalemeasure = mScaleMeasures[0];
        if (scalemeters >= 1000) {
            NumberFormat nFormat = NumberFormat.getInstance();
            nFormat.setMaximumFractionDigits(1);
            scaleMetersDisplayed = nFormat.format(scalemeters / 1000.0);
            scalemeasure = mScaleMeasures[1];
        }
        return scaleMetersDisplayed + scalemeasure;
    }

    //计算绘制位置
    private void calcScalePosition () {
        mScaleRight = mScaleLeft + mScaleWidth ;
        mScaleBottom = mScaleTop + mScaleHeight;
        mScaleText_X = mScaleLeft + mScaleWidth / 2 - mPaint.measureText(mScaleMeters) / 2;
        mScaleText_Y =mScaleTop + mScaleHeight  + mTextsize;
    }


    public void viewsizechanged(int w, int h){
        mScaleLeft = 0;
        mScaleTop = 0;
        calcScalePosition();
    }

    public int getScaleWidth () {
        return mScaleWidth;
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Log.d("scale","left = "+mScaleLeft+ ",top="+mScaleTop +",right="+ mScaleRight+",bottom="+ mScaleBottom);
        mScaleDrawable.setBounds(mScaleLeft, mScaleTop, mScaleRight, mScaleBottom);
        mScaleDrawable.draw(canvas);
        canvas.drawText(mScaleMeters, mScaleText_X, mScaleText_Y,  mPaint);

    }



}
