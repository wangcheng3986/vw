package com.navinfo.wenavi.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.navinfo.mirrorlink.MirrorLinkEvent;
import com.navinfo.sdk.mapapi.map.LocationData;
import com.navinfo.sdk.mapapi.map.MKMapStatus;
import com.navinfo.sdk.mapapi.map.MapView;
import com.navinfo.sdk.mapapi.search.adminarea.AdminAreaRecord;
import com.navinfo.sdk.mapapi.search.core.Geo;
import com.navinfo.sdk.mapapi.search.core.GeoCodeObj;
import com.navinfo.sdk.mapapi.search.core.POIGeoType;
import com.navinfo.sdk.mapapi.search.core.POIInfo;
import com.navinfo.sdk.mapapi.search.geocode.GeoCodeResult;
import com.navinfo.sdk.mapapi.search.geocode.ReverseGeoCodeResult;
import com.navinfo.sdk.mapapi.search.poi.POISearchResult;
import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.controller.AudioController;
import com.navinfo.wenavi.controller.GisController;
import com.navinfo.wenavi.controller.IController;
import com.navinfo.wenavi.controller.MapViewController;
import com.navinfo.wenavi.controller.RouteController;
import com.navinfo.wenavi.entity.AdminAreaEntity;
import com.navinfo.wenavi.model.CustomDialog;
import com.navinfo.wenavi.model.IMessage;
import com.navinfo.wenavi.entity.RoutePlanParam;
import com.navinfo.wenavi.model.WeNaviApplication;
import com.navinfo.wenavi.model.WeNaviInternalMessage;
import com.navinfo.wenavi.util.WeNaviDefine;
import com.navinfo.wenavi.util.WeNaviUtil;

import java.util.List;

/**
 * Created by Doone on 2015/3/7.
 */
public class Page_02301_Fragment extends  WeNaviBaseFragment {

    private final static String LOG_TAG = Page_02301_Fragment.class.getCanonicalName();



    Button btCity=null;
    TextView txtLoc=null;
    Button btDis=null;



    Button mBtBack=null;
    Button mBtGo=null;

    Button mBtCurrentLoc=null;
    MapView mMapView=null;
    ImageButton mBtCenter=null;

    Button btZoomin=null;
    Button btZoomout=null;
    ImageButton btCompass=null;
    ToggleButton btTraffic=null;
    MapScaler ctMapScaler=null;


    Page_02401_Dialog  mAdminDialog=null;

    @Override
    public void onSetListAdaptor() {
        if(mAdminDialog!=null) mAdminDialog.onSetListAdaptor();
    }

    @Override
    public void onRemoveListAdaptor() {
        if(mAdminDialog!=null) mAdminDialog.onRemoveListAdaptor();
    }

    @Override
    protected String getControllerName() {
        return MapViewController.class.getCanonicalName();
    }

    @Override
    public void onActionUpdate(Object... datas) {
        if(datas.length>0) {
            if (datas[0].getClass().getCanonicalName() == String.class.getCanonicalName()) {
                String sCms = (String) (datas[0]);
                //Log.e(LOG_TAG,"GisController Command= "+sCms);
                if(sCms== GisController.RET_REVERSEGEOCODE) { //逆地理编码结果
                    if(datas.length>3 &&
                            datas[1].getClass().getCanonicalName() == String.class.getCanonicalName() &&
                            datas[2].getClass().getCanonicalName() == String.class.getCanonicalName())
                    {
                        updateMsg((String)datas[1],(String)datas[2]);
                        mLastReverseGeoCodeResult=(ReverseGeoCodeResult)datas[3];
                    }
                }
                else if(sCms== MapViewController.RET_MAP_CLICKED) { //触发逆地理编码请求
                    if(datas.length>1 &&
                            datas[1].getClass().getCanonicalName() == GeoPoint.class.getCanonicalName())
                    {
                        mMapView.getController().setCenter((GeoPoint)datas[1]);
                        submitAction(GisController.CMD_GET_REVERSEGEOCODE,datas[1]);
                    }
                }
                else if(sCms== MapViewController.RET_MAP_ANIMATIONFINISH) { //触发逆地理编码请求

                    queryGeoreverseCode();

                }
                else if(sCms== MapViewController.RET_MAP_LOADFINISH)
                {

                    if(mMapView!=null) {
                        // GeoPoint point = mMapView.getMapCenter();
                        // submitAction(GisController.CMD_GET_REVERSEGEOCODE);
                        queryGeoreverseCode();
                        openIndicator();

                    }
                }
                else if(sCms== MapViewController.RET_MAP_STATUS_CHANGED)
                {
                    if(datas.length>1) onMapStatusChanged((MKMapStatus)datas[1]);

                    if(mMapView!=null) {
                        // GeoPoint point = mMapView.getMapCenter();

                        openIndicator();

                    }

                    //queryGeoreverseCode();
                }
                //else if(sCms== GisController.RET_M
                else if(sCms== MapViewController.RET_DISTANCE_TO_CURRENT_LOC)
                {
                    if(datas.length>1 &&
                            datas[1].getClass().getCanonicalName() == Integer.class.getCanonicalName())
                    {
                        updateDist((int)datas[1]);
                    }
                }
                else if(sCms== GisController.RET_GEOCODE)
                {
                    if(datas.length>1 &&
                            datas[1].getClass().getCanonicalName() == GeoCodeResult.class.getCanonicalName())
                    {
                        //updateDist((int)datas[1]);
                        GeoCodeResult r=(GeoCodeResult)datas[1];
                        GeoCodeObj obj = r.objs.get(0);
                        if(obj.point != null) {
                            submitAction(MapViewController.CMD_SET_MAP_CENTER,obj.point);
                        }

                    }
                }
                else if(sCms== GisController.RET_POI)
                {

                    if(datas.length>1 &&
                            datas[1].getClass().getCanonicalName().equals(POISearchResult.class.getCanonicalName()))
                    {
                        //updateDist((int)datas[1]);
                        POISearchResult r=(POISearchResult)datas[1];
                        if(r.pois.size()<1){

                        }else if(r.pois.size()==1){
                            POIInfo item=r.pois.get(0);
                            if(item!=null && item.geo!=null && item.name!=null) {

                                double[] doubles = WeNaviUtil.convertGeo(item.geo.value);
                                GeoPoint p = new GeoPoint((int) (doubles[1] * 3.6E6), (int) (doubles[0] * 3.6E6));

                                submitAction(MapViewController.CMD_SET_MAP_CENTER, p);
                                //选择城市更新
                                txtLoc.setText(item.name);
                            }
//                            mMapView.getController().setCenter(new GeoPoint(WeNaviUtil.convertGeo(poi.geo.value)[0],));
                        }else{
                            for(int i = 0;i<r.pois.size();i++){
                                POIInfo poi=r.pois.get(i);
                                Log.d(LOG_TAG,"poi.name"+poi.name);
                                Log.d(LOG_TAG,"poi.distance"+poi.distance);
                                Log.d(LOG_TAG," poi.geo.value"+ poi.geo.value);


                            }
                            showPoiList(r.pois);
                        }


                    }
                }
                else if(sCms== AudioController.RET_RECONGNISE) {
                    if(datas.length>1)
                        showAudioRecongniseResult(datas[1].toString());


                }
                else super.onActionUpdate(datas);

            }
        }


    }



    @Override
    protected int getFragmentLayoutID() {
        return R.layout.page_02301;
    }


    /**
     * 初始化控件为不可用,页面初始化时调用
     */
    @Override
    public  void onDisableControl()
    {
        mBtBack.setEnabled(false);
        mBtGo.setEnabled(false);

    }

    /**
     * 初始化控件为可用,页面初始化完成后被延时调用
     */
    @Override
    public  void onEnableControl()
    {
        mBtBack.setEnabled(true);
        mBtGo.setEnabled(true);
    }

    @Override
    protected void bindUIControl(View v) {

        mBtBack = (Button) v.findViewById(R.id.btBack);
        mBtGo = (Button) v.findViewById(R.id.btGo);

        mBtCurrentLoc = (Button) v.findViewById(R.id.btCurrentLoc);


        btZoomin = (Button) v.findViewById(R.id.btMapZoomin);
        btZoomout = (Button) v.findViewById(R.id.btMapZoomout);
        btCompass = (ImageButton) v.findViewById(R.id.btCompass);
        btTraffic = (ToggleButton) v.findViewById(R.id.btMapTraffic);

        ctMapScaler=(MapScaler)v.findViewById(R.id.ctMapScaler);




        //mMapView = (MapView) findViewById(R.id.mpView);
        mBtCenter = (ImageButton) v.findViewById(R.id.imageButton);


        btCity = (Button) v.findViewById(R.id.btCity);

        txtLoc = (TextView) v.findViewById(R.id.txtLoc);
        btDis = (Button) v.findViewById(R.id.btDis);
        btDis.setClickable(false);
        updateMsg("选择城市", "当前位置");

        IController c=getController();
        if (c != null) {
            mMapView = (MapView) c.getObject(MapView.class.getCanonicalName()); // findViewById(R.id.mpView);

            if (mMapView != null) {
                FrameLayout l = (FrameLayout) v.findViewById(R.id.mapframe);
                if (mMapView.getParent() != null) {
                    FrameLayout fv = (FrameLayout) mMapView.getParent();
                    if (fv != l) {
                        fv.removeAllViews();
                        l.addView(mMapView);
                    }
                } else
                    l.addView(mMapView);

            }
        }


        mBtBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(Page_0102_Activity.this.getApplicationContext(),
                //        String.format("mBtBack clicked"), Toast.LENGTH_LONG).show();


                onBack();

            }
        });




        mBtGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(Page_0102_Activity.this.getApplicationContext(),
                //       String.format("mBtGo clicked"), Toast.LENGTH_LONG).show();
                //submitAction(NaviController.CMD_ROUTE_PLAN);

                Page_02301_Fragment.this.startRoute();

            }
        });


        btCity.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                if(mAdminDialog==null) {
                    mAdminDialog = new Page_02401_Dialog(Page_02301_Fragment.this.getActivity(),
                            (WeNaviApplication)
                                    Page_02301_Fragment.this.getActivity().getApplication());


                    mAdminDialog.setOnClickListener(new CustomDialog.OnClickListener() {

                        @Override
                        public void onClick(Object o) {
                            AdminAreaEntity record = (AdminAreaEntity) o;
                            if (record != null) {
                                GeoPoint ptCenter = new GeoPoint(record.getLat(),record.getLon());
                                if (ptCenter != null) {
                                    submitAction(MapViewController.CMD_SET_MAP_CENTER, ptCenter);
                                    queryGeoreverseCode();
                                }
                            }


                        }
                    });
                }

                if(mAdminDialog!=null) mAdminDialog.showAtLocation(v, Gravity.NO_GRAVITY, 0, 0);

            }
        });





    }


    private ReverseGeoCodeResult mLastReverseGeoCodeResult=null;
    /**
     *  当UI处于分支中时，该回掉在UI resume时调用
     */
    @Override
    public void onUiBranch()
    {
        mBtGo.setText(R.string.action_settings);
        mBtGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Page_02301_Fragment.this.startRoute();

                if(requestLocationMessg!=null)
                {
                    GeoPoint end=mMapView.getMapCenter();


                    //Page_01401_Fragment.this.tap
                    ((WeNaviInternalMessage)requestLocationMessg).setReceiver(requestLocationMessg.getSender());
                    ((WeNaviInternalMessage)requestLocationMessg).setSender(Page_02301_Fragment.this.getClass().getCanonicalName());
                    ((WeNaviInternalMessage)requestLocationMessg).setLongitude(end.getLongitudeE6());
                    ((WeNaviInternalMessage)requestLocationMessg).setLatitude(end.getLatitudeE6());
                    if(mLastReverseGeoCodeResult!=null)
                    ((WeNaviInternalMessage)requestLocationMessg).setLocation(WeNaviUtil.toLocationString(mLastReverseGeoCodeResult));

                    toRootPage(requestLocationMessg.toBundle());
                }
                else toRootPage();


               /* if(requestLocationMessg!=null)
                {
                    GeoPoint end=mMapView.getMapCenter();
                    Bundle c=new Bundle();
                    c.putInt("Longitude",end.getLongitudeE6());
                    c.putInt("Latitude",end.getLatitudeE6());
                    IMessage m=new WeNaviInternalMessage(
                            Page_02301_Fragment.this.getClass().getCanonicalName(),
                            requestLocationMessg.getSender(),
                            WeNaviDefine.MSG_RESPONSE_LOCATION,
                            c);
                    //sendInternalMessage(m);
                    toRootPage(m.toBundle());
                }
                else toRootPage();*/

            }
        });
    }



    void startRoute()
    {
        GeoPoint start=mMapView.getMapCenter();
        LocationData loc=(LocationData) getController().getObject(LocationData.class.getCanonicalName());//getLocationData();
        if(loc!=null && loc.pt!=null) start=loc.pt;

        GeoPoint end=mMapView.getMapCenter();

        RoutePlanParam rpm=(RoutePlanParam) getController().getObject(RoutePlanParam.class.getCanonicalName());
        if(rpm!=null){
            rpm.reset();
            rpm.setStartPoint(start);
            rpm.setEndPoint(end);
            rpm.clearPassPoints();
            rpm.setRouteType(RouteController.CMD_ROUTE_PLAN);
        }

        //submitAction(RouteController.CMD_ROUTE_POINT,end,start);


        toPage(Page_02402_Fragment.class);
        //Intent intent = new Intent(getActivity(), Page_010201_Activity.class);
        //getActivity().startActivity(intent);
    }


    private IMessage requestLocationMessg=null;

    @Override
    protected void onInternalMessage(IMessage m) {

        if(m.getMessageType().equals(WeNaviDefine.MSG_REQUEST_LOCATION))
            requestLocationMessg=m;
        //super.onInternalMessage(m);
    }

    @Override
    public void onResume() {
        if(mMapView!=null) {
            FrameLayout l = (FrameLayout) getView().findViewById(R.id.mapframe);
            if (mMapView.getParent() != null) {
                FrameLayout v = (FrameLayout) mMapView.getParent();
                if(v!=l)
                {
                    v.removeAllViews();
                    l.addView(mMapView);
                }

            }

            openIndicator();


        }

        submitAction(MapViewController.CMD_BIND_COMPASS,btCompass);
        submitAction(MapViewController.CMD_BIND_MAPSCALER,ctMapScaler);
        submitAction(MapViewController.CMD_BIND_ZOOMIN,btZoomin);
        submitAction(MapViewController.CMD_BIND_ZOOMOUT,btZoomout);
        submitAction(MapViewController.CMD_BIND_TRAFFIC,btTraffic);
        submitAction(MapViewController.CMD_BIND_CURLOC,mBtCurrentLoc);

        requestLocationMessg=null;

        Bundle pm=getArguments();
        if(pm!=null)
        {
            requestLocationMessg=new WeNaviInternalMessage(pm);
        }

		submitAction(MapViewController.CMD_NORTH_MAP);
        AdminAreaEntity record  = (AdminAreaEntity)getParameters();


        if (record != null){
            //Log.d("mAdminRecord","record"+record.getCode()+","+ record.getLat()+","+record.getLon());

            submitAction(MapViewController.CMD_SET_MAP_CENTER, new GeoPoint(record.getLat(),record.getLon()));
        }else{
            Log.d("mAdminRecord","record == null");

            LocationData loc=(LocationData) getController().getObject(LocationData.class.getCanonicalName());
            if(loc.pt!=null) submitAction(MapViewController.CMD_SET_MAP_CENTER, loc.pt);
        }

        super.onResume();
        //mAudioRecongniser.startRecongnise(Page_0102_Activity.this);
    }


    @Override
    public void onPause() {
        submitAction(MapViewController.CMD_CLOSE_DISTANCE_OVERLAY);
        isOpenIndicator=false;
        super.onPause();

    }

    private  boolean isOpenIndicator=false;
    void openIndicator()
    {
        if(!isOpenIndicator) {
            boolean bLoaded = mMapView.getController().isMapLoadFinish();

            Log.e(LOG_TAG, "mMapView.getController().isMapLoadFinish()=" + bLoaded);
            Object o = getController().getObject(MapViewController.PROPERTY_IS_MAP_LOADED);
            if (o != null && o.getClass().getCanonicalName() == Boolean.class.getCanonicalName()) {
                bLoaded = (Boolean) o;
                Log.e(LOG_TAG,"GisController.PROPERTY_IS_MAP_LOADED="+bLoaded);
            }


            if (bLoaded) {
                submitAction(MapViewController.CMD_OPEN_DISTANCE_OVERLAY);
                isOpenIndicator = true;
            }
        }
    }


    protected void queryGeoreverseCode()
    {
        if(mMapView.getController().isMapLoadFinish())
            submitAction(GisController.CMD_GET_REVERSEGEOCODE);
    }

    @Override
    public void onBack() {
        submitAction(MapViewController.CMD_CLOSE_DISTANCE_OVERLAY);
        isOpenIndicator=false;
        super.onBack();
    }



    void updateMsg(final String sCity,final String sLoc)
    {
        getActivity().runOnUiThread(new Runnable() {
            public void run() {
                if(sCity!=null) btCity.setText(sCity);
                if(sLoc!=null) txtLoc.setText(sLoc);
            }

        });
    }

    void updateDist(final int nDis)
    {
        getActivity().runOnUiThread(new Runnable() {
            public void run() {
                if(nDis<1000)
                    btDis.setText("  "+nDis+"m  ");
                else {
                    String s=String.format("  %.1fkm  ",nDis/1000.0f);
                    btDis.setText(s);
                }

            }

        });
    }



    void showAudioRecongniseResult(final String s)
    {
        /*getActivity().runOnUiThread(new Runnable() {
            public void run() {
                //updateView(RET_RECONGNISE,s);
                String sInfo = String.format(getResources().getString(R.string.audio_command) + " %s", s);
                Toast.makeText(getActivity().getApplicationContext(), sInfo, Toast.LENGTH_LONG).show();
            }
        });*/
    }

    private POIInfo getPOIInfo(GeoPoint point, String name){
        POIInfo poi = new POIInfo();
        poi.name = name;
        poi.geo = new Geo();
        poi.geo.type = POIGeoType.POINT;
        poi.geo.value = String.format("POINT(%s %s)", point.getLongitudeE6()/3.6E6, point.getLatitudeE6()/3.6E6);
        return poi;
    }




    class POIListAdapter extends BaseAdapter {
        private Context mContext = null;
        private List<POIInfo> mlist = null;

        public POIListAdapter(Context context,List<POIInfo> list){
            this.mContext = context;
            this.mlist = list;
        }
        @Override
        public int getCount() {
            int count = 0;
            if (null != mlist)
            {
                count = mlist.size();
            }
            return count;
        }

        @Override
        public POIInfo getItem(int position) {
            POIInfo item = null;

            if (null != mlist)
            {
                item = mlist.get(position);
            }

            return item;
        }

        @Override
        public long getItemId(int position) {

            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder = null;

            if (null == convertView)
            {
                viewHolder = new ViewHolder();
                LayoutInflater mInflater = LayoutInflater.from(mContext);
                convertView = mInflater.inflate(R.layout.page_02301_poi_item, null);

                //if(convertView!=null) setFontSize((ViewGroup)convertView,getDefaultTextSize());

                viewHolder.name = (TextView) convertView.findViewById(R.id.tv_poi_item_name);
                viewHolder.distance = (TextView) convertView
                        .findViewById(R.id.tv_poi_item_address);

                convertView.setTag(viewHolder);
            }
            else
            {
                viewHolder = (ViewHolder) convertView.getTag();
            }


            final POIInfo item = getItem(position);
            if (null != item)
            {
                viewHolder.name.setText(item.name);
                viewHolder.distance.setText(WeNaviUtil.convertMeters((int) item.distance));
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    String n =  item.name;
                    double[] doubles = WeNaviUtil.convertGeo(item.geo.value);
                    GeoPoint p = new GeoPoint((int)(doubles[1]*3.6E6),(int)(doubles[0]*3.6E6));

                    submitAction(MapViewController.CMD_SET_MAP_CENTER, p);
                    //选择城市更新
                    txtLoc.setText(item.name);
                    Log.d(LOG_TAG,"(int)(doubles[1]*3.6E6)="+(int)(doubles[1]*3.6E6));
                }
            });


            return convertView;
        }
        private final class ViewHolder
        {
            TextView name;
            TextView distance;

        }

    }
    private AlertDialog dialog =null;
    private void showPoiList(List<POIInfo> list){
        LayoutInflater li = (LayoutInflater) getActivity().getSystemService(getActivity().LAYOUT_INFLATER_SERVICE);

        //setFontSize();
        final LinearLayout ll = (LinearLayout)li.inflate(R.layout.page_02301_poi_list, null);
        //ll.getBackground().setAlpha(100);
        ListView lv = (ListView) ll.findViewById(R.id.lv_poi_list);
        POIListAdapter adapter = new POIListAdapter(getActivity(),list);
        lv.setAdapter(adapter);

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setView(ll);

        /*dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                final ViewGroup root = (ViewGroup) ll.findViewById(R.id.layoutroot);
                if(root!=null) setFontSize(root,getDefaultTextSize());

            }
        });*/

        dialog = builder.show();

    }




    @Override
    public void onMirrorLinkClientKnobKeyShift(int nKnobID, MirrorLinkEvent.KnobShiftDirection dir) {

        submitAction(MapViewController.CMD_SHIFT_MAP,dir);
    }

    @Override
    public void onMirrorLinkClientKnobKeyRotate(int nKnobID, MirrorLinkEvent.KnobRotateAxis axis, MirrorLinkEvent.KnobRotateDirection dir) {
        //super.onMirrorLinkClientKnobKeyRotate(nKnobID, axis, dir);
        submitAction(MapViewController.CMD_SCALE_MAP,dir);
    }


    @Override
    public void onMirrorLinkClientKnobKeyPush(int nKnobID) {
        startRoute();
        //super.onMirrorLinkClientKnobKeyPush(nKnobID);
    }


    @Override
    public void onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey keyid) {

        if(keyid==MirrorLinkEvent.MultimediaKey.Multimedia_Play)
        {
            startRoute();
        }
        else super.onMirrorLinkCkientMultimediaKeyDown(keyid);
    }


    @Override
    public void onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey keyid) {
        if(keyid==MirrorLinkEvent.DeviceKey.Device_Ok)
        {
            startRoute();
        }
        else super.onMirrorLinkClientDeviceKeyDown(keyid);
    }


    public void onMapStatusChanged(MKMapStatus mapStatus)
    {
        /*

         */
        //当地图旋转角度发生变化时设置外置指南针的旋转角度




        // 取得想要缩放的matrix参数
        /*Matrix matrix = new Matrix();

        float scaleWidth = ((float) btCompass.getWidth()) / compassBitmap.getWidth();
        float scaleHeight = ((float) btCompass.getHeight()) / compassBitmap.getHeight();
        matrix.postScale(scaleWidth, scaleHeight);
        Bitmap mBitmap= Bitmap.createBitmap(compassBitmap, 0, 0,compassBitmap.getWidth(),compassBitmap.getHeight(), matrix, true);

        //旋转
        matrix=new Matrix();
        matrix.setRotate(mapStatus.mRotate);
        Bitmap mBitmap1=Bitmap.createBitmap(mBitmap, 0, 0,mBitmap.getWidth(),mBitmap.getHeight(), matrix, true);
        btCompass.setImageBitmap(mBitmap1);
        mBitmap.recycle();


        ScaleInfo info =  mMapView.getScaleInfo();
        if(info != null){
            ctMapScaler.setScaleWidthAndMeters(mMapView.getHeight(), info.scalePixels, info.scaleMeters);
            ctMapScaler.invalidate();
        }*/

    }


    @Override
    public void restoreViewStatus(Bundle status) {

    }

    @Override
    public Bundle getViewStatus() {
        return null;
    }
}
