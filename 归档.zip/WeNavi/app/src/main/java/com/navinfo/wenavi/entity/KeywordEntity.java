package com.navinfo.wenavi.entity;

import java.util.Date;

/**
 * Created by min on 2015/3/10.
 */
public class KeywordEntity {

    private String word;
    private Date time;

    public void setTime(Date time) {
        this.time = time;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public Date getTime() {
        return time;
    }

    public String getWord() {
        return word;
    }
}
