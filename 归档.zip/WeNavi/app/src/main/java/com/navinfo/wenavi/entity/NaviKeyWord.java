package com.navinfo.wenavi.entity;

import com.orm.SugarRecord;

import java.util.Date;

/**
 * Created by Doone on 2015/3/10.
 * 关键字历史数据实体
 */
public class NaviKeyWord extends SugarRecord<NaviKeyWord> {

    String searchKeyWord;
    Date searchTime;
    String cityName;
    String cityCode;
    int longitude;
    int latitude;


    public NaviKeyWord()
    {

    }

    public NaviKeyWord(String searchKeyWord, Date searchTime, String cityName, String cityCode, int longitude, int latitude) {
        this.searchKeyWord = searchKeyWord;
        this.searchTime = searchTime;
        this.cityName = cityName;
        this.cityCode = cityCode;
        this.longitude = longitude;
        this.latitude = latitude;
    }

    public String getSearchKeyWord() {
        return searchKeyWord;
    }

    public void setSearchKeyWord(String searchKeyWord) {
        this.searchKeyWord = searchKeyWord;
    }

    public Date getSearchTime() {
        return searchTime;
    }

    public void setSearchTime(Date searchTime) {
        this.searchTime = searchTime;
    }


    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public int getLongitude() {
        return longitude;
    }

    public void setLongitude(int longitude) {
        this.longitude = longitude;
    }

    public int getLatitude() {
        return latitude;
    }

    public void setLatitude(int latitude) {
        this.latitude = latitude;
    }
}
