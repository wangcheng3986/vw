package com.navinfo.wenavi.entity;

import com.orm.SugarRecord;

import java.util.Date;

/**
 * 行政区数据体
 * Created by cc on 15/3/31.
 */
public class AdminAreaEntity extends SugarRecord<AdminAreaEntity> {
    public static final int PROVINCE = 0;
    public static final int CITY = 1;
    public static final int REGION = 2;
    private java.lang.String code = null;
    private java.lang.String parentCode= null;
    private java.lang.String name= null;
    private java.lang.String py= null;
    private java.lang.String pySingle= null;
    private int lon=0;
    private int lat=0;
    private int type=0;
    private Date addTime;


    public AdminAreaEntity(String code, String parentCode, int type, String name, String py, int lat, int lon){
        this.code = code;
        this.type = type;
        this.name = name;
        this.py = py;
        this.pySingle = py.substring(0,1);
        this.lat = lat;
        this.lon = lon;
        this.parentCode = parentCode;
        this.addTime = new Date();
    }
    public AdminAreaEntity(){
        this.addTime = new Date();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPy() {
        return py;
    }

    public void setPy(String py) {
        this.py = py;
        this.pySingle = py.substring(0,1);
    }

    public int getLon() {
        return lon;
    }

    public void setLon(int lon) {
        this.lon = lon;
    }

    public int getLat() {
        return lat;
    }

    public void setLat(int lat) {
        this.lat = lat;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getParentCode() {
        return parentCode;
    }

    public void setParentCode(String parentCode) {
        this.parentCode = parentCode;
    }

    public Date getAddTime() {
        return addTime;
    }

    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    public String getPySingle() {
        return pySingle;
    }
}
