package com.navinfo.wenavi.controller;

import android.content.Context;
import android.util.DisplayMetrics;
import android.util.Log;


import com.navinfo.sdk.naviapi.NaviManager;
import com.navinfo.sdk.naviapi.NaviState;

import com.navinfo.sdk.naviapi.RoutePlanListener;
import com.navinfo.sdk.naviapi.routeplan.MKRoute;
import com.navinfo.sdk.naviapi.routeplan.RoutePlanData;
import com.navinfo.sdk.naviapi.setting.SettingManager;
import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;
import com.navinfo.wenavi.entity.AppConfig;
import com.navinfo.wenavi.model.Repository;
import com.navinfo.wenavi.entity.RoutePlanParam;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Doone on 2015/2/19.
 * 路径规划控制器
 */
public class RouteController extends MapViewController implements RoutePlanListener {



    /**
     * 功能代码: 路径规划， 需提供GeoPoint 终点， GeoPoint 起点
     * 允许起点不提供，默认采用当前位置为起点
     */
    public static final String CMD_ROUTE_POINT="CMD_ROUTE_POINT";

    /**
     * 功能代码: 路径规划， 需提供GeoPoint 终点， GeoPoint 起点
     * 允许起点不提供，默认采用当前位置为起点
     */
    public static final String CMD_ROUTE_PLAN="CMD_ROUTE_PLAN";

    /**
     * 功能代码: 时间最短路径规划， 需提供GeoPoint 终点， GeoPoint 起点
     * 允许起点不提供，默认采用当前位置为起点
     */
    public static final String CMD_ROUTE_PLAN_TIME="CMD_ROUTE_PLAN_TIME";

    /**
     * 功能代码: 高速优先路径规划， 需提供GeoPoint 终点， GeoPoint 起点
     * 允许起点不提供，默认采用当前位置为起点
     */
    public static final String CMD_ROUTE_PLAN_HIGHWAY="CMD_ROUTE_PLAN_HIGHWAY";


    /**
     * 功能代码: 距离最短路径规划， 需提供GeoPoint 终点， GeoPoint 起点
     * 允许起点不提供，默认采用当前位置为起点
     */
    public static final String CMD_ROUTE_PLAN_DISTANCE="CMD_ROUTE_PLAN_DISTANCE";



    /**
     * 功能代码: 加载最后一次路径规划
     *
     */
    public static final String CMD_RELOAD_LAST_ROUTE_PLAN="CMD_RELOAD_LAST_ROUTE_PLAN";


    /**
     * 功能代码: 免费优先路径规划， 需提供GeoPoint 终点， GeoPoint 起点
     * 允许起点不提供，默认采用当前位置为起点
     */
    public static final String CMD_ROUTE_PLAN_FREECHARGE="CMD_ROUTE_PLAN_FREECHARGE";


    /**
     * 功能代码: 查询缺省路径规划类型
     *
     */
    public static final String CMD_QUERY_DEFAULT_ROUTETYPE="CMD_QUERY_DEFAULT_ROUTETYPE";



    /**
     * 功能代码: 更新缺省路径规划类型
     *
     */
    public static final String CMD_UPDATE_DEFAULT_ROUTETYPE="CMD_UPDATE_DEFAULT_ROUTETYPE";


    /**
     * 功能代码: 增加途径点
     *
     */
    public static final String CMD_ADD_PASS_POINT="CMD_ADD_PASS_POINT";


    /**
     * 视图刷新代码:缺省路径规划类型
     */
    public static final String RET_DEFAULT_ROUTETYPE="RET_DEFAULT_ROUTETYPE";


    /**
     * 视图刷新代码:路径规划开始
     */
    public static final String RET_ROUTE_PLAN_START="RET_ROUTE_PLAN_START";




    /**
     * 视图刷新代码:路径规划结束
     */
    public static final String RET_ROUTE_PLAN_FINISH="RET_ROUTE_PLAN_FINISH";

    /**
     * 视图刷新代码:路径规划成功
     */
    public static final String RET_ROUTE_PLAN_SUCCESS="RET_ROUTE_PLAN_SUCCESS";

    /**
     * 视图刷新代码:路径规划失败
     */
    public static final String RET_ROUTE_PLAN_FAIL="RET_ROUTE_PLAN_FAIL";





    private RoutePlanData mRoutePlanData=null;


    private NaviManager mNaviManager=null;


    private GeoPoint mStartPoint=null;
    private GeoPoint mEndPoint=null;
    private String mDefaultRouteType=null;



    public RouteController(Context context) {
        super(context);



    }

    public NaviManager getNaviManager()
    {
        if(mNaviManager==null)
        {
            mNaviManager=(NaviManager)getDefaultModel().getObject(NaviManager.class.getCanonicalName());
            //mNaviManager=new NaviManager(getMapView(),getContext());

        }
        return mNaviManager;
    }

    public RoutePlanData getRoutePlanData()
    {
        return mRoutePlanData;
    }


    public GeoPoint getStartPoint()
    {
        return mStartPoint;
    }


    public GeoPoint getEndPoint()
    {
        return mEndPoint;
    }

    @Override
    public Object getObject(String sName) {
        if(sName==NaviManager.class.getCanonicalName())
            return getNaviManager();
        else if(sName==RoutePlanData.class.getCanonicalName())
            return getRoutePlanData();
        return super.getObject(sName);
    }

    @Override
    protected ShowParam getShowBuiltInZoomControls(DisplayMetrics dm) {
        ShowParam pm=new ShowParam();
        pm.isShow=false;

        int l=getMapView().getLeft();
        int r=getMapView().getRight();
        int t=getMapView().getTop();
        int h=getMapView().getHeight();
        int w=getMapView().getWidth();
        pm.y = t + dpToPixel(dm, 5);
        pm.x = l + w
                - getMapView().getTrafficControlIconWdith()
                - getMapView().getBuiltInZoomControlsWidth()
                - dpToPixel(dm,15);

        return pm;
    }

    @Override
    public void onViewResume() {
        super.onViewResume();

        if(getNaviManager()!=null)
        {
            //mNaviManager.regNavigationListener(this);
            mNaviManager.regRoutePlanListener(this);

            //设置线宽和颜色
            mNaviManager.setDrawRouteProperty(0, 100, 200, 30);
            //设置路线规划参数
            //SettingManager cfg = SettingManager.getInstance();
            //cfg.setRoutePlanParam(SettingManager.NAVIPLANTYPE_FASTESTTIME, false);
            //mNaviManager.setNaviSetPlanParamemter(cfg);

            //恢复最后一次路径规划
            //redoLastRoutePlan();
        }
    }

    @Override
    public void onViewPause() {


        //if(mEndPoint!=null)
        //getMapView().getController().setCenter(mEndPoint);

        //getNaviManager().quitNavigator();

        super.onViewPause();

    }

    @Override
    public void onViewDestroy() {

        getNaviManager().quitNavigator();
        super.onViewDestroy();
    }

    @Override
    public void onViewBack() {
        //MKMapStatus status = getMapView().getMapStatus();
        //status.mRotate = 0;
        //getMapView().getController().setMapStatus(status);
        //此处需要增加清除规划路径的代码

        //mNaviManager.destroy();
        //mNaviManager=null;

        mNaviManager.quitNavigator();

        mRoutePlanData=null;


        super.onViewBack();
    }

    @Override
    public void executeAction(Object... actionDatas) {
        if(actionDatas.length>0) {
            if (actionDatas[0].getClass().getCanonicalName().equals(String.class.getCanonicalName())) {
                String sCms = (String) (actionDatas[0]);


                if (sCms.equals(CMD_ROUTE_POINT) ) {


                    if (actionDatas.length > 1 &&
                            actionDatas[1].getClass().getCanonicalName() == GeoPoint.class.getCanonicalName()) {
                        mEndPoint = (GeoPoint) actionDatas[1];
                    }

                    if (actionDatas.length > 2 &&
                            actionDatas[2].getClass().getCanonicalName() == GeoPoint.class.getCanonicalName()) {
                        mStartPoint = (GeoPoint) actionDatas[2];
                    }
                }
                else if(sCms.equals(CMD_ADD_PASS_POINT))
                {
                    if (actionDatas.length > 1 &&
                            actionDatas[1].getClass().getCanonicalName() == GeoPoint.class.getCanonicalName()) {
                        addPassPoint((GeoPoint) actionDatas[1]);
                    }
                }

                else if (sCms.equals(CMD_ROUTE_PLAN) || sCms.equals(CMD_ROUTE_PLAN_TIME) ||
                        sCms.equals(CMD_ROUTE_PLAN_HIGHWAY) || sCms.equals(CMD_ROUTE_PLAN_DISTANCE) ||
                        sCms.equals(CMD_ROUTE_PLAN_FREECHARGE))
                {
                    /*mLastRoutePlan=sCms;
                    GeoPoint start=getMapView().getMapCenter();
                    LocationData loc= getLocationData();
                    if(loc!=null && loc.pt!=null) start=loc.pt;

                    GeoPoint end=getMapView().getMapCenter();

                    if(actionDatas.length>1 &&
                            actionDatas[1].getClass().getCanonicalName()==GeoPoint.class.getCanonicalName() ) {
                        end=(GeoPoint) actionDatas[1];
                    }

                    if(actionDatas.length>2 &&
                            actionDatas[2].getClass().getCanonicalName()==GeoPoint.class.getCanonicalName() ) {
                        start=(GeoPoint) actionDatas[2];
                    }

                    if(mEndPoint!=null) end=mEndPoint;
                    if(mStartPoint!=null) start=mStartPoint;

                    startRoutrPlan(sCms,start,end);*/
                    RoutePlanParam rpm=(RoutePlanParam) getObject(RoutePlanParam.class.getCanonicalName());
                    if(rpm!=null){
                        rpm.setRouteType(sCms);
                    }
                    redoLastRoutePlan();


                }
                else if(sCms.equals(CMD_RELOAD_LAST_ROUTE_PLAN))
                {
                    redoLastRoutePlan();
                }
                else if(sCms.equals(CMD_QUERY_DEFAULT_ROUTETYPE))
                {
                    queryDefaultRouteType();
                }
                else if(sCms.equals(CMD_UPDATE_DEFAULT_ROUTETYPE))
                {

                   // updateDefaultRouteType();
                }
                else
                    super.executeAction(actionDatas);
            }
        }

    }

    public void queryDefaultRouteType()
    {

        RoutePlanParam rpm=(RoutePlanParam)getObject(RoutePlanParam.class.getCanonicalName());
        if(rpm!=null)
        {
            if(rpm.getRouteType()!=null && !rpm.getRouteType().equals(CMD_ROUTE_PLAN))
            {
              updateView(RET_DEFAULT_ROUTETYPE,rpm.getRouteType());
              return;
            }
        }

        AppConfig c= Repository.getAppConfig("UserRouteType");
        if(c==null)
        {
            c=new AppConfig("UserRouteType",CMD_ROUTE_PLAN_TIME,null);
            c.save();
        }
        if(c!=null)
        {
            if(rpm!=null) rpm.setRouteType(c.getParamValue());
            updateView(RET_DEFAULT_ROUTETYPE,c.getParamValue());
        }

    }

    public void redoLastRoutePlan()
    {
        RoutePlanParam rpm=(RoutePlanParam)getObject(RoutePlanParam.class.getCanonicalName());
        if(rpm!=null)
        {
            if(rpm.getRouteType()!=null && rpm.getStartPoint()!=null && rpm.getEndPoint()!=null)
            {
                //LocationData loc= getLocationData();
                GeoPoint pStart=rpm.getStartPoint();
                //if(loc!=null && loc.pt!=null) pStart=loc.pt;
                startRoutrPlan(rpm.getRouteType(),pStart,rpm.getEndPoint(),rpm.getPassPoints());
            }

        }
        else if( mStartPoint!=null && mEndPoint!=null)
        {
            startRoutrPlan(CMD_ROUTE_PLAN,mStartPoint,mEndPoint,null);
        }
    }

    public void addPassPoint(GeoPoint p)
    {
        RoutePlanParam rpm=(RoutePlanParam)getObject(RoutePlanParam.class.getCanonicalName());
        if(rpm!=null) {
            rpm.addPassPoint(p);
            Log.e(this.getClass().getCanonicalName(),"Add Pass Point "+p.getLongitudeE6()+" "+p.getLatitudeE6());
        }
    }





    public void startRoutrPlan(String sCms,GeoPoint start,GeoPoint end,List<GeoPoint> lsPassPoints)
    {
        //GeoPoint ps = new GeoPoint((int)( mLat1), (int) (mLon1));
        //GeoPoint pe = new GeoPoint((int)( mLat2), (int) (mLon2));

        //添加途经点，最多可以添加5个途经点，此处举例添加2个
        //ArrayList<GeoPoint> pViaList = new ArrayList<GeoPoint>();
        //if(mViaLon != 0 && mViaLat != 0)
        //{
        //    GeoPoint pVia1 = new GeoPoint((int)( mViaLat), (int) (mViaLon));
        //    pViaList.add(pVia1);
        //}


        //if(!checkNetWork()) return;
        checkNetWork();



        MKRoute mRoute = new MKRoute();

        //if(pViaList.isEmpty() != true && pViaList.size() > 0)
        //{
        //    mRoute.customizeRoute(ps,pe,pViaList);
        //}
        //else
        //{
        if(lsPassPoints!=null && lsPassPoints.size()>0) {
            mRoute.customizeRoute(start, end, (ArrayList<GeoPoint>) lsPassPoints);
            Log.e(this.getClass().getCanonicalName(),"customizeRoute Pass Points "+lsPassPoints.size());
        }
        else mRoute.customizeRoute(start, end, null);
        //}

        //设置路线规划参数
        SettingManager cfg = SettingManager.getInstance();
        if(sCms.equals(CMD_ROUTE_PLAN_TIME))
            cfg.setRoutePlanParam(SettingManager.NAVIPLANTYPE_FASTESTTIME, false,SettingManager.NAVIPLANMODE_DRIVE);
        else if(sCms.equals(CMD_ROUTE_PLAN_HIGHWAY))
            cfg.setRoutePlanParam(SettingManager.NAVIPLANTYPE_HIGHPRIORITY, false,SettingManager.NAVIPLANMODE_DRIVE);
        else if(sCms.equals(CMD_ROUTE_PLAN_DISTANCE))
            cfg.setRoutePlanParam(SettingManager.NAVIPLANTYPE_SHORTESTDISTANCE, false,SettingManager.NAVIPLANMODE_DRIVE);
        else if(sCms.equals(CMD_ROUTE_PLAN_FREECHARGE))
            cfg.setRoutePlanParam(SettingManager.NAVIPLANTYPE_STATEROADPRIORITY, false,SettingManager.NAVIPLANMODE_DRIVE);
        else {
            cfg.setRoutePlanParam(SettingManager.NAVIPLANTYPE_FASTESTTIME, false,SettingManager.NAVIPLANMODE_DRIVE);
            sCms=CMD_ROUTE_PLAN_TIME;
        }

        AppConfig c= Repository.getAppConfig("UserRouteType");
        if(c!=null) {
            c.setParamValue(sCms);
            c.save();
        }
        getNaviManager().setNaviSetPlanParamemter(cfg);


        getNaviManager().showRoute(mRoute);

        /*RoutePlanParam rpm=(RoutePlanParam)getObject(RoutePlanParam.class.getCanonicalName());
        if(rpm!=null)
        {
            if(sCms==null || sCms==CMD_ROUTE_PLAN) sCms=CMD_ROUTE_PLAN_TIME;
            rpm.setRouteType(sCms);
            rpm.setStartPoint(mStartPoint);
            rpm.setEndPoint(mEndPoint);
        }*/

    }




    @Override
    public void onRoutePlanListener(int notify, RoutePlanData routeinfo, int dwError) {
        //String str = null;
        if(routeinfo != null)
        {
            Log.e("navigation", routeinfo.toString());
            //str = "路程："+convertMeters(routeinfo.commonDistance)
            //        +",时间："+ convertTime(routeinfo.commonTime);
            //prompt.setText(str);

            mRoutePlanData=routeinfo;

        }

        switch(notify)
        {
            case NaviState.NAVI_NET_REQUEST:{
                Log.e("","CCCCCCCCCCAAA--callback 0");
                //网络请求开始
                //str = "状态：规划开始......";
                //textstate.setText(str);
                updateView(RET_ROUTE_PLAN_START);
            }
            break;
            case NaviState.NAVI_NET_FINISH:{
                //网络请求结束
                //str = "状态：规划结束";
                //textstate.setText(str);
                updateView(RET_ROUTE_PLAN_FINISH);
            }
            break;
            case NaviState.NAVI_ERROR:{
                //error
                //str = "状态：error";
                //textstate.setText(str);
                updateView(RET_ROUTE_PLAN_FAIL);
            }
            break;
            case NaviState.NAVI_ROUTEPLAN_FINISH:{
                //error
                //str = "状态：规划成功";
                //textstate.setText(str);
                updateView(RET_ROUTE_PLAN_SUCCESS);
            }
            break;
            default:{
                //str = "状态：其他状态";
                //textstate.setText(str);
            }
        }

    }
}