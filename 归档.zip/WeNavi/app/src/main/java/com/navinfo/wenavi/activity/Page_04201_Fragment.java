package com.navinfo.wenavi.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.navinfo.wenavi.R;
import com.navinfo.wenavi.controller.Page_04201_Controller;
import com.navinfo.wenavi.controller.RouteController;
import com.navinfo.wenavi.entity.NaviDesitination;
import com.navinfo.wenavi.entity.NaviHistory;
import com.navinfo.wenavi.model.Page_04201_ListAdapter;
import com.navinfo.wenavi.model.WeNaviInternalMessage;
import com.navinfo.wenavi.util.WeNaviDefine;

import java.util.List;

/**
 * 导航记录.
 */
public class Page_04201_Fragment extends WeNaviBaseFragment implements Page_04201_ListAdapter.onItemListClickListener {

    private static final int HISTORY_TYPE = 0;
    private static final int COMMON_TYPE = 1;

    private final static String LOG_TAG = Page_04201_Fragment.class.getCanonicalName();

    private ListView mCommonListCtrl = null;
    private ListView mHistoryListCtrl = null;
    private Page_04201_ListAdapter mPage_04201_ListAdapter = null;

    private Button mBtnCommon = null;
    private Button mBtnHistory = null;
    private Button mBtnDel = null;
    private Button mBtnAdd = null;
    private Button mBtnBack = null;
    private Button mBtnNavi = null;
    private TextView mLastNavigationText = null;

    private List<NaviDesitination> mCommonList = null;
    private List<NaviHistory> mHistoryList  = null;
    private int mType = 0;


    @Override
    public boolean onHandlerMessage(Message msg) {
        return super.onHandlerMessage(msg);
    }

    @Override
    public void onSetListAdaptor() {
        delayOnResume();
    }

    @Override
    public void onRemoveListAdaptor() {
        mHistoryListCtrl.setAdapter(null);
        mCommonListCtrl.setAdapter(null);
    }

    @Override
    public void onResume() {
        super.onResume();

        Bundle c = getArguments();
        if (c != null) {
            WeNaviInternalMessage m=new WeNaviInternalMessage(c);

            if (m !=null) {
                NaviDesitination des= new NaviDesitination();
                des.setTitle(m.getTitle());
                des.setIdSearchKey(m.getIdSearchKey());
                des.setLongitude(m.getLongitude());
                des.setLatitude(m.getLatitude());
                des.setLocation(m.getLocation());
                des.setAddTime(m.getAddTime());

                updateCommonList(des);

            }
        }


        submitAction(Page_04201_Controller.CMD_GET_ALL_HISTORY);
        submitAction(Page_04201_Controller.CMD_GET_ALL_DES);
    }

    @Override
    public void onActionUpdate(Object... datas) {
        if(datas.length>0) {
            if (datas[0].getClass().getCanonicalName() == String.class.getCanonicalName()) {
                String sCms = (String) (datas[0]);

                if(sCms.equals(Page_04201_Controller.RET_ALL_DES)) {
                    List<NaviDesitination> list = (List<NaviDesitination>) datas[1];
                    //数据刷新
                    if(null != list  && list.size()>0){
                        for (NaviDesitination temp :list){
                            Log.d("04201","commonlist"+temp.getLocation()+","+temp.getTitle());
                        }
                        mCommonList = list;
                        if (mType ==COMMON_TYPE){
                            refreshList();
                        }
                    }
                }
                else if (sCms.equals(Page_04201_Controller.RET_ALL_HISTORY)) {
                    List<NaviHistory> list = (List<NaviHistory>) datas[1];
                    //数据刷新
                    if (null != list && list.size() > 0) {
                        mHistoryList = list;
                        if (mType == HISTORY_TYPE) {
                            refreshList();
                        }
                        if (mHistoryList != null && mHistoryList.size() > 0) {
                            mLastNavigationText.setText(mHistoryList.get(0).getStartLocation());
                        } else {
                            mLastNavigationText.setText("");
                        }
                    }
                }
                else super.onActionUpdate(datas);

            }
        }


    }

    @Override
    protected String getControllerName() {
        return Page_04201_Controller.class.getCanonicalName();
    }

    @Override
    public void restoreViewStatus(Bundle status) {

    }

    @Override
    public Bundle getViewStatus() {
        return null;
    }


    @Override
    protected int getFragmentLayoutID() {
        return R.layout.page_04201;
    }


    /**
     * 初始化控件为不可用,页面初始化时调用
     */
    @Override
    public  void onDisableControl()
    {
        mBtnBack.setEnabled(false);

    }

    /**
     * 初始化控件为可用,页面初始化完成后被延时调用
     */
    @Override
    public  void onEnableControl()
    {
        mBtnBack.setEnabled(true);

    }

    @Override
    protected void bindUIControl(View v) {
        mBtnNavi = (Button)v.findViewById(R.id.btn_navi_back);
        mBtnAdd = (Button)v.findViewById(R.id.btn_add);
        mBtnDel  = (Button)v.findViewById(R.id.btn_del);
        mBtnBack  = (Button)v.findViewById(R.id.btn_back);
        mBtnCommon = (Button)v.findViewById(R.id.btn_common);
        mBtnHistory = (Button)v.findViewById(R.id.btn_history);
        mLastNavigationText = (TextView)v.findViewById(R.id.textView);

        mBtnNavi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mHistoryList != null && mHistoryList.size()>0){
                    toNavi(mHistoryList.get(0), true);
                }

            }
        });

        mBtnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null == mCommonList){
                    return;
                }
                if (mCommonList.size() > 1 && mCommonList.size() < 5){
                    NaviDesitination a = new NaviDesitination();
                    a.setTitle("常用地址" + (mCommonList.size() - 1));
                    a.setLocation("请编辑地址");
                    submitAction(Page_04201_Controller.CMD_ADD_A_DES, a);
                    mCommonList.add(a);
                    refreshList();
                }else{
                    showInfoamtion("提示","最多添加3条自定义地址!", null);
                }
            }
        });

        mBtnDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showConfirm("提示", "您确认要删除所有历史记录么?",new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(which!=0) return;
                        //删除所有历史纪录
                        submitAction(Page_04201_Controller.CMD_DEL_ALL_HISTORY);
                        if (mHistoryList != null){
                            mHistoryList.clear();
                            refreshList();
                        }
                        mLastNavigationText.setText("");

                    }
                });
            }
        });

        mBtnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBack();
            }
        });


        mBtnCommon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeListState(COMMON_TYPE);
                refreshList();
            }
        });

        mBtnHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeListState(HISTORY_TYPE);
                refreshList();
            }
        });

        mHistoryListCtrl = (ListView) v.findViewById(R.id.history_list);

        //常用列表
        mCommonListCtrl = (ListView) v.findViewById(R.id.common_list);

        changeListState(COMMON_TYPE);
    }

    private void refreshList(){
        switch (mType)
        {
            case COMMON_TYPE:
            {
                if(mCommonList!=null) {
                    mPage_04201_ListAdapter.setCommonList(mCommonList);
                    mPage_04201_ListAdapter.getCommonListAdapter().notifyDataSetChanged();
                }
            }
            break;
            case HISTORY_TYPE:
            {
                if(mHistoryList!=null) {
                    mPage_04201_ListAdapter.setHistoryList(mHistoryList);
                    mPage_04201_ListAdapter.getHistoryListAdapter().notifyDataSetChanged();
                }
            }
            break;
            default:
                break;
        }
    }


    private void changeListState(int type){
        mType = type;
        switch (type)
        {
            case COMMON_TYPE:
            {
                mCommonListCtrl.setVisibility(View.VISIBLE);
                mHistoryListCtrl.setVisibility(View.INVISIBLE);
                mBtnDel.setVisibility(View.INVISIBLE);
                mBtnAdd.setVisibility(View.VISIBLE);

                mBtnCommon.setFocusable(true);
                mBtnCommon.setFocusableInTouchMode(true);
                mBtnCommon.requestFocus();
                mBtnCommon.requestFocusFromTouch();

                mBtnHistory.setFocusable(false);
                mBtnHistory.setFocusableInTouchMode(false);
                mBtnHistory.requestFocus();
                mBtnHistory.requestFocusFromTouch();
            }
            break;
            case HISTORY_TYPE:
            {
                mHistoryListCtrl.setVisibility(View.VISIBLE);
                mCommonListCtrl.setVisibility(View.INVISIBLE);
                mBtnDel.setVisibility(View.VISIBLE);
                mBtnAdd.setVisibility(View.INVISIBLE);
                //设按钮焦点
                mBtnCommon.setFocusable(false);
                mBtnCommon.setFocusableInTouchMode(false);
                mBtnCommon.requestFocus();
                mBtnCommon.requestFocusFromTouch();

                mBtnHistory.setFocusable(true);
                mBtnHistory.setFocusableInTouchMode(true);
                mBtnHistory.requestFocus();
                mBtnHistory.requestFocusFromTouch();
            }
            break;
            default:
                break;
        }
    }


    void delayOnResume()
    {
        mPage_04201_ListAdapter = (Page_04201_ListAdapter) getController().
                getObject(Page_04201_ListAdapter.class.getCanonicalName() );
        mPage_04201_ListAdapter.setListener(this);
        //历史纪录列表
        //mHistoryListCtrl = (ListView) v.findViewById(R.id.history_list);
        mHistoryListCtrl.setAdapter(mPage_04201_ListAdapter.getHistoryListAdapter());
        //常用列表
        //mCommonListCtrl = (ListView) v.findViewById(R.id.common_list);
        mCommonListCtrl.setAdapter(mPage_04201_ListAdapter.getCommonListAdapter());


    }



    @Override
    public void onClick(int type, final int index, int event) {
           if (type == 0){
               //历史纪录
               if (event == 0){
                   //点击item
                   toNavi(mHistoryList.get(index-1), false);
               }else{
                   //点击删除按钮
                   showConfirm("提示","您确认要删除这条记录么?",new DialogInterface.OnClickListener() {
                       @Override
                       public void onClick(DialogInterface dialog, int which) {
                           if(which!=0) return;
                           //删除一条纪录
                           submitAction(Page_04201_Controller.CMD_DEL_A_HISTORY,mHistoryList.get(index-1).getMyId());
                           mHistoryList.remove(index - 1);
                           mPage_04201_ListAdapter.getHistoryListAdapter().notifyDataSetChanged();
                           if(mHistoryList != null && mHistoryList.size() > 0){
                               mLastNavigationText.setText(mHistoryList.get(0).getStartLocation());
                           }else{
                               mLastNavigationText.setText("");
                           }
                       }
                   });
               }
           }else{
               //常用列表
               if (event == 0){
                   //点击item
                   if (mCommonList.get(index).getLongitude() == 0 || mCommonList.get(index).getLatitude() == 0){
                       toSearchPage(mCommonList.get(index));
                       return;
                   }
                   NaviHistory h=new NaviHistory();
                   h.setRouteType(RouteController.CMD_ROUTE_PLAN_TIME);
                   h.setLongitudeEnd(mCommonList.get(index).getLongitude());
                   h.setLatitudeEnd(mCommonList.get(index).getLatitude());
                   toNavi(h , false);
               }else{
                   //点击编辑按钮
                   Log.e("ccc","onClick common"+index);

                   toSearchPage(mCommonList.get(index));
               }
           }
    }

    private void toSearchPage(NaviDesitination des){
        WeNaviInternalMessage m=new WeNaviInternalMessage(
                Page_04201_Fragment.this.getClass(),
                Page_02201_Fragment.class,
                WeNaviDefine.MSG_REQUEST_LOCATION,
                null);
        m.setTitle(des.getTitle());
        m.setAddTime(des.getAddTime());
        m.setIdSearchKey(des.getIdSearchKey());

        toBranchPage(Page_02201_Fragment.class, m.toBundle());
    }

    private void toNavi(NaviHistory h, boolean back){
        if ( back ){
            if (h.getLatitudeStart() == 0 || h.getLongitudeStart() == 0){
                return;
            }

            WeNaviInternalMessage m=new WeNaviInternalMessage(
                    Page_04201_Fragment.this.getClass(),
                    Page_02402_Fragment.class,
                    WeNaviDefine.MSG_REQUEST_LOCATION,
                    null);

            m.setLongitude(h.getLongitudeStart());
            m.setLatitude(h.getLatitudeStart());
            m.setTitle(h.getRouteType());
            toPage(Page_02402_Fragment.class, m.toBundle());

        }else{
            if (h.getLatitudeEnd() == 0 || h.getLongitudeEnd() == 0){

                return;
            }

            WeNaviInternalMessage m=new WeNaviInternalMessage(
                    Page_04201_Fragment.this.getClass(),
                    Page_02402_Fragment.class,
                    WeNaviDefine.MSG_REQUEST_LOCATION,
                    null);

            m.setLongitude(h.getLongitudeEnd());
            m.setLatitude(h.getLatitudeEnd());
            m.setTitle(h.getRouteType());
            toPage(Page_02402_Fragment.class, m.toBundle());
        }

    }

    private void updateCommonList(NaviDesitination des){
        submitAction(Page_04201_Controller.CMD_ADD_A_DES, des);
    }
}
