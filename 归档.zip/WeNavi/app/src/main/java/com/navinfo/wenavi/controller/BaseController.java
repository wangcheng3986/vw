package com.navinfo.wenavi.controller;

import android.content.Context;
import android.os.Bundle;

import com.navinfo.wenavi.activity.IView;
import com.navinfo.wenavi.model.IModel;
import com.navinfo.wenavi.model.WeNaviApplication;
import com.navinfo.wenavi.util.NetWork;

/**
 * Created by Doone on 2015/2/4.
 * 控制器抽象基类
 */
public abstract class BaseController implements IController {

    protected WeNaviApplication mContext=null;
    protected IView mCurrentView=null;
    private IModel mDefaultModel=null;
    private Bundle mViewStatusBundle=null;


    /**
     * 功能代码: 保存视图状态，附带参数Bundle
     */
    public static final String CMD_SAVE_VIEW_STATUS="CMD_SAVE_VIEW_STATUS";


    public static final String CMD_IS_NEWWORK_ENABLED="CMD_IS_NEWWORK_ENABLED";


    /**
     * 视图刷新代码: 恢复视图状态 附带 Bundle
     */
    public static final String RET_RESTORE_VIEW_STATUS="RET_RESTORE_VIEW_STATUS";


    /**
     * 视图刷新代码: 错误信息， 附带 Error String对象
     */
    public static final String RET_ERROR="RET_ERROR";



    /**
     * 视图刷新代码: 状态信息， 附带 status String对象
     */
    public static final String RET_STARUS="RET_STARUS";



    public static final String RET_NEWWORK_DISABLED="RET_NEWWORK_DISABLED";


    private boolean mCanUpdateView=false;

    public BaseController(Context context)
    {
        mContext=(WeNaviApplication)context;

    }

    /**
     * 更新IView
     * @param datas 需更新数据
     */
    @Override
    public void updateView(Object... datas) {
        if(!mCanUpdateView) return;
        if(mCurrentView!=null)
        {
            mCurrentView.onActionUpdate(datas);
        }
    }

    public boolean checkNetWork(){
        boolean b=NetWork.isConnected(mContext);
        if(!b){
            updateView(RET_NEWWORK_DISABLED);
        }

        return b;
    }



    protected WeNaviApplication getContext()
    {
        return mContext;
    }


    /**
     * 返回Controller 缺省需要的IModel 类全名
     * @return IModel 类全名
     */
    @Override
    public abstract String getDefaultModelName();


    /**
     * 如果Controller 缺省需要的IModel 类全名不为空将尝试获取该类实例并返回
     * @return IModel 对象
     */
    @Override
    public IModel getDefaultModel()
    {
        if(mDefaultModel==null) {
            String sModel = getDefaultModelName();
            if (sModel != null && sModel.length() > 0) {
                mDefaultModel = mContext.getModel(sModel);
            }
        }
        return mDefaultModel;
    }


    @Override
    public Object getObject(String sName)
    {
        IModel m=getDefaultModel();
        if(m!=null) return m.getObject(sName);
        return null;
    }

    @Override
    public IView getView()
    {
        return mCurrentView;
    }


    /**
     * IView Restart 时由IView调用
     */
    @Override
    public void onViewRestart()
    {

    }


    /**
     * IView Start 时由IView调用
     */
    @Override
    public void onViewStart()
    {
        mCanUpdateView=true;
        if(mViewStatusBundle!=null) updateView(RET_RESTORE_VIEW_STATUS,mViewStatusBundle);
    }


    @Override
    public void onViewPause() {
        mCanUpdateView=false;
    }

    @Override
    public void onViewResume() {

    }


    /**
     * IView Stop 时由IView调用
     */
    @Override
    public void onViewStop()
    {

    }

    @Override
    public void onViewDestroy() {

    }

    @Override
    public void onViewBack() {

    }

    @Override
    public void attachView(IView v) {
        dettachView();
        mCurrentView=v;
        v.setController(this);
    }

    @Override
    public void dettachView() {
        if(mCurrentView!=null) {
            mCurrentView.setController(null);
            mCurrentView = null;
        }

    }

    @Override
    public void destroy() {

    }

    @Override
    public  void executeAction(Object... actionDatas)
    {

        if(actionDatas.length>0) {
            if (actionDatas[0].getClass().getCanonicalName().equals(String.class.getCanonicalName())) {
                String sCms = (String) (actionDatas[0]);
                if (sCms.equals(CMD_SAVE_VIEW_STATUS) && actionDatas.length>1) saveViewStatus((Bundle)actionDatas[1]);
                else if(sCms.equals(CMD_IS_NEWWORK_ENABLED)){
                    checkNetWork();
                }

            }
        }

    }


    public void saveViewStatus(Bundle status)
    {
        mViewStatusBundle=status;
    }
}
