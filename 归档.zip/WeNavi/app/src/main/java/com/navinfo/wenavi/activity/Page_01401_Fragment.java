package com.navinfo.wenavi.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.navinfo.sdk.mapapi.map.ItemizedOverlay;
import com.navinfo.sdk.mapapi.map.LocationData;
import com.navinfo.sdk.mapapi.map.MapView;
import com.navinfo.sdk.mapapi.map.OverlayItem;
import com.navinfo.sdk.mapapi.map.PopupClickListener;
import com.navinfo.sdk.mapapi.map.PopupOverlay;
import com.navinfo.sdk.mapapi.search.core.POIInfo;
import com.navinfo.sdk.mapapi.search.poi.POISearchResult;
import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.controller.BaseController;
import com.navinfo.wenavi.controller.GisController;
import com.navinfo.wenavi.controller.IController;
import com.navinfo.wenavi.controller.MapViewController;
import com.navinfo.wenavi.controller.Page_01401_Controller;
import com.navinfo.wenavi.controller.RouteController;
import com.navinfo.wenavi.model.IMessage;
import com.navinfo.wenavi.model.PoiListAdapter;
import com.navinfo.wenavi.entity.PoiSearchParam;
import com.navinfo.wenavi.entity.RoutePlanParam;
import com.navinfo.wenavi.model.PoiTypeAdapter;
import com.navinfo.wenavi.model.WeNaviInternalMessage;
import com.navinfo.wenavi.util.NIMapUtil;
import com.navinfo.wenavi.util.WeNaviDefine;
import com.navinfo.wenavi.util.WeNaviUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Handler;

/**
 * Created by Doone on 2015/3/17.
 * 关键字搜索结果
 */
public class Page_01401_Fragment extends WeNaviBaseFragment implements PoiListAdapter.IPoiListViewInteractor {

    public final static int PAGE_ROWS=10;
    public final static int DEFAULT_RADIUS=15000;

    Button mBtBack = null;
    Button mBtGo = null;

    Button mBtCurrentLoc = null;
    MapView mMapView = null;
    ImageButton mBtCenter = null;
    ListView resultList = null;
    TextView mEtSearch;
    TextView mPage=null;
    Button btZoomin = null;
    Button btZoomout = null;
    ImageButton btCompass = null;
    ToggleButton btTraffic = null;
    MapScaler ctMapScaler = null;


    private TextView tvAddress;
    private Button btScope;
    //默认距离
    private int scope = 0;
    //触摸存储
    private List<Float> list = new ArrayList<Float>();
    //翻页拉动像素条件
    private final int pullSizi = 66;
    private boolean toTop = false;
    private boolean toEnd = false;
    private boolean tFlag = true;
    private int startY;
    private int endY;

    private static final String LOG_TAG = Page_01401_Fragment.class.getCanonicalName();

    public Page_01401_Fragment() {
    }

    @Override
    protected String getControllerName() {
        return Page_01401_Controller.class.getCanonicalName();
    }

    @Override
    public void restoreViewStatus(Bundle status) {

    }

    @Override
    public Bundle getViewStatus() {
        return null;
    }

    @Override
    protected int getFragmentLayoutID() {
        return R.layout.page_01401;
    }


    IMessage requestLocationMessg = null;

    /**
     * 当UI处于分支中时，该回掉在UI resume时调用
     */
    @Override
    public void onUiBranch() {
        index = -1;
        mBtGo.setText(R.string.action_settings);
        mBtGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Page_02301_Fragment.this.startRoute();
                //toRootPage();

                //if (tapPoint == null) return;
                //得到poi点坐标
                if (  tapPoint == null) {
                    showInfoamtion("提示", "请选择目标地点", null);
                    return;
                }
                if (requestLocationMessg != null) {
                    GeoPoint end = mMapView.getMapCenter();

                    //Page_01401_Fragment.this.tap
                    ((WeNaviInternalMessage) requestLocationMessg).setReceiver(requestLocationMessg.getSender());
                    ((WeNaviInternalMessage) requestLocationMessg).setSender(Page_01401_Fragment.this.getClass().getCanonicalName());
                    ((WeNaviInternalMessage) requestLocationMessg).setLongitude(tapPoint.getLongitudeE6());
                    ((WeNaviInternalMessage) requestLocationMessg).setLatitude(tapPoint.getLatitudeE6());

                    StringBuilder sb=new StringBuilder();
                    if(mItemAddress!=null && mItemAddress.length()>0) sb.append(mItemAddress);
                    if(mItemName !=null && mItemName.length()>0)
                    {
                        if(sb.length()>0) sb.append(",");
                        sb.append(mItemName);
                    }

                    ((WeNaviInternalMessage) requestLocationMessg).setLocation(sb.toString());


                    toRootPage(requestLocationMessg.toBundle());
                } else toRootPage();

            }
        });
    }

    PoiListAdapter adapter;

    @Override
    public void onSetListAdaptor() {
        //resultList
        adapter = (PoiListAdapter) getController().
                getObject(PoiListAdapter.class.getCanonicalName() + "_Keyword");//new POIListAdapter(getActivity(),list);
        adapter.setContext(this.getActivity());
        adapter.setPoiListViewInteractor(this);

        setListAdapter(adapter);
    }

    @Override
    public void onRemoveListAdaptor() {
        setListAdapter(null);
    }


    ListView getListView()
    {
        return  resultList;
    }

    void setListAdapter(ListAdapter d)
    {
        getListView().setAdapter(d);
    }


    /**
     * 初始化控件为不可用,页面初始化时调用
     */
    @Override
    public  void onDisableControl()
    {
        mBtBack.setEnabled(false);
        mBtGo.setEnabled(false);

    }

    /**
     * 初始化控件为可用,页面初始化完成后被延时调用
     */
    @Override
    public  void onEnableControl()
    {
        mBtBack.setEnabled(true);
        mBtGo.setEnabled(true);
    }

    @Override
    protected void bindUIControl(View v) {
        Resources res = Page_01401_Fragment.this.getActivity().getResources();
        //drawableTap = res.getDrawable(R.drawable.ui_01401_1_map_points_big);
        mEtSearch = (TextView) v.findViewById(R.id.txtKeyWord);
        mEtSearch.setText("");
        mPage=(TextView)v.findViewById(R.id.txtPage);
        mBtBack = (Button) v.findViewById(R.id.btBack);
        mBtGo = (Button) v.findViewById(R.id.btGo);

        mBtCurrentLoc = (Button) v.findViewById(R.id.btCurrentLoc);

        resultList = (ListView)v.findViewById(android.R.id.list);//getListView();// v.findViewById(R.id.resultList);

        btZoomin = (Button) v.findViewById(R.id.btMapZoomin);
        btZoomout = (Button) v.findViewById(R.id.btMapZoomout);
        btCompass = (ImageButton) v.findViewById(R.id.btCompass);
        btTraffic = (ToggleButton) v.findViewById(R.id.btMapTraffic);

        ctMapScaler = (MapScaler) v.findViewById(R.id.ctMapScaler);

        tvAddress = (TextView) v.findViewById(R.id.tv_ui01401_address);
        btScope = (Button) v.findViewById(R.id.btn_01401_1_set_scope);

        IController c = getController();
        if (c != null) {
            mMapView = (MapView) c.getObject(MapView.class.getCanonicalName()); // findViewById(R.id.mpView);

            if (mMapView != null) {
                FrameLayout l = (FrameLayout) v.findViewById(R.id.mapframe);
                if (mMapView.getParent() != null) {
                    FrameLayout fv = (FrameLayout) mMapView.getParent();
                    if (fv != l) {
                        fv.removeAllViews();
                        l.addView(mMapView);
                    }
                } else
                    l.addView(mMapView);

            }
        }

        btScope.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                setScope();
                //默认中间值15km
                String defautScope = "1";
                if (scope == 5000) {
                    defautScope = "0";
                } else if (scope == 15000) {
                    defautScope = "1";
                } else if (scope == 25000) {
                    defautScope = "2";
                } else if (scope == 50000) {
                    defautScope = "3";
                } else if (scope == 0) {
                    defautScope = "4";
                }
                WeNaviAlertDialog dlg = new WeNaviAlertDialog((WeNaviBaseActivity) Page_01401_Fragment.this.getActivity());
                dlg.showSetScope(defautScope, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                        switch (which) {
                            case 0:
                                scope = 5000;
                                break;
                            case 1:
                                scope = 15000;
                                break;
                            case 2:
                                scope = 25000;
                                break;
                            case 3:
                                scope = 50000;
                                break;
                            case 4:
                                scope = 0;
                                break;

                        }

                        updateRadiusButton(scope);

                        //scope = Integer.parseInt(num);// * 1000;

                        PoiSearchParam poi=(PoiSearchParam) getController().getObject(PoiSearchParam.class.getCanonicalName());
                        if(poi!=null) {
                            poi.setRadius(scope);
                            poi.setPageIndex(1);
                            poi.setPageRows(PAGE_ROWS);
                            tvAddress.setVisibility(View.INVISIBLE);
                            submitAction(Page_01401_Controller.CMD_SEARCH_POI, poi);

                        }

                        //submitAction(Page_01401_Controller.CMD_SEARCH_POI, sType, scope, sKeyWord, 10, 1);

                    }
                });


            }
        });

        mBtBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBack();

            }
        });

        mBtGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(Page_0102_Activity.this.getApplicationContext(),
                //       String.format("mBtGo clicked"), Toast.LENGTH_LONG).show();
                //submitAction(NaviController.CMD_ROUTE_PLAN);

                Page_01401_Fragment.this.startRoute();

            }
        });

        resultList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                Log.d(LOG_TAG, "count=" + view.getCount());
                Log.d(LOG_TAG, "getLastVisiblePosition=" + view.getLastVisiblePosition());
                Log.d(LOG_TAG, "getFirstVisiblePosition=" + view.getFirstVisiblePosition());
                switch (scrollState) {
                    case AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:
                        break;
                    case AbsListView.OnScrollListener.SCROLL_STATE_IDLE:

                        if (view.getFirstVisiblePosition() >= 4) {
                            toEnd = true;
                        } else {
                            toEnd = false;
                        }
                        if (view.getFirstVisiblePosition() == 0) {
                            toTop = true;
                        } else {
                            toTop = false;
                        }

                        break;
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });

        resultList.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent ev) {
                if (tFlag) {
                    list.clear();
                }
                list.add(ev.getY());

                switch (ev.getAction()) {
                    case MotionEvent.ACTION_DOWN:

                        break;
                    case MotionEvent.ACTION_CANCEL:
                    case MotionEvent.ACTION_UP:
                        tFlag = true;
                        endY = (int) ev.getY();
                        float d = list.get(list.size() - 1) - list.get(0);
                        Log.d(LOG_TAG, "d=" + d);
                        if (d > pullSizi) {
                            //下拉
                            if (toTop) {
                                if (curPage > 1) {

                                curPage = curPage - 1;
                                PoiSearchParam poi=(PoiSearchParam) getController().getObject(PoiSearchParam.class.getCanonicalName());
                                if(poi!=null) {

                                    poi.setPageIndex(curPage);
                                    poi.setPageRows(PAGE_ROWS);
                                    tvAddress.setVisibility(View.INVISIBLE);
                                    submitAction(Page_01401_Controller.CMD_SEARCH_POI,poi);

                                    }
                                    //submitAction(Page_01401_Controller.CMD_SEARCH_POI, sType, scope, sKeyWord, 5, curPage);
                                }
                            }
                        }
                        if (d < -pullSizi) {
                            //上啦
                            if (toEnd) {


                                if (curPage < totalPage) {

                                    curPage = curPage + 1;

                                    PoiSearchParam poi = (PoiSearchParam) getController().getObject(PoiSearchParam.class.getCanonicalName());
                                    if (poi != null) {

                                        poi.setPageIndex(curPage);
                                        poi.setPageRows(PAGE_ROWS);
                                        submitAction(Page_01401_Controller.CMD_SEARCH_POI, poi);

                                    }
                                    //submitAction(Page_01401_Controller.CMD_SEARCH_POI, sType, scope, sKeyWord, 5, curPage);
                                }
                            }

                        }
                        break;
                    case MotionEvent.ACTION_MOVE:

                        tFlag = false;

                        break;
                }
                return false;
            }
        });
        //initOverlay();

    }


    private void updateRadiusButton(int radius) {
        String num = "";
        if (radius < 1000) num = String.format("%.0f", scope / 1000f);
        else num = String.format("%d", scope / 1000);

        if (num.equals("0")) {
            btScope.setTextSize(20);
            num = "全市";
        }else {
            btScope.setTextSize(33);
        }
        btScope.setText(num);
    }


    private void setScope() {
        //弹出框
        final AlertDialog dlg = new AlertDialog.Builder(this.getActivity()).create();
        dlg.show();
        Window window = dlg.getWindow();

        window.setContentView(R.layout.dialog_scope);
        final ViewGroup root = (ViewGroup) window.findViewById(R.id.layoutroot);
        if (root != null)
            WeNaviUtil.updateUiTextSize((WeNaviBaseActivity) this.getActivity(), root);

//        TextView title=(TextView)window.findViewById(R.id.txtTitle);
//        title.setText(sTitle);
//
//        TextView message=(TextView)window.findViewById(R.id.txtMessage);
//        message.setText(sMessage);


        String k = "km";

        StringBuilder builder = new StringBuilder();
        builder.append(k);
        builder.append("  ");

        btScope.setText(builder.toString());
    }


    void startRoute() {
        GeoPoint start = mMapView.getMapCenter();
        LocationData loc = (LocationData) getController().getObject(LocationData.class.getCanonicalName());//getLocationData();
        if (loc != null && loc.pt != null) start = loc.pt;

        //得到poi点坐标
        if (  tapPoint == null) {
            showInfoamtion("提示", "请选择目标地点", null);
            return;
        }


        RoutePlanParam rpm = (RoutePlanParam) getController().getObject(RoutePlanParam.class.getCanonicalName());
        if (rpm != null) {
            rpm.reset();
            rpm.setStartPoint(start);
            rpm.setEndPoint(tapPoint);

            StringBuilder sb=new StringBuilder();
            if(mItemAddress!=null && mItemAddress.length()>0) sb.append(mItemAddress);
            if(mItemName !=null && mItemName.length()>0)
            {
                if(sb.length()>0) sb.append(",");
                sb.append(mItemName);
            }

            if(sb.length()>0) rpm.setEndLaocation(sb.toString());

            rpm.setRouteType(RouteController.CMD_ROUTE_PLAN);
        }

        toPage(Page_02402_Fragment.class);

    }




    @Override
    public void onPause() {



        isListNull=true;
        super.onPause();

    }

    @Override
    public void onStop() {

        //软键盘关闭
//        InputMethodManager methodManager = (InputMethodManager) this.getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
//        methodManager.hideSoftInputFromWindow(mEtSearch.getWindowToken(),0);

        super.onStop();
    }

    String sType = null;
    String sKeyWord = null;
    private int curPage = 1;

    @Override
    public void onResume() {

        super.onResume();

        showPoiList(null);

        if (mMapView != null) {
            FrameLayout l = (FrameLayout) getView().findViewById(R.id.mapframe);
            if (mMapView.getParent() != null) {
                FrameLayout v = (FrameLayout) mMapView.getParent();
                if (v != l) {
                    v.removeAllViews();
                    l.addView(mMapView);
                }
            }
        }

        tvAddress.setVisibility(View.INVISIBLE);

        submitAction(MapViewController.CMD_BIND_COMPASS, btCompass);
        submitAction(MapViewController.CMD_BIND_MAPSCALER, ctMapScaler);
        submitAction(MapViewController.CMD_BIND_ZOOMIN, btZoomin);
        submitAction(MapViewController.CMD_BIND_ZOOMOUT, btZoomout);
        submitAction(MapViewController.CMD_BIND_TRAFFIC, btTraffic);
        submitAction(MapViewController.CMD_BIND_CURLOC, mBtCurrentLoc);



        submitAction(MapViewController.CMD_NORTH_MAP);
        LocationData loc=(LocationData) getController().getObject(LocationData.class.getCanonicalName());
        if(loc!=null && loc.pt!=null) submitAction(MapViewController.CMD_SET_MAP_CENTER, loc.pt);



        requestLocationMessg=null;

        Bundle arg=getArguments();
        if(arg!=null)
        {
            requestLocationMessg=new WeNaviInternalMessage(arg);
            if(requestLocationMessg.getMessageType().equals(WeNaviDefine.MSG_SEARCH_POI_BY_KEYWORD)||
                    requestLocationMessg.getMessageType().equals(WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME)||
            requestLocationMessg.getMessageType().equals(WeNaviDefine.MSG_SEARCH_POI_BY_KIND_CODE))
            {

                PoiSearchParam poi=(PoiSearchParam) getController().getObject(PoiSearchParam.class.getCanonicalName());
                if(poi!=null)
                {
                    if(requestLocationMessg.getMessageType().equals(WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME )||
                            requestLocationMessg.getMessageType().equals(WeNaviDefine.MSG_SEARCH_POI_BY_KIND_CODE)) {
                        if(scope==0) scope=DEFAULT_RADIUS;
                    }
                    else
                        scope=0;


                    poi.reset();
                    poi.setSearchType(requestLocationMessg.getMessageType());
                    poi.setKeyword(((WeNaviInternalMessage) requestLocationMessg).getKeyword());
                    poi.setKindName(((WeNaviInternalMessage) requestLocationMessg).getKeyword());
                    poi.setPageIndex(1);
                    poi.setPageRows(PAGE_ROWS);
                    poi.setRadius(scope);
                    poi.setRegion(((WeNaviInternalMessage)requestLocationMessg).getCityCode());

                }

            }
        }

        //if()
        PoiSearchParam poi=(PoiSearchParam) getController().getObject(PoiSearchParam.class.getCanonicalName());
        if(poi!=null) {
            //当前时刻可能没有位置，如果没有位置，列表不为空不发请求
            if (isListNull) {
                //num=String.format("%.0f",scope/1000f);

                scope=poi.getRadius();

                updateRadiusButton(scope);

                if (poi.getSearchType() == WeNaviDefine.MSG_SEARCH_POI_BY_KEYWORD)
                    mEtSearch.setText(poi.getKeyword());
                else if (poi.getSearchType() == WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME ||
                        poi.getSearchType() == WeNaviDefine.MSG_SEARCH_POI_BY_KIND_CODE)
                    mEtSearch.setText(poi.getKindName());


                Object pm = getParameters();
                if(pm !=null ) {
                    POISearchResult r=(POISearchResult)pm;
                    totalPage = (r.total / Page_01401_Fragment.PAGE_ROWS);
                     if(r.total % Page_01401_Fragment.PAGE_ROWS>0)  totalPage+=1;
                    poiInfoList = r.pois;
                    messageHandler.sendEmptyMessageDelayed(11,500);
//                    showPoi(r.pois);


                    setParameters(null);
                }
                else {

                    submitAction(Page_01401_Controller.CMD_SEARCH_POI, poi);

                }
            }

        }
        //清除选中
        if(adapter!=null){
            adapter.setSelected(-1);
        }


    }


    private void showPoi(List<POIInfo> list){
        if(null!=list){

            hidePopMessage();
            PoiSearchParam poi=(PoiSearchParam) getController().getObject(PoiSearchParam.class.getCanonicalName());
            if(poi!=null) {
                String sMsg =  poi.getPageIndex()+"/" + totalPage;
                mPage.setText(sMsg);


                if (poi.getSearchType() == WeNaviDefine.MSG_SEARCH_POI_BY_KEYWORD)
                    mEtSearch.setText(poi.getKeyword());
                else if (poi.getSearchType() == WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME||
                        poi.getSearchType() == WeNaviDefine.MSG_SEARCH_POI_BY_KIND_CODE)
                    mEtSearch.setText(poi.getKindName());

            }
            showPoiList(list);
            mCurItem=null;
            tvAddress.setVisibility(View.INVISIBLE);
            //showPoiOverlay(list);
            submitAction(Page_01401_Controller.CMD_SHOW_POI_OVERLAY,list);


        }
    }

    private void showPoiList(List<POIInfo> list) {
        //resultList
        PoiListAdapter adapter = (PoiListAdapter) getController().
                getObject(PoiListAdapter.class.getCanonicalName() + "_Keyword");//new POIListAdapter(getActivity(),list);
        //adapter.setContext(this.getActivity());
        //adapter.setPoiListViewInteractor(this);
        adapter.setData(list);
        adapter.notifyDataSetChanged();

    }



    private boolean isListNull = true;
    //private final int PAGESIZE = 5;
    private int totalPage;
    List<POIInfo> poiInfoList;

    private int index = -1;

    @Override
    public boolean onHandlerMessage(Message msg) {
        Log.d(LOG_TAG,"onHandlerMessage");
        switch (msg.what){
            case 11:
                showPoi(poiInfoList);
                break;
            case 12: {

                adapter.setSelected(index);

                adapter.notifyDataSetChanged();
                adapter.setListTap(false);
            }
            break;
        }
        return super.onHandlerMessage(msg);
    }

    @Override
    public void onActionUpdate(Object... datas) {

        if (datas.length > 0) {
            if (datas[0].getClass().getCanonicalName().equals(String.class.getCanonicalName())) {
                String sCms = (String) (datas[0]);
                if (sCms == GisController.RET_POI) {
                    //清楚翻頁後背景
                    index = -1;
                    tapPoint=null;
                    if (datas.length > 1 &&
                            datas[1].getClass().getCanonicalName().equals(POISearchResult.class.getCanonicalName())) {
                        //updateDist((int)datas[1]);
                        POISearchResult r = (POISearchResult) datas[1];
                        totalPage = (r.total / Page_01401_Fragment.PAGE_ROWS);
                        if(r.total % Page_01401_Fragment.PAGE_ROWS>0)  totalPage+=1;
                        if (r.pois.size() < 1) {
                            isListNull = true;
                        } else {
                            isListNull = false;
                            poiInfoList = r.pois;
                            messageHandler.sendEmptyMessageDelayed(11,500);

                            messageHandler.sendEmptyMessageDelayed(12, 300);
//                            showPoi(r.pois);


//
                        }


                    }
                }
                else if(sCms.equals(Page_01401_Controller.RET_CURRENT_POPITEM) && datas.length > 1 )
                {
                    showAddress((OverlayItem)datas[1]);
                }
                else if(sCms.equals(BaseController.RET_STARUS))
                {

                    if(datas.length>1) {
                        final String sMsg = (String) datas[1];

                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                mEtSearch.setText(sMsg);
                            }
                        });
                    }
                } else if (sCms.equals(Page_01401_Controller.RET_SHOW_TAP_ITEM) && datas.length > 1) {
                    final int nindex = (int) datas[1];
                    index = nindex;
                    //如果點擊列表的話 就直接刷背景

                    if (!adapter.isListTap()) {
//                        getListView().setSelectionFromTop(nindex, 20);

                        int last = getListView().getLastVisiblePosition();
                        int first = getListView().getFirstVisiblePosition();
                        if (first >= nindex || last <= nindex) {
                            getListView().setSelectionFromTop(nindex, 0);

                        }
                    }
                    messageHandler.sendEmptyMessageDelayed(12, 300);

                } else {
                    super.onActionUpdate(datas);
                }


            }
        }
    }


    GeoPoint tapPoint = null;
    String mItemName=null;
    String mItemAddress=null;
    private OverlayItem mCurItem = null;

    void showAddress(OverlayItem item)
    {
        String address = item.getSnippet();


        mCurItem = item;
        mItemName = item.getTitle();
        tapPoint = item.getPoint();
        mItemAddress=address;


        if (address.length() > 0) {

            tvAddress.setText(address);
            tvAddress.setVisibility(View.VISIBLE);
        }else {
            tvAddress.setVisibility(View.INVISIBLE);
        }
    }



    @Override
    public void onItemClick(POIInfo p) {

    }

    @Override
    public void onItemClick(POIInfo p, int index) {

        submitAction(Page_01401_Controller.CMD_SHOW_POI_POP,index);

    }





}
