package com.navinfo.wenavi.model;

import android.util.Log;

import com.navinfo.wenavi.entity.AdminAreaEntity;
import com.navinfo.wenavi.entity.AppConfig;
import com.navinfo.wenavi.entity.NaviDesitination;
import com.navinfo.wenavi.entity.NaviHistory;
import com.navinfo.wenavi.entity.NaviKeyWord;
import com.orm.query.Condition;
import com.orm.query.Select;

import java.util.Date;
import java.util.List;

/**
 * Created by Doone on 2015/3/11.
 * 数据库访问类
 */
public class Repository {



    /**
     * 根据配置项名称返回App配置信息
     * @param sParamName 配置项名称
     * @return {@AppConfig} 不存在则返回空
     */
    public static  AppConfig getAppConfig(String sParamName)
    {
        Select<AppConfig> s=Select.from(AppConfig.class).where(Condition.prop("param_name").eq(sParamName));
        return s.first();
    }


    /***
     * 保存App配置信息
     * @param c {@AppConfig}
     */
    public static void saveAppConfig(AppConfig c)
    {
        c.save();

    }

    /**
     * 返回关键字搜索历史记录
     * @return List<{@NaviKeyWord}>
     */
    public static List<NaviKeyWord> getNaviKeyWords()
    {
        try {
            Select<NaviKeyWord> s = Select.from(NaviKeyWord.class).orderBy("search_time desc");
            return s.list();
        }
        catch (Exception e)
        {
            e.printStackTrace();

        }

        return null;

    }

    /***
     * 增加关键字搜索记录
     * @param w 关键字
     */

    public static void addNaviKeyWord(String w,String city,String cityCode,int longitude,int latitude)
    {
        try {
            if(w==null || w.trim().length()<=0) return;
            Select<NaviKeyWord> s = Select.from(NaviKeyWord.class)
                    .where(Condition.prop("search_key_word").eq(w))
                    .and(Condition.prop("city_code").eq(cityCode));
            NaviKeyWord k = s.first();
            if(k==null)
            {
                k =new NaviKeyWord(w,new Date(),city,cityCode,longitude,latitude);
            }
            else
                k.setSearchTime(new Date());
            k.save();

        }
        catch (Exception e)
        {
            e.printStackTrace();

        }

    }


    /*public static void addNaviKeyWord(String w)
    {
        try {
            if(w==null || w.trim().length()<=0) return;
            Select<NaviKeyWord> s = Select.from(NaviKeyWord.class)
                    .where(Condition.prop("search_key_word").eq(w));
            NaviKeyWord k = s.first();
            if(k==null)
            {
                k =new NaviKeyWord(w,new Date());
            }
            else
               k.setSearchTime(new Date());
            k.save();

        }
        catch (Exception e)
        {
            e.printStackTrace();

        }

    }*/


    /***
     * 删除关键字搜索记录
     * @param w 关键字
     */
    public static void deleteNaviKeyWord(String w)
    {
        NaviKeyWord.deleteAll(NaviKeyWord.class,"search_key_word=?",w);

    }


    /***
     * 删除所有关键字记录
     *
     */
    public static void deleteAllNaviKeyWord()
    {
        NaviKeyWord.deleteAll(NaviKeyWord.class);

    }



    /***
     * 返回所有保存的地点
     * @return List<{@NaviDesitination}>
     */
    public  static List<NaviDesitination> getNaviDesitinations()
    {
        try {
            Select<NaviDesitination> s = Select.from(NaviDesitination.class);//.orderBy("add_time");
            return s.list();
        }
        catch (Exception e)
        {
            e.printStackTrace();

        }


        return null;
    }

    /***
     * 增加或者修改一个地点
     * @param des 关键字
     */
    public static void addNaviDesitination(NaviDesitination des)
    {
        if (des == null  ||
                des.getLocation() == null || des.getLocation().length() == 0 ||
                des.getTitle() == null || des.getTitle().length() == 0 ){
            Log.d("04201","addNaviDesitination");
            return;
        }

        try {
            Log.d("","sele "+des.getIdSearchKey());
            Select<NaviDesitination> s = Select.from(NaviDesitination.class)
                    .where(Condition.prop("id_search_key").eq(des.getIdSearchKey()));
            NaviDesitination k = s.first();
            if(k != null)
            {
                k.setLocation(des.getLocation());
                k.setAddTime(des.getAddTime());
                k.setLatitude(des.getLatitude());
                k.setLongitude(des.getLongitude());
                k.setTitle(des.getTitle());
            }else
            {
                k = des;
            }
            k.save();

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }


    /***
     * 删除一个地点
     * @param key 关键字
     */
    public static void deleteNaviDesitination(String key)
    {
        NaviDesitination.deleteAll(NaviDesitination.class,"id_search_key=?",key);
    }


    /***
     * 删除所有地点
     */
    public static void deleteAllNaviDesitination()
    {
        NaviDesitination.deleteAll(NaviDesitination.class);
    }


    /**
     * 返回导航历史记录
     */
    public static List<NaviHistory> getNaviHistory()
    {
        try {
            Select<NaviHistory> s = Select.from(NaviHistory.class).orderBy("navi_time desc");
            return s.list();
        }
        catch (Exception e)
        {
            e.printStackTrace();

        }
        return null;
    }

    /***
     * 增加或者修改一条纪录
     */
    public static void addNaviHistory(NaviHistory history)
    {
        if (history != null &&
                history.getLatitudeEnd() != 0 &&
                history.getLongitudeEnd() != 0 &&
                history.getEndLocation() != null && history.getEndLocation().length()>0 &&
                history.getLongitudeStart() != 0 && history.getLatitudeStart() != 0 &&
                history.getStartLocation() != null && history.getStartLocation().length() > 0){

        }else{
            return;
        }

        Log.d("ccc","addNaviHistory 1" + history.getLongitudeEnd()+","+history.getLatitudeEnd());
        try {
            List<NaviHistory> allList = getNaviHistory();
            Log.d("ccc","addNaviHistory -all-"+ allList.size());
            //超过20条删除旧记录
            if (allList != null && allList.size() >= 20){
                Log.d("ccc","addNaviHistory -del");
                deleteNaviHistory(allList.get(allList.size()-1).getMyId());
            }
            //判断是否有相同的纪录
            Select<NaviHistory> lon = Select.from(NaviHistory.class)
                    .where(
                            Condition.prop("longitude_end").eq(history.getLongitudeEnd()),
                            Condition.prop("latitude_end").eq(history.getLatitudeEnd()) );
            NaviHistory result = lon.first();
            if ( result != null){
                Log.d("ccc","addNaviHistory same" + result.getLongitudeEnd()+","+result.getLatitudeEnd());
                return;
            }
            Log.d("ccc","add new NaviHistory");
            //查看已有记录
            Select<NaviHistory> s = Select.from(NaviHistory.class)
                    .where(Condition.prop("my_id").eq(history.getMyId()));
            NaviHistory k = s.first();
            //若存在则修改
            if(k != null)
            {
                k.setEndLocation(history.getEndLocation());
                k.setLatitudeStart(history.getLatitudeStart());
                k.setRouteType(history.getRouteType());
                k.setLongitudeStart(history.getLongitudeStart());
                k.setStartLocation(history.getStartLocation());
                k.setLongitudeEnd(history.getLongitudeEnd());
                k.setLatitudeEnd(history.getLatitudeEnd());
                k.setRouteDistance(history.getRouteDistance());
                k.setSimulateNavi(history.isSimulateNavi());
                k.setNaviTime(history.getNaviTime());

            }else
            {
                k = history;
            }
            k.save();

        }
        catch (Exception e)
        {
            e.printStackTrace();

        }
    }


    /***
     * 删除一条纪录
     */
    public static void deleteNaviHistory(String id)
    {
        NaviHistory.deleteAll(NaviHistory.class,"my_id=?",id);
    }


    /***
     * 删除所有纪录
     */
    public static void deleteAllNaviHistory()
    {
        NaviHistory.deleteAll(NaviHistory.class);
    }


    /**
     * 根据code获取符合条件的城市
     * @param code 城市代码，非空
     * @return 返回城市信息
     */
    public static AdminAreaEntity getAdminAreaByCode(String code)
    {
        if (code == null || code.trim().length() == 0){
            return null;
        }
        Select<AdminAreaEntity> data = Select.from(AdminAreaEntity.class)
                .where(
                        Condition.prop("code").eq(code)
                 ).orderBy("py_single");
        AdminAreaEntity result = data.first();
        return result;
    }

    /**
     * 根据code获取符合条件的下级城市
     * @param code 城市代码，若为"PROVINCE"则返回所有省级列表
     * @return 返回城市列表
     */
    public static List<AdminAreaEntity> getSubAdminAreaByCode(String code){
        Select<AdminAreaEntity> data = Select.from(AdminAreaEntity.class)
                .where(
                        Condition.prop("parent_code").eq(code)
                ).orderBy("py_single");
        List<AdminAreaEntity> result = data.list();
        return result;
    }

    /**
     * 插入/更新一个城市
     * @param record
     */
    public static void insertAdminArea(AdminAreaEntity record){
        if (record == null){
            return;
        }
        try {
            record.save();

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    /**
     * 删除一个城市
     * @param code
     */
    public static void deleteAdminArea(String code){
        NaviHistory.deleteAll(NaviHistory.class,"code=?",code);
    }

    /***
     * 删除所有城市
     */
    public static void deleteAllAdminArea()
    {
        AdminAreaEntity.deleteAll(AdminAreaEntity.class);
    }
}
