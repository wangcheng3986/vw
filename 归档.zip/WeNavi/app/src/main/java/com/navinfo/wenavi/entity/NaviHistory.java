package com.navinfo.wenavi.entity;

import com.orm.SugarRecord;

import java.util.Date;

/**
 * Created by Doone on 2015/3/11.
 * 导航历史数据实体
 */
public class NaviHistory extends SugarRecord<NaviHistory> {
    String routeType = "";
    int longitudeStart = 0;
    int latitudeStart =0 ;
    String startLocation= "";
    int longitudeEnd = 0;
    int latitudeEnd = 0;
    String endLocation = "";
    float routeDistance = 0.0f;
    boolean isSimulateNavi = false;
    Date naviTime = new Date();
    private  String myId = "k"+this.hashCode();

    public String getMyId() {
        return myId;
    }

    public NaviHistory()
    {

    }

    public NaviHistory(String routeType, int longitudeStart, int latitudeStart, String startLocation, int longitudeEnd, int latitudeEnd, String endLocation, float routeDistance, boolean isSimulateNavi) {
        this.routeType = routeType;
        this.longitudeStart = longitudeStart;
        this.latitudeStart = latitudeStart;
        this.startLocation = startLocation;
        this.longitudeEnd = longitudeEnd;
        this.latitudeEnd = latitudeEnd;
        this.endLocation = endLocation;
        this.routeDistance = routeDistance;
        this.isSimulateNavi = isSimulateNavi;
    }


    public String getRouteType() {
        return routeType;
    }

    public void setRouteType(String routeType) {
        this.routeType = routeType;
    }

    public int getLongitudeStart() {
        return longitudeStart;
    }

    public void setLongitudeStart(int longitudeStart) {
        this.longitudeStart = longitudeStart;
    }

    public int getLatitudeStart() {
        return latitudeStart;
    }

    public void setLatitudeStart(int latitudeStart) {
        this.latitudeStart = latitudeStart;
    }

    public String getStartLocation() {
        return startLocation;
    }

    public void setStartLocation(String startLocation) {
        this.startLocation = startLocation;
    }

    public int getLongitudeEnd() {
        return longitudeEnd;
    }

    public void setLongitudeEnd(int longitudeEnd) {
        this.longitudeEnd = longitudeEnd;
    }

    public int getLatitudeEnd() {
        return latitudeEnd;
    }

    public void setLatitudeEnd(int latitudeEnd) {
        this.latitudeEnd = latitudeEnd;
    }

    public String getEndLocation() {
        return endLocation;
    }

    public void setEndLocation(String endLocation) {
        this.endLocation = endLocation;
    }

    public float getRouteDistance() {
        return routeDistance;
    }

    public void setRouteDistance(float routeDistance) {
        this.routeDistance = routeDistance;
    }

    public boolean isSimulateNavi() {
        return isSimulateNavi;
    }

    public void setSimulateNavi(boolean isSimulateNavi) {
        this.isSimulateNavi = isSimulateNavi;
    }

    public Date getNaviTime() {
        return naviTime;
    }

    public void setNaviTime(Date naviTime) {
        this.naviTime = naviTime;
    }


    public boolean equal(NaviHistory o) {
        return (this.getLatitudeEnd() == o.getLatitudeEnd()
        && this.getLongitudeEnd() == o.getLongitudeEnd());
    }
}
