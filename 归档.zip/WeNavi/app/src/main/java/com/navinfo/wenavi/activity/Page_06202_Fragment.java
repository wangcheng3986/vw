package com.navinfo.wenavi.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.navinfo.wenavi.R;

/**
 *
 */
public class Page_06202_Fragment extends WeNaviBaseFragment implements View.OnClickListener{


    private Button mBtBack;


    public Page_06202_Fragment() {
        // Required empty public constructor
    }


    @Override
    public void restoreViewStatus(Bundle status) {

    }

    @Override
    public Bundle getViewStatus() {
        return null;
    }

    @Override
    protected int getFragmentLayoutID() {
        return R.layout.page_06202;
    }


    /**
     * 初始化控件为不可用,页面初始化时调用
     */
    @Override
    public  void onDisableControl()
    {


    }

    /**
     * 初始化控件为可用,页面初始化完成后被延时调用
     */
    @Override
    public  void onEnableControl()
    {

    }

    @Override
    protected void bindUIControl(View v) {
        mBtBack = (Button) v.findViewById(R.id.btn_06202_back);
        mBtBack.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_06202_back:
                onBack();
                break;

            default:
                break;
        }
    }
}
