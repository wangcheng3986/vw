package com.navinfo.wenavi.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import com.navinfo.sdk.mapapi.search.adminarea.AdminAreaRecord;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.entity.AdminAreaEntity;
import com.navinfo.wenavi.model.CustomDialog;
import com.navinfo.wenavi.model.Page_02401_Model;
import com.navinfo.wenavi.model.WeNaviApplication;
import com.navinfo.wenavi.util.AdminAreaComparator;
import com.navinfo.wenavi.util.WeNaviUtil;
import java.util.ArrayList;
import java.util.List;

/**
 * 城市列表对话框
 * Created by cc on 15/3/10.
 */
public class Page_02401_Dialog extends CustomDialog {

    Context context;
    private Button mBack = null;
    private ListView mCityList = null;
    private GridView mGridView = null;
    private Page_02401_Model.Page_02401_ListAdapter listAdapter = null;
    private Button mCurrentPYBtn = null;
    private Button mProvinceBtn = null;
    private Button mCityBtn = null;
    private Button mRegionBtn = null;
    private Button mCurrentFocusBtn = null;
    private Button mKeyboardBtn = null;

    //城市列表
    private List<AdminAreaEntity> mAllProvinceList = null;
    private List<AdminAreaEntity> mShowAdminAreaRecordList = null;
    private AdminAreaEntity mCurrentProvince = null;
    private AdminAreaEntity mCurrentCity = null;
    private AdminAreaEntity mCurrentRegion = null;
    private int currentType = -1;
    //
    private WeNaviApplication mApplication = null;

    Page_02401_Model.OnAdminAreaRecordListener mListener = null;
    private ProgressDialog mProgressDialog = null;
    private boolean mLoading = false;
    private GridViewAdapter  gridViewAdapter =null;

    //拼音首字母
    private String[] mPinyinKeys = new String[]{"", "A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "W", "X", "Y", "Z"};
    private String mCurrentPY = "";

    public Page_02401_Dialog(Activity activity, WeNaviApplication app) {
        super(activity, R.layout.page_02401);
        mApplication = app;
        init(activity);
    }




    public void onSetListAdaptor() {
        //获取所有支持离线地图的城市
        Page_02401_Model model = (Page_02401_Model)(mApplication.getModel(Page_02401_Model.class.getCanonicalName()));
        if (model == null){
            return;
        }
        listAdapter = model.getPage_02401_ListAdapter(context);
        mCityList.setAdapter(listAdapter);

        if(gridViewAdapter==null) gridViewAdapter=new GridViewAdapter();
        mGridView.setAdapter(gridViewAdapter);

    }




    public void onRemoveListAdaptor() {
        mCityList.setAdapter(null);
        mGridView.setAdapter(null);
    }


    public void init(Context context) {
        this.context = context;
        Button mOk = (Button) getView().findViewById(R.id.ok_btn);
        mBack = (Button) getView().findViewById(R.id.back_btn);
        mCityList = (ListView) getView().findViewById(R.id.listView);
        mGridView = (GridView) getView().findViewById(R.id.gridView);
        mCurrentPYBtn = (Button) getView().findViewById(R.id.current_key);
        mProvinceBtn = (Button) getView().findViewById(R.id.btn_province);
        mCityBtn = (Button) getView().findViewById(R.id.btn_city);
        mRegionBtn = (Button) getView().findViewById(R.id.btn_region);
        mKeyboardBtn = (Button) getView().findViewById(R.id.current_keyboard);

        final Page_02401_Model model = (Page_02401_Model)(mApplication.getModel(Page_02401_Model.class.getCanonicalName()));

        mBack.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (getOnClickListener() != null){
                    getOnClickListener().onClick(null);
                }
                //TODO:
                hide();
            }
        });


        mOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AdminAreaEntity temp = null;
                if (mCurrentRegion != null){
                    temp = mCurrentRegion;
                }
                else if (mCurrentCity != null) {
                    temp = mCurrentCity;
                }
                else if (mCurrentProvince != null) {
                    temp = mCurrentProvince;
                }
                if (getOnClickListener() != null){
                    getOnClickListener().onClick(temp);
                }
                hide();
            }
        });
        mProvinceBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mAllProvinceList == null || mAllProvinceList.size() == 0){
                    showProgressDialog();
                }
                else{
                    currentType = 0;
                    mCurrentPY = "";
                    setFocusBtn(mProvinceBtn);
                    mShowAdminAreaRecordList = mAllProvinceList;

                    mGridView.setVisibility(View.INVISIBLE);
                    mCityList.setVisibility(View.VISIBLE);
                    mCurrentPYBtn.setVisibility(View.INVISIBLE);
                    mKeyboardBtn.setVisibility(View.VISIBLE);
                    showListViewAgain();
                }
            }
        });

        mCityBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                currentType = 1;
                mCurrentPY = "";
                setFocusBtn(mCityBtn);
                mShowAdminAreaRecordList = model.getSubAdminAreaList(mCurrentProvince.getCode());
                mGridView.setVisibility(View.INVISIBLE);
                mCityList.setVisibility(View.VISIBLE);
                mCurrentPYBtn.setVisibility(View.INVISIBLE);
                mKeyboardBtn.setVisibility(View.VISIBLE);
                showListViewAgain();
            }
        });

        mRegionBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                currentType = 2;
                mCurrentPY = "";
                mShowAdminAreaRecordList = model.getSubAdminAreaList(mCurrentCity.getCode());
                mGridView.setVisibility(View.INVISIBLE);
                mCityList.setVisibility(View.VISIBLE);
                mCurrentPYBtn.setVisibility(View.INVISIBLE);
                mKeyboardBtn.setVisibility(View.VISIBLE);
                setFocusBtn(mRegionBtn);
                showListViewAgain();
            }
        });

        mCurrentPYBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mGridView.setVisibility(View.VISIBLE);
                mCityList.setVisibility(View.INVISIBLE);
                mCurrentPYBtn.setVisibility(View.INVISIBLE);
                mKeyboardBtn.setVisibility(View.VISIBLE);
            }
        });

        mKeyboardBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mAllProvinceList == null || mAllProvinceList.size() == 0){
                    showProgressDialog();
                }else{
                    mGridView.setVisibility(View.VISIBLE);
                    mCityList.setVisibility(View.INVISIBLE);
                }
            }
        });
        mCurrentPYBtn.setClickable(true);
        mProvinceBtn.setClickable(true);
        mRegionBtn.setClickable(false);
        mCityBtn.setClickable(false);

        setFocusBtn(mProvinceBtn);
        initView();
    }


    private void showProgressDialog(){
        Log.d("updateDatabase", "showProgressDialog" );
        /*if (mProgressDialog == null){
            mProgressDialog =  ProgressDialog.show(getActivity(), null, "正在获取行政区数据，请稍候...", true, true);
            mProgressDialog.setCanceledOnTouchOutside(false);
        }
        else
        {
            mProgressDialog.show();
        }*/
    }

    private void hideProgressDialog(){
        Log.d("updateDatabase", "hideProgressDialog" );
        /*if (mProgressDialog != null){
            mProgressDialog.dismiss();
            mProgressDialog = null;
        }*/
    }

    private AdminAreaRecord copyAdminAreaRecord(AdminAreaRecord src)
    {
        if (src != null){
            AdminAreaRecord des = new AdminAreaRecord();
            des.py = src.py;
            des.name = src.name;
            des.code = src.code;
            des.point = src.point;
            des.type = src.type;
            des.childRegions = null;
            des.childCities = null;
            return des;
        }
        return null;
    }

    private void initView() {

        mCityList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View v, int index, long arg3) {
                mCurrentPY = "";
                mCurrentPYBtn.setText(mCurrentPY);
                final Page_02401_Model model = (Page_02401_Model)(mApplication.getModel(Page_02401_Model.class.getCanonicalName()));
                //点击列表项选择对应城市
                switch (currentType) {
                    case 0:
                        mCurrentProvince = mShowAdminAreaRecordList.get(index);
                        mCurrentCity = null;
                        mCurrentRegion = null;
                        mCityBtn.setText("选择市");
                        mRegionBtn.setText("选择县");
                        mCityBtn.setClickable(true);
                        mRegionBtn.setClickable(false);
                        mProvinceBtn.setText(mCurrentProvince.getName());
                        currentType = 1;

                        mShowAdminAreaRecordList = model.getSubAdminAreaList(mCurrentProvince.getCode());
                        setFocusBtn(mCityBtn);
                        mCurrentPYBtn.setVisibility(View.INVISIBLE);
                        mKeyboardBtn.setVisibility(View.VISIBLE);
                        showListViewAgain();
                        break;
                    case 1:
                        mCurrentCity = mShowAdminAreaRecordList.get(index);
                        mCurrentRegion = null;
                        mRegionBtn.setText("选择县");
                        mRegionBtn.setClickable(true);
                        mCityBtn.setText(mCurrentCity.getName());

                        currentType = 2;
                        mShowAdminAreaRecordList = model.getSubAdminAreaList(mCurrentCity.getCode());
                        setFocusBtn(mRegionBtn);
                        mCurrentPYBtn.setVisibility(View.INVISIBLE);
                        mKeyboardBtn.setVisibility(View.VISIBLE);
                        showListViewAgain();
                        break;
                    case 2:
                        mCurrentRegion = mShowAdminAreaRecordList.get(index);
                        mRegionBtn.setText(mCurrentRegion.getName());

                        mShowAdminAreaRecordList = null;
                        mCurrentPYBtn.setVisibility(View.INVISIBLE);
                        mKeyboardBtn.setVisibility(View.VISIBLE);
                        showListViewAgain();
                        break;

                    default:
                        break;
                }
            }
        });


        onSetListAdaptor();
        currentType = 0;
        mCurrentPYBtn.setVisibility(View.INVISIBLE);
        mKeyboardBtn.setVisibility(View.VISIBLE);
        mGridView.setVisibility(View.INVISIBLE);
        mCityList.setVisibility(View.VISIBLE);
        mCurrentPYBtn.setVisibility(View.VISIBLE);
        updateListView();
    }


    private void setFocusBtn(Button btn){
        if (btn != null){
            if (mCurrentFocusBtn != null)
            {
                mCurrentFocusBtn.setFocusable(false);
                mCurrentFocusBtn.setFocusableInTouchMode(false);
                mCurrentFocusBtn.requestFocus();
                mCurrentFocusBtn.requestFocusFromTouch();
            }
            mCurrentFocusBtn = btn;
            mCurrentFocusBtn.setFocusable(true);
            mCurrentFocusBtn.setFocusableInTouchMode(true);
            mCurrentFocusBtn.requestFocus();
            mCurrentFocusBtn.requestFocusFromTouch();
        }else{
            mCityBtn.setFocusable(false);
            mCityBtn.setFocusableInTouchMode(false);
            mCityBtn.requestFocus();
            mCityBtn.requestFocusFromTouch();

            mProvinceBtn.setFocusable(false);
            mProvinceBtn.setFocusableInTouchMode(false);
            mProvinceBtn.requestFocus();
            mProvinceBtn.requestFocusFromTouch();

            mRegionBtn.setFocusable(false);
            mRegionBtn.setFocusableInTouchMode(false);
            mRegionBtn.requestFocus();
            mRegionBtn.requestFocusFromTouch();
            mCurrentFocusBtn = null;
        }
    }


    private void getAdminArea(){
        Log.d("updateDatabase", "getAdminArea REQUEST" );
        Page_02401_Model model = (Page_02401_Model)(mApplication.getModel(Page_02401_Model.class.getCanonicalName()));

        if (mListener == null){
            mListener =  new Page_02401_Model.OnAdminAreaRecordListener() {
                @Override
                public void onAdminAreaRecordResponse(List<AdminAreaEntity> list) {
                    Log.d("updateDatabase", "onAdminAreaRecordResponse" );
                    mAllProvinceList = list;
                    if (mAllProvinceList != null){
                        Log.d("updateDatabase", "onAdminAreaRecordResponse updateListView" );
                        hideProgressDialog();
                        updateListView();
                    }
                }
            };
        }

        mAllProvinceList = model.getProvinceRecords(mListener);
    }


    public  List<AdminAreaEntity> getAdminAreaRecordListByKey(List<AdminAreaEntity> listData, String key){
        if (listData == null){
            return null;
        }
        ArrayList<AdminAreaEntity> temp = null;
        for (AdminAreaEntity r : listData){
            String tempKey = r.getPy().substring(0, 1);
            if (tempKey.equals(key)){
                if (temp == null){
                    temp = new ArrayList<>();
                }
                temp.add(r);
            }
        }

        return temp;
    }

    //更新列表数据
    private void updateListView(){
        if (mAllProvinceList == null || mAllProvinceList.size() == 0){
            getAdminArea();
        }
        switch (currentType){
            case 0:
                if (mAllProvinceList != null ){
                    if (mCurrentPY.length() ==0 ){
                        mShowAdminAreaRecordList = mAllProvinceList;
                    }else
                    {
                        mShowAdminAreaRecordList = getAdminAreaRecordListByKey(mAllProvinceList ,mCurrentPY);
                    }

                }
                break;
            case 1: {
                final Page_02401_Model model = (Page_02401_Model) (mApplication.getModel(Page_02401_Model.class.getCanonicalName()));
                if (mCurrentProvince != null) {
                    mShowAdminAreaRecordList = model.getSubAdminAreaList(mCurrentProvince.getCode());
                    if (mCurrentPY.length() != 0) {
                        mShowAdminAreaRecordList = getAdminAreaRecordListByKey(mShowAdminAreaRecordList, mCurrentPY);
                    }

                }
                break;
            }
            case 2: {
                final Page_02401_Model model = (Page_02401_Model) (mApplication.getModel(Page_02401_Model.class.getCanonicalName()));
                if (mCurrentCity != null) {
                    mShowAdminAreaRecordList = model.getSubAdminAreaList(mCurrentCity.getCode());
                    if (mCurrentPY.length() != 0) {
                        mShowAdminAreaRecordList = getAdminAreaRecordListByKey(mShowAdminAreaRecordList, mCurrentPY);
                    }
                }
                break;
            }
            default:
                mShowAdminAreaRecordList = null;
                break;
        }
        showListViewAgain();
    }

    //更新列表视图
    private void showListViewAgain(){
        listAdapter.setCurrentPY(mCurrentPY);
        listAdapter.setShowAdminAreaRecordList(mShowAdminAreaRecordList);
        listAdapter.notifyDataSetChanged();
    }



    //自定义适配器
    private class GridViewAdapter extends BaseAdapter{

        private class buttonViewHolder {
            Button btn;
        }
        private buttonViewHolder holder;

        GridViewAdapter(){
        }
        public int getCount() {
            return 24;
        }

        public Object getItem(int item) {
            return item;
        }

        public long getItemId(int id) {
            return id;
        }

        //创建View方法
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView != null) {
                holder = (buttonViewHolder) convertView.getTag();
            } else {
                //convertView = View.inflate(context, R.layout.page_02401_btn, null);

                AbsListView.LayoutParams pm=new AbsListView.LayoutParams(
                        WeNaviUtil.dip2px(context, 52),
                        WeNaviUtil.dip2px(context, 52));


                LinearLayout layout=new LinearLayout(context);
                layout.setOrientation(LinearLayout.HORIZONTAL);
                layout.setLayoutParams(pm);

                Button bt=new Button(context);
                bt.setBackgroundResource(R.drawable.p2401_btn2_color);
                bt.setTextColor(context.getResources().getColorStateList(R.drawable.p2401_btn_txt_color));
                bt.setTextSize(25);
                LinearLayout.LayoutParams pm1=new LinearLayout.LayoutParams(
                        WeNaviUtil.dip2px(context, 52),
                        WeNaviUtil.dip2px(context, 52)
                );
                bt.setLayoutParams(pm1);
                bt.setTag("button");
                layout.addView(bt);

                convertView=layout;

                holder = new buttonViewHolder();
                convertView.setTag(holder);
            }

            holder.btn =  (Button)convertView.findViewWithTag("button");//.findViewById(R.id.button);
            holder.btn.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    Button btnClick = (Button)v;
                    mCurrentPY = btnClick.getText().toString();
                    mCurrentPYBtn.setText(mCurrentPY+"  ");
                    mCityList.setVisibility(View.VISIBLE);
                    mGridView.setVisibility(View.INVISIBLE);
                    mCurrentPYBtn.setVisibility(View.VISIBLE);
                    mKeyboardBtn.setVisibility(View.INVISIBLE);
                    updateListView();

                }
            });
            holder.btn.setText(mPinyinKeys[position+1]);
            return convertView;
        }
    }
}