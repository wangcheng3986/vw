package com.navinfo.wenavi.controller;

import android.content.Context;
import android.util.Log;

import com.navinfo.wenavi.activity.Page_04201_Fragment;
import com.navinfo.wenavi.entity.NaviDesitination;
import com.navinfo.wenavi.entity.NaviHistory;
import com.navinfo.wenavi.model.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by cc on 15/3/18.
 */
public class Page_04201_Controller extends AudioController {

    /**
     * 命令: 获取所有地点
     */
    public static final String CMD_GET_ALL_DES="CMD_GET_ALL_DES";

    /**
     * 命令: 添加一个地点
     */
    public static final String CMD_ADD_A_DES="CMD_ADD_A_DES";

    /**
     * 命令: 删除一个地点
     */
    public static final String CMD_DEL_A_DES="CMD_DEL_A_DES";

    /**
     * 命令: 删除所有地点
     */
    public static final String CMD_DEL_ALL_DES="CMD_DEL_ALL_DES";


    /**
     * 视图刷新代码: 地点列表，附带 List<{@NaviDesitination}>
     */
    public static final String RET_ALL_DES="RET_ALL_DES";


    /**
     * 命令: 获取所有导航纪录
     */
    public static final String CMD_GET_ALL_HISTORY="CMD_GET_ALL_HISTORY";

    /**
     * 命令: 添加一条纪录
     */
    public static final String CMD_DEL_A_HISTORY="CMD_DEL_A_HISTORY";

    /**
     * 命令: 添加一条纪录
     */
    public static final String CMD_DEL_ALL_HISTORY="CMD_DEL_ALL_HISTORY";


    /**
     * 视图刷新代码: 纪录列表，附带 List<{@NaviHistory}>
     */
    public static final String RET_ALL_HISTORY="RET_ALL_HISTORY";

    /**
     * 视图刷新代码: 纪录，附带 {@NaviHistory}
     */
    public static final String RET_ADD_A_HISTORY="RET_ADD_A_HISTORY";

    /**
     * 视图刷新代码: 地点列表，附带 List<{@NaviHistory}>
     */
    public static final String RET_DEL_ALL_HISTORY="RET_DEL_ALL_HISTORY";


    public Page_04201_Controller(Context context) {
        super(context);
        Log.e("ccc", "Page_04201_Controller create");
    }

    @Override
    public void executeAction(Object... actionDatas) {
        if(actionDatas.length>0) {
            if (actionDatas[0].getClass().getCanonicalName().equals(String.class.getCanonicalName())) {
                String sCms = (String) (actionDatas[0]);
                if (sCms.equals(CMD_GET_ALL_DES))
                {
                    getAllDes();
                }
                else if (sCms.equals(CMD_ADD_A_DES) && actionDatas.length>1)
                {
                    addDes((NaviDesitination)actionDatas[1]);
                }
                else if (sCms.equals(CMD_DEL_A_DES) && actionDatas.length>1)
                {
                    delADes((String) actionDatas[1]);
                }
                else if (sCms.equals(CMD_DEL_ALL_DES))
                {
                    delAllDes();
                }

                else if (sCms.equals(CMD_GET_ALL_HISTORY))
                {
                    getAllNaviHistory();
                }
                else if (sCms.equals(CMD_DEL_A_HISTORY) && actionDatas.length>1)
                {
                    delNaviHistory((String) actionDatas[1]);
                }
                else if (sCms.equals(CMD_DEL_ALL_HISTORY))
                {
                    delAllNaviHistory();
                }
                else super.executeAction(actionDatas);

            }
        }

    }


    private void getAllDes(){
        List<NaviDesitination> result= Repository.getNaviDesitinations();


        if(result != null && result.size()>0) {
            Log.d("04201","getAllDes "+result.size());
            updateView(RET_ALL_DES,result);
        }else{
            NaviDesitination a = new NaviDesitination();
            a.setTitle("公司");
            a.setLocation("请编辑地址");

            NaviDesitination b = new NaviDesitination();
            b.setTitle("家");
            b.setLocation("请编辑地址");

            addDes(a);
            addDes(b);
            ArrayList<NaviDesitination> list = new ArrayList<NaviDesitination>();
            list.add(a);
            list.add(b);
            updateView(RET_ALL_DES,list);
        }
    }

    private void addDes(NaviDesitination des){
        if (des == null) return;
        Repository.addNaviDesitination(des);
    }

    private void delADes(String id){
        if (id != null){
            Repository.deleteNaviDesitination(id);
        }
    }

    private void delAllDes(){
        Repository.deleteAllNaviDesitination();
    }




    private void getAllNaviHistory(){
        List<NaviHistory> result= Repository.getNaviHistory();

        if(result != null) {
            Log.d("sql","getAllNaviHistory "+result.size());
            updateView(RET_ALL_HISTORY,result);
        }
    }

    private void delNaviHistory(String id) {
        if (id != null) {
            Repository.deleteNaviHistory(id);
        }
    }

    private void delAllNaviHistory(){
        Repository.deleteAllNaviHistory();
    }

}
