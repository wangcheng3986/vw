package com.navinfo.wenavi.activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.navinfo.audio.IAudioGenerateListerner;
import com.navinfo.audio.IAudioGenerator;
import com.navinfo.sdk.mapapi.search.poi.POISearchResult;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.controller.AudioController;
import com.navinfo.wenavi.controller.BaseController;
import com.navinfo.wenavi.controller.IController;
import com.navinfo.wenavi.controller.Page_01301_Controller;
import com.navinfo.wenavi.controller.Page_02201_Controller;
import com.navinfo.wenavi.entity.POITypeEntity;
import com.navinfo.wenavi.entity.PoiSearchParam;
import com.navinfo.wenavi.model.IMessage;
import com.navinfo.wenavi.model.POITypeModel;
import com.navinfo.wenavi.model.PoiTypeAdapter;
import com.navinfo.wenavi.model.WeNaviInternalMessage;
import com.navinfo.wenavi.util.WeNaviDefine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class Page_01301_Fragment extends WeNaviBaseFragment implements PoiTypeAdapter.IPoiTypeListViewInteractor {

    private Button mBtBack,mBtSound,mBtnSeatch;
    private EditText mEtPOIType;
    private ListView mLvPOITypes;
    private LinearLayout mLLPOITypes;
    private Boolean bShowPOITypeList = false;
    private Button mBtnOther,mBtnHospital,mBtnHotel,mBtnToilet,mBtnPharmacy,mBtnBank,mBtnPark,mBtnRestaurant;
    private TextView mTvOther,mTvHospital,mTvHotel,mTvToilet,mTvPharmacy,mTvBank,mTvPark,mTvRestaurant,mTvNotice;


    private IMessage requestLocationMessg = null;
    private String mAdminCode = "110000";
    //PoiTypeAdapter adapter =null;
    //提示
    private PopupWindow popupWindow;

    List<String> mlistTopPOITypes;
    HashMap<String, List<String>> mlistSubPOITypes;

    //private OnFragmentInteractionListener mListener;

    public Page_01301_Fragment() {
        // Required empty public constructor
    }


        @Override
        public boolean onHandlerMessage(Message msg)
        {
            IController c=getController();
            IAudioGenerator p=null;
            if(c!=null)
             p = (IAudioGenerator) c.getObject(IAudioGenerator.class.getCanonicalName());
            int tag = msg.what;
            switch (tag) {
                case 1:
                    submitAction(AudioController.CMD_START_RECONGNISE_AFTER_NOTIFY,
                            null,
                            AudioController.HCI_POI_RECONGNISER);

                    mBtSound.setEnabled(false);
                    return true;
                case 2:
                    Bundle bundle = msg.getData();
                    String kw = (String) bundle.get("kw");
                    mBtSound.setEnabled(true);
                    mEtPOIType.setText(kw);
                    mBtSound.setBackgroundResource(R.drawable.ui_01201_btn_sounds_normal);
                    return true;
                case 3:
                    //识别失败，没有内容
                    if(p!=null) {
                        p.play("对不起，未能识别目的地，请重说一遍",
                                new IAudioGenerateListerner() {
                                    @Override
                                    public void onError(String s) {

                                    }

                                    @Override
                                    public void onPlayFinished() {
                                        messageHandler.sendEmptyMessage(7);

                                    }
                                });
                    }

                    mBtSound.setBackgroundResource(R.drawable.ui_01201_btn_sounds_normal);
                    return true;

                case 4:
                    //识别失败，没有内容
                    if(p!=null) {
                        p.play("对不起，未能识别目的地，请重说一遍",
                                new IAudioGenerateListerner() {
                                    @Override
                                    public void onError(String s) {

                                    }

                                    @Override
                                    public void onPlayFinished() {
                                        // mBtSound.setEnabled(true);
                                        // handler.sendEmptyMessage()
                                        messageHandler.sendEmptyMessage(7);

                                    }
                                });
                    }

                    mBtSound.setBackgroundResource(R.drawable.ui_01201_btn_sounds_normal);
                    return true;

                case 6:
                    mBtSound.setBackgroundResource(R.drawable.ui_01201_btn_sounds_pressed);
                    return true;
                case 7:
                    //mBtSound.setBackgroundResource(R.drawable.ui_btn_sounds_pressed);
                    mBtSound.setEnabled(true);
                    return true;
                case 8: {
                    Bundle b = msg.getData();
                    POITypeEntity[] types = (POITypeEntity[]) b.get("types");
                    if(types.length > 0) {
                        mLLPOITypes.setVisibility(View.GONE);
                        mLvPOITypes.setVisibility(View.VISIBLE);
                        mTvNotice.setVisibility(View.GONE);
                        PoiTypeAdapter adapter = (PoiTypeAdapter) getController().
                                getObject(PoiTypeAdapter.class.getCanonicalName());//new POIListAdapter(getActivity(),list);
                        if (adapter != null) {
                            //adapter = new PoiTypeAdapter();
                            //adapter.setContext(Page_01301_Fragment.this.getActivity());
                            //adapter.setPoiTypeListViewInteractor(Page_01301_Fragment.this);
                            //setListAdapter(adapter);

                            adapter.setData(types);
                            adapter.notifyDataSetChanged();
                        }
                    }
                    else{
                        mLLPOITypes.setVisibility(View.GONE);
                        mLvPOITypes.setVisibility(View.GONE);
                        mTvNotice.setText("没有相关的类别！");
                        mTvNotice.setVisibility(View.VISIBLE);
                    }
                    return true;


                    //mLvPOITypes.setAdapter(adapter);
                }


            }

            return super.onHandlerMessage(msg);

        }

    @Override
    public void onSetListAdaptor() {
        PoiTypeAdapter adapter = (PoiTypeAdapter) getController().
                getObject(PoiTypeAdapter.class.getCanonicalName());//new POIListAdapter(getActivity(),list);
        adapter.setContext(Page_01301_Fragment.this.getActivity());
        adapter.setPoiTypeListViewInteractor(Page_01301_Fragment.this);
        //adapter.setData(types);
        setListAdapter(adapter);
    }

    @Override
    public void onRemoveListAdaptor() {
        setListAdapter(null);
    }

    ListView getListView()
    {
        return  mLvPOITypes;
    }

    void setListAdapter(ListAdapter d)
    {
        getListView().setAdapter(d);
    }

    @Override
    protected String getControllerName() {
        return Page_01301_Controller.class.getCanonicalName();
    }

    @Override
    public void restoreViewStatus(Bundle status) {

    }

    @Override
    public Bundle getViewStatus() {
        return null;
    }

    @Override
    protected int getFragmentLayoutID() {
        return R.layout.page_01301;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onBack()
    {
        if(bShowPOITypeList){
            mLLPOITypes.setVisibility(View.VISIBLE);
            mLvPOITypes.setVisibility(View.GONE);
            bShowPOITypeList = false;
        }
        else{
            super.onBack();
        }


    }


    /**
     * 初始化控件为不可用,页面初始化时调用
     */
    @Override
    public  void onDisableControl()
    {
        mBtBack.setEnabled(false);

    }

    /**
     * 初始化控件为可用,页面初始化完成后被延时调用
     */
    @Override
    public  void onEnableControl()
    {
        mBtBack.setEnabled(true);
    }


    @Override
    protected void bindUIControl(View v) {

        mBtBack  = (Button) v.findViewById(R.id.btn_01301_back);
        mBtSound = (Button) v.findViewById(R.id.btn_01301_sound);
        mBtnSeatch = (Button) v.findViewById(R.id.btn_01301_search);
        mEtPOIType  = (EditText) v.findViewById(R.id.et_ui_01301_poitype);
        mLLPOITypes = (LinearLayout)v.findViewById(R.id.ll_01301_show_types_icons);
        mLvPOITypes = (ListView)v.findViewById(android.R.id.list);
        //mLvPOITypes = (ListView)getListView();// v.findViewById(R.id.lv_01301_show_types);

        mTvHospital = (TextView) v.findViewById(R.id.tvHospital);
        mTvHotel = (TextView) v.findViewById(R.id.tvHotel);
        mTvToilet = (TextView) v.findViewById(R.id.tvToilet);
        mTvPharmacy = (TextView) v.findViewById(R.id.tvPharmacy);
        mTvBank = (TextView) v.findViewById(R.id.tvBank);
        mTvPark = (TextView) v.findViewById(R.id.tvPark);
        mTvRestaurant = (TextView) v.findViewById(R.id.tvRestaurant);
        mTvOther = (TextView) v.findViewById(R.id.tvOther);
        mTvNotice = (TextView) v.findViewById(R.id.tvNotice);

        mBtnHospital = (Button) v.findViewById(R.id.btn_hospital);
        mBtnHotel = (Button) v.findViewById(R.id.btn_hotel);
        mBtnToilet = (Button) v.findViewById(R.id.btn_toilet);
        mBtnPharmacy = (Button) v.findViewById(R.id.btn_pharmacy);
        mBtnBank = (Button) v.findViewById(R.id.btn_bank);
        mBtnPark = (Button) v.findViewById(R.id.btn_park);
        mBtnRestaurant = (Button) v.findViewById(R.id.btn_restaurant);
        mBtnOther = (Button) v.findViewById(R.id.btn_other);





       // adapter.setData(types);
       // adapter.notifyDataSetChanged();

        mBtnSeatch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchPOITypeByName(mEtPOIType.getText().toString());
            }
        });

        mBtBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //关闭软键盘
                View view = Page_01301_Fragment.this.getActivity().getWindow().peekDecorView();
                if (view != null) {
                    InputMethodManager inputmanger = (InputMethodManager) Page_01301_Fragment.this.getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                    inputmanger.hideSoftInputFromWindow(view.getWindowToken(), 0);
                }
                onBack();

            }
        });

        mBtSound.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                mBtSound.setEnabled(false);
                messageHandler.sendEmptyMessage(1);
//                int state = soundPool.play(hitOkSfx,1,1,0,0,1);
//                Message message = new Message();
//                message.what = 1;
//                if(state!=0){
//                    handler.sendMessageDelayed(message,1000);
//                }
            }
        });

        mEtPOIType.addTextChangedListener(new TextWatcher() {
            private CharSequence temp;
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                temp = s;

            }

            @Override
            public void afterTextChanged(Editable s) {
                int length = temp.length();
                if(length >= 2){
                    searchPOITypeByName(s.toString());
                }
                else{
                    searchPOITypeByName("");
                }
            }
        });

        mBtnHospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPOISearch(new POITypeEntity(null,"医院",1), WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME);
            }
        });

        mBtnHotel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPOISearch(new POITypeEntity(null,"酒店",1), WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME);
            }
        });

        mBtnToilet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPOISearch(new POITypeEntity(null,"厕所",1), WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME);
            }
        });

        mBtnPharmacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPOISearch(new POITypeEntity(null,"药店",1), WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME);
            }
        });

        mBtnBank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPOISearch(new POITypeEntity(null,"银行",1), WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME);
            }
        });

        mBtnPark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPOISearch(new POITypeEntity(null,"停车场",1), WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME);
            }
        });

        mBtnRestaurant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPOISearch(new POITypeEntity(null,"餐饮",1), WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME);
            }
        });

        mBtnOther.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                searchPOITypeByName("");
            }
        });

        mTvHospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPOISearch(new POITypeEntity(null,"医院",1), WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME);
            }
        });

        mTvHotel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPOISearch(new POITypeEntity(null,"酒店",1), WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME);
            }
        });

        mTvToilet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPOISearch(new POITypeEntity(null,"厕所",1), WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME);
            }
        });

        mTvPharmacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPOISearch(new POITypeEntity(null,"药店",1), WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME);
            }
        });

        mTvBank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPOISearch(new POITypeEntity(null,"银行",1), WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME);
            }
        });

        mTvPark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPOISearch(new POITypeEntity(null,"停车场",1), WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME);
            }
        });

        mTvRestaurant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toPOISearch(new POITypeEntity(null,"餐饮",1), WeNaviDefine.MSG_SEARCH_POI_BY_KIND_NAME);
            }
        });

        mTvOther.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                searchPOITypeByName("");
            }
        });

        mLvPOITypes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                POITypeEntity poiTypeEntity =  (POITypeEntity)mLvPOITypes.getItemAtPosition(position);
                if(poiTypeEntity != null){
                    toPOISearch(poiTypeEntity, WeNaviDefine.MSG_SEARCH_POI_BY_KIND_CODE);
                }
            }
        });

        //submitAction(Page_01301_Controller.CMD_LOAD_POI_TYPE);
    }

    private void searchPOITypeByName(String typeName){

        if(POITypeModel.getPOIpoiSKindList() == null){
            mLLPOITypes.setVisibility(View.GONE);
            mLvPOITypes.setVisibility(View.GONE);
            mTvNotice.setText("类别信息未加载，请重试！");
            mTvNotice.setVisibility(View.VISIBLE);
            submitAction(Page_01301_Controller.CMD_LOAD_POI_TYPE);
        }
        else {
            submitAction(Page_01301_Controller.CMD_SEARCH_POI_TYPE_BY_NAME, typeName);
        }

        bShowPOITypeList = true;
    }

    private void prepareListData() {
        mlistTopPOITypes = new ArrayList<String>();
        mlistSubPOITypes = new HashMap<String, List<String>>();

        mlistTopPOITypes.add("购物");
        mlistTopPOITypes.add("风景名胜");


        List<String> shopping = new ArrayList<String>();
        shopping.add("超市");
        shopping.add("家电卖场");
        shopping.add("商场");

        List<String> natureview = new ArrayList<String>();
        natureview.add("自然风景");
        natureview.add("名胜古迹");

        mlistSubPOITypes.put(mlistTopPOITypes.get(0), shopping);
        mlistSubPOITypes.put(mlistTopPOITypes.get(1), natureview);
    }

    /*
  * 父类方法继承
  *
  * */
    @Override
    public void onActionUpdate(Object... datas) {

        if(datas.length>0) {
            if (datas[0].getClass().getCanonicalName() == String.class.getCanonicalName()) {
                String sCms = (String) (datas[0]);

                if(sCms.equals(AudioController.RET_RECORD_START))
                {
                    messageHandler.sendEmptyMessage(6);

                }
                else if(sCms.equals(AudioController.RET_RECONGNISE_START))
                {
                    messageHandler.sendEmptyMessage(7);

                }
                else if(sCms.equals(AudioController.RET_RECONGNISE)){
                    String kw = (String) datas[1];
                    if(null!=kw&kw.length()>0){
                        Message message = new Message();
                        message.what = 2;
                        Bundle b = new Bundle();
                        b.putString("kw",kw);
                        message.setData(b);
                        messageHandler.sendMessage(message);
                    }else{
                        messageHandler.sendEmptyMessage(3);
                    }


                }
                else if(sCms.equals(AudioController.RET_RECONGNISE_ERROR)){

                    if(datas[2]!=null){
                        messageHandler.sendEmptyMessage(4);
                    }
                }
                else if(sCms.equals(Page_01301_Controller.RET_UPDATE_POI_TYPE_LIST)){
                    if(datas[1]!=null){
                        POITypeEntity[] types = (POITypeEntity[])datas[1];
                        Message message = new Message();
                        message.what = 8;
                        Bundle b = new Bundle();
                        b.putSerializable("types",types);
                        Log.e(Page_01301_Fragment.class.getCanonicalName(),"POIKind result "+types.length);
                        message.setData(b);
                        messageHandler.sendMessage(message);

                    }
                }
                else if (sCms.equals(Page_02201_Controller.RET_POI)) {
                    //handler.sendEmptyMessage(8);
                    setSearchEnable(true);
                    if(datas.length>1) {
                        showPoi((POISearchResult) datas[1]);
                    }

                }
                else if (sCms.equals(Page_02201_Controller.RET_ERROR)) {
                    setSearchEnable(true);
                    final  String sError=(String)datas[1];
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {


                            showInfoamtion("注意",sError,null);


                        }
                    });
                }
                else
                {
                    if(sCms.equals(BaseController.RET_NEWWORK_DISABLED))
                        setSearchEnable(true);
                    super.onActionUpdate(datas);
                }
            }
        }


    }

    void showPoi(POISearchResult poi)
    {
        hidePopMessage();
        if (requestLocationMessg != null) {
            requestLocationMessg.setReceiver(Page_01401_Fragment.class.getCanonicalName());

            //sendInternalMessage(requestLocationMessg);
            toPage(Page_01401_Fragment.class, requestLocationMessg.toBundle(),poi);

        }
        else
            toPage(Page_01401_Fragment.class, poi);

    }

    // TODO: Rename method, update argument and hook method into UI event
   /* public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }*/

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        //mListener = null;
    }

    @Override
    public void onItemClick(POITypeEntity p) {
        toPOISearch(p, WeNaviDefine.MSG_SEARCH_POI_BY_KIND_CODE);
    }

    @Override
    public void onItemClick(POITypeEntity p, int index) {
        toPOISearch(p, WeNaviDefine.MSG_SEARCH_POI_BY_KIND_CODE);
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    /*public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        public void onFragmentInteraction(Uri uri);
    }*/

    void setSearchEnable(boolean enable)
    {
        mTvBank.setEnabled(enable);
        mBtnBank.setEnabled(enable);
        mTvHospital.setEnabled(enable);
        mBtnHospital.setEnabled(enable);
        mTvHotel.setEnabled(enable);
        mBtnHotel.setEnabled(enable);
        mTvPark.setEnabled(enable);
        mBtnPark.setEnabled(enable);
        mTvPharmacy.setEnabled(enable);
        mBtnPharmacy.setEnabled(enable);
        mTvRestaurant.setEnabled(enable);
        mBtnRestaurant.setEnabled(enable);
        mTvToilet.setEnabled(enable);
        mBtnToilet.setEnabled(enable);
        mTvOther.setEnabled(enable);
        mBtnOther.setEnabled(enable);
        mBtnSeatch.setEnabled(enable);
        if(!enable)
            mBtnSeatch.setText("查询中...");
        else
            mBtnSeatch.setText("搜索");

    }
    private void toPOISearch(POITypeEntity poiType, String kindSearchType){
        //Toast.makeText(this.getActivity(),poiType.getTypeCode(),Toast.LENGTH_SHORT).show();

        setSearchEnable(false);

        WeNaviInternalMessage m=new WeNaviInternalMessage(
                Page_01301_Fragment.this.getClass(),
                Page_01401_Fragment.class,
                kindSearchType,
                null);

       // if(poiType.getTypeCode()!=null && poiType.getTypeCode().length()>0)
            m.setKeyword(poiType.getTypeName());

        PoiSearchParam pm=(PoiSearchParam) getController().getObject(PoiSearchParam.class.getCanonicalName());
        if(pm!=null)
        {
            pm.reset();
            pm.setSearchType(kindSearchType);
            pm.setKindName(poiType.getTypeName());
            pm.setKindCode(poiType.getTypeCode());
            pm.setPageIndex(1);
            pm.setPageRows(Page_01401_Fragment.PAGE_ROWS);
            pm.setRadius(Page_01401_Fragment.DEFAULT_RADIUS);
            pm.setRegion(mAdminCode);

        }

        if (requestLocationMessg != null) {
            requestLocationMessg.setReceiver(Page_01401_Fragment.class.getCanonicalName());

            //sendInternalMessage(requestLocationMessg);
            toPage(Page_01401_Fragment.class, requestLocationMessg.toBundle());

        } else {
            submitAction(Page_01301_Controller.CMD_SEARCH_POI, pm);
        }
    }

    @Override
    protected void onInternalMessage(IMessage m) {

        if (m.getMessageType().equals(WeNaviDefine.MSG_REQUEST_LOCATION))
            requestLocationMessg = m;
        //super.onInternalMessage(m);
    }

    @Override
    public void onResume() {
        Bundle pm = getArguments();
        if (pm != null) {

            WeNaviInternalMessage m = new WeNaviInternalMessage(pm);
            requestLocationMessg = m;
        }

        super.onResume();
    }

}
