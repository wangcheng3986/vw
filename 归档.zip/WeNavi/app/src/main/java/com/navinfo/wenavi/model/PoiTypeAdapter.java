package com.navinfo.wenavi.model;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;

import com.navinfo.wenavi.R;
import com.navinfo.wenavi.activity.WeNaviBaseActivity;
import com.navinfo.wenavi.entity.POITypeEntity;
import com.navinfo.wenavi.util.WeNaviUtil;

/**
 * Created by Doone on 2015/3/18.
 */
public class PoiTypeAdapter extends BaseAdapter {
    private Context mContext = null;
    private POITypeEntity[] mlist = null;
    private IPoiTypeListViewInteractor mPoiTypeListViewInteractor=null;

    public interface IPoiTypeListViewInteractor
    {
        void onItemClick(POITypeEntity p);

        void onItemClick(POITypeEntity p, int index);
    }

    public PoiTypeAdapter(){
        //this.mContext = context;
        //this.mlist = list;
    }

    public void setContext(Context c)
    {
        this.mContext=c;
    }

    public void setPoiTypeListViewInteractor(IPoiTypeListViewInteractor interactor)
    {
        mPoiTypeListViewInteractor=interactor;
    }

    public void setData(POITypeEntity[] list)
    {
        this.mlist = list;
    }

    @Override
    public int getCount() {
        int count = 0;
        if (null != mlist)
        {
            count = mlist.length;
        }
        return count;
    }

    @Override
    public POITypeEntity getItem(int position) {
        POITypeEntity item = null;

        if (null != mlist)
        {
            item = mlist[position];
        }

        return item;
    }

    @Override
    public long getItemId(int position) {

        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        //ViewHolder viewHolder = null;

        if (null == convertView)
        {

            //LayoutInflater mInflater = LayoutInflater.from(mContext);
           // Log.e(this.getClass().getCanonicalName(),"Inflater "+mInflater.hashCode()+ " Context"+mContext.hashCode());

            //convertView = mInflater.inflate(R.layout.page_01301_poisubtypes_item, null);

            //if(convertView!=null) setFontSize((ViewGroup)convertView,getDefaultTextSize());

            AbsListView.LayoutParams pm=new AbsListView.LayoutParams(
                    AbsListView.LayoutParams.MATCH_PARENT,
                    WeNaviUtil.dip2px(mContext, 55));


            LinearLayout layout=new LinearLayout(mContext);
            layout.setOrientation(LinearLayout.HORIZONTAL);
            layout.setLayoutParams(pm);
            layout.setBackgroundResource(R.drawable.p1301_listitem_color);

            Space s=new Space(mContext);
            LinearLayout.LayoutParams pms=new LinearLayout.LayoutParams(
                    WeNaviUtil.dip2px(mContext, 55),
                    WeNaviUtil.dip2px(mContext, 55)
            );
            pms.gravity=Gravity.CENTER;
            s.setLayoutParams(pms);
            layout.addView(s);

            ImageView v=new ImageView(mContext);
            v.setImageResource(R.drawable.ui_01301_bit);
            pms=new LinearLayout.LayoutParams(
                    WeNaviUtil.dip2px(mContext, 8),
                    WeNaviUtil.dip2px(mContext, 8)
            );
            pms.gravity=Gravity.CENTER;
            v.setLayoutParams(pms);
            layout.addView(v);


            s=new Space(mContext);
            pms=new LinearLayout.LayoutParams(
                    WeNaviUtil.dip2px(mContext, 10),
                    WeNaviUtil.dip2px(mContext, 10)
            );
            pms.gravity=Gravity.CENTER;
            s.setLayoutParams(pms);
            layout.addView(s);



            TextView name=new TextView(mContext);
            name.setTextColor(mContext.getResources().getColorStateList(R.drawable.p2401_listitem_white_yellow));
            name.setTextSize(20);
            name.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
            LinearLayout.LayoutParams pm1=new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    WeNaviUtil.dip2px(mContext, 55)
            );
            name.setLayoutParams(pm1);

            name.setTag("name");
            layout.addView(name);

            convertView=layout;
        }


        final POITypeEntity item = getItem(position);
        if (null != item)
        {
            TextView name  = (TextView) convertView.findViewWithTag("name");//.findViewById(R.id.lblListItem);
            name.setText(item.getTypeName());
            convertView.setTag(item);
            WeNaviUtil.updateUiTextSize((WeNaviBaseActivity)mContext,(ViewGroup)convertView);
        }

         convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Object tag=v.getTag();
                if(tag!=null && (tag instanceof POITypeEntity))
                {
                    if(mPoiTypeListViewInteractor!=null)
                        mPoiTypeListViewInteractor.onItemClick((POITypeEntity)tag,position);
                }
            }

        });



        return convertView;
    }

}
