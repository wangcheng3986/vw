package com.navinfo.wenavi.model;



import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;


import com.navinfo.mirrorlink.IMirrorLinkBuilder;
import com.navinfo.mirrorlink.MirrorLinkApplicationContext;

import com.navinfo.sdk.location.NavinfoLocation;
import com.navinfo.sdk.location.NavinfoLocationClient;
import com.navinfo.sdk.location.NavinfoLocationClientOption;
import com.navinfo.sdk.location.NavinfoLocationListener;
import com.navinfo.sdk.mapapi.NIMapManager;

import com.navinfo.sdk.mapapi.map.LocationData;
import com.navinfo.sdk.mapapi.search.SearchSDKInitializer;
import com.navinfo.sdk.mapapi.search.geocode.GeoCodeResult;
import com.navinfo.sdk.mapapi.search.geocode.GeoCoder;
import com.navinfo.sdk.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.navinfo.sdk.mapapi.search.geocode.ReverseGeoCodeOption;
import com.navinfo.sdk.mapapi.search.geocode.ReverseGeoCodeResult;
import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;
import com.navinfo.wenavi.controller.AudioController;
import com.navinfo.wenavi.controller.GisController;
import com.navinfo.wenavi.controller.IController;
import com.navinfo.wenavi.controller.MapViewController;
import com.navinfo.wenavi.controller.NaviController;
import com.navinfo.wenavi.controller.Page_01301_Controller;
import com.navinfo.wenavi.controller.Page_01401_Controller;
import com.navinfo.wenavi.controller.Page_02201_Controller;
import com.navinfo.wenavi.controller.Page_04201_Controller;
import com.navinfo.wenavi.controller.RouteController;
import com.navinfo.wenavi.entity.AppConfig;
import com.navinfo.wenavi.util.WeNaviUtil;
import com.orm.SugarApp;
import com.orm.query.Condition;
import com.orm.query.Select;
import com.tencent.map.geolocation.TencentLocation;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

/**
 * Created by Doone on 2015/1/18.
 */
public class WeNaviApplication extends SugarApp implements IMirrorLinkBuilder{



    private NIMapManager mNIMapManager = null;


    private HashMap<String,IController> mControllers=new HashMap<String,IController>();
    private HashMap<String,IModel> mModels=new HashMap<String,IModel>();
    private List<IController> lsControllers=new ArrayList<IController>();
    private MirrorLinkApplicationContext mMirrorLinkContext=null;

    private Handler mHandler = new Handler(){

        public void handleMessage(final android.os.Message msg) {
            switch (msg.what) {
                case 0:
                {
                    getFirstLocation();
                    //启动时获取行政区列表
                    getModel(Page_02401_Model.class.getCanonicalName());
                }
                break;
                default:
                    break;
            }
        }
    };

    @Override
    public void onCreate(){
        super.onCreate();

        //连接MirrorLink Server
        getMirrorLinkContext().register();

        // 在使用Search SDK 各组间之前初始化 context 信息，传入 ApplicationContext
        SearchSDKInitializer.initialize(this);

        mNIMapManager = new NIMapManager(this);
        mNIMapManager.init();

        //程序运行即开始定位
        /*MapViewController mc=(MapViewController)getController(MapViewController.class.getCanonicalName());
        if(mc!=null)
        {
            mc.openLocation();
            mc.startLocation();
        }*/




        AppConfig c=Repository.getAppConfig("lastLunchTime");

        if(c==null)
        {
            c=new AppConfig();
            c.setParamName("lastLunchTime");
            SimpleDateFormat bartDateFormat =
                    new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            Date date = new Date();
            c.setParamValue(bartDateFormat.format(date));
            c.save();
        }
        else
        {
            //Toast.makeText(this, "上次运行时间:"+c.getParamValue(), Toast.LENGTH_LONG).show();

            SimpleDateFormat bartDateFormat =
                    new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = new Date();
            c.setParamValue(bartDateFormat.format(date));
            c.save();
        }
        //AppConfig cf=AppConfig.find()

        mHandler.sendEmptyMessageDelayed(0,500);
    }

    @Override
    public void onTerminate() {

        Iterator<Entry<String,IController>> iter =  mControllers.entrySet().iterator();
        while (iter.hasNext()) {
            Entry<String,IController> entry =   iter.next();

             IController c = entry.getValue();
            if(c!=null) c.destroy();
          }


        Iterator<Entry<String,IModel>> iterM =  mModels.entrySet().iterator();
        while (iterM.hasNext()) {
            Entry<String,IModel> entry =   iterM.next();

            IModel m = entry.getValue();
            if(m!=null) m.destroy();
        }

        mNIMapManager.destroy();


        super.onTerminate();
    }


    /**
     * 获取首次开机位置
     */
    void getFirstLocation()
    {
        //开始定位
        NavinfoLocationClientOption locOption = new NavinfoLocationClientOption();
        locOption.setLocMode(NavinfoLocationClientOption.LocationMode.Hight_Accuracy);
        locOption.setCoordinateType(NavinfoLocationClientOption.COORDINATE_TYPE_GCJ02);
        locOption.setRequestLevel(NavinfoLocationClientOption.REQUEST_LEVEL_GEO);
        locOption.setMillis(1000);

        final WeNaviModel m=(WeNaviModel)getModel(WeNaviModel.class.getCanonicalName());
        final NavinfoLocationClient mLocClient = m.getLocationClient();
        mLocClient.setLocOption(locOption);
        mLocClient.setNiLocationListener(new NavinfoLocationListener() {
            @Override
            public void onLocationChanged(NavinfoLocation location, int error,
                                          String reason) {

                if (error == TencentLocation.ERROR_OK) {

                    GeoPoint p = new GeoPoint((int) (location.getLatitude() * 3.6E6), (int) (location.getLongitude() * 3.6E6));
                    LocationData locData = m.getLocData();
                    locData.pt = p;
                    //如果不显示定位精度圈，将accuracy赋值为0即可
                    locData.accuracy = location.getAccuracy();
                    mLocClient.stop();

                    getCurrentCity( p);
                }

            }

            @Override
            public void onStatusUpdate(String s, int i, String s2) {

            }
        });

        mLocClient.start();
    }


    /**
     * 获取当前行政区信息
     * @param p
     */
    public void getCurrentCity(GeoPoint p)
    {
        final GeoCoder Search = GeoCoder.newInstance();
        Search.setOnGetGeoCodeResultListener(new OnGetGeoCoderResultListener() {
            @Override
            public void onGetReverseGeoCodeResult(ReverseGeoCodeResult result) {
                //mStartLocation= WeNaviUtil.toLocationString(reverseGeoCodeResult);
                //获取逆地理编码状态码
                if(result.status != 0){


                    return;
                }

                StringBuilder b=new StringBuilder();
                String sCity="";
                String sCityCode="";
                if(result.adminregion!=null)
                {
                    if(result.adminregion.provname!=null)
                    {
                        if(result.adminregion.provname.indexOf("北京")==-1 &&
                                result.adminregion.provname.indexOf("上海")==-1 &&
                                result.adminregion.provname.indexOf("天津")==-1 &&
                                result.adminregion.provname.indexOf("重庆")==-1 )

                            b.append(result.adminregion.provname);
                    }
                    if(result.adminregion.cityname!=null)
                    {
                        b.append(result.adminregion.cityname);

                    }
                    /*if(result.adminregion.distname!=null)
                    {
                        if(b.indexOf(result.adminregion.distname)==-1)
                            b.append(result.adminregion.distname);
                    }*/

                    if(result.adminregion.provcode!=null)
                    {
                        sCityCode=result.adminregion.provcode;
                    }
                    if(result.adminregion.citycode!=null)
                    {
                        sCityCode=result.adminregion.citycode;
                    }
                    /*if(result.adminregion.distcode!=null)
                    {
                        sCityCode=result.adminregion.distcode;
                    }*/
                }

                if(b.length()>0) sCity=b.toString();

                if(sCity!=null && sCityCode!=null)
                {
                    saveCurrentRegion(sCity,sCityCode);
                }

                Search.destroy();


            }

            @Override
            public void onGetGeoCodeResult(GeoCodeResult geoCodeResult) {

            }
        });
        boolean success = Search.reverseGeoCode(new ReverseGeoCodeOption().location(p));
    }



    void  saveCurrentRegion(String sCity,String sCityCode)
    {
        if(sCity!=null && sCity.length()>0) {
            AppConfig c = Repository.getAppConfig("CurrentCity");
            if (c == null) {
                c = new AppConfig();
                c.setParamName("CurrentCity");
                c.setParamValue(sCity);
                c.save();
            } else {
                c.setParamValue(sCity);
                c.save();
            }
        }


        if(sCityCode!=null && sCityCode.length()>0) {
            AppConfig c = Repository.getAppConfig("CurrentCityCode");
            if (c == null) {
                c = new AppConfig();
                c.setParamName("CurrentCityCode");
                c.setParamValue(sCityCode);
                c.save();
            } else {
                c.setParamValue(sCityCode);
                c.save();
            }
        }

    }


    /**
     * 根据类全名创建并返回Controller
     * @param sName Controllerler 类全名
     * @return Controllerler对象
     */
    public IController getController(String sName)
    {
        if(mControllers.containsKey(sName)) return mControllers.get(sName);
        else {
            if (sName.equals(GisController.class.getCanonicalName())) {
                IController c = new GisController(this);
                mControllers.put(GisController.class.getCanonicalName(), c);
                return c;
            } else if (sName.equals(AudioController.class.getCanonicalName())) {
                IController c = new AudioController(this);
                mControllers.put(AudioController.class.getCanonicalName(), c);
                return c;
            }else if (sName.equals(RouteController.class.getCanonicalName())) {
                IController c = new RouteController(this);
                mControllers.put(RouteController.class.getCanonicalName(), c);
                return c;
            }else if (sName.equals(NaviController.class.getCanonicalName())) {
                IController c = new NaviController(this);
                mControllers.put(NaviController.class.getCanonicalName(), c);
                return c;
            }else if (sName.equals(MapViewController.class.getCanonicalName())) {
                IController c = new MapViewController(this);
                mControllers.put(MapViewController.class.getCanonicalName(), c);
                return c;
            }
            else if (sName.equals(Page_02201_Controller.class.getCanonicalName())) {
                IController c = new Page_02201_Controller(this);
                mControllers.put(Page_02201_Controller.class.getCanonicalName(), c);
                return c;
            }//MapViewController //Page_01401_Controller
            else if (sName.equals(Page_01401_Controller.class.getCanonicalName())) {
                IController c = new Page_01401_Controller(this);
                mControllers.put(Page_01401_Controller.class.getCanonicalName(), c);
                return c;
            }
            else if (sName.equals(Page_04201_Controller.class.getCanonicalName())) {
                IController c = new Page_04201_Controller(this);
                mControllers.put(Page_04201_Controller.class.getCanonicalName(), c);
                return c;
            }
            else if (sName.equals(Page_01301_Controller.class.getCanonicalName())) {
                IController c = new Page_01301_Controller(this);
                mControllers.put(Page_01301_Controller.class.getCanonicalName(), c);
                return c;
            }

        }

        /*if (sName == GisController.class.getCanonicalName()) {
            IController c = new GisController(this);
            //mControllers.put(GisController.class.getCanonicalName(), c);
            return c;
        } else if (sName == AudioController.class.getCanonicalName()) {
            IController c = new AudioController(this);
            //mControllers.put(AudioController.class.getCanonicalName(), c);
            return c;
        } else if (sName == NaviController.class.getCanonicalName()) {
            IController c = new NaviController(this);
            //mControllers.put(NaviController.class.getCanonicalName(), c);
            return c;
        }*/
        //lsControllers

        return null;

    }


    /**
     * 根据类全名创建并返回Model
     * @param sName Model类名
     * @return Model对象
     */
    public IModel getModel(String sName)
    {
        if(mModels.containsKey(sName)) return mModels.get(sName);
        else
        {
            if(sName.equals( WeNaviModel.class.getCanonicalName()))
            {
                IModel m=WeNaviModel.getInstance(this);
                m.loadModel();
                mModels.put(WeNaviModel.class.getCanonicalName(),m);
                return m;
            }
            else if(sName.equals(CueWordModel.class.getCanonicalName()))
            {
                IModel m=new CueWordModel(this);
                m.loadModel();
                mModels.put(CueWordModel.class.getCanonicalName(),m);
                return m;

            }
            else if(sName.equals(Page_02401_Model.class.getCanonicalName()))
            {
                IModel m= new Page_02401_Model(this);
                m.loadModel();
                mModels.put(Page_02401_Model.class.getCanonicalName(),m);
                return m;
            }
            else if(sName.equals(POITypeModel.class.getCanonicalName()))
            {
                IModel m= new POITypeModel(this);
                m.loadModel();
                mModels.put(POITypeModel.class.getCanonicalName(),m);
                return m;
            }
        }


        return null;
    }


    @Override
    public MirrorLinkApplicationContext getMirrorLinkContext() {
        if(mMirrorLinkContext==null) mMirrorLinkContext=new MirrorLinkApplicationContext(this);
        return mMirrorLinkContext;
    }
}
