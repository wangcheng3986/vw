package com.navinfo.wenavi.entity;

import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Doone on 2015/2/19.
 * 路径规划参数对象
 */
public class RoutePlanParam {

    private String routeType=null;
    private GeoPoint startPoint=null;
    private GeoPoint endPoint=null;
    private boolean isSimulateNavi=false;
    private ArrayList<GeoPoint> passPoints=null;
    private String startLaocation=null;
    private String endLaocation=null;

    public void reset()
    {
        routeType=null;
        startPoint=null;
        endPoint=null;
        isSimulateNavi=false;
        passPoints=null;
        startLaocation=null;
        endLaocation=null;

    }

    public String getRouteType()
    {
        return routeType;
    }


    public void setRouteType(String sType)
    {
        routeType=sType;
    }


    public GeoPoint getStartPoint()
    {
        return startPoint;
    }


    public void setStartPoint(GeoPoint p)
    {
        startPoint=p;
    }

    public void addPassPoint(GeoPoint p)
    {
        if(passPoints==null) passPoints=new ArrayList<GeoPoint>();
        passPoints.add(p);
    }

    public List<GeoPoint> getPassPoints()
    {
        return passPoints;
    }


    public void clearPassPoints()
    {
        if(passPoints!=null) passPoints.clear();
    }

    public GeoPoint getEndPoint()
    {
        return endPoint;
    }


    public void setEndPoint(GeoPoint p)
    {
        endPoint=p;
    }

    public boolean isSimulateNavi()
    {
        return isSimulateNavi;
    }

    public void setSimulateNavi(boolean bSimula)
    {
        isSimulateNavi=bSimula;
    }

    public String getStartLaocation() {
        return startLaocation;
    }

    public void setStartLaocation(String startLaocation) {
        this.startLaocation = startLaocation;
    }

    public String getEndLaocation() {
        return endLaocation;
    }

    public void setEndLaocation(String endLaocation) {
        this.endLaocation = endLaocation;
    }
}
