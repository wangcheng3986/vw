package com.navinfo.wenavi.util;

/**
 * Created by Doone on 2015/3/21.
 */
public class WeNaviDefine {

    //控制器命令定义

    //控制器应答定义


    //交互消息定义

    public static final String MSG_REQUEST_LOCATION="MSG_REQUEST_LOCATION";

    public static final String MSG_RESPONSE_LOCATION="MSG_REQUEST_LOCATION";


    public static final String MSG_SEARCH_POI_BY_KEYWORD="MSG_SEARCH_POI_BY_KEYWORD";

    public static final String MSG_SEARCH_POI_BY_KIND_NAME ="MSG_SEARCH_POI_BY_KIND_NAME";

    public static final String MSG_SEARCH_POI_BY_KIND_CODE ="MSG_SEARCH_POI_BY_KIND_CODE";

    public static final String MSG_REQUEST_KEYWORD="MSG_REQUEST_KEYWORD";




    public static final int MSG_SET_LISTVIEW_ADAPTOR=1000;

    public static final int MSG_ENABLE_CONTROL=1001;

    public static final int MSG_NETWORK_DISABLE=1002;




}
