package com.navinfo.wenavi.activity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.Log;

import com.navinfo.wenavi.R;

/**
 * 获取气泡图片类
 */
public class PopupView {

    private Drawable mBgLeft;
    private Drawable mBgMiddle;
    private Drawable mBgRight;
    private Paint mPaint = new Paint();//画笔
    private int mHeight = 10;
    private int mMidW;
    private int mScreenW;
    private float mTextSize = 32f;
    private float density;

    public PopupView(Context context) {
        mBgLeft = context.getResources().getDrawable(R.drawable.ui_01401_label_1_left);
        mBgMiddle = context.getResources().getDrawable(R.drawable.ui_01401_label_1_middle);
        mBgRight = context.getResources().getDrawable(R.drawable.ui_01401_label_1_right);
        density = context.getResources().getDisplayMetrics().density;

        mHeight = mBgRight.getIntrinsicHeight();
        mMidW = mBgMiddle.getIntrinsicWidth();

        Log.d("","PopupView"+  mBgMiddle.getIntrinsicHeight() +","+
                mBgLeft.getIntrinsicHeight() );
        if(density <= 1.0){
            mTextSize = 15f;
        }
        else if(density > 1.0f && density <= 1.5f){
            mTextSize = 25f;
        }
        else if (density > 1.5f &&  density <= 2.0f) {
            mTextSize = 38f;
        }
        else if (density > 2.0f && density <= 3.0) {
            mTextSize = 55f;
        }
        else{
            mTextSize = 70f;
        }

        mPaint.setTextSize(mTextSize);
        mPaint.setARGB(255, 0, 0, 0);
        mPaint.setTextAlign(Paint.Align.CENTER);
        mPaint.setAntiAlias(true);
        mPaint.setColor(Color.WHITE);

    }


    private int getFontHeight()
    {
        Paint.FontMetrics fm = mPaint.getFontMetrics();
        return (int) Math.ceil(fm.descent - fm.top) + 2;
    }

    public Bitmap getPopupBitmap(String text) {

        mScreenW = (int)(mPaint.measureText(text) + 20* density);


        Bitmap bitmap = Bitmap
                .createBitmap(
                        mScreenW,
                        mHeight,
                        Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        mBgLeft.setBounds(0, 0, (mScreenW - mMidW)/2 , mHeight);
        mBgMiddle.setBounds((mScreenW - mMidW)/2, 0, (mScreenW - mMidW)/2 + mMidW, mHeight);
        mBgRight.setBounds((mScreenW - mMidW)/2+ mMidW, 0, mScreenW, mHeight);
        mBgLeft.draw(canvas);
        mBgMiddle.draw(canvas);
        mBgRight.draw(canvas);
        canvas.drawText(text, mScreenW/2, (mHeight)/2 +10 ,  mPaint);

        return bitmap;
    }
}
