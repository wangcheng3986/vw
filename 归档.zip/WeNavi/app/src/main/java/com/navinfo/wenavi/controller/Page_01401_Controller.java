package com.navinfo.wenavi.controller;

import android.app.Fragment;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.navinfo.sdk.mapapi.map.ItemizedOverlay;
import com.navinfo.sdk.mapapi.map.LocationData;
import com.navinfo.sdk.mapapi.map.MapView;
import com.navinfo.sdk.mapapi.map.OverlayItem;
import com.navinfo.sdk.mapapi.map.PopupClickListener;
import com.navinfo.sdk.mapapi.map.PopupOverlay;
import com.navinfo.sdk.mapapi.search.core.POIInfo;
import com.navinfo.sdk.mapapi.search.core.POISearchOrderBy;
import com.navinfo.sdk.mapapi.search.core.POISearchSortType;
import com.navinfo.sdk.mapapi.search.poi.POIAdvancedSearchOption;
import com.navinfo.sdk.mapapi.search.poi.POINearbySearchOption;
import com.navinfo.sdk.platform.comapi.basestruct.GeoPoint;
import com.navinfo.wenavi.R;
import com.navinfo.wenavi.activity.IView;
import com.navinfo.wenavi.activity.PopupView;
import com.navinfo.wenavi.util.NIMapUtil;
import com.navinfo.wenavi.util.WeNaviUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.zip.Inflater;

/**
 * Created by Doone on 2015/3/17.
 */
public class Page_01401_Controller extends MapViewController {



    public final static  String CMD_SHOW_POI_OVERLAY="CMD_SHOW_POI_OVERLAY";


    public final static  String CMD_SHOW_POI_POP="CMD_SHOW_POI_POP";


    public final static  String RET_CURRENT_POPITEM="RET_CURRENT_POPITEM";

    public final static  String RET_SHOW_TAP_ITEM = "RET_SHOW_TAP_ITEM";

    //poi overlay
    private MyOverlay mOverlay = null;
    private PopupOverlay pop = null;
    private OverlayItem mCurItem = null;

    //气泡view
    private PopupView mPopupView = null;

    public Page_01401_Controller(Context context) {
        super(context);
        initOverlay();
    }



    @Override
    public void executeAction(Object... actionDatas) {
        if (actionDatas.length > 0) {
            if (actionDatas[0].getClass().equals(String.class)) {
                String sCms = (String) (actionDatas[0]);

                if(sCms.equals(CMD_SHOW_POI_OVERLAY) && actionDatas.length>1)
                {
                    showPoiOverlay((List<POIInfo>) actionDatas[1]);
                }
                else if(sCms.equals(CMD_SHOW_POI_POP) && actionDatas.length>1)
                {
                    showPop((int)actionDatas[1]);
                }
               super.executeAction(actionDatas);
            }
        }
    }

    @Override
    public void onViewPause() {

        mOverlay.removeAll();
        if (pop != null) {
            pop.hidePop();
        }
        getMapView().refresh();

        super.onViewPause();
    }







    private final String LOG_TAG=Page_01401_Controller.class.getCanonicalName();


    private void showPoiOverlay(List<POIInfo> list) {
        if (null != list & list.size() > 0) {
            mOverlay.removeAll();
            pop.hidePop();
            for (POIInfo poiInfo : list) {
                double[] doubles = WeNaviUtil.convertGeo(poiInfo.geo.value);
                GeoPoint p = new GeoPoint((int) (doubles[1] * 3.6E6), (int) (doubles[0] * 3.6E6));

                OverlayItem item1 = new OverlayItem(p, poiInfo.address, poiInfo.name);
                Drawable drawable = getContext().getResources().getDrawable(R.drawable.ui_01401_map_points_normal);
//                WeNaviUtil.dip2px(,25.5);
                //Drawable d = WeNaviUtil.zoomDrawable(drawable, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
                item1.setMarker(drawable);
                mOverlay.addItem(item1);

            }

            getMapView().refresh();
            POIInfo item = list.get(0);
            if (item != null && item.geo != null && item.name != null) {

                //double[] doubles = WeNaviUtil.convertGeo(item.geo.value);
                //GeoPoint p = new GeoPoint((int) (doubles[1] * 3.6E6), (int) (doubles[0] * 3.6E6));

                //submitAction(MapViewController.CMD_SET_MAP_CENTER, p);

                //根据poi结果缩放
                GeoPoint center = mOverlay.getCenter();
                getMapView().getController().setCenter(center);

                int latSpanE6 = mOverlay.getLatSpanE6();
                int lonSpanE6 = mOverlay.getLonSpanE6();
                Log.d("1401","latSpanE6="+latSpanE6+","+lonSpanE6);
                getMapView().getController().zoomToSpan(latSpanE6, lonSpanE6);
            }
        }


    }

    private void showPop(int index)
    {
        if(mOverlay!=null ) mOverlay.onTap(new int[]{index});
    }

    public void initOverlay() {
/**
 * 创建一个popupoverlay
 */
        drawableTap = getContext().getResources().getDrawable(R.drawable.ui_01401_1_map_points_big);
        PopupClickListener popListener = new PopupClickListener() {


            @Override
            public void onClickedPopup(int[] ints) {
                pop.hidePop();
                // if (index == 0) {
                //更新item位置
//                    GeoPoint p = new GeoPoint(mCurItem.getPoint().getLatitudeE6() + 5000,
//                            mCurItem.getPoint().getLongitudeE6() + 5000);
//                    mCurItem.setGeoPoint(p);
//                    mOverlay.updateItem(mCurItem);
//                    mMapView.refresh();
                // } else if (index == 2) {
                //更新图标
//                    mCurItem.setMarker(getResources().getDrawable(R.drawable.nav_turn_via_1));
//                    mOverlay.updateItem(mCurItem);
//                    mMapView.refresh();
                // }

            }
        };
        mOverlay = new MyOverlay(getContext().getResources().getDrawable(R.drawable.icon_poi), getMapView());
        /**
         * 设置overlay的优先级
         */
        mOverlay.setOverlayPriority(15);

        getMapView().getOverlays().add(mOverlay);

        pop = new PopupOverlay(getMapView(), popListener);

        /**
         * 设置pop的优先级
         */
        pop.setOverlayPriority(20);

        getMapView().getOverlays().add(pop);

        /**
         * 刷新地图
         */
        getMapView().refresh();
    }


    private Drawable drawableNormal;
    private Drawable drawableTap;

    public class MyOverlay extends ItemizedOverlay {

        public MyOverlay(Drawable defaultMarker, MapView mapView) {
            super(defaultMarker, mapView);
        }

        public void setAddress(String address) {
            this.address = address;
        }

        private String address = "";


        @Override
        public boolean onTap(int[] index) {



            if (index == null && index.length <= 0) return false;

            OverlayItem item = getItem(index[0]);
            updateView(RET_SHOW_TAP_ITEM,index[0]);

            if(item==null) return  false;
            mCurItem = item;
            getMapView().getController().setCenter(item.getPoint());
            getMapView().getController().setZoom(18);

            Resources res = getContext().getResources();
            //其他全部设置原来红色
            ArrayList<OverlayItem> list = getAllItem();
            for (OverlayItem item1 : list) {
                //Resources resources = Page_01401_Fragment.this.getActivity().getResources();
                Drawable drawable1 = res.getDrawable(R.drawable.ui_01401_map_points_normal);//id为R.drawable.图片名称
                item1.setMarker(drawable1);
                updateItem(item1);
            }

            //id为R.drawable.图片名称
            item.setMarker(drawableTap);
            updateItem(item);

            address = item.getSnippet();

            if (mPopupView == null) {
                mPopupView = new PopupView(mContext);

            }
            pop.showPopup(mPopupView.getPopupBitmap(item.getTitle()), item.getPoint(), mCurItem.getMarker().getIntrinsicHeight());

            updateView(RET_CURRENT_POPITEM,item);
            return true;
        }

        @Override
        public boolean onTap(GeoPoint pt, MapView mMapView) {
            if (pop != null) {
                pop.hidePop();
            }
            return false;
        }
    }



}
