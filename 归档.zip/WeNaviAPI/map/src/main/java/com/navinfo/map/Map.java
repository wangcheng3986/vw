package com.navinfo.map;

import com.navinfo.sdk.mapapi.map.MapView;

/**
 * Created by Doone on 2015/2/3.
 */
public class Map {
    MapView m=null;
}
