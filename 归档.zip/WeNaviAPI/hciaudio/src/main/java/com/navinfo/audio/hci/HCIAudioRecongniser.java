package com.navinfo.audio.hci;

import android.content.Context;
import android.util.Log;

import com.navinfo.audio.AudioRecongniseError;
import com.navinfo.audio.AudioRecongniseStatus;
import com.navinfo.audio.IAudioRecongniseListener;
import com.navinfo.audio.IAudioRecongniser;
import com.sinovoice.hcicloudsdk.android.asr.recorder.ASRRecorder;

import com.sinovoice.hcicloudsdk.common.asr.AsrConfig;
import com.sinovoice.hcicloudsdk.common.asr.AsrGrammarId;
import com.sinovoice.hcicloudsdk.common.asr.AsrInitParam;
import com.sinovoice.hcicloudsdk.common.asr.AsrRecogResult;
import com.sinovoice.hcicloudsdk.recorder.ASRCommonRecorder;
import com.sinovoice.hcicloudsdk.recorder.ASRRecorderListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Doone on 2015/1/26.
 */
public class HCIAudioRecongniser  implements IAudioRecongniser,ASRRecorderListener {


    public final static String CLOUD_NOMAL_MODE="asrcapKey";
    public final static String CLOUD_GRAMMAR_MODE="asrgrammarKey";

    public final static String CLOUD_POI_MODE="asrpoicapKey";


    protected ASRRecorder mAsrRecorder;

    private String grammar=null;

    // 配置识别参数
    private AsrConfig mAsrConfig = null;

    private final static  String TAG=HCIAudioRecongniser.class.getCanonicalName();

    private IAudioRecongniseListener mAudioRecongniseListener=null;

    private boolean mEngineLaunch=false;

    private HCIAudio mHCIAudio=null;

    public HCIAudioRecongniser(HCIAudio audio) {
        mHCIAudio=audio;
    }

    private String mRecongniseMode=CLOUD_NOMAL_MODE;





    @Override
    public void setRecongniseMode(String sMode) {
        //asrcapKey  //asrpoicapKey
        mRecongniseMode=sMode;

    }

    @Override
    public void setEngineMode(String sMode) {

    }


    AsrConfig getAsrConfig()
    {
        // 读取用户的调用的能力
        String capKey =mHCIAudio.getAccountInfo(mRecongniseMode);

        // 配置识别参数
        AsrConfig iAsrConfig = new AsrConfig();
        // PARAM_KEY_CAP_KEY 设置使用的能力
        iAsrConfig.addParam(AsrConfig.PARAM_KEY_CAP_KEY, capKey);
        // PARAM_KEY_AUDIO_FORMAT 音频格式根据不同的能力使用不用的音频格式
        iAsrConfig.addParam(AsrConfig.PARAM_KEY_AUDIO_FORMAT,
                AsrConfig.HCI_ASR_AUDIO_FORMAT_PCM_16K16BIT);
        // PARAM_KEY_ENCODE 音频编码压缩格式，使用OPUS可以有效减小数据流量
        iAsrConfig.addParam(AsrConfig.PARAM_KEY_ENCODE, "speex");


        iAsrConfig.addParam(AsrConfig.PARAM_KEY_DOMAIN, "siwei");

        //*
        // 你把realtime=yes给去掉，或者给改为no
        //asr.cloud.grammar这个不支持实时识别
        //在前面设置这个为yes,如果是grammar识别的时候设置为no
        // *
        iAsrConfig.addParam(AsrConfig.PARAM_KEY_REALTIME, "yes");
        // 语法相关的配置,若使用自由说能力可以不必配置该项
        if (capKey.contains("grammar")) {
            // grammar = mHCIAudio.loadGrammar("wordlist_utf8.txt");

            AsrGrammarId id = new AsrGrammarId();
            id.setGrammarId(10001);
            // mAsrRecorder.loadGrammar("grammarType=wordlist", grammar, id);

            // PARAM_KEY_GRAMMAR_TYPE 语法类型，使用自由说能力时，忽略以下此参数
            iAsrConfig.addParam(AsrConfig.PARAM_KEY_GRAMMAR_TYPE,
                    AsrConfig.HCI_ASR_GRAMMAR_TYPE_ID);
            iAsrConfig.addParam(AsrConfig.PARAM_KEY_GRAMMAR_ID,
                    "" + id.getGrammarId());
            iAsrConfig.addParam(AsrConfig.PARAM_KEY_REALTIME, "no");

        }

        return iAsrConfig;

    }



    @Override
    public void startRecongnise(IAudioRecongniseListener l) {

        stop();
        mAudioRecongniseListener=l;
        if(!mEngineLaunch) launch();



        if(!mEngineLaunch)
        {

            onError(AudioRecongniseError.RECONGNISE_ERROR_ENGINE_UNLAUNCH,0,"识别引擎启动失败");
            return;
        }

        if (mAsrRecorder.getRecorderState() == ASRRecorder.RECORDER_STATE_IDLE) {
            //mAsrConfig.addParam(AsrConfig.PARAM_KEY_REALTIME, "no");
            //mAsrConfig.addParam(AsrConfig.PARAM_KEY_REALTIME, "yes");
            mAsrRecorder.start(getAsrConfig().getStringConfig(),grammar );
        } else {
            Log.e("recorder", "录音机未处于空闲状态，请稍等");

            onError(AudioRecongniseError.RECONGNISE_ERROR_ENGINE_BUSY,0,"录音机忙");
            return;
        }

    }





    @Override
    public void launch() {

        if(mEngineLaunch) return;
//        if(null==mHCIAudio) return;
//        if(null!=mHCIAudio){
//            if(mHCIAudio.isEngineLaunch()){
//                return;
//            }
//        }

        if(!mHCIAudio.isEngineLaunch()) return;

        // 读取用户的调用的能力
        String capKey =mHCIAudio.getAccountInfo(mRecongniseMode);
        if (capKey == null) {
            Log.i(TAG, "capKey is null , please check it!");
            return;
        }

        Log.i(TAG, "capKey: " + capKey.toString());

        //mHCIAudio
        // 判断capkey是否可用
        if (!mHCIAudio.isCapKeyEnable(capKey)) {
            Log.e(TAG, "capKey is not enabel: " + capKey.toString());
            // 由于系统已经初始化成功,在结束前需要调用方法hciRelease()进行系统的反初始化

            return;
        }
        // 初始化录音机
        mAsrRecorder = new ASRRecorder();

        // 配置初始化参数
        AsrInitParam asrInitParam = new AsrInitParam();
        String asrDirPath = mHCIAudio.getBaseContext().getFilesDir().getPath().replace("files", "lib");
        asrInitParam.addParam(AsrInitParam.PARAM_KEY_INIT_CAP_KEYS, capKey);
        asrInitParam.addParam(AsrInitParam.PARAM_KEY_DATA_PATH, asrDirPath);
        asrInitParam.addParam(AsrInitParam.PARAM_KEY_FILE_FLAG, "android_so");
        Log.v(TAG, "init parameters:" + asrInitParam.getStringConfig());

        // 设置初始化参数
        mAsrRecorder.init(asrInitParam.getStringConfig(),
                this);



        mEngineLaunch=true;


    }

    @Override
    public void stop() {
     if(mAsrRecorder!=null) mAsrRecorder.cancel();

    }


    @Override
    public void destroy() {
        if(mEngineLaunch) mAsrRecorder.release();
        mEngineLaunch=false;
    }

    String toEventString(ASRCommonRecorder.RecorderEvent event)
    {
        String sText=null;
        switch (event) {
            case RECORDER_EVENT_BEGIN_RECOGNIZE:
                sText = "开始识别";
                break;

            case RECORDER_EVENT_BEGIN_RECORD:
                sText = "录音开始";
                break;
            case RECORDER_EVENT_DEVICE_ERROR:
                sText = "设备出错";
                break;
            case RECORDER_EVENT_END_RECORD:
                sText = "录音完毕";
                break;
            case RECORDER_EVENT_ENGINE_ERROR:
                sText = "引擎出错";
                break;
            case RECORDER_EVENT_HAVING_VOICE:
                sText = "听到声音";
                break;
            case RECORDER_EVENT_NO_VOICE_INPUT:
                sText = "没有听到声音";
                break;
            case RECORDER_EVENT_RECOGNIZE_COMPLETE:
                sText = "识别完毕";
                break;
            case RECORDER_EVENT_RECOGNIZE_PROCESS:
                sText = "识别中间结果";
                break;
            case RECORDER_EVENT_VOICE_BUFFER_FULL:
                sText = "音频缓冲区满";
                break;
        }

        return sText;

    }

    void onError(AudioRecongniseError e,int errCode,String sError)
    {
        this.stop();
        if(null!=mAudioRecongniseListener)
        {
            Log.i(TAG,"RECORDER_EVENT_NO_VOICE_INPUT");

            mAudioRecongniseListener.onError(e,errCode,sError);

        }
    }


    void onStatusCheanged(AudioRecongniseStatus s)
    {

        if(null!=mAudioRecongniseListener)
        {
            Log.i(TAG,"onStatusCheanged");
            mAudioRecongniseListener.onStatusChanged(s);

        }
    }


    void onRecongnised(String sResult)
    {

        if(null!=mAudioRecongniseListener)
        {
            Log.i(TAG,"onRecongnised="+sResult);
            mAudioRecongniseListener.onRecongnised(sResult);

        }
    }

    //ASRRecorderListener
    @Override
    public void onRecorderEventStateChange(ASRCommonRecorder.RecorderEvent recorderEvent) {

        AudioRecongniseStatus s=AudioRecongniseStatus.RECONGNISE_NOSTATUS;
        if (recorderEvent == ASRCommonRecorder.RecorderEvent.RECORDER_EVENT_BEGIN_RECORD) {
            Log.i(TAG,"RECORDER_EVENT_BEGIN_RECORD");
            s=AudioRecongniseStatus.RECONGNISE_START_RECORD;
        } else if (recorderEvent == ASRCommonRecorder.RecorderEvent.RECORDER_EVENT_BEGIN_RECOGNIZE) {
            Log.i(TAG,"RECORDER_EVENT_BEGIN_RECOGNIZE");
            s=AudioRecongniseStatus.RECONGNISE_START_RECONGNISE;
        } else if (recorderEvent == ASRCommonRecorder.RecorderEvent.RECORDER_EVENT_NO_VOICE_INPUT) {
            Log.i(TAG,"RECORDER_EVENT_NO_VOICE_INPUT");

            onError(AudioRecongniseError.RECONGNISE_ERROR_NOINPUT,0,toEventString(recorderEvent));
            return;
        }

        onStatusCheanged(s);



       // Message m = mUIHandle.obtainMessage(1, 1, 1, sState);
       // mUIHandle.sendMessage(m);

    }

    @Override
    public void onRecorderEventRecogFinsh(ASRCommonRecorder.RecorderEvent recorderEvent, AsrRecogResult asrRecogResult) {

        if (recorderEvent == ASRCommonRecorder.RecorderEvent.RECORDER_EVENT_RECOGNIZE_COMPLETE) {
            //String sState = "状态为：识别结束";
            //Message m = mUIHandle.obtainMessage(1, 1, 1, sState);
            //mUIHandle.sendMessage(m);
            Log.i(TAG,"ASRCommonRecorder.RecorderEvent.RECORDER_EVENT_RECOGNIZE_COMPLETE");
            onStatusCheanged(AudioRecongniseStatus.RECONGNISE_RECONGNISE_FINISHED);

        }
        if (asrRecogResult != null) {
            String sResult;
            if (asrRecogResult.getRecogItemList().size() > 0) {
                sResult =  asrRecogResult.getRecogItemList().get(0).getRecogResult();
                Log.i(TAG,"asrRecogResult.getRecogItemList().size() > 0");
                onRecongnised(sResult);

            } else {
                Log.i(TAG,"asrRecogResult.getRecogItemList().size() <= 0");

                onError(AudioRecongniseError.RECONGNISE_ERROR_FAIL,0,"识别失败");

            }
            //Message m = mUIHandle.obtainMessage(1, 2, 1, sResult);
            //mUIHandle.sendMessage(m);
        }

    }

    @Override
    public void onRecorderEventRecogProcess(ASRCommonRecorder.RecorderEvent recorderEvent, AsrRecogResult asrRecogResult) {

        //asrRecogResult.


    }

    @Override
    public void onRecorderEventError(ASRCommonRecorder.RecorderEvent recorderEvent, int i) {
       // String sError = "错误码为：" + i;
        Log.i(TAG,"onRecorderEventError,错误码为"+i);

        Log.e(TAG,"recorderEvent.name()="+recorderEvent.name()+",recorderEvent.toString()="+recorderEvent.toString());
        onError(AudioRecongniseError.RECONGNISE_ERROR_ENGINE_ERROR,i,toEventString(recorderEvent));

    }

    @Override
    public void onRecorderRecording(byte[] bytes, int i) {

    }
}
