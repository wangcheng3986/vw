package com.navinfo.audio.pq;

import android.content.Context;
import android.media.AudioManager;
import android.util.Log;

import com.navinfo.audio.IAudioGenerateListerner;
import com.navinfo.audio.IAudioGenerator;
import com.pachira.tts.control.ITTSControl;
import com.pachira.tts.control.OfflineTTS;
import com.pachira.tts.control.TTSPlayerListener;

/**
 * Created by Doone on 2015/3/16.
 */
public class PQAudioGenerator implements IAudioGenerator,TTSPlayerListener {

    private static final String LOG_TAG=PQAudioGenerator.class.getCanonicalName();
    ITTSControl mTTSPlayer ;

    Context mContext=null;

    private boolean mEngineLaunch=false;

    IAudioGenerateListerner mAudioGenerateListerner=null;

    public PQAudioGenerator(Context c,float fVolume) {
        mContext = c;
        //音量控制,初始化定义
        AudioManager mAudioManager = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);

        //最大音量
        int maxVolume = mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

        int nVolume=(int)(maxVolume*fVolume);

        //当前音量
        int currentVolume = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);

        if(currentVolume<nVolume)
            mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC,nVolume,0);
    }


    public Context getContext()
    {
        return mContext;
    }

    @Override
    public void setEngineMode(String sMode) {

    }

    @Override
    public void play(String sText, IAudioGenerateListerner l) {
        if(!mEngineLaunch) launch();
        mAudioGenerateListerner=l;
        if(mTTSPlayer!=null) mTTSPlayer.play(sText);
        Log.d(LOG_TAG,"play:"+sText);
    }

    @Override
    public void pause() {
        if(mTTSPlayer!=null) mTTSPlayer.pause();
        Log.d(LOG_TAG,"TTSPlayer pause called");
    }

    @Override
    public void resume() {
        //if(mTTSPlayer!=null) mTTSPlayer.
    }

    @Override
    public void launch() {
        if(mEngineLaunch) return;

        if(mContext!=null) {

            mTTSPlayer = OfflineTTS.getInstance();
            mTTSPlayer.initTTSEngine(mContext);
            mTTSPlayer.setTTSListener(this);
            mEngineLaunch=true;

            Log.d(LOG_TAG,"TTSPlayer initTTSEngine OK");

        }
    }

    @Override
    public void stop() {
        if(mTTSPlayer!=null) mTTSPlayer.stop();
        Log.d(LOG_TAG,"TTSPlayer stop called");

    }

    @Override
    public void destroy() {
        if(mTTSPlayer!=null) mTTSPlayer.releaseTTSEngine();
        mEngineLaunch=false;
        Log.d(LOG_TAG,"TTSPlayer releaseTTSEngine called");

    }


    @Override
    public void onBuffer() {
        Log.d(LOG_TAG,"TTSPlayer onBuffer called");
    }

    @Override
    public void onPlayBegin() {
        Log.d(LOG_TAG,"TTSPlayer onPlayBegin called");
    }

    @Override
    public void onEnd() {
        Log.d(LOG_TAG,"TTSPlayer onEnd called");
        if(mAudioGenerateListerner!=null) mAudioGenerateListerner.onPlayFinished();
    }
}
