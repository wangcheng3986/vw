package com.navinfo.audio.pq;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.navinfo.audio.AudioRecongniseError;
import com.navinfo.audio.AudioRecongniseStatus;
import com.navinfo.audio.IAudioRecongniseListener;
import com.navinfo.audio.IAudioRecongniser;
import com.pachira.common.Common;
import com.pachira.common.QianyuInterface;
import com.pachira.common.Response;
import com.pachira.common.SRResultList;
import com.pachira.common.SharedConstants;
import com.pachira.common.SRResult;
import com.pachira.platform.QianyuSystem;
import com.pachira.platform.StreamingAudio;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

/**
 * Created by Doone on 2015/3/5.
 */
public class PQAudioRecongniser   implements IAudioRecongniser,QianyuInterface {

    private static final String TAG=PQAudioRecongniser.class.getCanonicalName();


    private int mApplicationID=1;


    protected Context mContext=null;
    private boolean mEngineLaunch=false;
    private IAudioRecongniseListener mAudioRecongniseListener=null;


    StreamingAudio mStreamAudio=null;

    Timer mTimmer=null;


    public Context getBaseContext()
    {
        return mContext;
    }

    /*
   * 保存用户登录信息以及使用能力的Map; 该Map中的Item由一对字符串组成,分别表示用户登录信息的名称和值 如: 对于配置文件中的
   * developerId=13一项 键值对会以 key是developerId, value是13的形式存入(代码:
   * map.put("developerId", "13"))
   */
    protected Map<String, String> mAccountInfo = null;



    public PQAudioRecongniser(Context context)
    {
        mContext=context;
    }


    /**
     * 加载用户的注册信息
     *
     * @param fileName
     * @throws java.io.IOException
     */
    protected void loadAccountInfo(String fileName) throws IOException {
        if (mAccountInfo == null) {
            mAccountInfo = new HashMap<String, String>();
        }

        InputStream in = null;
        in = mContext.getResources().getAssets().open(fileName);
        InputStreamReader inputStreamReader = new InputStreamReader(in, "gbk");
        BufferedReader br = new BufferedReader(inputStreamReader);
        String temp = null;
        String[] sInfo = new String[2];
        temp = br.readLine();
        while (temp != null) {
            if (!temp.startsWith("#") && !temp.equalsIgnoreCase("")) {
                sInfo = temp.split("=");
                if (sInfo.length == 2)
                    mAccountInfo.put(sInfo[0], sInfo[1]);
            }
            temp = br.readLine();
        }
    }


    /**
     * 加载账户信息
     *
     * @return true 成功
     */
    protected boolean GetAccountInfo() {
        // 加载用户的初始化信息,平台id,开发者id等等
        // 用户应用自己的信息将asset文件夹中的文件PQAccountInfo.txt填充完整
        try {
            loadAccountInfo("PQAccountInfo.txt");
        } catch (IOException e) {
            e.printStackTrace();
            // 读取错误,通知界面并返回
            Log.e(TAG, "load account info error");
            return false;
        }
        return true;
    }



    public String getAccountInfo(String sKey)
    {
        return mAccountInfo.get(sKey);
    }



    @Override
    public void setRecongniseMode(String sMode) {

    }

    @Override
    public void setEngineMode(String sMode) {

    }

    @Override
    public void startRecongnise(IAudioRecongniseListener l) {

        if(!mEngineLaunch) launch();

        stop();

        mAudioRecongniseListener=l;


        //kid
        // appId：即初始化QianyuSystem时，传入的applicationId

        int kID=Integer.parseInt(getAccountInfo("keywordListId"));

        mAudioRecongniseListener=l;
        mStreamAudio = new StreamingAudio(mContext,this,kID,mApplicationID);
        mStreamAudio.startRecording();

        mTimmer = new Timer();
        mTimmer.schedule(new timerOutTak(),20000);

    }


    class timerOutTak extends TimerTask {

        @Override
        public void run() {
            if(mAudioRecongniseListener!=null)
                mAudioRecongniseListener.onError(AudioRecongniseError.RECONGNISE_ERROR_NOINPUT,0,"识别超时,请重新尝试");

           stop();
        }

    }



    @Override
    public void launch() {

        if(mEngineLaunch) return;
         /*
		 * 从文件assets/AccountInfo.txt获取从捷通分配的应用账号信息
		 * strAccountInfo形如："appKey=##,developerKey=###,cloudUrl=###"
		 * 用户实际使用时可直接使用一个字符串代替 *
		 */
        boolean bRet = GetAccountInfo();
        if (!bRet) {
            Log.e(TAG, "GetAccountInfo error: ");
            return ;
        }
        mApplicationID=Integer.parseInt(getAccountInfo("appKey"));
        String sIP=getAccountInfo("cloudUrl");
        int recordTimeout=Integer.parseInt(getAccountInfo("recordTimeout"));
        int accurateScore=Integer.parseInt(getAccountInfo("accurateScore"));
        int silenceTimeout=Integer.parseInt(getAccountInfo("silenceTimeout"));

        Log.i(TAG,"Call QianyuSystem Params: AppID="+mApplicationID+" IP:"+sIP+" recordTimeout:"+recordTimeout+
        " accurateScore="+accurateScore+" silenceTimeout="+silenceTimeout);

        QianyuSystem sys=new QianyuSystem(mApplicationID,sIP,getBaseContext(), recordTimeout,accurateScore,silenceTimeout);
        sys.initSystemByContext();
        mEngineLaunch=true;

    }





    @Override
    public void stop() {
        if(mStreamAudio!=null) {
            mStreamAudio.stopAll(false, 0);
            mStreamAudio = null;
        }
        if(mTimmer!=null) {
            mTimmer.cancel();
            mTimmer = null;
        }

        mAudioRecongniseListener=null;

    }

    @Override
    public void destroy() {

    }

    //=============================================================================

    @Override
    public void onSetState(int i) {
        if(mAudioRecongniseListener!=null)
        {
            Log.i(TAG,"onSetState: "+i);
            if(i== Common.RECORDING) {
                mAudioRecongniseListener.onStatusChanged(AudioRecongniseStatus.RECONGNISE_START_RECORD);
                Log.i(TAG,"onSetState: Common.RECORDING" );
            }
            else if(i== Common.PROCESS) {
                mAudioRecongniseListener.onStatusChanged(AudioRecongniseStatus.RECONGNISE_START_RECONGNISE);
                Log.i(TAG,"onSetState: Common.PROCESS" );
            }
            else if(i== Common.RESULT) {
                mAudioRecongniseListener.onStatusChanged(AudioRecongniseStatus.RECONGNISE_RECONGNISE_FINISHED);
                Log.i(TAG,"onSetState: Common.RESULT" );
            }

        }


    }

    @Override
    public void onSetCurrentEnergy(int i) {

    }

    @Override
    public void onShowSRResult(Response response, boolean b) {

        if (response.getState() != SharedConstants.CALL_RET_VALUE_SUCCESS_INT) {
            return;
        }

        SRResultList lsResult = (SRResultList) response.getResult();
        if(lsResult!=null && lsResult.getSize()>0)
        {
            String sText=lsResult.getSRResult(0).getResult();
            Log.i(TAG,"onShowSRResult: "+sText);
            if(mAudioRecongniseListener!=null)
                mAudioRecongniseListener.onRecongnised(sText);
            stop();
        }




    }

    @Override
    public void onShowProgress() {


    }

    @Override
    public void onShowError(String s) {
        Log.e(TAG,"onShowError: "+s);
        stop();
        if(mAudioRecongniseListener!=null)
            mAudioRecongniseListener.onError(AudioRecongniseError.RECONGNISE_ERROR_FAIL,0,s);

    }

    @Override
    public void onShowAnimation() {

    }

    @Override
    public void onShowRecordUI() {

    }

    @Override
    public void onShowFinishBtn() {

    }
}
