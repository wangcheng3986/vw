package com.navinfo.audio;

/**
 * Created by Doone on 2015/1/23.
 * 语音识别合成回调接口
 */
public interface IAudioGenerateListerner {

    /**
     * 合成失败
     * @param sError 错误信息
     */
    public void onError(String sError);

    /**
     * 播放完毕
     */
    public void onPlayFinished();
}
