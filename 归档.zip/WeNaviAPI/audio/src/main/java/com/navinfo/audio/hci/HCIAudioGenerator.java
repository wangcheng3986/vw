package com.navinfo.audio.hci;

import android.content.Context;
import android.media.AudioManager;
import android.os.Environment;
import android.util.Log;

import com.navinfo.audio.IAudioGenerateListerner;
import com.navinfo.audio.IAudioGenerator;
import com.sinovoice.hcicloudsdk.android.tts.player.TTSPlayer;
import com.sinovoice.hcicloudsdk.common.asr.AsrInitParam;
import com.sinovoice.hcicloudsdk.common.hwr.HwrInitParam;
import com.sinovoice.hcicloudsdk.common.tts.TtsConfig;
import com.sinovoice.hcicloudsdk.common.tts.TtsInitParam;
import com.sinovoice.hcicloudsdk.player.TTSCommonPlayer;
import com.sinovoice.hcicloudsdk.player.TTSPlayerListener;

import java.io.File;

/**
 * Created by Doone on 2015/1/23.
 */
public class HCIAudioGenerator  implements IAudioGenerator,TTSPlayerListener {

    public int TTSPLAY_DEFAULT = 0;
    public int TTSPLAY_NORMAL = 1;
    public int TTSPLAY_PAUSE = 2;
    public int TTSPLAY_STOP = 3;

    private int ttsPlayState = TTSPLAY_DEFAULT;


    private TTSPlayer mTtsPlayer = null;

    private final static  String TAG=HCIAudioGenerator.class.getCanonicalName();

    public final String SDCARD_PATH = Environment.getExternalStorageDirectory()
            .getAbsolutePath();
    private static final String COMPONEY_FOLDER = "HciCloudTtsPlayerExample";
    private static final String APP_FOLDER = "HciCloudTtsPlayerExample";
    private static final String LOG_FOLDER = "log";
    private static final String FOLDER_SEP = File.separator;

    private boolean mEngineLaunch=false;
    private HCIAudio mHCIAudio=null;
    private TtsConfig mTtsConfig = null;
    private IAudioGenerateListerner mAudioGenerateListerner=null;

    /**
     * 构造函数
     * @param audio {@link HCIAudio}
     * @param fVolume 0~1
     */
    public HCIAudioGenerator(HCIAudio audio,float fVolume){
        mHCIAudio=audio;
        //音量控制,初始化定义
        AudioManager mAudioManager = (AudioManager) mHCIAudio.getBaseContext().getSystemService(Context.AUDIO_SERVICE);

        //最大音量
        int maxVolume = mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

        int nVolume=(int)(maxVolume*fVolume);

        //当前音量
        int currentVolume = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);

        if(currentVolume<nVolume)
            mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC,nVolume,0);


    }

    @Override
    public void setEngineMode(String sMode) {

    }

    @Override
    public void play(String sText,IAudioGenerateListerner l) {

        mAudioGenerateListerner=l;
        if(!mEngineLaunch) launch();

        if (mTtsPlayer.getPlayerState() == TTSCommonPlayer.PLAYER_STATE_PLAYING
                || mTtsPlayer.getPlayerState() == TTSCommonPlayer.PLAYER_STATE_PAUSE) {
            mTtsPlayer.stop();
        }

        if (mTtsPlayer.getPlayerState() == TTSCommonPlayer.PLAYER_STATE_IDLE) {
            mTtsPlayer.play(sText, mTtsConfig.getStringConfig());
        }
    }

    @Override
    public void pause() {
        if (mTtsPlayer != null) {
            try {
                //暂停
                if (mTtsPlayer.getPlayerState() == TTSCommonPlayer.PLAYER_STATE_PLAYING) {
                    //ttsPlayState = TTSPLAY_PAUSE;
                    mTtsPlayer.pause();
                }
            }
            catch (IllegalStateException ex) {
            }
        }

    }

    @Override
    public void resume() {
        if (mTtsPlayer != null) {
            try {
                //恢复播放
                if (mTtsPlayer.getPlayerState() == TTSCommonPlayer.PLAYER_STATE_PAUSE) {
                    mTtsPlayer.resume();
                    //ttsPlayState = TTSPLAY_NORMAL;
                }
            }
            catch (IllegalStateException ex) {
            }
        }

    }

    @Override
    public void launch() {
        if(mEngineLaunch) return;

        // 读取用户的调用的能力
        String capKey =mHCIAudio.getAccountInfo("ttscapKey");
        if (capKey == null) {
            Log.i(TAG, "capKey is null , please check it!");

            return;
        }

        //mHCIAudio
        // 判断capkey是否可用
        if (!mHCIAudio.isCapKeyEnable(capKey)) {
            Log.e(TAG, "capKey is not enabel: " + capKey.toString());
            // 由于系统已经初始化成功,在结束前需要调用方法hciRelease()进行系统的反初始化

            return;
        }

        mTtsPlayer = new TTSPlayer();

        TtsInitParam ttsInitParam = new TtsInitParam();
        String dataPath = mHCIAudio.getBaseContext().getFilesDir().getAbsolutePath().replace("files", "lib");

        ttsInitParam.addParam(TtsInitParam.PARAM_KEY_DATA_PATH, dataPath);
        ttsInitParam.addParam(AsrInitParam.PARAM_KEY_INIT_CAP_KEYS,capKey);
        ttsInitParam.addParam(HwrInitParam.PARAM_KEY_FILE_FLAG, "android_so");

        mTtsPlayer.init(ttsInitParam.getStringConfig(),this);

        mEngineLaunch=(mTtsPlayer.getPlayerState() == TTSPlayer.PLAYER_STATE_IDLE);


        mTtsConfig = new TtsConfig();
        mTtsConfig.addParam(TtsConfig.PARAM_KEY_AUDIO_FORMAT, "pcm16k16bit");
        mTtsConfig.addParam(TtsConfig.PARAM_KEY_CAP_KEY,capKey);
        mTtsConfig.addParam(TtsConfig.PARAM_KEY_SPEED, "5");

        return;

    }



    @Override
    public void stop() {
        if (mTtsPlayer != null && mTtsPlayer.canStop()) {
            try {
                //暂停
                //ttsPlayState = TTSPLAY_STOP;

                mTtsPlayer.stop();
            }
            catch (IllegalStateException ex) {
            }
        }

    }

    @Override
    public void destroy() {
        if (mTtsPlayer != null && mEngineLaunch)
            mTtsPlayer.release();
    }

    @Override
    public void onPlayerEventStateChange(TTSCommonPlayer.PlayerEvent playerEvent) {
        if(playerEvent==TTSCommonPlayer.PlayerEvent.PLAYER_EVENT_END)
        {
            if(mAudioGenerateListerner!=null) mAudioGenerateListerner.onPlayFinished();
        }

    }


    @Override
    public void onPlayerEventProgressChange(TTSCommonPlayer.PlayerEvent playerEvent, int i, int i2) {

    }

    @Override
    public void onPlayerEventPlayerError(TTSCommonPlayer.PlayerEvent playerEvent, int i) {
        if(mAudioGenerateListerner!=null) mAudioGenerateListerner.onError(playerEvent.toString()+" Code:"+i);

    }
}
