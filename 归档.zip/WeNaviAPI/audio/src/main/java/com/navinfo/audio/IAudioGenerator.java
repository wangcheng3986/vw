package com.navinfo.audio;

/**
 * Created by Doone on 2015/1/23.
 * 语音合成接口
 */
public interface IAudioGenerator extends IEngine {


    /**
     * 引擎模式定义
     */
    public static class EngineMode {
        /**
         * 本地引擎
         */
        public static final  String LOCALENGINE ="LOCALENGINE";

        /**
         * 云端引擎
         */
        public static final  String CLOUDENGINE="CLOUDENGINE";
    }

    /**
     * 设置引擎模式
     * @param sMode
     */
    public void setEngineMode(String sMode);

    /**
     * 合成语音并播放
     * @param sText 合成内容
     */
    public void play(String sText,IAudioGenerateListerner l);


    /**
     * 暂停播放
     */
    public void pause();

    /**
     * 恢复播放
     */
    public void resume();

    /**
     * 停止播放
     */
    public void stop();

}
