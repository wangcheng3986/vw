package com.navinfo.audio.hci;

import android.content.Context;
import android.util.Log;

import com.navinfo.audio.AudioRecongniseError;
import com.navinfo.audio.AudioRecongniseStatus;
import com.navinfo.audio.IAudioRecongniseListener;
import com.navinfo.audio.IAudioRecongniser;
import com.sinovoice.hcicloudsdk.android.asr.recorder.ASRRecorder;
import com.sinovoice.hcicloudsdk.api.HciCloudSys;
import com.sinovoice.hcicloudsdk.common.HciErrorCode;
import com.sinovoice.hcicloudsdk.common.InitParam;
import com.sinovoice.hcicloudsdk.common.asr.AsrConfig;
import com.sinovoice.hcicloudsdk.common.asr.AsrGrammarId;
import com.sinovoice.hcicloudsdk.common.asr.AsrInitParam;
import com.sinovoice.hcicloudsdk.common.asr.AsrRecogResult;
import com.sinovoice.hcicloudsdk.recorder.ASRCommonRecorder;
import com.sinovoice.hcicloudsdk.recorder.ASRRecorderListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Doone on 2015/1/26.
 */
public class HCIAudioRecongniser  implements IAudioRecongniser,ASRRecorderListener {


    public final static String CLOUD_NOMAL_MODE="asrcapKey";


    public final static String CLOUD_POI_MODE="asrpoicapKey";


    protected ASRRecorder mAsrRecorder;

    private String grammar=null;

    // 配置识别参数
    private AsrConfig mAsrConfig = null;

    private final static  String TAG=HCIAudioRecongniser.class.getCanonicalName();

    private List<IAudioRecongniseListener> mAudioRecongniseListeners=null;

    private boolean mEngineLaunch=false;

    private HCIAudio mHCIAudio=null;

    public HCIAudioRecongniser(HCIAudio audio) {
        mHCIAudio=audio;
    }

    private String mRecongniseMode=CLOUD_NOMAL_MODE;





    @Override
    public void setRecongniseMode(String sMode) {
        //asrcapKey  //asrpoicapKey
        mRecongniseMode=sMode;

    }

    @Override
    public void setEngineMode(String sMode) {

    }

    @Override
    public void startRecongnise(IAudioRecongniseListener l) {

        addResultListener(l);
        if(!mEngineLaunch) launch();
        if(!mEngineLaunch)
        {
            onError(AudioRecongniseError.RECONGNISE_ERROR_ENGINE_UNLAUNCH,0);
            return;
        }

        if (mAsrRecorder.getRecorderState() == ASRRecorder.RECORDER_STATE_IDLE) {
            //mAsrConfig.addParam(AsrConfig.PARAM_KEY_REALTIME, "no");
            //mAsrConfig.addParam(AsrConfig.PARAM_KEY_REALTIME, "yes");
            mAsrRecorder.start(mAsrConfig.getStringConfig(),grammar );
        } else {
            Log.e("recorder", "录音机未处于空闲状态，请稍等");
            onError(AudioRecongniseError.RECONGNISE_ERROR_ENGINE_BUSY,0);
            return;
        }

    }


    void addResultListener(IAudioRecongniseListener l) {
        if(mAudioRecongniseListeners==null)
            mAudioRecongniseListeners=new ArrayList<IAudioRecongniseListener>();

        mAudioRecongniseListeners.clear();
        if(mAudioRecongniseListeners!=null && !mAudioRecongniseListeners.contains((l)))
            mAudioRecongniseListeners.add(l);

    }


    @Override
    public void launch() {

        if(mEngineLaunch) return;



        // 读取用户的调用的能力
        String capKey =mHCIAudio.getAccountInfo(mRecongniseMode);
        if (capKey == null) {
            Log.i(TAG, "capKey is null , please check it!");
            return;
        }

        //mHCIAudio
        // 判断capkey是否可用
        if (!mHCIAudio.isCapKeyEnable(capKey)) {
            Log.e(TAG, "capKey is not enabel: " + capKey.toString());
            // 由于系统已经初始化成功,在结束前需要调用方法hciRelease()进行系统的反初始化

            return;
        }
        // 初始化录音机
        mAsrRecorder = new ASRRecorder();

        // 配置初始化参数
        AsrInitParam asrInitParam = new AsrInitParam();
        String asrDirPath = mHCIAudio.getBaseContext().getFilesDir().getPath().replace("files", "lib");
        asrInitParam.addParam(AsrInitParam.PARAM_KEY_INIT_CAP_KEYS, capKey);
        asrInitParam.addParam(AsrInitParam.PARAM_KEY_DATA_PATH, asrDirPath);
        asrInitParam.addParam(AsrInitParam.PARAM_KEY_FILE_FLAG, "android_so");
        Log.v(TAG, "init parameters:" + asrInitParam.getStringConfig());

        // 设置初始化参数
        mAsrRecorder.init(asrInitParam.getStringConfig(),
                this);

        // 配置识别参数
        mAsrConfig = new AsrConfig();
        // PARAM_KEY_CAP_KEY 设置使用的能力
        mAsrConfig.addParam(AsrConfig.PARAM_KEY_CAP_KEY, capKey);
        // PARAM_KEY_AUDIO_FORMAT 音频格式根据不同的能力使用不用的音频格式
        mAsrConfig.addParam(AsrConfig.PARAM_KEY_AUDIO_FORMAT,
                AsrConfig.HCI_ASR_AUDIO_FORMAT_PCM_16K16BIT);
        // PARAM_KEY_ENCODE 音频编码压缩格式，使用OPUS可以有效减小数据流量
        mAsrConfig.addParam(AsrConfig.PARAM_KEY_ENCODE, "opus");
        // 其他配置，此处可以全部选取缺省值

        // 语法相关的配置,若使用自由说能力可以不必配置该项
        if (capKey.contains("grammar")) {
            grammar = mHCIAudio.loadGrammar("wordlist_utf8.txt");
            // 加载本地语法获取语法ID
            AsrGrammarId id = new AsrGrammarId();
            mAsrRecorder.loadGrammar("grammarType=wordlist", grammar, id);

            // PARAM_KEY_GRAMMAR_TYPE 语法类型，使用自由说能力时，忽略以下此参数
            mAsrConfig.addParam(AsrConfig.PARAM_KEY_GRAMMAR_TYPE,
                    AsrConfig.HCI_ASR_GRAMMAR_TYPE_ID);
            mAsrConfig.addParam(AsrConfig.PARAM_KEY_GRAMMAR_ID,
                    "" + id.getGrammarId());

            /*List<String> grammarList = loadGrammarList(grammar);
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1, grammarList);
            mGrammarLv.setAdapter(adapter);*/
        }

        mAsrConfig.addParam(AsrConfig.PARAM_KEY_REALTIME, "yes");
        mEngineLaunch=true;


    }

    @Override
    public void stop() {
     if(mAsrRecorder!=null) mAsrRecorder.cancel();

    }


    @Override
    public void destroy() {
        if(mEngineLaunch) mAsrRecorder.release();
        mEngineLaunch=false;
    }


    void onError(AudioRecongniseError e,int errCode)
    {
        if(mAudioRecongniseListeners!=null && mAudioRecongniseListeners.size()>0)
        {
            for(IAudioRecongniseListener l:mAudioRecongniseListeners)
            {
                l.onError(e,errCode);
            }
        }
    }


    void onStatusCheanged(AudioRecongniseStatus s)
    {
        if(mAudioRecongniseListeners!=null && mAudioRecongniseListeners.size()>0)
        {
            for(IAudioRecongniseListener l:mAudioRecongniseListeners)
            {
                l.onStatusChanged(s);
            }
        }
    }


    void onRecongnised(String sResult)
    {
        if(mAudioRecongniseListeners!=null && mAudioRecongniseListeners.size()>0)
        {
            for(IAudioRecongniseListener l:mAudioRecongniseListeners)
            {
                l.onRecongnised(sResult);
            }
        }
    }

    //ASRRecorderListener
    @Override
    public void onRecorderEventStateChange(ASRCommonRecorder.RecorderEvent recorderEvent) {

        AudioRecongniseStatus s=AudioRecongniseStatus.RECONGNISE_NOSTATUS;
        if (recorderEvent == ASRCommonRecorder.RecorderEvent.RECORDER_EVENT_BEGIN_RECORD) {
            s=AudioRecongniseStatus.RECONGNISE_START_RECORD;
        } else if (recorderEvent == ASRCommonRecorder.RecorderEvent.RECORDER_EVENT_BEGIN_RECOGNIZE) {
            s=AudioRecongniseStatus.RECONGNISE_START_RECONGNISE;
        } else if (recorderEvent == ASRCommonRecorder.RecorderEvent.RECORDER_EVENT_NO_VOICE_INPUT) {

            onError(AudioRecongniseError.RECONGNISE_ERROR_NOINPUT,0);
            return;
        }

        onStatusCheanged(s);



       // Message m = mUIHandle.obtainMessage(1, 1, 1, sState);
       // mUIHandle.sendMessage(m);

    }

    @Override
    public void onRecorderEventRecogFinsh(ASRCommonRecorder.RecorderEvent recorderEvent, AsrRecogResult asrRecogResult) {

        if (recorderEvent == ASRCommonRecorder.RecorderEvent.RECORDER_EVENT_RECOGNIZE_COMPLETE) {
            //String sState = "状态为：识别结束";
            //Message m = mUIHandle.obtainMessage(1, 1, 1, sState);
            //mUIHandle.sendMessage(m);

            onStatusCheanged(AudioRecongniseStatus.RECONGNISE_RECONGNISE_FINISHED);

        }
        if (asrRecogResult != null) {
            String sResult;
            if (asrRecogResult.getRecogItemList().size() > 0) {
                sResult =  asrRecogResult.getRecogItemList().get(0).getRecogResult();
                onRecongnised(sResult);

            } else {

                onError(AudioRecongniseError.RECONGNISE_ERROR_FAIL,0);

            }
            //Message m = mUIHandle.obtainMessage(1, 2, 1, sResult);
            //mUIHandle.sendMessage(m);
        }

    }

    @Override
    public void onRecorderEventError(ASRCommonRecorder.RecorderEvent recorderEvent, int i) {
       // String sError = "错误码为：" + i;
        onError(AudioRecongniseError.RECONGNISE_ERROR_ENGINE_ERROR,i);

    }

    @Override
    public void onRecorderRecording(byte[] bytes, int i) {

    }
}
