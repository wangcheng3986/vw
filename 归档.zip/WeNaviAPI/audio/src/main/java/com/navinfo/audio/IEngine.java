package com.navinfo.audio;

/**
 * Created by Doone on 2015/1/26.
 * 引擎接口
 */
public interface IEngine {

    /**
     * 启动引擎
     */
    public void launch();

    /**
     * 停止引擎
     */
    public void stop();

    /**
     * 销毁引擎
     */
    public void destroy();
}
