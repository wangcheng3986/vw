package com.navinfo.audio;

/**
 * Created by Doone on 2015/1/26.
 * 语音识别状态码
 */
public enum AudioRecongniseStatus {

    /**
     * 无状态
     */
    RECONGNISE_NOSTATUS,

    /**
     * 开始录音
     */
    RECONGNISE_START_RECORD,

    /**
     * 开始识别
     */
    RECONGNISE_START_RECONGNISE,

    /**
     * 识别完毕
     */
    RECONGNISE_RECONGNISE_FINISHED,

    /**
     * 无输入
     */
    RECONGNISE_NOINPUT,


    /**
     * 取消识别
     */
    RECONGNISE_CANCEL

}
