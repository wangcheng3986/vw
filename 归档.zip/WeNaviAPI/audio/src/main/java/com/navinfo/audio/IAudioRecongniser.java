package com.navinfo.audio;

/**
 * Created by Doone on 2015/1/23.
 * 语音识别接口
 */
public interface IAudioRecongniser extends IEngine {

    /**
     * 识别模式定义
     */
    public static class RecongniseMode{
        /**
         * 自由识别
         */
        public static final  String FREECONTENT ="FREECONTENT";

        /**
         * 预设命令识别，语法识别
         */
        public static final  String AUDIOCOMMAND="AUDIOCOMMAND";
    }


    /**
     * 引擎模式定义
     */
    public static class EngineMode{
        /**
         * 本地引擎
         */
        public static final  String LOCALENGINE ="LOCALENGINE";

        /**
         * 云端引擎
         */
        public static final  String CLOUDENGINE="CLOUDENGINE";
    }

    /**
     * 设置识别模式
     * @param sMode
     */
    public void setRecongniseMode(String sMode);

    /**
     * 设置引擎模式
     * @param sMode
     */
    public void setEngineMode(String sMode);

    /**
     * 启动识别
     */
    public void startRecongnise(IAudioRecongniseListener l);


}
