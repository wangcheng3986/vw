package com.navinfo.audio;

/**
 * Created by Doone on 2015/1/26.
 * 语音识别错误码
 */
public enum AudioRecongniseError {

    RECONGNISE_ERROR_UNKNOW,

    RECONGNISE_ERROR_ENGINE_INIT_FAIL,

    RECONGNISE_ERROR_ENGINE_UNLAUNCH,

    RECONGNISE_ERROR_NOINPUT,

    RECONGNISE_ERROR_FAIL,

    RECONGNISE_ERROR_ENGINE_BUSY,

    RECONGNISE_ERROR_ENGINE_ERROR,

    RECONGNISE_ERROR_TIMEOUT

}
