package com.navinfo.audio;

/**
 * Created by Doone on 2015/1/23.
 * 语音识别回调接口
 */
public interface IAudioRecongniseListener {

    /**
     * 识别成功
     * @param sText 识别内容
     */
    public void onRecongnised(String sText);


    /**
     * 识别失败
     * @param e 错误信息
     * @param errCode 引擎错误码
     */
    public void onError(AudioRecongniseError e,int errCode,String sError);

    /**
     * 识别失败
     * @param status 状态信息
     */
    public void onStatusChanged(AudioRecongniseStatus status);
}
