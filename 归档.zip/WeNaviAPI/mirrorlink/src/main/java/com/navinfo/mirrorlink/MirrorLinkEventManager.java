package com.navinfo.mirrorlink;


import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;

import com.mirrorlink.android.commonapi.Defs;
import com.mirrorlink.android.commonapi.ICommonAPIService;
import com.mirrorlink.android.commonapi.IEventMappingListener;
import com.mirrorlink.android.commonapi.IEventMappingManager;

import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

/**
 * Created by weihongying@navinfo.com on 2015/1/14.
 */
public class MirrorLinkEventManager extends  MirrorLinkManager {

    private final static String LOG_TAG = MirrorLinkEventManager.class.getCanonicalName();

    IEventMappingManager mManager=null;

    Bundle mEventMapping=null;
    Bundle mEventConfiguration=null;

    public MirrorLinkEventManager(MirrorLinkApplicationContext context) {
        super(context);
    }


    IEventMappingListener mEventMappingListener = new IEventMappingListener.Stub() {
        @Override
        public void onEventMappingChanged(Bundle eventMapping) throws RemoteException {
            mEventMapping=eventMapping;
            callCallbacks(CallBackType.EVENT_MAPING_CHANGED);

        }

        @Override
        public void onEventConfigurationChanged(Bundle eventConfiguration) throws RemoteException {
            mEventConfiguration=eventConfiguration;
            callCallbacks(CallBackType.EVENT_CONFIG_CHANGED);
        }
    };


    @Override
    public void register() {
        Log.v(LOG_TAG, "register to Server  ");
        try {
            if (mManager == null) {
                ICommonAPIService service = getMirrorLinkService();
                if (service != null)
                    mManager = service.getEventMappingManager(getContext().getPackageName(), mEventMappingListener);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void unRegister() {
        super.unRegister();
        try {

            if (mManager != null)
            {
                mManager.unregister();
                mManager = null;

                mEventMapping=null;
                mEventConfiguration=null;

            }


        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }


    void loadEventConfiguration()
    {
        if(mEventConfiguration==null)
        {
            try
            {
                if (mManager != null){
                    mEventConfiguration=mManager.getEventConfiguration();
                }
            }catch (RemoteException e) {
                e.printStackTrace();
            }

        }

    }

    /**
     * The keyboard layout language code (according to ISO 639-1).
     * uint16 packaged as int
     */

    public int getKeyboardLayoutLanguage()
    {
        loadEventConfiguration();
        if(mEventConfiguration!=null) return mEventConfiguration.getInt(Defs.EventConfiguration.KEYBOARD_LANGUAGE);
        return 0;
    }

    /**
     * The keyboard layout country code (according to ISO 3166-1 aplha-2).
     * uint16 packaged as int
     */
    public int getKeyboardLayoutCountry()
    {
        loadEventConfiguration();
        if(mEventConfiguration!=null) return mEventConfiguration.getInt(Defs.EventConfiguration.KEYBOARD_COUNTRY);
        return 0;
    }

    /**
     * The UI language code (according to ISO 639-1).
     * uint16 packaged as int
     */
    public int getUILanguage()
    {
        loadEventConfiguration();
        if(mEventConfiguration!=null) return mEventConfiguration.getInt(Defs.EventConfiguration.UI_LANGUAGE);
        return 0;
    }

    /**
     * The UI language country code (according to ISO 3166-1 aplha-2).
     * uint16 packaged as int
     */
    public int getUICoutry()
    {
        loadEventConfiguration();
        if(mEventConfiguration!=null) return mEventConfiguration.getInt(Defs.EventConfiguration.UI_COUNTRY);
        return 0;
    }

    /**
     * Supported knob events from the MirrorLink Session.
     * Bit mask as defined in the VNC specification.
     * uint32 packaged as a int
     */
    public int getKnobSupport()
    {
        loadEventConfiguration();
        if(mEventConfiguration!=null) return mEventConfiguration.getInt(Defs.EventConfiguration.KNOB_KEY_SUPPORT);
        return 0;
    }

    /**
     * Supported device key events from the MirrorLink Session.
     * Bit mask as defined in the VNC specification.
     * uint32 packaged as a int
     */
    public int getDeviceKeySupport()
    {
        loadEventConfiguration();
        if(mEventConfiguration!=null) return mEventConfiguration.getInt(Defs.EventConfiguration.DEVICE_KEY_SUPPORT);
        return 0;
    }


    /**
     * Supported multimedia key events from the MirrorLink Session.
     * Bit mask as defined in the VNC specification.
     * uint32 packaged as a int
     */

    public int getMultimediaSupport()
    {
        loadEventConfiguration();
        if(mEventConfiguration!=null) return mEventConfiguration.getInt(Defs.EventConfiguration.MULTIMEDIA_KEY_SUPPORT);
        return 0;
    }

    /**
     * Number of supported function keys from the MirrorLink Session.
     * uint8 packaged as a int
     */
    public int getNumberOfFunctionKeys()
    {
        loadEventConfiguration();
        if(mEventConfiguration!=null) return mEventConfiguration.getInt(Defs.EventConfiguration.FUNC_KEY_SUPPORT);
        return 0;
    }

    /**
     * Support for ITU keys from the MirrorLink Session.
     * boolean
     */
    public boolean isITUKeySupported()
    {
        loadEventConfiguration();
        if(mEventConfiguration!=null) return mEventConfiguration.getBoolean(Defs.EventConfiguration.ITU_KEY_SUPPORT);
        return false;
    }

    /**
     * Number of simultaneous touch events, supported from the MirrorLink Client.
     * uint8 packaged as a int
     */
    public int getNumberOfSimultaneousTouch()
    {
        loadEventConfiguration();
        if(mEventConfiguration!=null) return mEventConfiguration.getInt(Defs.EventConfiguration.TOUCH_SUPPORT);
        return 0;
    }

    /**
     * The pressure mask indicates how many pressure levels can be distinguished from the
     * MirrorLink Server and Client.
     */

    public String getPressureMask()
    {
        loadEventConfiguration();
        if(mEventConfiguration!=null) return mEventConfiguration.getString(Defs.EventConfiguration.PRESSURE_MASK);
        return "";
    }



    public HashMap getAllEventMapping(){

        List<Bundle> lsEventMap=null;

        try {
            if (mManager != null) {
                lsEventMap = mManager.getEventMappings();
            }
        } catch (RemoteException e) {
            e.printStackTrace();
        }

       if(lsEventMap!=null)
        {
            HashMap eventMap=new HashMap();
            for(Bundle b:lsEventMap) {

                eventMap.put(
                b.getString(Defs.EventMapping.REMOTE_EVENT),
                b.getString(Defs.EventMapping.LOCAL_EVENT)
                );
            }
            return eventMap;
        }


        return null;
        //return lsEventMap;

    }

    /**
     * Key event value of the remote event.
     */

    public String getRemoteEvent() {
        if (mEventConfiguration != null)
            return mEventConfiguration.getString(Defs.EventMapping.REMOTE_EVENT);
        return "";
    }

    /**
     * Key event value of the local event, as it will be emulated on the
     * MirrorLink Server device in response to the received remote event.
     */
    public String getLocalEvent() {
        if (mEventConfiguration != null)
            return mEventConfiguration.getString(Defs.EventMapping.LOCAL_EVENT);
        return "";
    }

}
