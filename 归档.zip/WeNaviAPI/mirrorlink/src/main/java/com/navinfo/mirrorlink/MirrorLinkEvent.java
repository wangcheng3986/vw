package com.navinfo.mirrorlink;

/**
 * Created by Doone on 2015/2/7.
 */
public  class MirrorLinkEvent {

    public static enum KnobRotateAxis {
        X, Y, Z;
    }


    public static  enum  KnobShiftDirection{
        ShiftUp,
        ShiftDown,
        ShiftLeft,
        ShiftRight,
        ShiftUpLeft,
        ShiftUpRight,
        ShiftDownLeft,
        ShiftDownRight
    }


    public static enum KnobRotateDirection{
        RotateLeft,
        RotateRight
    }

    public static enum ITUKey{
        ITU_Key_0,
        ITU_Key_1,
        ITU_Key_2,
        ITU_Key_3,
        ITU_Key_4,
        ITU_Key_5,
        ITU_Key_6,
        ITU_Key_7,
        ITU_Key_8,
        ITU_Key_9,
        ITU_Key_Asterix,
        ITU_Key_Pound
    }

    public static enum DeviceKey{
        Device_Phone_call,
        Device_Phone_end,
        Device_Soft_left,
        Device_Soft_middle,
        Device_Soft_right,
        Device_Application,
        Device_Ok,
        Device_Delete,
        Device_Zoom_in,
        Device_Zoom_out,
        Device_Clear,
        Device_Forward,
        Device_Backward,
        Device_Home,
        Device_Search,
        Device_Menu
    }

    public static enum MultimediaKey{
        Multimedia_Play,
        Multimedia_Pause,
        Multimedia_Stop,
        Multimedia_Forward,
        Multimedia_Rewind,
        Multimedia_Next,
        Multimedia_Previous,
        Multimedia_Mute,
        Multimedia_Unmute,
        Multimedia_Photo

    }
}
