package com.navinfo.mirrorlink;

import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;


import com.mirrorlink.android.commonapi.Defs;

import com.mirrorlink.android.commonapi.ICommonAPIService;
import com.mirrorlink.android.commonapi.IDisplayListener;
import com.mirrorlink.android.commonapi.IDisplayManager;


/**
 * Created by weihongying@navinfo.com on 2015/1/14.
 */
public class MirrorLinkDisplayManager extends MirrorLinkManager {


    IDisplayManager mDisplayManager = null;

    Bundle mMirrorLinkDisplayConfig=null;
    Bundle mMirrorLinkDevicePixelFormat=null;

    private final static String LOG_TAG = MirrorLinkDisplayManager.class.getCanonicalName();

    public MirrorLinkDisplayManager(MirrorLinkApplicationContext context)
    {
        super(context);

    }


    public IDisplayManager getDisplayManager(){
        if (mDisplayManager == null)
            Log.e(LOG_TAG, "Display Manager not available");
            //Toast.makeText(this, "Display Manager not available", Toast.LENGTH_SHORT).show();
        return mDisplayManager;
    }

    IDisplayListener mDisplayListener = new IDisplayListener.Stub() {
        @Override
        public void onPixelFormatChanged(Bundle pixelFormat) throws RemoteException {
            mMirrorLinkDevicePixelFormat=pixelFormat;
           callCallbacks(CallBackType.CLIENT_PIXEL_CHANGED);
        }
        @Override
        public void onDisplayConfigurationChanged(Bundle displayConfiguration) throws RemoteException {
            mMirrorLinkDisplayConfig=displayConfiguration;
            Log.e(LOG_TAG, String.format("Origional onDisplayConfigurationChanged Callback"));
            callCallbacks(CallBackType.CLIENT_DISPLAY_CONFIG_CHANGED);
        }
    };

    private void loadDisplayConfig()
    {
        if(mMirrorLinkDisplayConfig==null)
            try {
                mMirrorLinkDisplayConfig=mDisplayManager.getDisplayConfiguration();
            }catch (Exception e) {
                e.printStackTrace();
            }
    }

    private void loadClientPixelFormat()
    {
        if(mMirrorLinkDevicePixelFormat==null)
            try {
                mMirrorLinkDevicePixelFormat=mDisplayManager.getClientPixelFormat();
            }catch (Exception e) {
                e.printStackTrace();
            }
    }

    public int getServerPixelWidth()
    {
        loadDisplayConfig();

        if(mMirrorLinkDisplayConfig!=null)
            return mMirrorLinkDisplayConfig.getInt(Defs.DisplayConfiguration.SERVER_PIXEL_WIDTH);
        return 0;
    }


    public int getServerPixelHeight()
    {
        loadDisplayConfig();
        if(mMirrorLinkDisplayConfig!=null)
            return mMirrorLinkDisplayConfig.getInt(Defs.DisplayConfiguration.SERVER_PIXEL_HEIGHT);
        return 0;
    }

    public int getClientPixelWidth()
    {
        loadDisplayConfig();
        if(mMirrorLinkDisplayConfig!=null)
            return mMirrorLinkDisplayConfig.getInt(Defs.DisplayConfiguration.CLIENT_PIXEL_WIDTH);
        return 0;
    }


    public int getClientPixelHeight()
    {
        loadDisplayConfig();
        if(mMirrorLinkDisplayConfig!=null)
            return mMirrorLinkDisplayConfig.getInt(Defs.DisplayConfiguration.CLIENT_PIXEL_HEIGHT);
        return 0;
    }

    public int getClientMmWidth()
    {
        loadDisplayConfig();
        if(mMirrorLinkDisplayConfig!=null)
            return mMirrorLinkDisplayConfig.getInt(Defs.DisplayConfiguration.MM_WIDTH);
        return 0;
    }


    public int getClientMmHeight()
    {
        loadDisplayConfig();
        if(mMirrorLinkDisplayConfig!=null)
            return mMirrorLinkDisplayConfig.getInt(Defs.DisplayConfiguration.MM_HEIGHT);
        return 0;
    }


    public int getClientDistanceToDisplay()
    {
        loadDisplayConfig();
        if(mMirrorLinkDisplayConfig!=null)
            return mMirrorLinkDisplayConfig.getInt(Defs.DisplayConfiguration.DISTANCE);
        return 0;
    }

    public int getBitsPerPixel(){
        loadClientPixelFormat();
        if(mMirrorLinkDevicePixelFormat!=null)
            return mMirrorLinkDevicePixelFormat.getInt(Defs.ClientPixelFormat.BITS_PER_PIXEL);
        return 0;
    }


    public int getMaxRed()
    {
        loadClientPixelFormat();
        if(mMirrorLinkDevicePixelFormat!=null)
            return mMirrorLinkDevicePixelFormat.getInt(Defs.ClientPixelFormat.RED_MAX);
        return 0;
    }

    public int getMaxBlue()
    {
        loadClientPixelFormat();
        if(mMirrorLinkDevicePixelFormat!=null)
            return mMirrorLinkDevicePixelFormat.getInt(Defs.ClientPixelFormat.BLUE_MAX);
        return 0;
    }

    public int getMaxGreen()
    {
        loadClientPixelFormat();
        if(mMirrorLinkDevicePixelFormat!=null)
            return mMirrorLinkDevicePixelFormat.getInt(Defs.ClientPixelFormat.GREEN_MAX);
        return 0;
    }

    public int getDepth()
    {
        loadClientPixelFormat();
        if(mMirrorLinkDevicePixelFormat!=null)
            return mMirrorLinkDevicePixelFormat.getInt(Defs.ClientPixelFormat.DEPTH);
        return 0;
    }

    @Override
    public void register() {
        if (mDisplayManager == null)
        {
            Log.v(LOG_TAG, "register to Server  ");
            try {

                    ICommonAPIService service = getMirrorLinkService();
                    if (service != null) {
                        mDisplayManager = service.getDisplayManager(getContext().getPackageName(), mDisplayListener);
                        if(mDisplayListener!=null) mMirrorLinkDisplayConfig = mDisplayManager.getDisplayConfiguration();
                    }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void unRegister() {
        super.unRegister();
        try {

            if (mDisplayManager != null)
            {
                mDisplayManager.unregister();
                mDisplayManager = null;
                mMirrorLinkDisplayConfig=null;
            }


        } catch (RemoteException e) {
            e.printStackTrace();
        }

    }

}
