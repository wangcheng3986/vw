package com.navinfo.mirrorlink;


import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;

import com.mirrorlink.android.commonapi.Defs;
import com.mirrorlink.android.commonapi.ICertificationListener;
import com.mirrorlink.android.commonapi.ICertificationManager;
import com.mirrorlink.android.commonapi.ICommonAPIService;


/**
 * Created by weihongying@navinfo.com on 2015/1/14.
 */
public class MirrorLinkCertificationManager extends  MirrorLinkManager {

    private final static String LOG_TAG = MirrorLinkCertificationManager.class.getCanonicalName();

    ICertificationManager mManager=null;
    Bundle mApplicationCertificationStatus;


    public MirrorLinkCertificationManager(MirrorLinkApplicationContext context) {
        super(context);
    }


    ICertificationListener mCertificationListener =  new ICertificationListener.Stub() {
        @Override
        public void onCertificationStatusChanged() throws RemoteException {
            callCallbacks(CallBackType.CERTIFICATION_STATUS_CHANGED);
        }
    };


    @Override
    public void register() {
        Log.v(LOG_TAG, "register to Server  ");
        try {
            if (mManager == null) {
                ICommonAPIService service = getMirrorLinkService();
                if (service != null)
                    mManager = service.getCertificationManager(getContext().getPackageName(), mCertificationListener);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void unRegister() {
        super.unRegister();
        try {

            if (mManager != null)
            {
                mManager.unregister();
                mManager = null;

                mApplicationCertificationStatus=null;

            }


        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }


    void loadApplicationCertificationStatus()
    {
        if(mApplicationCertificationStatus==null)
        {
            if(mManager!=null)
                try {
                    mApplicationCertificationStatus=mManager.getApplicationCertificationStatus();
                }catch (RemoteException e) {
                    e.printStackTrace();
                }
        }
    }

    /**
     * Flag, indicating whether the MirrorLink server has a valid certificate for the
     * application.
     * boolean
     */
    public boolean hasValidCertificate()
    {
        loadApplicationCertificationStatus();
        if(mApplicationCertificationStatus!=null) return mApplicationCertificationStatus.getBoolean(Defs.ApplicationCertificationStatus.HAS_VALID_CERTIFICATE);
        return false;
    }


    /**
     * Flag, indicating, whether the MirrorLink server has included the application into its
     * UPnP advertisements as a certified application. If the application is only certified by a
     * manufacturer, the value of this will be false, unless the server is connected to a client
     * that matches the manufacturer name.
     * boolean
     */
    public boolean isAdvertisementedAsCertifiedApp()
    {
        loadApplicationCertificationStatus();
        if(mApplicationCertificationStatus!=null) return mApplicationCertificationStatus.getBoolean(Defs.ApplicationCertificationStatus.ADVERTISED_AS_CERTIFIEDAPP);
        return false;
    }


    /**
     * 4.3.2 Get Application Certifying Entities.
     *
     * <br>
     * <i>Function reference 0x0202.</i>
     * <br>
     * Provide information on the certifying entities.
     *
     * @return Comma-separated list of certifying entities, which certified the application,
     */
    public String getApplicationCertifyingEntities()
    {
        if(mManager!=null)
            try {
                return mManager.getApplicationCertifyingEntities();
            }catch (RemoteException e) {
                e.printStackTrace();
            }
        return "";
    }

    /**
     * 4.3.3 Get Application Certification Information.
     *
     * <br>
     * <i>Function reference 0x0203.</i>
     * <br>
     * Provide application certificate information.
     *
     * @param   entity the name of the certifying entity,
     *
     * @return  Bundle containing {@link Defs.CertificateInformation} for the given entity
     *          or null if the application isn't certified or the entity is not part of the list of
     *          certifying entities for the application,
     */
    public AppCertificateInformation getAppCertificateInformation(String entity)
    {
        if(mManager!=null)
            try {
                Bundle b= mManager.getApplicationCertificationInformation(entity);
                if(b!=null) return new AppCertificateInformation(b);
            }catch (RemoteException e) {
                e.printStackTrace();
            }
        return null;
    }


}
