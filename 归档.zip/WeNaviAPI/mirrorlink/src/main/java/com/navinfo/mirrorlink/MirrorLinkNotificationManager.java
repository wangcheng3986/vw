package com.navinfo.mirrorlink;

import android.net.Uri;
import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;

import com.mirrorlink.android.commonapi.Defs;
import com.mirrorlink.android.commonapi.ICommonAPIService;
import com.mirrorlink.android.commonapi.INotificationListener;
import com.mirrorlink.android.commonapi.INotificationManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by weihongying@navinfo.com on 2015/1/14.
 */
public class MirrorLinkNotificationManager extends MirrorLinkManager {

    private final static String LOG_TAG = MirrorLinkEventManager.class.getCanonicalName();
    INotificationManager mManager = null;

    boolean mNotiEnable=false;
    Bundle mNotificationConfiguration=null;

    int mNotificationId=0;
    int mActionId=0;



    public MirrorLinkNotificationManager(MirrorLinkApplicationContext context) {
        super(context);
    }


    INotificationListener mNotificationListener = new INotificationListener.Stub() {

        @Override
        public void onNotificationEnabledChanged(boolean notiEnabled) throws RemoteException {
            mNotiEnable=notiEnabled;
            callCallbacks(CallBackType.NOTIFICATION_ENABLED_CHANGED,notiEnabled);

        }

        @Override
        public void onNotificationConfigurationChanged(Bundle notificationConfiguration) throws RemoteException {
            mNotificationConfiguration=notificationConfiguration;
            callCallbacks(CallBackType.NOTIFICATION_CONFIG_CHANGED,notificationConfiguration);
        }

        @Override
        public void onNotificationActionReceived(int notificationId, int actionId) throws RemoteException {
            mNotificationId=notificationId;
            mActionId=actionId;
            callCallbacks(CallBackType.NOTIFICATION_ACTION_RECEIVED,notificationId,actionId);
        }
    };


    @Override
    public void register() {
        Log.v(LOG_TAG, "register to Server  ");
        try {
            if (mManager == null) {
                ICommonAPIService service = getMirrorLinkService();
                if (service != null)
                    mManager = service.getNotificationManager(getContext().getPackageName(), mNotificationListener);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void unRegister() {
        super.unRegister();
        try {

            if (mManager != null)
            {
                mManager.unregister();
                mManager = null;
            }


        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    void loadNotificationConfig()
    {
        if(mNotificationConfiguration==null)
        {
            if(mManager!=null)
            {
                try{
                    mNotificationConfiguration=mManager.getNotificationConfiguration();
                }catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Flag, whether the MirrorLink client supports its own notification UI.
     * boolean
     */
    public boolean isNotificationSupported()
    {
        loadNotificationConfig();
        if(mNotificationConfiguration!=null)
        {
            return mNotificationConfiguration.getBoolean(Defs.NotificationConfiguration.NOTIFICATION_SUPPORTED);
        }
        return false;
    }

    /**
     * Maximum number of actions.
     */
    public int getNotificationMaxActions()
    {
        loadNotificationConfig();
        if(mNotificationConfiguration!=null)
        {
            return mNotificationConfiguration.getInt(Defs.NotificationConfiguration.MAX_ACTIONS);
        }
        return 0;
    }

    /**
     * Maximum number of characters of the Action Name.
     */
    public int getNotificationMaxActionName()
    {
        loadNotificationConfig();
        if(mNotificationConfiguration!=null)
        {
            return mNotificationConfiguration.getInt(Defs.NotificationConfiguration.MAX_ACTION_NAME_LENGTH);
        }
        return 0;
    }

    /**
     * Maximum number of characters of the notification title.
     */
    public int getNotificationMaxTitleLength()
    {
        loadNotificationConfig();
        if(mNotificationConfiguration!=null)
        {
            return mNotificationConfiguration.getInt(Defs.NotificationConfiguration.MAX_TITLE_LENGTH);
        }
        return 0;
    }

    /**
     * Maximum number of characters of the notification body.
     */
    public int getNotificationMaxBodyLength()
    {
        loadNotificationConfig();
        if(mNotificationConfiguration!=null)
        {
            return mNotificationConfiguration.getInt(Defs.NotificationConfiguration.MAX_BODY_LENGTH);
        }
        return 0;
    }


    /**
     * 4.12.1 Notifications Supported.
     *
     * <br>
     * <i>Function reference 0x0B01.</i>
     * <br>
     * Indicate support for UPnP notifications from the application; the MirrorLink Server will
     * issue a NotiAppListUpdate event, to inform the MirrorLink Client that the notification
     * support for this application has changed. Unless otherwise set by the application, the
     * MirrorLink Server MUST assume that the application will not support notifications.
     *
     * @param notificationSupported Flag indicating notification support from the application.
     */
    public void setNotificationSupported(boolean notificationSupported)
    {
        if(mManager!=null)
            try{
                mManager.setNotificationSupported(notificationSupported);
            }catch (RemoteException e) {
                e.printStackTrace();
            }
    }

    /**
     * 4.12.2 Notifications Enabled.
     *
     * <br>
     * <i>Function reference 0x0B02.</i>
     * <br>
     * Checks whether notifications are enabled for the application from the MirrorLink Server and
     * Client.
     *
     * @return Flag indicating that notifications are enabled from MirrorLink Server and Client for
     * the application.
     */
    public boolean getNotificationEnabled()
    {
        if(mManager!=null)
            try{
                mNotiEnable=mManager.getNotificationEnabled();
            }catch (RemoteException e) {
                e.printStackTrace();
            }
        return mNotiEnable;
    }



    /**
     * 4.12.6 Send Notification for client-based Notification UI.
     *
     * <br>
     * <i>Function reference 0x0B06.</i>
     * <br>
     * Send a notification from the application; this notification replaces a previously send notification.
     *
     * @param   title Title of the notification event
     * @param   body Body of the notification event
     * @param   iconUrl Url to icon belonging to the notification
     * @param   actionList List of actions belonging to the notification
     *
     * @return The notification identifier; a Zero value will be returned, if the action was not successful.
     */
    public int sendClientNotification( String title,  String body,  Uri iconUrl,  List<String> actionList)
    {
        if(mManager!=null)
            try{

               // List<String> actionList = Arrays.asList(actionListText.getValue().split(","));
              //  Uri iconUrl = Uri.parse(iconUrlListText.getValue());

               List<Bundle> actions = new ArrayList<Bundle>();

                for (int i=0;i<actionList.size();i++)
                {
                    Bundle action =  new Bundle();
                    action.putInt(Defs.Action.ACTION_ID, i+1);
                    action.putString(Defs.Action.ACTION_NAME, actionList.get(i));
                    action.putBoolean(Defs.Action.LAUNCH_APP, false);
                    actions.add(action);
                }
              return  mManager.sendClientNotification(title,body,iconUrl,actions);
            }catch (RemoteException e) {
                e.printStackTrace();
            }
        return 0;
    }

    /**
     * 4.12.7 Send Notification for VNC-based Notification UI.
     *
     * <br>
     * <i>Function reference 0x0B07.</i>
     * <br>
     * Send a notification from the application; this notification replaces a previously send notification.
     *
     * @return The notification identifier; a Zero value will be returned, if the action was not successful.
     */
    public int sendVncNotification()
    {
        if(mManager!=null)
            try{
                return  mManager.sendVncNotification();
            }catch (RemoteException e) {
                e.printStackTrace();
            }
        return 0;
    }

    /**
     * 4.12.8 Cancel Notification.
     *
     * <br>
     * <i>Function reference 0x0B08.</i>
     * <br>
     * Cancel a notification from the application.
     *
     * @param notificationId Identifier of the notification, which needs to get canceled.
     */
    public boolean cancelNotification(int notificationId)
    {
        if(mManager!=null)
            try{
                return  mManager.cancelNotification(notificationId);
            }catch (RemoteException e) {
                e.printStackTrace();
            }
        return false;
    }

}
