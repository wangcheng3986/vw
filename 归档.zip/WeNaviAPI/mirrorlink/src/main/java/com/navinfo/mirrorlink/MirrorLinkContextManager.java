package com.navinfo.mirrorlink;

import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;

import com.mirrorlink.android.commonapi.Defs;
import com.mirrorlink.android.commonapi.ICommonAPIService;
import com.mirrorlink.android.commonapi.IContextListener;
import com.mirrorlink.android.commonapi.IContextManager;

import java.util.List;

/**
 * Created by weihongying@navinfo.com on 2015/1/14.
 */
public class MirrorLinkContextManager  extends  MirrorLinkManager{

    private final static String LOG_TAG = MirrorLinkContextManager.class.getCanonicalName();

    IContextManager mManager=null;

    Bundle mFramebufferAreaBlocked=null;
    int mFramebufferBlockedReason=0;
    boolean mIsFramebufferBlocked=false;

    int mAudioBlockedReason=0;
    boolean mIsAudioBlocked=false;



    public MirrorLinkContextManager(MirrorLinkApplicationContext context) {
        super(context);
    }

    IContextListener mContextListener = new IContextListener.Stub() {
        @Override
        public void onFramebufferBlocked(int reason, Bundle framebufferArea) throws RemoteException {
            mFramebufferAreaBlocked=framebufferArea;
            mFramebufferBlockedReason=reason;
            mIsFramebufferBlocked=true;
            callCallbacks(CallBackType.FRAPME_BUFFER_BLOCKED);
        }
        @Override
        public void onAudioBlocked(int reason) throws RemoteException {
            mAudioBlockedReason=reason;
            mIsAudioBlocked=true;
            callCallbacks(CallBackType.AUDIO_BLOCKED);
        }
        @Override
        public void onFramebufferUnblocked() throws RemoteException {
            mFramebufferAreaBlocked=null;
            mFramebufferBlockedReason=0;
            mIsFramebufferBlocked=false;
            callCallbacks(CallBackType.FRAPME_BUFFER_UNBLOCKED);

        }
        @Override
        public void onAudioUnblocked() throws RemoteException {
            mAudioBlockedReason=0;
            mIsAudioBlocked=false;
            callCallbacks(CallBackType.AUDIO_UNBLOCKED);
        }
    };

    @Override
    public void register() {
        Log.v(LOG_TAG, "register to Server  ");
        try {
            if (mManager == null) {
                ICommonAPIService service = getMirrorLinkService();
                if (service != null)
                    mManager = service.getContextManager(getContext().getPackageName(), mContextListener);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void unRegister() {
        super.unRegister();
        try {

            if (mManager != null)
            {
                mManager.unregister();
                mManager = null;

                mFramebufferAreaBlocked=null;
                mFramebufferBlockedReason=0;
                mIsFramebufferBlocked=false;

                mAudioBlockedReason=0;
                mIsAudioBlocked=false;


            }


        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }



    public boolean isFramebufferBlocked()
    {
        return mIsFramebufferBlocked;
    }

    public int getFramebufferBlockedReason()
    {
        return mFramebufferBlockedReason;
    }

    public Bundle getFramebufferAreaBlocked()
    {
        return mFramebufferAreaBlocked;
    }

    public boolean isAudioBlocked()
    {
        return mIsAudioBlocked;
    }


    public int getAudioBlockedReason()
    {
        return mAudioBlockedReason;
    }

    /**
     * 4.9.1 Framebuffer Context Information.
     *
     * <br>
     * <i>Function reference 0x0801.</i>
     * <br>
     * Provides information of the current framebuffer context; the MirrorLink Server MUST use the
     * application and content category values from the UPnP advertisements, unless otherwise stated
     * from the application using this function. The MirrorLink Server MUST use the given values
     * until a new set function is called. Unless set by the application, the MirrorLink Server MUST
     * treat the "Handle Blocking" flag as being set to a FALSE value.
     * <br>
     * The application MUST continue updating the information, whenever the context chang-es, even
     * when the application is blocked (0x0802) by the MirrorLink Client. The Mir-rorLink Server
     * MUST store the latest update and use it, whenever needed.
     * <br>
     * If no explicit framebuffer context information is set, then the server will behave as if the
     * appplication doesn't handle framebuffer blocking notifications.
     * <br>
     * Calling this will reset any previous information on the framebuffer context information, so
     * the application must ensure to always include all the context information each time it
     * invokes this call.
     *
     * @param config Frame buffer context information. Any areas not
     * covered by the list will be treated as having the default context information. So if the list
     * is empty, then the server will just assume that the context information is the default one
     * for the whole application. Each element of the list is a Bundle with the fields defined in
     * {@link Defs.FramebufferAreaContent}. The ordering of the rectangles in the list is from back
     * to front. The application MUST provide for each item explicit rectangle information and the
     * explicit content category (none of the fileds should not be undefined). The coordinates of
     * each rectangle MUST be absolute screen coordinates.
     * handleBlocking Flag indicating whether the application will take care of the blocking
     * if the MirrorLink Client blocks the content.
     */
    public void setFramebufferContextInformation(FramebufferContentConfig config)//(List<Bundle> content, boolean handleBlocking)
    {
        try {
            if (mManager != null)
                mManager.setFramebufferContextInformation(config.toBundles(), config.getHandleBlock());
        }
        catch (RemoteException e) {
            e.printStackTrace();
        }

    }

    /**
     * 4.9.3 Audio Context Information.
     *
     * <br>
     * <i>Function reference 0x0803.</i>
     * <br>
     * Provides information of the current audio context and whether the application is currently
     * providing audio; The MirrorLink Server MUST use the application category value from the UPnP
     * advertisements, unless otherwise stated from the application using this SET function. The
     * MirrorLink Server MUST use the given values until a new SET function call is issued. The
     * application has to set the application context information prior to starting the audio
     * stream. Unless set by the application, the MirrorLink Server MUST treat the "Handle Blocking"
     * flag as being set to a FALSE value.
     * <br>
     * If no explicit audio context information is set, then the server will behave as if the
     * appplication doesn't handle audio blocking notifications.
     * <br>
     * Calling this will reset any previous information on the audio context information, so the
     * application must ensure to always include all the context information each time it invokes
     * this call.
     * <br>
     * The application MUST set the application context information with audioContent set to
     * False, after stopping the audio stream.
     * <br>
     * The application MUST continue updating the information, whenever the context changes, even
     * when the audio is blocked by the MirrorLink Client. The MirrorLink Server MUST store the
     * latest update and use it, whenever needed.
     *
     * @param audioContent Application is providing Audio content. If set to True, the application
     * is contributing to the audio stream, which is potentially mixed with other audio sources.
     * @param audioCategories Categories of the audio stream. An integer array of categories with
     * values defined in {@link Defs.ContextInformation}. Usually an application will only have one
     * category (for example media), but if some applications have two or more audio sources
     * contributing to the stream in parallel (for example one application might stream media and
     * navigation at the same time), then it is possible to report both categories. The list should
     * be ordered with the higher priority category first (top priority is at position 0). Setting
     * the value to a null, or empty array, will reset the audio content category to the value
     * provided in the UPnP application advertisement, if audioContent is true.
     * @param handleBlocking Flag indicating whether the application will take care of the blocking
     * if the MirrorLink Client blocks the content.
     */
    public void setAudioContextInformation(boolean audioContent, int[] audioCategories,
                                     boolean handleBlocking)
    {
        try {
            if (mManager != null)
                mManager.setAudioContextInformation(audioContent,audioCategories,handleBlocking);
        }
        catch (RemoteException e) {
            e.printStackTrace();
        }

    }
}
