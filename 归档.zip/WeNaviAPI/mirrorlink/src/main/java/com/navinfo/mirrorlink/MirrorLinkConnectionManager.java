package com.navinfo.mirrorlink;

import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;

import com.mirrorlink.android.commonapi.Defs;
import com.mirrorlink.android.commonapi.ICommonAPIService;
import com.mirrorlink.android.commonapi.IConnectionListener;
import com.mirrorlink.android.commonapi.IConnectionManager;

/**
 * Created by weihongying@navinfo.com on 2015/1/12.
 */
public class MirrorLinkConnectionManager extends MirrorLinkManager {

    private final static String LOG_TAG = MirrorLinkConnectionManager.class.getCanonicalName();

    IConnectionManager mManager = null;
    int mRemoteDisplayConnection= Defs.RemoteDisplayConnection.REMOTEDISPLAY_NONE;
    boolean mMirrolinkSessionIsEstablished=false;
    Bundle mAudioConnections=null;

    public MirrorLinkConnectionManager(MirrorLinkApplicationContext context) {
        super(context);
    }

    IConnectionListener mConnectionListener =  new IConnectionListener.Stub() {
        @Override
        public void onRemoteDisplayConnectionChanged(int remoteDisplayConnection) throws RemoteException {
            mRemoteDisplayConnection=remoteDisplayConnection;
            callCallbacks(CallBackType.CLIENT_DISPLAY_CONNECTION_CHANGED);
        }
        @Override
        public void onMirrorLinkSessionChanged(boolean mirrolinkSessionIsEstablished) throws RemoteException {
            mMirrolinkSessionIsEstablished=mirrolinkSessionIsEstablished;
            callCallbacks(CallBackType.MIRRORLINK_SESSION_CHANGED);
        }
        @Override
        public void onAudioConnectionsChanged(Bundle audioConnections) throws RemoteException {
            mAudioConnections=audioConnections;
            callCallbacks(CallBackType.CLIENT_AUDIO_CONNECTION_CHANGED);
        }
    };


    @Override
    public void register() {
        Log.v(LOG_TAG, "register to Server  ");
        try {
            if (mManager == null)
            {
                ICommonAPIService service = getMirrorLinkService();
                if (service != null)
                    mManager = service.getConnectionManager(getContext().getPackageName(), mConnectionListener);
                if(mManager!=null) mAudioConnections = mManager.getAudioConnections();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void unRegister() {
        super.unRegister();
        try {

            if (mManager != null)
            {
                mManager.unregister();
                mManager = null;

                mRemoteDisplayConnection= Defs.RemoteDisplayConnection.REMOTEDISPLAY_NONE;
                mMirrolinkSessionIsEstablished=false;
                mAudioConnections=null;

            }


        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }



    /**
     * 4.4.5 Established Remote Display Connection.
     *
     * <br>
     * <i>Function reference 0x0305.</i>
     * <br>
     * Established remote display connection within MirrorLink Session.
     *
     * @return Value containing the status of the remote display connections available. The values
     * are defined in {@link Defs.RemoteDisplayConnection}.
     */
    public int getRemoteDisplayConnections(){
        try {
            return mManager.getRemoteDisplayConnections();
        }catch (Exception e) {
            e.printStackTrace();
        }
        return mRemoteDisplayConnection;
    }

    /**
     * 4.4.1 Indicates whether a MirrorLink session is currently established.
     *
     * <br>
     * <i>Function reference 0x0301.</i>
     * <br>
     * A MirrorLink is considered established if a ClientProfile has been
     * set on the MirrorLink Server for the current tethering session.
     */
    public boolean isMirrolinkSessionEstablished(){
        try {
            return mManager.isMirrorLinkSessionEstablished();
        }catch (Exception e) {
            e.printStackTrace();
        }

        return mMirrolinkSessionIsEstablished;
    }

    void loadAudioConnections()
    {
        if(mAudioConnections==null)
        {
            try {
                mAudioConnections = mManager.getAudioConnections();
            }catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    /**
     * Identifier of the audio connection for media audio (output).
     * uint8 packaged as a int
     */
    public int getMediaAudioOut(){
        loadAudioConnections();
        if(mAudioConnections!=null)
            return mAudioConnections.getInt(Defs.AudioConnections.MEDIA_AUDIO_OUT);
        return 0;
    }


    /**
     * Identifier of the audio connection for media audio (input).
     * uint8 packaged as a int
     */
    public int getMediaAudioIn(){
        loadAudioConnections();
        if(mAudioConnections!=null)
            return mAudioConnections.getInt(Defs.AudioConnections.MEDIA_AUDIO_IN);
        return 0;
    }


    /**
     * Identifier of the audio connection for Voice Control audio (input).
     * uint8 packaged as a int
     */
    public int getVoiceControl(){
        loadAudioConnections();
        if(mAudioConnections!=null)
            return mAudioConnections.getInt(Defs.AudioConnections.VOICE_CONTROL);
        return 0;
    }

    /**
     * Identifier of the audio connection for Phone audio (input & output).
     * uint8 packaged as a int
     */
    public int getPhoneAudio(){
        loadAudioConnections();
        if(mAudioConnections!=null)
            return mAudioConnections.getInt(Defs.AudioConnections.PHONE_AUDIO);
        return 0;
    }

    /**
     * Comma separated list of supported RTP payload types in case an RTP connection is used.
     * String
     */
    public String getPayloadTypes(){
        loadAudioConnections();
        if(mAudioConnections!=null)
            return mAudioConnections.getString(Defs.AudioConnections.PAYLOAD_TYPES);
        return "";
    }


}
