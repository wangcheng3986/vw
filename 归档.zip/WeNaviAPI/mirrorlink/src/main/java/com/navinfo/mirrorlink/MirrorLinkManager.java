package com.navinfo.mirrorlink;



import android.os.Bundle;
import android.util.Log;

import com.mirrorlink.android.commonapi.ICommonAPIService;


import java.util.ArrayList;
import java.util.List;



/**
 * Created by weihongying@navinfo.com on 2015/1/11.
 */
public abstract class MirrorLinkManager implements IMirrorLinkManager {



    public static final class CallBackType {

        public static final String SERVICE_CONNECTED = "SERVICE_CONNECTED";

        public static final String SERVICE_DISCONNECTED = "SERVICE_DISCONNECTED";


        public static final String CLIENT_PIXEL_CHANGED = "CLIENT_PIXEL_CHANGE";

        public static final String CLIENT_DISPLAY_CONFIG_CHANGED = "CLIENT_DISPLAY_CONFIG_CHANGE";

        public static final String CLIENT_DISPLAY_CONNECTION_CHANGED = "CLIENT_DISPLAY_CONNECTION_CHANGED";

        public static final String CLIENT_AUDIO_CONNECTION_CHANGED = "CLIENT_AUDIO_CONNECTION_CHANGED";

        public static final String MIRRORLINK_SESSION_CHANGED = "MIRRORLINK_SESSION_CHANGED";

        public static final String CLIENT_NIGHTMODE_CHANGED = "CLIENT_NIGHTMODE_CHANGED";

        public static final String CLIENT_DRIVEMODE_CHANGED = "CLIENT_DRIVEMODE_CHANGED";

        public static final String CLIENT_MICINPUT_CHANGED = "CLIENT_MICINPUT_CHANGED";

        public static final String DECIVE_INFO_CHANGED = "DECIVE_INFO_CHANGED";

        public static final String FRAPME_BUFFER_BLOCKED = "FRAPME_BUFFER_BLOCKED";

        public static final String AUDIO_BLOCKED = "AUDIO_BLOCKED";

        public static final String FRAPME_BUFFER_UNBLOCKED = "FRAPME_BUFFER_UNBLOCKED";

        public static final String AUDIO_UNBLOCKED = "AUDIO_UNBLOCKED";

        public static final String EVENT_CONFIG_CHANGED = "EVENT_CONFIG_CHANGED";

        public static final String EVENT_MAPING_CHANGED = "EVENT_MAPING_CHANGED";

        public static final String CERTIFICATION_STATUS_CHANGED = "CERTIFICATION_STATUS_CHANGED";

        public static final String NOTIFICATION_ENABLED_CHANGED = "NOTIFICATION_ENABLED_CHANGED";

        public static final String NOTIFICATION_CONFIG_CHANGED = "NOTIFICATION_CONFIG_CHANGED";

        public static final String NOTIFICATION_ACTION_RECEIVED = "NOTIFICATION_ACTION_RECEIVED";

        public  static final String AVAILABLE_DATA_SERVICES_CHANGED="AVAILABLE_DATA_SERVICES_CHANGED";

        public  static final String DATA_SERVICES_SUBSCRIBE_RESPONSE="DATA_SERVICES_SUBSCRIBE_RESPONSE";

        public  static final String DATA_SERVICES_SETDATAOBJECT_RESPONSE="DATA_SERVICES_SETDATAOBJECT_RESPONSE";

        public  static final String DATA_SERVICES_GETDATAOBJECT_RESPONSE="DATA_SERVICES_GETDATAOBJECT_RESPONSE";

        public  static final String DATA_SERVICES_REGISTER_RESPONSE="DATA_SERVICES_REGISTER_RESPONSE";

    }


    //protected ICommonAPIService mService = null;
    private MirrorLinkApplicationContext mContext=null;

    List<IMirrorLinkServerCallback> mMirrorLinkServerCallbacks = new ArrayList<IMirrorLinkServerCallback>();
    //List<Object> mDisplayManagerReferenceList = new ArrayList<Object>();


    private final static String LOG_TAG = MirrorLinkManager.class.getCanonicalName();

    public MirrorLinkManager(MirrorLinkApplicationContext context)
    {
        //mService=service;
        mContext=context;

    }

    //protected abstract IInterface getMirrorLinkListener();

    protected void callCallbacks(String sCallbackType,Object... pms)
    {
        Log.e(LOG_TAG,String.format("Callback Count:%d",mMirrorLinkServerCallbacks.size()));
        for (IMirrorLinkServerCallback cb: mMirrorLinkServerCallbacks){
            try	{
                Log.e(LOG_TAG, String.format("Callback from %s with type %s ", MirrorLinkManager.this.getClass().getCanonicalName(), sCallbackType));
                cb.onMirrorLinkServerCall(MirrorLinkManager.this,sCallbackType,pms);
            }
            catch (Exception e)	{
                e.printStackTrace();
            }
        }
    }



    /*protected void callCallbacks(String sCallbackType,Bundle pm)
    {
        Log.e(LOG_TAG,String.format("Callback Count:%d",mMirrorLinkServerCallbacks.size()));
        for (IMirrorLinkServerCallback cb: mMirrorLinkServerCallbacks){
            try	{
                Log.e(LOG_TAG, String.format("Callback from %s with type %s ", MirrorLinkManager.this.getClass().getCanonicalName(), sCallbackType));
                cb.onMirrorLinkServerCall(MirrorLinkManager.this,sCallbackType,pm);
            }
            catch (Exception e)	{
                e.printStackTrace();
            }
        }
    }*/

    public MirrorLinkApplicationContext getContext()
    {
        return mContext;
    }

    public ICommonAPIService getMirrorLinkService()
    {
        if(mContext!=null)  return  mContext.getService();
        return null;
    }


    public boolean isMirrorLinkServerConnected()
    {
        if(mContext!=null) return mContext.isMirrorLinkServerConnected();
        return false;
    }


    @Override
    public abstract void register();

    @Override
    public  void unRegister()
    {
        clearCallbacks();

    }

    @Override
    public void addCallback(IMirrorLinkServerCallback cb) {
        if (cb != null && !mMirrorLinkServerCallbacks.contains(cb))
            mMirrorLinkServerCallbacks.add(cb);

    }

    @Override
    public void removeCallback(IMirrorLinkServerCallback cb) {
        if (cb != null && mMirrorLinkServerCallbacks.contains(cb))
            mMirrorLinkServerCallbacks.remove(cb);

    }

    public void clearCallbacks(){
        mMirrorLinkServerCallbacks.clear();
    }
}
