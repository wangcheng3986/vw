package com.navinfo.mirrorlink;

/**
 * Created by weihongying@navinfo.com on 2015/1/8.
 */
import java.util.ArrayList;
import java.util.List;

import android.app.Application;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.widget.Toast;

import com.mirrorlink.android.commonapi.Defs;
import com.mirrorlink.android.commonapi.ICommonAPIService;


public class MirrorLinkApplicationContext  implements IMirrorLinkManager,ServiceConnection {
    String LOG_TAG = MirrorLinkApplicationContext.class.getCanonicalName();


    private static volatile ICommonAPIService mService = null;
    //protected MlServerApiServiceConnection mlsConnection = null;

    IMirrorLinkManager[] mMirrorLinkManagers =null;
    List<IMirrorLinkServerCallback> mMirrorLinkServerCallbacks = new ArrayList<IMirrorLinkServerCallback>();

    boolean mMirrorLinkServerConnected=false;

    private Context mContext=null;

    public MirrorLinkApplicationContext(Context context)
    {
        mContext=context;
    }

    public Context getContext()
    {
        return mContext;
    }


    public String getPackageName()
    {
        if(getContext()!=null) return getContext().getPackageName();
        return null;
    }


    IMirrorLinkManager[] getMirrorLinkManagers() {
        return new IMirrorLinkManager[] {
                new MirrorLinkDisplayManager(this),
                new MirrorLinkConnectionManager(this),
                new MirrorLinkDeviceManager(this),
                new MirrorLinkContextManager(this),
                new MirrorLinkEventManager(this),
                new MirrorLinkCertificationManager(this),
                new MirrorLinkNotificationManager(this),
                new MirrorLinkDataServicseManager(this)
        };
    }

    public IMirrorLinkManager[] getAllMirrorLinkManagers()
    {
        if(mMirrorLinkManagers==null)
            mMirrorLinkManagers=getMirrorLinkManagers();
        return mMirrorLinkManagers;
    }



    public void addCallbackToAllMirrorLinkManagers(IMirrorLinkServerCallback cb)
    {
        if(!isMirrorLinkSessionEstablished()) return;

        if(mMirrorLinkManagers==null) return;

        for (IMirrorLinkManager manager: mMirrorLinkManagers) {
            manager.addCallback(cb);
        }
    }

    public IMirrorLinkManager getMirrorLinkManager(String sClassName)
    {

        if(!isMirrorLinkSessionEstablished()) return null;

        if(mMirrorLinkManagers==null) return null;

        for (IMirrorLinkManager manager: mMirrorLinkManagers) {
            if(manager.getClass().getCanonicalName().indexOf(sClassName)!=-1)
                return manager;

        }

        return null;
    }


    private MirrorLinkConnectionManager getConnectionManager()
    {
        //MirrorLinkConnectionManager
        if(mMirrorLinkManagers==null) return null;

        for (IMirrorLinkManager manager: mMirrorLinkManagers) {
            if(manager.getClass().getCanonicalName().indexOf(MirrorLinkConnectionManager.class.getCanonicalName())!=-1)
                return (MirrorLinkConnectionManager)manager;

        }

        return  null;
    }

    /*@Override
    public void onCreate()
    {
        super.onCreate();

        register();

    }*/



    public void registerToMirrorLink(){

        if(mMirrorLinkManagers==null)
            mMirrorLinkManagers=getMirrorLinkManagers();
        if(mMirrorLinkManagers!=null && mMirrorLinkManagers.length>0)
            for (IMirrorLinkManager manager: mMirrorLinkManagers) {
                manager.register();

            }

        //registerDisplayManager();

    }

    public void unregisterFromMirrorLink() {
        //mMirrorLinkManagers=getMirrorLinkManagers();
        if(mMirrorLinkManagers!=null && mMirrorLinkManagers.length>0)
            for (IMirrorLinkManager manager: mMirrorLinkManagers) {
                manager.unRegister();

            }
        //unregisterDisplayManager();
    }

    public ICommonAPIService getService()
    {
        return mService;
    }

    void showMsg(String sMsg)
    {

        //Toast.makeText(getContext(), sMsg, Toast.LENGTH_LONG).show();
    }


     void connect()
    {

        Log.v(LOG_TAG, "Connect to service");
        //mlsConnection = new MlServerApiServiceConnection(this,serviceConnetedCallback,serviceDisconnectedCallback);
        //mlsConnection.connectService();

        showMsg("Connect to service");

        try {
            Intent bindIntent = new Intent(Defs.Intents.BIND_MIRRORLINK_API);
            if(getContext()!=null) getContext().bindService(bindIntent, this, Context.BIND_AUTO_CREATE);
        }
        catch (Exception e)
        {
            showMsg(e.getMessage());
        }



    }

     void disconnect()
    {
        /*if(mlsConnection!=null) {
            Log.v(LOG_TAG, "Disconnect from service");
            unregisterFromMirrorLink();
            mlsConnection.disconnectService();
            mlsConnection = null;
        }
        else
            mService=null;*/

        if(isMirrorLinkServerConnected() && mService!=null)
        {
            unregisterFromMirrorLink();
            Log.v(LOG_TAG, "Disconnect from service");
            getContext().unbindService(this);
        }

    }


    protected void callCallbacks(String sCallbackType,Object... pms)
    {
        for (IMirrorLinkServerCallback cb: mMirrorLinkServerCallbacks){
            try	{
                cb.onMirrorLinkServerCall(this,sCallbackType,pms);
            }
            catch (Exception e)	{
                e.printStackTrace();
            }
        }
    }


    public boolean isMirrorLinkServerConnected()
    {
        return  mMirrorLinkServerConnected;
    }


    /**
     * MirrorLink会话是否已经建立
     * @return true 是
     */
    public boolean isMirrorLinkSessionEstablished()
    {
        if(!isMirrorLinkServerConnected()) return false;

        MirrorLinkConnectionManager m= getConnectionManager();
        if(m!=null) return  m.isMirrolinkSessionEstablished();

        return false;

    }

    @Override
    public  void register()
    {
        connect();
    }

    @Override
    public  void unRegister()
    {
        mMirrorLinkServerCallbacks.clear();
        disconnect();
    }

    @Override
    public void addCallback(IMirrorLinkServerCallback cb) {
        if (cb != null && !mMirrorLinkServerCallbacks.contains(cb))
            mMirrorLinkServerCallbacks.add(cb);

    }

    @Override
    public void removeCallback(IMirrorLinkServerCallback cb) {
        if (cb != null && mMirrorLinkServerCallbacks.contains(cb))
            mMirrorLinkServerCallbacks.remove(cb);

    }

    @Override
    public void onServiceConnected(ComponentName name, IBinder service) {
        ICommonAPIService s = ICommonAPIService.Stub.asInterface(service);

        mService = s;
        mMirrorLinkServerConnected=true;

        //Toast.makeText(getContext(),"MirrorLink Server 连接OK", Toast.LENGTH_SHORT).show();

        Log.d(LOG_TAG, "onServiceConnected Called");
        try {
            mService.applicationStarted(getPackageName(), mService.getCommonAPIServiceApiLevel());
        } catch (RemoteException e8) {
            e8.printStackTrace();
        }

        registerToMirrorLink();
        callCallbacks(MirrorLinkManager.CallBackType.SERVICE_CONNECTED);
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
        Log.d(LOG_TAG, "onServiceDisconnected Called");

        mMirrorLinkServerConnected=false;
        mService = null;

        callCallbacks(MirrorLinkManager.CallBackType.SERVICE_DISCONNECTED);
        //Toast.makeText(MirrorLinkApplicationContext.this,"MirrorLink Server 连接已断开", Toast.LENGTH_SHORT).show();



    }
}

