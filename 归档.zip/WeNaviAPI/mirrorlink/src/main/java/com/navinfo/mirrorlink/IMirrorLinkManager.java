package com.navinfo.mirrorlink;

/**
 * Created by weihongying@navinfo.com on 2015/1/14.
 */
public interface IMirrorLinkManager {
    public void register();
    public void unRegister();
    public void addCallback(IMirrorLinkServerCallback cb);
    public void removeCallback(IMirrorLinkServerCallback cb);
}
