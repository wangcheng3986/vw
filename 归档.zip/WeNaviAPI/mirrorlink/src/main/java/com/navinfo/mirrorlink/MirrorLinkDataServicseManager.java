package com.navinfo.mirrorlink;

import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;

import com.mirrorlink.android.commonapi.Defs;
import com.mirrorlink.android.commonapi.ICommonAPIService;
import com.mirrorlink.android.commonapi.IDataServicesListener;
import com.mirrorlink.android.commonapi.IDataServicesManager;

import java.util.ArrayList;

import java.util.List;


/**
 * Created by weihongying@navinfo.com on 2015/1/14.
 */
public class MirrorLinkDataServicseManager extends MirrorLinkManager{
    public MirrorLinkDataServicseManager(MirrorLinkApplicationContext context) {
        super(context);
    }

    private final static String LOG_TAG = MirrorLinkEventManager.class.getCanonicalName();

    IDataServicesManager mManager=null;

    List<Bundle> mAvailableServices=null;

    IDataServicesListener mDataServicseListener = new IDataServicesListener.Stub() {

        @Override
        public void onSubscribeResponse(int serviceId, int objectId, boolean success, int subscriptionType, int interval) throws RemoteException {
            Bundle b=new Bundle();
            b.putInt("serviceId",serviceId);
            b.putInt("objectId",objectId);
            b.putBoolean("success",success);
            b.putInt("subscriptionType",subscriptionType);
            b.putInt("interval",interval);

            callCallbacks(CallBackType.DATA_SERVICES_SUBSCRIBE_RESPONSE,b);
        }

        @Override
        public void onSetDataObjectResponse(int serviceId, int objectId, boolean success) throws RemoteException {
            Bundle b=new Bundle();
            b.putInt("serviceId",serviceId);
            b.putInt("objectId",objectId);
            b.putBoolean("success",success);
            callCallbacks(CallBackType.DATA_SERVICES_SETDATAOBJECT_RESPONSE,b);

        }

        @Override
        public void onRegisterForService(int serviceId, boolean success) throws RemoteException {
            Bundle b=new Bundle();
            b.putInt("serviceId",serviceId);

            b.putBoolean("success",success);
            callCallbacks(CallBackType.DATA_SERVICES_REGISTER_RESPONSE,b);
        }

        @Override
        public void onGetDataObjectResponse(int serviceId, int objectId, boolean success, Bundle object) throws RemoteException {
            Bundle b=new Bundle();
            b.putInt("serviceId",serviceId);
            b.putInt("objectId",objectId);
            b.putBoolean("success",success);
            b.putBundle("object",object);
            callCallbacks(CallBackType.DATA_SERVICES_GETDATAOBJECT_RESPONSE,b);
        }

        @Override
        public void onAvailableServicesChanged(List<Bundle> services) throws RemoteException {
            mAvailableServices=services;
            callCallbacks(CallBackType.AVAILABLE_DATA_SERVICES_CHANGED);
        }
    };

    @Override
    public void register() {
        Log.v(LOG_TAG, "register to Server  ");
        try {
            if (mManager == null) {
                ICommonAPIService service = getMirrorLinkService();
                if (service != null)
                    mManager = service.getDataServicesManager(getContext().getPackageName(), mDataServicseListener);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void unRegister() {
        super.unRegister();
        try {

            if (mManager != null)
            {
                mManager.unregister();
                mManager = null;
                mAvailableServices=null;

            }


        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }


    /**
     * 4.11.1 Get Available Services.
     *
     * <br>
     * <i>Function reference 0x0A01.</i>
     * <br>
     * Retrieve list of available Services provided from the MirrorLink Client and supported from
     * the MirrorLink Server.
     *
     * @return  List of provided services;
     *          an empty list is returned if the CDB connection has not been established. The list
     *          contains Bundles with the fields as defined in {@link Defs.ServiceInformation}.
     */
    public List<MirrorLinkDataServiceInformation> getAvailableServices()
    {
        if(mAvailableServices==null)
        {
            if(mManager!=null)
                try{
                    mAvailableServices=mManager.getAvailableServices();
                }catch (RemoteException e) {
                    e.printStackTrace();
                }
        }
        if(mAvailableServices!=null)
        {
            List<MirrorLinkDataServiceInformation> lsInfo= new ArrayList<MirrorLinkDataServiceInformation>();
            for(Bundle b : mAvailableServices)
            {
                lsInfo.add(new MirrorLinkDataServiceInformation(b));
            }
            return lsInfo;
        }

        return null;
    }

    /**
     * 4.11.3 Register to a Service.
     *
     * <br>
     * <i>Function reference 0x0A03.</i>
     * <br>
     * Register to an available Service.
     *
     * @param serviceId Service identifier. Can be one of {@link
     * Defs.LocationService#LOCATION_OBJECT_UID}, or {@link Defs.GPSService#NMEA_OBJECT_UID}.
     * @param versionMajor The major version of the service supported by the application.
     * @param versionMinor The minor version of the service supported by the application.
     */
    public void registerToService( int serviceId,  int versionMajor,  int versionMinor)
    {
        if(mManager!=null)
            try{
                mManager.registerToService(serviceId,versionMajor,versionMinor);
            }catch (RemoteException e) {
                e.printStackTrace();
            }
    }

    /**
     * 4.11.5 Unregister from a Service.
     *
     * <br>
     * <i>Function reference 0x0A05.</i>
     * <br>
     * Unregister from an available Service.
     *
     * @param serviceId Service identifier.
     */
    public void unregisterFromService(int serviceId)
    {
        if(mManager!=null)
            try{
                mManager.unregisterFromService(serviceId);
            }catch (RemoteException e) {
                e.printStackTrace();
            }
    }

    /**
     * 4.11.6 Subscribe to an Object.
     *
     * <br>
     * <i>Function reference 0x0A06.</i>
     * <br>
     * Subscribe a Service Object.
     *
     * @param serviceId Service identifier.
     * @param objectId Hash value of the object.
     */
    public void subscribeObject( int serviceId,  int objectId)
    {
        if(mManager!=null)
            try{
                mManager.subscribeObject(serviceId, objectId);
            }catch (RemoteException e) {
                e.printStackTrace();
            }
    }

    /**
     * 4.11.8 Unsubscribe from an Object.
     *
     * <br>
     * <i>Function reference 0x0A08.</i>
     * <br>
     * Unsubscribe from a Service Object.
     *
     * @param serviceId Service identifier.
     * @param objectId Hash value of the object.
     */
    public void unsubscribeObject( int serviceId,  int objectId)
    {
        if(mManager!=null)
            try{
                mManager.unsubscribeObject(serviceId, objectId);
            }catch (RemoteException e) {
                e.printStackTrace();
            }
    }

    /**
     * 4.11.9 Set an Object.
     *
     * <br>
     * <i>Function reference 0x0A09.</i>
     * <br>
     * Set a Service Object. Requires established CDB connection and registered service.
     *
     * The Object is packaged as a Bundle as described in {@link Defs.DataObjectKeys}.
     *
     * @param serviceId Service identifier.
     * @param objectId the hash value of the object.
     * @param object Bundle containing the object payload.
     */
    public void setObject( int serviceId,  int objectId,  Bundle object)
    {
        if(mManager!=null)
            try{
                mManager.setObject(serviceId, objectId, object);
            }catch (RemoteException e) {
                e.printStackTrace();
            }
    }

    /**
     * 4.11.11 Get an Object.
     *
     * <br>
     * <i>Function reference 0x0A0B.</i>
     * <br>
     * Get a Service Object. Requires established CDB connection and registered service.
     *
     * @param serviceId Service identifier
     * @param objectId the hash value of the object
     */
    public void getObject( int serviceId,  int objectId)
    {
        if(mManager!=null)
            try{
                mManager.getObject(serviceId, objectId);
            }catch (RemoteException e) {
                e.printStackTrace();
            }
    }


}
