package com.navinfo.mirrorlink;

/**
 * Created by Doone on 2015/3/10.
 */
public interface IMirrorLinkBuilder {

    public MirrorLinkApplicationContext getMirrorLinkContext();
}
