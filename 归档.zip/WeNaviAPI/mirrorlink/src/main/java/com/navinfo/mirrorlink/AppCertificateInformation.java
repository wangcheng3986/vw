package com.navinfo.mirrorlink;

import android.os.Bundle;

import com.mirrorlink.android.commonapi.Defs;

/**
 * Created by weihongying@navinfo.com on 2015/1/14.
 */
public class  AppCertificateInformation {

    Bundle mCertificateInformation=null;

    public AppCertificateInformation(Bundle b)
    {
        mCertificateInformation=b;
    }

    /**
     * Name of the certifying entity.
     * String
     */
    public String getEntityName()
    {
        if(mCertificateInformation!=null)return mCertificateInformation.getString(Defs.CertificateInformation.ENTITY);
        return "";
    }

    /**
     * Flag, whether the application has been certified from the given entity.
     * boolean
     */
    public  boolean isCertified()
    {
        if(mCertificateInformation!=null)return mCertificateInformation.getBoolean(Defs.CertificateInformation.CERTIFIED);
        return false;
    }

    /**
     * Comma-separated list of locales for which the application has been certified
     * for restricted use (drive-level) from the given entity.
     * String
     */
    public String getDriveLevelCertified()
    {
        if(mCertificateInformation!=null)return mCertificateInformation.getString(Defs.CertificateInformation.RESTRICTED);
        return "";
    }

    /**
     * Comma-separated list of locales for which the application has been certified
     * for non-restricted use (base-level) from the given entity.
     * String
     */
    public String getBaseLevelCertified()
    {
        if(mCertificateInformation!=null)return mCertificateInformation.getString(Defs.CertificateInformation.RESTRICTED);
        return "";
    }

}

