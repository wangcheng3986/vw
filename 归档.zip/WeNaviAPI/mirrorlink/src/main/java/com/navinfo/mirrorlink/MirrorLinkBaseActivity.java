package com.navinfo.mirrorlink;


import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.app.Activity;
import android.os.RemoteException;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.Toast;

import com.mirrorlink.android.commonapi.Defs;


/**
 * Created by weihongying@navinfo.com on 2015/1/10.
 */
public abstract class MirrorLinkBaseActivity extends Activity implements IMirrorLinkServerCallback {


    private final static String LOG_TAG = MirrorLinkBaseActivity.class.getCanonicalName();
    private MirrorLinkApplicationContext mMirrorLinkApplicationContext = null;


    private boolean mIsPlaying = false;
    private boolean mIsMute = false;
    


    public MirrorLinkApplicationContext getMirrorLinkContext() 
    {
        return mMirrorLinkApplicationContext;
    }


    public void setMirrorLinkContext(MirrorLinkApplicationContext c)
    {
        mMirrorLinkApplicationContext=c;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        processIntent();


        Log.e(this.getClass().getCanonicalName(), "onCreate... ");
        //setContentView(R.layout.activity_mirror_link_base);

        loadUi(null);

    }


    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        processIntent();
    }


    protected void processIntent()
    {
        Intent it=getIntent();
        if(it.getAction()== Defs.Intents.TERMINATE_MIRRORLINK_APP)
        {
            if(isMirrorLinkMaster()) {
                Log.e(LOG_TAG, "disConnect from ML Server... ");
                if (getMirrorLinkContext()  != null && getMirrorLinkContext().getService() != null) {
                    try {
                        getMirrorLinkContext().getService().applicationStopping(getPackageName());
                    } catch (RemoteException e) {
                        Log.e(LOG_TAG, e.getMessage());
                    }
                    getMirrorLinkContext().unRegister();
                }

                return;
            }
        }
        /*else if(it.getAction()== Defs.Intents.LAUNCH_MIRRORLINK_APP)
        {
            //if(it.getAction()== Defs.Intents.TERMINATE_MIRRORLINK_APP)
        }*/

        connectToMirrorLinkServer();

    }


    protected void  connectToMirrorLinkServer()
    {
        try {
            Context c=getApplicationContext();
            if(c instanceof  IMirrorLinkBuilder) {
                setMirrorLinkContext(((IMirrorLinkBuilder) c).getMirrorLinkContext());
                if (getMirrorLinkContext().getService() == null) {
                    Log.e(LOG_TAG, "MirrorLinkApplicationContext.register() call..");
                    getMirrorLinkContext().addCallback(this);
                    getMirrorLinkContext().register();

                    /*runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(getApplicationContext(), "MirrorLinkApplicationContext.register() call..", Toast.LENGTH_LONG).show();

                        }
                    });*/


                }
            }
        }
        catch (Exception e) {
            Log.e(LOG_TAG, e.getMessage());


        }
    }





    /**
     * 加载UI
     */
    protected abstract void loadUi(Configuration newConfig);

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        loadUi(newConfig);
    }


    /**
     * 是否为负责维护MirrorLink 连接，只有主Activity需要重载在函数并返回true。
     * @return true 是
     */
    protected  boolean isMirrorLinkMaster()
    {
        return false;
    }


    /***
     * 获取MirrorLink 管理器
     * @param sClassName 管理器类名
     * @return IMirrorLinkManager 实例
     */
    public IMirrorLinkManager getMirrorLinkManager(String sClassName)
    {
        return getMirrorLinkContext() .getMirrorLinkManager(sClassName);
    }


    /**
     * MirrorLink会话是否已经建立
     * @return true 是
     */
    public boolean isMirrorLinkSessionEstablished()
    {
        return getMirrorLinkContext() .isMirrorLinkSessionEstablished();
    }


    /**
     * 是否处于夜间模式
     * @return true 是
     */
    public boolean isInNightMode()
    {
        MirrorLinkDeviceManager m = (MirrorLinkDeviceManager)getMirrorLinkManager(MirrorLinkDeviceManager.class.getCanonicalName());
        if(m!=null) return m.isInNightMode();
        return false;
    }


    /**
     * 是否处于驾驶模式
     * @return true 是
     */
    public boolean isInDriveMode()
    {
        MirrorLinkDeviceManager m = (MirrorLinkDeviceManager)getMirrorLinkManager(MirrorLinkDeviceManager.class.getCanonicalName());
        if(m!=null) return m.isInDriveMode();
        return false;
    }

    @Override
    protected void onResume() {
        super.onResume();

        Log.e(LOG_TAG, "onResume... ");
        //registor all mirrorlink managers to MirrorLink Server


        if(getMirrorLinkContext() !=null &&
                getMirrorLinkContext() .isMirrorLinkServerConnected()) {
            Log.e(LOG_TAG, "registerToMirrorLink... ");
            getMirrorLinkContext() .registerToMirrorLink();
            addCallbackAfterConnect();
        }
        else
        {
            //Log.e(LOG_TAG, "Common API not available!!!");
            //Toast.makeText(this, "Common API not available", Toast.LENGTH_SHORT).show();
            //finish();
            return;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(isMirrorLinkMaster()) {
            Log.e(LOG_TAG, "onPause... ");
            //unregistor all mirrorlink managers from MirrorLink Server
            if (getMirrorLinkContext()  != null) {
                Log.e(LOG_TAG, "unregisterFromMirrorLink... ");
                getMirrorLinkContext() .unregisterFromMirrorLink();
            }
        }
    }


    @Override
    protected void onDestroy()
    {
        if(isMirrorLinkMaster()) {
            Log.e(LOG_TAG, "onDestroy... ");
            if (getMirrorLinkContext()  != null && getMirrorLinkContext() .getService() != null) {
                try {
                    getMirrorLinkContext() .getService().applicationStopping(getPackageName());
                } catch (RemoteException e) {
                    Log.e(LOG_TAG, e.getMessage());
                }

                getMirrorLinkContext() .unRegister();
            }
        }
        super.onDestroy();
    }

    public void setMirrorLinkContext()
    {
        Log.e(LOG_TAG, "Set framebuffer context... ");
        MirrorLinkContextManager m=(MirrorLinkContextManager)getMirrorLinkContext() .getMirrorLinkManager(MirrorLinkContextManager.class.getCanonicalName());
        if(m!=null)
        {
            FramebufferContentConfig c=new FramebufferContentConfig(isHandleFramebufferBlock());

            DisplayMetrics dm = new DisplayMetrics();
            this.getWindowManager().getDefaultDisplay().getMetrics(dm);
            c.AddConfig(0,0,dm.widthPixels,dm.heightPixels,getAppCategory(),getFrameCategory());

            m.setFramebufferContextInformation(c);

            m.setAudioContextInformation(hasAudio(),getAudioCategory(),isHandleAudioBlock());
        }


    }

    //Activity Context Category

    /**
     * Application category of this activity
     * @return int value of category defined in {@link com.mirrorlink.android.commonapi.Defs.ContextInformation}
     */
    protected abstract int getAppCategory();

    /**
     * Framebuffer category of this activity
     * @return int value of category defined in {@link com.mirrorlink.android.commonapi.Defs.ContextInformation}
     */
    protected abstract int getFrameCategory();

    /**
     * Indicates whether or not this activity will handle frame buffer block
     * @return true means Yes
     */
    protected abstract boolean isHandleFramebufferBlock();


    /**
     * Audio category of this activity
     * @return int value of category defined in {@link com.mirrorlink.android.commonapi.Defs.ContextInformation}
     */
    protected abstract int[] getAudioCategory();

    /**
     * Indicates whether or not this activity output audio when in show
     * @return true means Yes and getAudioCategory() MUST return corresponding type
     */
    protected abstract boolean hasAudio();


    /**
     * Indicates whether or not this activity will handle audio block
     * @return true means Yes
     */
    protected abstract boolean isHandleAudioBlock();





    //MirrorLinkCertificationManager Interactors
    protected void onCertificationStatusChanged(IMirrorLinkManager manager) {}


    //MirrorLinkDisplayManager Interactors

    protected void onMirrorLinkDevicePixelFormatChanged(IMirrorLinkManager manager){}

    protected void onMirrorLinkDeviceDisplayChanged(IMirrorLinkManager manager){}

    //MirrorLinkConnectionManager Interactors

    protected void onMirrorLinkSessionChanged(IMirrorLinkManager manager)
    {
        MirrorLinkConnectionManager m=(MirrorLinkConnectionManager)manager;
        if(m.isMirrolinkSessionEstablished())
        {


            /**
             * 设置为横屏
             */
            if(getRequestedOrientation()!= ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE){
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            }
            setMirrorLinkContext();
        }
        else
        {
           /* if(getRequestedOrientation()!= ActivityInfo.SCREEN_ORIENTATION_PORTRAIT){
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }*/
        }
    }

    protected void onRemoteDisplayConnectionChanged(IMirrorLinkManager manager){}

    protected void onAudioConnectionsChanged(IMirrorLinkManager manager){}

    //MirrorLinkContextManager Interactors
    protected void onFramebufferBlocked(IMirrorLinkManager manager){}

    protected void onAudioBlocked(IMirrorLinkManager manager){}

    protected void onFramebufferUnblocked(IMirrorLinkManager manager){}

    protected void onAudioUnblocked(IMirrorLinkManager manager){}

    //MirrorLinkDeviceManager Interactors
    protected void onNightModeChanged(IMirrorLinkManager manager){}

    protected void onMicrophoneStatusChanged(IMirrorLinkManager manager){}

    protected void onDriveModeChange(IMirrorLinkManager manager){}


    /**
     * add callback to manager, note: callback can be add only after ML Server connected
     */
    protected void addCallbackAfterConnect()
    {
        /*IMirrorLinkManager displayManager=getMirrorLinkContext() .getMirrorLinkManager("MirrorLinkDisplayManager");
        if(displayManager!=null){
            displayManager.addCallback(this);
        }*/

        getMirrorLinkContext() .addCallbackToAllMirrorLinkManagers(this);

        IMirrorLinkManager manager=getMirrorLinkContext() .getMirrorLinkManager(MirrorLinkConnectionManager.class.getCanonicalName());
        if(manager!=null) onMirrorLinkSessionChanged(manager);

    }

    /**
     * MirrorLink Server 回调，接收处理MirrorLink Server发送给App的事件
     * @param manager MirrorLink 管理器
     * @param sCallbackType 回调类型
     * @param  pms 回调参数
     */
    @Override
    public void onMirrorLinkServerCall(final IMirrorLinkManager manager, final String sCallbackType,Object... pms) {

        String sInfo=String.format("Callback %s with %s",sCallbackType,manager.getClass().getCanonicalName());
        Log.e(LOG_TAG,sInfo);

        if(sCallbackType==MirrorLinkManager.CallBackType.CLIENT_DISPLAY_CONFIG_CHANGED)
            onMirrorLinkDeviceDisplayChanged( manager);
        else if(sCallbackType==MirrorLinkManager.CallBackType.CLIENT_PIXEL_CHANGED)
            onMirrorLinkDevicePixelFormatChanged( manager);
        else if(sCallbackType==MirrorLinkManager.CallBackType.SERVICE_CONNECTED)
            addCallbackAfterConnect();
        else if(sCallbackType==MirrorLinkManager.CallBackType.MIRRORLINK_SESSION_CHANGED)
            onMirrorLinkSessionChanged( manager);
        else if(sCallbackType==MirrorLinkManager.CallBackType.CLIENT_DISPLAY_CONNECTION_CHANGED)
            onRemoteDisplayConnectionChanged( manager);
        else if(sCallbackType==MirrorLinkManager.CallBackType.CLIENT_AUDIO_CONNECTION_CHANGED)
            onAudioConnectionsChanged( manager);
        else if(sCallbackType==MirrorLinkManager.CallBackType.FRAPME_BUFFER_BLOCKED)
            onFramebufferBlocked( manager);
        else if(sCallbackType==MirrorLinkManager.CallBackType.AUDIO_BLOCKED)
            onAudioBlocked( manager);
        else if(sCallbackType==MirrorLinkManager.CallBackType.FRAPME_BUFFER_UNBLOCKED)
            onFramebufferUnblocked( manager);
        else if(sCallbackType==MirrorLinkManager.CallBackType.AUDIO_UNBLOCKED)
            onAudioUnblocked( manager);
        else if(sCallbackType==MirrorLinkManager.CallBackType.CERTIFICATION_STATUS_CHANGED)
            onCertificationStatusChanged( manager);
        else if(sCallbackType==MirrorLinkManager.CallBackType.CLIENT_DRIVEMODE_CHANGED)
            onDriveModeChange(manager);
        else if(sCallbackType==MirrorLinkManager.CallBackType.CLIENT_NIGHTMODE_CHANGED)
            onNightModeChanged(manager);
        else if(sCallbackType==MirrorLinkManager.CallBackType.CLIENT_MICINPUT_CHANGED)
            onMicrophoneStatusChanged(manager);



    }




    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        int nKnobID = 0;
        switch (keyCode) {
            //Knob
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                onMirrorLinkClientKnobKeyShift(nKnobID,MirrorLinkEvent.KnobShiftDirection.ShiftRight);
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                onMirrorLinkClientKnobKeyShift(nKnobID,MirrorLinkEvent.KnobShiftDirection.ShiftLeft);
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
                onMirrorLinkClientKnobKeyShift(nKnobID,MirrorLinkEvent.KnobShiftDirection.ShiftUp);
                return true;
            case KeyEvent.KEYCODE_BUTTON_1:
                onMirrorLinkClientKnobKeyShift(nKnobID,MirrorLinkEvent.KnobShiftDirection.ShiftUpRight);
                return true;
            case KeyEvent.KEYCODE_BUTTON_2:
                onMirrorLinkClientKnobKeyShift(nKnobID,MirrorLinkEvent.KnobShiftDirection.ShiftUpLeft);
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                onMirrorLinkClientKnobKeyShift(nKnobID,MirrorLinkEvent.KnobShiftDirection.ShiftDown);
                return true;
            case KeyEvent.KEYCODE_BUTTON_3:
                onMirrorLinkClientKnobKeyShift(nKnobID,MirrorLinkEvent.KnobShiftDirection.ShiftDownRight);
                return true;
            case KeyEvent.KEYCODE_BUTTON_4:
                onMirrorLinkClientKnobKeyShift(nKnobID,MirrorLinkEvent.KnobShiftDirection.ShiftDownLeft);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
                onMirrorLinkClientKnobKeyPush(nKnobID);
                return true;
            case KeyEvent.KEYCODE_BUTTON_L1:
                onMirrorLinkClientKnobKeyRotate(nKnobID,MirrorLinkEvent.KnobRotateAxis.X,MirrorLinkEvent.KnobRotateDirection.RotateLeft);
                return true;
            case KeyEvent.KEYCODE_BUTTON_R1:
                onMirrorLinkClientKnobKeyRotate(nKnobID,MirrorLinkEvent.KnobRotateAxis.X,MirrorLinkEvent.KnobRotateDirection.RotateRight);
                return true;
            case KeyEvent.KEYCODE_BUTTON_L2:
                onMirrorLinkClientKnobKeyRotate(nKnobID,MirrorLinkEvent.KnobRotateAxis.Y,MirrorLinkEvent.KnobRotateDirection.RotateLeft);
                return true;
            case KeyEvent.KEYCODE_BUTTON_R2:
                onMirrorLinkClientKnobKeyRotate(nKnobID,MirrorLinkEvent.KnobRotateAxis.Y,MirrorLinkEvent.KnobRotateDirection.RotateRight);
                return true;
            case KeyEvent.KEYCODE_BUTTON_THUMBL:
                onMirrorLinkClientKnobKeyRotate(nKnobID,MirrorLinkEvent.KnobRotateAxis.Z,MirrorLinkEvent.KnobRotateDirection.RotateLeft);
                return true;
            case KeyEvent.KEYCODE_BUTTON_THUMBR:
                onMirrorLinkClientKnobKeyRotate(nKnobID,MirrorLinkEvent.KnobRotateAxis.Z,MirrorLinkEvent.KnobRotateDirection.RotateRight);
                return true;
            //ITU
            case KeyEvent.KEYCODE_0:
                onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey.ITU_Key_0);
                return true;
            case KeyEvent.KEYCODE_1:
                onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey.ITU_Key_1);
                return true;
            case KeyEvent.KEYCODE_2:
                onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey.ITU_Key_2);
                return true;
            case KeyEvent.KEYCODE_3:
                onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey.ITU_Key_3);
                return true;
            case KeyEvent.KEYCODE_4:
                onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey.ITU_Key_4);
                return true;
            case KeyEvent.KEYCODE_5:
                onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey.ITU_Key_5);
                return true;
            case KeyEvent.KEYCODE_6:
                onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey.ITU_Key_6);
                return true;
            case KeyEvent.KEYCODE_7:
                onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey.ITU_Key_7);
                return true;
            case KeyEvent.KEYCODE_8:
                onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey.ITU_Key_8);
                return true;
            case KeyEvent.KEYCODE_9:
                onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey.ITU_Key_9);
                return true;
            case KeyEvent.KEYCODE_STAR:
                onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey.ITU_Key_Asterix);
                return true;
            case KeyEvent.KEYCODE_POUND:
                onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey.ITU_Key_Pound);
                return true;
            //Device
            case KeyEvent.KEYCODE_CALL:
                onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey.Device_Phone_call);
                return true;
            case KeyEvent.KEYCODE_ENDCALL:
                onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey.Device_Phone_end);
                return true;
            case KeyEvent.KEYCODE_SOFT_LEFT:
                onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey.Device_Soft_left);
                return true;
            case KeyEvent.KEYCODE_SOFT_RIGHT:
                onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey.Device_Soft_right);
                return true;
            case KeyEvent.KEYCODE_APP_SWITCH:
                onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey.Device_Application);
                return true;
            case KeyEvent.KEYCODE_ENTER:
                onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey.Device_Ok);
                return true;
            case KeyEvent.KEYCODE_DEL:
                onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey.Device_Delete);
                return true;
            case KeyEvent.KEYCODE_ZOOM_IN:
                onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey.Device_Zoom_in);
                return true;
            case KeyEvent.KEYCODE_ZOOM_OUT:
                onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey.Device_Zoom_out);
                return true;
            case KeyEvent.KEYCODE_CLEAR:
                onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey.Device_Clear);
                return true;
            //case KeyEvent.KEYCODE_BACK:
                //onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey.Device_Backward);

                //return true;
            //case KeyEvent.KEYCODE_HOME:
             //   onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey.Device_Home);
            //    return true;
            case KeyEvent.KEYCODE_SEARCH:
                onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey.Device_Search);
                return true;
            //case KeyEvent.KEYCODE_MENU:
            //    onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey.Device_Menu);
            //    return true;
            //Function
            case KeyEvent.KEYCODE_F1:
                onMirrorLinkClientFunctionKeyDown(0);
                return true;
            case KeyEvent.KEYCODE_F2:
                onMirrorLinkClientFunctionKeyDown(1);
                return true;
            case KeyEvent.KEYCODE_F3:
                onMirrorLinkClientFunctionKeyDown(2);
                return true;
            case KeyEvent.KEYCODE_F4:
                onMirrorLinkClientFunctionKeyDown(3);
                return true;
            case KeyEvent.KEYCODE_F5:
                onMirrorLinkClientFunctionKeyDown(4);
                return true;
            case KeyEvent.KEYCODE_F6:
                onMirrorLinkClientFunctionKeyDown(5);
                return true;
            case KeyEvent.KEYCODE_F7:
                onMirrorLinkClientFunctionKeyDown(6);
                return true;
            case KeyEvent.KEYCODE_F8:
                onMirrorLinkClientFunctionKeyDown(7);
                return true;
            case KeyEvent.KEYCODE_F9:
                onMirrorLinkClientFunctionKeyDown(8);
                return true;
            case KeyEvent.KEYCODE_F10:
                onMirrorLinkClientFunctionKeyDown(9);
                return true;
            case KeyEvent.KEYCODE_F11:
                onMirrorLinkClientFunctionKeyDown(10);
                return true;
            case KeyEvent.KEYCODE_F12:
                onMirrorLinkClientFunctionKeyDown(11);
                return true;
            //Multimedia
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                if(mIsPlaying){
                    onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey.Multimedia_Pause);
                }
                else{
                    onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey.Multimedia_Play);
                }
                mIsPlaying = !mIsPlaying;
                return true;
            case KeyEvent.KEYCODE_MEDIA_STOP:
                onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey.Multimedia_Stop);
                return true;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey.Multimedia_Forward);
                return true;
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey.Multimedia_Rewind);
                return true;
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey.Multimedia_Next);
                return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey.Multimedia_Previous);
                return true;
            case KeyEvent.KEYCODE_VOLUME_MUTE:
            case KeyEvent.KEYCODE_MUTE:
                if(mIsMute){
                    onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey.Multimedia_Unmute);
                }
                else{
                    onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey.Multimedia_Mute);
                }
                mIsMute = !mIsMute;
                return true;
            case KeyEvent.KEYCODE_CAMERA:
                onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey.Multimedia_Photo);
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }


    /**
     * MirrorLink 车机客户端旋钮平移事件回调
     * @param nKnobID 旋钮ID
     * @param dir 平移方向
     */
    protected void onMirrorLinkClientKnobKeyShift(int nKnobID,MirrorLinkEvent.KnobShiftDirection dir)
    {

    }


    /**
     * MirrorLink 车机客户端旋钮按压事件回调
     * @param nKnobID 旋钮ID
     */
    protected void onMirrorLinkClientKnobKeyPush(int nKnobID)
    {

    }

    /**
     * MirrorLink 车机客户端旋钮按旋转件回调
     * @param nKnobID 旋钮ID
     * @param dir 旋转方向
     */
    protected void onMirrorLinkClientKnobKeyRotate(int nKnobID,MirrorLinkEvent.KnobRotateAxis axis,MirrorLinkEvent.KnobRotateDirection dir)
    {

    }

    /**
     * MirrorLink 车机客户端旋钮拉拔事件回调
     * @param nKnobID 旋钮ID
     */
    protected void onMirrorLinkClientKnobKeyPull(int nKnobID)
    {

    }


    /**
     * MirrorLink 车机客户端ITU按钮按压事件回调
     * @param keyid  ITU按钮ID
     */
    protected void onMirrorLinkClientITUkeyDown(MirrorLinkEvent.ITUKey keyid)
    {

    }

    /**
     * MirrorLink 车机客户端车机设备按钮按压事件回调
     * @param keyid 按钮ID
     */
    protected void onMirrorLinkClientDeviceKeyDown(MirrorLinkEvent.DeviceKey keyid)
    {

    }

    /**
     * MirrorLink 车机客户端功能键按压事件回调
     * @param nKeyID 按钮ID
     */
    protected void onMirrorLinkClientFunctionKeyDown(int nKeyID)
    {

    }


    /**
     * MirrorLink 车机客户端多媒体按键按压事件回调
     * @param keyid 按钮ID
     */
    protected void onMirrorLinkCkientMultimediaKeyDown(MirrorLinkEvent.MultimediaKey keyid)
    {

    }


}
