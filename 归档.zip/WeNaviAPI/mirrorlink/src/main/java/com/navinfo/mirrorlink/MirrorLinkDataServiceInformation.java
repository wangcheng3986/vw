package com.navinfo.mirrorlink;

import android.os.Bundle;

import com.mirrorlink.android.commonapi.Defs;

/**
 * Created by weihongying@navinfo.com on 2015/1/15.
 */
public class MirrorLinkDataServiceInformation {

    Bundle mInfo=null;

    public MirrorLinkDataServiceInformation(Bundle b){
        mInfo=b;
    }

    /**
     * Major service version.
     * uint8 packaged as a int
     */
    public int getVersionMajor()
    {
        if(mInfo!=null) return mInfo.getInt(Defs.ServiceInformation.VERSION_MAJOR);
        return 0;
    }


    /**
     * Minor service version.
     * uint8 packaged as a int
     */
    public int getVersionMinor()
    {
        if(mInfo!=null) return mInfo.getInt(Defs.ServiceInformation.VERSION_MINOR);
        return 0;
    }

    /**
     * Service identifier.
     * uint16 packaged as an int
     */
    public int getServiceID()
    {
        if(mInfo!=null) return mInfo.getInt(Defs.ServiceInformation.SERVICE_ID);
        return 0;
    }

    /**
     * Service name.
     * String
     */
    public String getServiceName()
    {
        if(mInfo!=null) return mInfo.getString(Defs.ServiceInformation.SERVICE_NAME);
        return "";
    }

}


