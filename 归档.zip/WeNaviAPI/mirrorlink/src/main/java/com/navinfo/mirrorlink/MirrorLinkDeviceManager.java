package com.navinfo.mirrorlink;

import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;

import com.mirrorlink.android.commonapi.Defs;
import com.mirrorlink.android.commonapi.ICommonAPIService;
import com.mirrorlink.android.commonapi.IDeviceInfoListener;
import com.mirrorlink.android.commonapi.IDeviceInfoManager;
import com.mirrorlink.android.commonapi.IDeviceStatusListener;
import com.mirrorlink.android.commonapi.IDeviceStatusManager;

/**
 * Created by weihongying@navinfo.com on 2015/1/14.
 */
public class MirrorLinkDeviceManager extends  MirrorLinkManager {

    private final static String LOG_TAG = MirrorLinkDeviceManager.class.getCanonicalName();
    IDeviceInfoManager mInfoManager=null;
    IDeviceStatusManager mStatusManager=null;

    boolean mDriveMode=false;
    boolean mNightMode=false;
    boolean mMicInput=false;


    Bundle mClientInformation=null;
    Bundle mServerVirtualKeyboardSupport=null;


    public MirrorLinkDeviceManager(MirrorLinkApplicationContext context) {
        super(context);
    }


    IDeviceInfoListener mDeviceInfoListener = new IDeviceInfoListener.Stub() {
        @Override
        public void onDeviceInfoChanged(Bundle clientInformation) throws RemoteException {
            mClientInformation=clientInformation;
            callCallbacks(CallBackType.DECIVE_INFO_CHANGED);
        }
    };


    IDeviceStatusListener mDeviceStatusListener = new IDeviceStatusListener.Stub() {

        @Override
        public void onNightModeChanged(boolean nightMode) throws RemoteException {
            mNightMode=nightMode;
            callCallbacks(CallBackType.CLIENT_NIGHTMODE_CHANGED);
        }

        @Override
        public void onMicrophoneStatusChanged(boolean micInput) throws RemoteException {
            mMicInput=micInput;
            callCallbacks(CallBackType.CLIENT_MICINPUT_CHANGED);
        }

        @Override
        public void onDriveModeChange(boolean driveMode) throws RemoteException {
            mDriveMode=driveMode;
            callCallbacks(CallBackType.CLIENT_DRIVEMODE_CHANGED);

        }
    };

    @Override
    public void register() {
        Log.v(LOG_TAG, "register to Server  ");
        try {

                ICommonAPIService service = getMirrorLinkService();
                if (service != null) {

                    if (mInfoManager == null)
                        mInfoManager = service.getDeviceInfoManager(getContext().getPackageName(), mDeviceInfoListener);
                    if (mStatusManager == null)
                        mStatusManager = service.getDeviceStatusManager(getContext().getPackageName(), mDeviceStatusListener);
                }
            //mAudioConnections=mManager.getAudioConnections();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void unRegister() {
        super.unRegister();
        try {

            if (mInfoManager != null)
            {
                mInfoManager.unregister();
                mInfoManager = null;

            }

            if (mStatusManager != null)
            {
                mStatusManager.unregister();
                mStatusManager = null;

            }

            mDriveMode=false;
            mNightMode=false;
            mMicInput=false;


            mClientInformation=null;
            mServerVirtualKeyboardSupport=null;


        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }




    /**
     * 4.10.1 Drive Mode.
     *
     * <br>
     * <i>Function reference 0x0901.</i>
     * <br>
     * Check the drive mode status on the MirrorLink Server; requires established VNC connection.
     *
     * @return Flag set to true if the Server is in Drive Mode.
     */
    public boolean isInDriveMode() {
        try {
            if (mStatusManager != null) mDriveMode = mStatusManager.isInDriveMode();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return mDriveMode;
    }


    /**
     * 4.10.3 Night Mode.
     *
     * <br>
     * <i>Function reference 0x0903.</i>
     * <br>
     * Check the night mode status on the MirrorLink Server; requires established VNC connection.
     *
     * @return Flag set to true if the Server is in Night Mode.
     */
    public boolean isInNightMode()
    {
        try {
            if (mStatusManager != null) mNightMode = mStatusManager.isInNightMode();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return mNightMode;
    }

    /**
     * 4.10.5 Microphone State.
     *
     * <br>
     * <i>Function reference 0x0905.</i>
     * <br>
     * Check the status of the Microphone from the MirrorLink Client; requires established VNC
     * connection.
     *
     * @return Flag set to true if the mic input is enabled on MirrorLink Client.
     */
    public boolean isMicrophoneOn()
    {
        try {
            if (mStatusManager != null) mMicInput = mStatusManager.isMicrophoneOn();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return mMicInput;
    }

    /**
     * 4.10.7 Set Open Microphone.
     *
     * <br>
     * <i>Function reference 0x0907.</i>
     * <br>
     * Open the Microphone on the MirrorLink Client.
     *
     * @param micInput Flag enabling mic input on the MirrorLink Client.
     * @param voiceInput Flag enabling voice input on the MirrorLink Client. The application MUST
     * set the Mic Input flag to true if the Voice input flag is set to true.
     */
    public boolean setMicrophoneOpen( boolean micInput,  boolean voiceInput)
    {
        boolean bRet=false;
        try {
            if (mStatusManager != null) bRet = mStatusManager.setMicrophoneOpen(micInput,voiceInput);
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return bRet;
    }



    /**
     * 4.2.1 MirrorLink Session Major Version.
     *
     * <br>
     * <i>Function reference 0x0101.</i>
     * <br>
     * Available MirrorLink Version for the established connection, as agreed between the MirrorLink
     * Server and Client. Information MUST be available as soon as the MirrorLink session is
     * connected
     *
     * @return  MirrorLink Session major version
     *          or 1 if version information is not available.
     */
    public int getMirrorLinkSessionVersionMajor()
    {
        try {
            if (mInfoManager != null) return mInfoManager.getMirrorLinkSessionVersionMajor();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 4.2.1 MirrorLink Session Minor Version.
     *
     * <br>
     * <i>Function reference 0x0101.</i>
     * <br>
     * Available MirrorLink Version for the established connection, as agreed between the MirrorLink
     * Server and Client. Information MUST be available as soon as the MirrorLink session is
     * connected
     *
     * @return  MirrorLink Session minor version
     *          or 0 if version information is not available.
     */
    public int getMirrorLinkSessionVersionMinor()
    {
        try {
            if (mInfoManager != null) return mInfoManager.getMirrorLinkSessionVersionMinor();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return 0;
    }


    void loadClientInformation() {
        if(mClientInformation==null) {
            try {
                if (mInfoManager != null) mClientInformation = mInfoManager.getMirrorLinkClientInformation();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }



    /**
     * MirrorLink Session major version, as defined by the client.
     * int
     */
    public int getClientVersionMajor()
    {
        loadClientInformation();
        if(mClientInformation!=null) return mClientInformation.getInt(Defs.ClientInformation.VERSION_MAJOR);
        return 0;
    }

    /**
     * MirrorLink Session minor version, as defined by the client.
     */
    public int getClientVersionMinor()
    {
        loadClientInformation();
        if(mClientInformation!=null) return mClientInformation.getInt(Defs.ClientInformation.VERSION_MINOR);
        return 0;
    }

    /**
     * Identifier of the MirrorLink client.
     * String
     */
    public String getClientIdentifier()
    {
        loadClientInformation();
        if(mClientInformation!=null) return mClientInformation.getString(Defs.ClientInformation.CLIENT_IDENTIFIER);
        return "";
    }

    /**
     * Short user-friendly description of the MirrorLink client.
     * String
     */
    public String getClientFriendlyName()
    {
        loadClientInformation();
        if(mClientInformation!=null) return mClientInformation.getString(Defs.ClientInformation.CLIENT_FRIENDLY_NAME);
        return "";
    }

    /**
     * Manufacturer Name of the MirrorLink client.
     * String
     */
    public String getClientManufacturer()
    {
        loadClientInformation();
        if(mClientInformation!=null) return mClientInformation.getString(Defs.ClientInformation.CLIENT_MANUFACTURER);
        return "";
    }

    /**
     * Model name of the MirrorLink client.
     * String
     */
    public String getClientModelName()
    {
        loadClientInformation();
        if(mClientInformation!=null) return mClientInformation.getString(Defs.ClientInformation.CLIENT_MODEL_NAME);
        return "";
    }

    /**
     * Model number of the MirrorLink client.
     * String
     */
    public String getClientModelNumber()
    {
        loadClientInformation();
        if(mClientInformation!=null) return mClientInformation.getString(Defs.ClientInformation.CLIENT_MODEL_NUMBER);
        return "";
    }



    void loadServerVirtualKeyboardSupport() {
        if(mClientInformation==null) {
            try {
                if (mInfoManager != null) mServerVirtualKeyboardSupport = mInfoManager.getServerVirtualKeyboardSupport();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Flag, to indicate the availability of a virtual keyboard
     * from the MirrorLink Server.
     * boolean
     */
    public boolean isVirtualKeyboardAvailable()
    {
        loadServerVirtualKeyboardSupport();
        if(mClientInformation!=null) return mServerVirtualKeyboardSupport.getBoolean(Defs.VirtualKeyboardSupport.AVAILABLE);
        return false;
    }

    /**
     * Flag, to indicate whether the virtual keyboard supports
     * touch events.
     * boolean
     */
    public boolean isVirtualKeyboardTouchSupport()
    {
        loadServerVirtualKeyboardSupport();
        if(mClientInformation!=null) return mServerVirtualKeyboardSupport.getBoolean(Defs.VirtualKeyboardSupport.TOUCH_SUPPORT);
        return false;
    }

    /**
     * Flag, to indicate whether the virtual keyboard supports
     * knob events.
     * boolean
     */
    public boolean isVirtualKeyboardKnobSupport()
    {
        loadServerVirtualKeyboardSupport();
        if(mClientInformation!=null) return mServerVirtualKeyboardSupport.getBoolean(Defs.VirtualKeyboardSupport.KNOB_SUPPORT);
        return false;
    }

    /**
     * Flag, to indicate whether the virtual keyboard is following driver distraction ruling,
     * as set force for CCC drive-certification.
     * boolean
     */
    public boolean isVirtualKeyboardDriveModeSupport()
    {
        loadServerVirtualKeyboardSupport();
        if(mClientInformation!=null) return mServerVirtualKeyboardSupport.getBoolean(Defs.VirtualKeyboardSupport.DRIVE_MODE);
        return false;
    }


}
