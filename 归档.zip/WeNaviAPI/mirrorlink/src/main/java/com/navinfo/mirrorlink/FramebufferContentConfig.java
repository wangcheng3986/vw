package com.navinfo.mirrorlink;

import android.os.Bundle;

import com.mirrorlink.android.commonapi.Defs;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by weihongying@navinfo.com on 2015/1/16.
 *
 * Framebuffer Context Information builder.
 *
 * <br>
 * <i>Function reference 0x0801.</i>
 * <br>
 * Provides information of the current framebuffer context; the MirrorLink Server MUST use the
 * application and content category values from the UPnP advertisements, unless otherwise stated
 * from the application using this function. The MirrorLink Server MUST use the given values
 * until a new set function is called. Unless set by the application, the MirrorLink Server MUST
 * treat the "Handle Blocking" flag as being set to a FALSE value.
 * <br>
 * The application MUST continue updating the information, whenever the context chang-es, even
 * when the application is blocked (0x0802) by the MirrorLink Client. The Mir-rorLink Server
 * MUST store the latest update and use it, whenever needed.
 * <br>
 * If no explicit framebuffer context information is set, then the server will behave as if the
 * appplication doesn't handle framebuffer blocking notifications.
 * <br>
 * Calling this will reset any previous information on the framebuffer context information, so
 * the application must ensure to always include all the context information each time it
 * invokes this call.
 */
public class FramebufferContentConfig {

    List<Bundle> mBundles=new ArrayList<Bundle>();
    boolean bHandleBlock=false;

    /**
     * Config constructor
     * @param bHandleBlock  Flag indicating whether the application will take care of the blocking
     * if the MirrorLink Client blocks the content.
     */
    public FramebufferContentConfig(boolean bHandleBlock)
    {
        bHandleBlock=bHandleBlock;
    }


    /**
     * Add a rectangles with their context information to the configuration. Any areas not
     * covered by the list will be treated as having the default context information. So if the list
     * is empty, then the server will just assume that the context information is the default one
     * for the whole application. Each element of the list is a Bundle with the fields defined in
     * {@link Defs.FramebufferAreaContent}. The ordering of the rectangles in the list is from back
     * to front. The application MUST provide for each item explicit rectangle information and the
     * explicit content category (none of the fileds should not be undefined). The coordinates of
     * each rectangle MUST be absolute screen coordinates.
     * @param X Horizontal offset of the upper left corner.
     * @param Y Vertical offset of the upper left corner.
     * @param W Width of the frame buffer
     * @param H Height of the frame buffer
     * @param nApplicationCategory  Category of the application
     * @param nContentCategory The category of the content.
     */
    public void AddConfig(int X,int Y,int W,int H,int nApplicationCategory, int nContentCategory)
    {
        Bundle rect=new Bundle();
        rect.putInt(Defs.Rect.X,X);
        rect.putInt(Defs.Rect.Y,Y);
        rect.putInt(Defs.Rect.WIDTH,W);

        rect.putInt(Defs.Rect.HEIGHT,H);
        Bundle config=new Bundle();
        config.putBundle(Defs.FramebufferAreaContent.RECT,rect);
        config.putInt(Defs.FramebufferAreaContent.APPLICATION_CATEGORY,nApplicationCategory);
        config.putInt(Defs.FramebufferAreaContent.CONTENT_CATEGORY,nContentCategory);

        mBundles.add(config);
    }

    /**
     * To return all the added frame buffer configuration as a list of {@link android.os.Bundle}
     * @return List<Bundle>  all then frame buffer config added to this object
     */
    public List<Bundle> toBundles()
    {
        return mBundles;
    }


    /**
     * Return indicating whether the application will take care of the blocking
     * @return boolean
     */
    public  boolean getHandleBlock() {
        return bHandleBlock;
    }



}
