package com.navinfo.mirrorlink;

import android.os.Bundle;

/**
 * Created by weihongying@navinfo.com on 2015/1/14.
 */
public interface IMirrorLinkServerCallback {
    public void onMirrorLinkServerCall(IMirrorLinkManager manager,String sCallbackType,Object... pms);
    //public void onMirrorLinkServerCall(IMirrorLinkManager manager,String sCallbackType);
    //public void onMirrorLinkServerCall(IMirrorLinkManager manager,String sCallbackType,Bundle pm);
}
